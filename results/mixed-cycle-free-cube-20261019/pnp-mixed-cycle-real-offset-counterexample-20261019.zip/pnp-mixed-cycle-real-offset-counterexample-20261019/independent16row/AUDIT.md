# Exact counterexample: four active mixed-parity cycles

19 October 2026. Independent audit and consecutive-column specialization of an exact algebraic construction. All work is local. No repository, PR, release, or external service was changed.

## Result and scope

**The arbitrary-distinct-real-offset extension to four active cycles with mixed flip parity is false.** There is a 16-row instance with:

- column exponents exactly `0,1,...,15`;
- pairwise distinct, positive, explicitly specified real algebraic row offsets;
- support consisting of four disjoint alternating cycles with 6, 3, 3, and 3 rows, and one forced edge;
- strictly positive cycle cost differences `(1,1,1,1)`;
- a complete target-cost-2 fiber containing exactly six permutations;
- an identically zero signed fiber polynomial.

This is a full polynomial cancellation, not merely cancellation of a leading coefficient. It **does not settle or refute the canonical row-offset case `a_i=i`**. The established theorem for at most three active cycles, and the four-active-cycle theorem with all flips odd, remain untouched.

The certificate is exact and computer-assisted: rational Sturm root isolation, polynomial arithmetic modulo an explicitly specified degree-51 polynomial, and directed rational interval inequalities. No numerical approximation is used as a premise.

## 1. Algebraic parameter

Let `z` be the unique real root in

`(-118854581049/10^12, -118854581048/10^12)`

of the degree-51 integer polynomial `G` in `parameter_polynomial.txt`. A compact independently reproducible definition of `G` is given below: it is the unique degree-51 factor of the discriminant, with respect to `u`, of the numerator of the rational polynomial `N_z(u)`.

Define

```
d = 1/(1-9z^3)
q = (1-3z^2)d
k = 3q^3/(2d)
a = (-9q-2k+2d)/4
b = 4k+2+4a-a^2-d
c = k^2+2k-d(2k-a^2)
h = -dk^2
N_z(u) = 3u^3 + bu^2 + cu + h.
```

Define the repeated and simple roots by rational expressions

```
p = (27h-bc)/(2(b^2-9c))
s = -b/3-2p.
```

The exact certificate verifies the denominator is nonzero and

`N_z(u) = 3(u-p)^2(u-s)`.

Certified strict rational enclosures include:

| Quantity | Lower bound | Upper bound |
|---|---:|---:|
| d | 0.98511 | 0.98512 |
| q | 0.94336 | 0.94337 |
| k | 1.27833 | 1.27834 |
| a | -2.26919 | -2.26918 |
| p | 1.14494 | 1.14496 |
| s | 0.40933 | 0.40935 |
| a²−4k | 0.03585 | 0.03586 |

In particular, all square roots used below are real and nonzero. Write

`rho_minus = (-a-sqrt(a²-4k))/2`,
`rho_plus = (-a+sqrt(a²-4k))/2`.

These lie respectively in `(1.0398,1.0400)` and `(1.2292,1.2294)`.

## 2. Exact six-term rational identity

Let

```
r2(t) = (t^2+a t+k)/(t-1)^2
r3(t) = (t^2-a t+k)/(t+1)^2
r4(t) = t^2/(t^2-d)
r1(t) = (t^2-p)^2(t^2-s)/(t^2-q)^3.
```

Taking the common denominator `(t-1)^2(t+1)^2(t^2-d)`, direct symbolic expansion gives

```
r2+r3+r4 = 3(t^2-q)^3 / [(t-1)^2(t+1)^2(t^2-d)]
r2r3+r2r4+r3r4 = N_z(t^2) / [(t-1)^2(t+1)^2(t^2-d)].
```

The factorization from Section 1 therefore proves the exact rational identity

`r2r3+r2r4+r3r4 - r1r2-r1r3-r1r4 = 0`.

## 3. Genuine cycle realization

Use the following row-root order. The actual row offset corresponding to a root `rho` is `3-rho`, so the corresponding linear factor is `(L+3)-rho`. Put `t=L+3`.

| Component | Ordered row roots | Ordered baseline exponents |
|---|---|---|
| Cycle 1 | `sqrt(s), -sqrt(s), sqrt(p), -sqrt(p), sqrt(q), -sqrt(q)` | `0,1,2,4,6,3` |
| Cycle 2 | `rho_minus, rho_plus, 1` | `7,8,9` |
| Cycle 3 | `-rho_minus, -rho_plus, -1` | `10,11,12` |
| Cycle 4 | `0, sqrt(d), -sqrt(d)` | `13,15,14` |
| Forced row | `2` | `5` |

For each cycle, its A-matching assigns the listed exponents to the listed rows. Its B-matching assigns each row the next exponent in that same cyclic list. The divisor differences `B−A` are thus

```
Cycle 1: (1,1,2,2,-3,-3)
Cycle 2: (1,1,-2)
Cycle 3: (1,1,-2)
Cycle 4: (2,-1,-1).
```

They produce exactly `r1,r2,r3,r4` as the ratios of the unsigned B-products to the A-products. Each list is one actual cycle on distinct exponents; no arbitrary divisor has been substituted for a permutation cycle.

All exponents together, including the forced exponent 5, are exactly `0,...,15`. The interval certificate checks every pair of the sixteen row roots is distinct. The maximum row root is the forced root 2; consequently every offset `3-rho` is positive.

A cycle with `m` rows changes the permutation sign by `(-1)^(m-1)`, so these four flips have signs

`(-1,+1,+1,+1)`.

## 4. Complete additive-cost fiber

Label columns by their exponents `0,...,15`. Include precisely the A and B edges of each cycle and the forced edge. Every supported edge has cost 0, except the first B edge of each cycle, which has cost 1. Every unsupported edge has cost 100.

The target is 2. Because every edge cost is nonnegative, no target-2 permutation can use an unsupported edge. Each supported cycle has exactly two local perfect matchings. Choosing B instead of A increases total cost by 1. Hence the entire target-2 fiber consists of the six choices selecting exactly two B-matchings.

The independent backtracking verifier constructs this 16-by-16 cost matrix and enumerates actual supported perfect matchings, not just cube labels. It finds exactly 16 supported perfect matchings, with cost counts

`cost 0: 1; cost 1: 4; cost 2: 6; cost 3: 4; cost 4: 1`.

The matrix and actual six permutations are saved as `cost_matrix.json` and `complete_fiber.json`.

Let `sigma` be the sign of the A-baseline permutation, `H` the forced-row factor, and `A_j` the unsigned A-product of cycle j. The full target-2 polynomial is

```
sigma H A1 A2 A3 A4
  * (r2r3+r2r4+r3r4-r1r2-r1r3-r1r4).
```

The bracket is identically zero by Section 2. Multiplication clears denominators because these are genuine local matching ratios. Thus the original signed permutation sum is the zero polynomial.

## 5. Verification and failure conditions

Run:

```
python verify_counterexample.py
python -O verify_counterexample.py
python verify_negative_controls.py
```

All checks use explicit exceptions and remain active under optimized Python. The certificate independently:

1. Derives the common-denominator expressions from the three input ratios.
2. Verifies the cube denominator identity exactly in rational functions of z.
3. Derives the degree-51 discriminant factor and isolates the chosen root by a rational Sturm count.
4. Checks all relevant denominator inverses and the cubic factorization coefficient by coefficient modulo G.
5. Proves all required inequalities using directed rational interval arithmetic, including all row-root separations.
6. Checks the genuine cyclic exponent differences and exact exponent set `0,...,15`.
7. Builds the cost matrix and enumerates the 16 supported matchings and the complete six-term target fiber.

Suspend the conclusion if the parameter interval fails isolation, a modular denominator ceases to be invertible, a certified root interval overlaps another, the cyclic assignments fail, the support admits any other perfect matching, or the exact rational identity fails. None of those failures occurs in either recorded verification mode.

This is a counterexample to the proposed stronger real-offset theorem. It is not a P-versus-NP result, proof-assistant formalization, or a claim about the still-unresolved consecutive row offsets.

## 6. Recorded mutation checks

All four deliberately invalid variants are rejected at their intended checks:

- Replace the denominator cube coefficient 3 by 4: exact algebraic identity fails.
- Replace the isolating interval by (1,2): the rational root-isolation check fails.
- Change the first B-edge cost from 1 to 2 on every cycle: the enumerated cost distribution fails.
- Alter the six-cycle baseline exponent order: the cyclic divisor multiplicity check fails.

`NEGATIVE_CONTROLS.json` records these outcomes. `ENVIRONMENT.json` records Python and SymPy versions. `SHA256SUMS` covers the deliverable files. The full cost matrix contains only the nonnegative integers 0, 1, and 100.
