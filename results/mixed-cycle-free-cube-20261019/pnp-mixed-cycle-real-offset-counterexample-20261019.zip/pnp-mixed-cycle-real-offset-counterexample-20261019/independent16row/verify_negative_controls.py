#!/usr/bin/env python3
"""Reject four distinct single-fault mutations of the exact certificate."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
ROOT=Path(__file__).parent
source=(ROOT/'verify_counterexample.py').read_text()
cases=[
 ('algebra',"Q-3*(t*t-q)**3","Q-4*(t*t-q)**3",'e1 denominator identity failed'),
 ('parameter_interval',"lo=S.Rational(-118854581049,10**12)\nhi=S.Rational(-118854581048,10**12)","lo=S.Rational(1)\nhi=S.Rational(2)",'Parameter interval does not isolate exactly one real root'),
 ('edge_cost',"=1 if j==0 else 0","=2 if j==0 else 0",'Wrong complete supported cost distribution'),
 ('cycle_permutation',"[0,1,2,4,6,3],[1,1,2,2,-3,-3]","[0,1,2,4,3,6],[1,1,2,2,-3,-3]",'Cyclic divisor multiplicity mismatch'),
]
results=[]
for name,old,new,expected in cases:
    if source.count(old)!=1:raise RuntimeError('Mutation target not unique: '+name)
    with tempfile.TemporaryDirectory(prefix='four-cycle-negative-') as td:
        path=Path(td)/'verify_counterexample.py'
        path.write_text(source.replace(old,new))
        result=subprocess.run([sys.executable,str(path)],text=True,capture_output=True,timeout=120)
        passed=result.returncode!=0 and expected in result.stderr
        results.append({'fault':name,'rejected':passed,'returncode':result.returncode,'expected_failure':expected,'last_error_line':result.stderr.strip().splitlines()[-1] if result.stderr.strip() else ''})
        if not passed:raise RuntimeError('Negative control unexpectedly passed or failed at wrong check: '+name+'\n'+result.stdout+'\n'+result.stderr)
report={'status':'PASS','controls':results}
(ROOT/'NEGATIVE_CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
