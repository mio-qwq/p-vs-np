#!/usr/bin/env python3
"""Independent exact certificate for the 4-mixed-cycle algebraic-offset example.
All root isolation and interval inequalities are rational/exact, not floating point.
"""
from fractions import Fraction as F
import itertools
import json
from pathlib import Path
import sympy as S

OUT = Path(__file__).parent
z,u,t = S.symbols('z u t')
def require(test, message):
    if not test: raise RuntimeError(message)

# Independently derive the e1/e2 numerators directly from the three input ratios.
d = 1/(1-9*z**3)
q = (1-3*z**2)*d
k = 3*q**3/(2*d)
a = (-9*q-2*k+2*d)/4
U2=t*t+a*t+k; U3=t*t-a*t+k; U4=t*t
V2=(t-1)**2; V3=(t+1)**2; V4=t*t-d
Q=S.factor(U2*V3*V4 + U3*V2*V4 + U4*V2*V3)
N=S.factor(U2*U3*V4 + U2*U4*V3 + U3*U4*V2)
require(S.cancel(Q-3*(t*t-q)**3)==0, 'e1 denominator identity failed')
N_expected=3*u**3+(4*k+2+4*a-a*a-d)*u**2+(k*k+2*k-d*(2*k-a*a))*u-d*k*k
require(S.cancel(N-N_expected.subs(u,t*t))==0, 'e2 numerator identity failed')
Npoly=S.Poly(S.cancel(N_expected).as_numer_denom()[0],u)
Dnum=S.factor(S.discriminant(Npoly.as_expr(),u))
factors=S.factor_list(Dnum)[1]
Gs=[f for f,m in factors if S.degree(f,z)==51]
require(len(Gs)==1,'Unexpected discriminant factorization')
G=S.Poly(Gs[0],z)
lo=S.Rational(-118854581049,10**12)
hi=S.Rational(-118854581048,10**12)
require(G.count_roots(lo,hi)==1,'Parameter interval does not isolate exactly one real root')
require(G.eval(lo)*G.eval(hi)<0,'Parameter root not bracketed')
(OUT/'parameter_polynomial.txt').write_text(str(G.as_expr())+'\n')

# The repeated-root formula is rational in the cubic coefficients; no numerical
# square root is used to identify or certify the double root.
b=4*k+2+4*a-a*a-d
c=k*k+2*k-d*(2*k-a*a)
h=-d*k*k
# Reduce coefficient fractions before multiplication; this avoids gigantic
# intermediate rational functions while checking every denominator algebraically.
def ring(expr):
    nn,dd=S.cancel(expr).as_numer_denom()
    nn=S.Poly(nn,z,domain=S.QQ).rem(G)
    dd=S.Poly(dd,z,domain=S.QQ).rem(G)
    require(S.gcd(dd,G).degree()==0,'Noninvertible coefficient denominator')
    return (nn*S.invert(dd,G)).rem(G)
def times(x,y): return (x*y).rem(G)
bm,cm,hm=[ring(v) for v in [b,c,h]]
H=(times(bm,bm)-9*cm).rem(G)
require(S.gcd(H,G).degree()==0,'Triple-root degeneration')
pm=(times(27*hm-times(bm,cm),S.invert(2*H,G))).rem(G)
sm=(-bm/3-2*pm).rem(G)
require((bm+3*(2*pm+sm)).rem(G).is_zero,'u^2 factor coefficient mismatch')
require((cm-3*(times(pm,pm)+2*times(pm,sm))).rem(G).is_zero,'u factor coefficient mismatch')
require((hm+3*times(times(pm,pm),sm)).rem(G).is_zero,'constant factor coefficient mismatch')

# Small exact rational interval arithmetic implementation, independent of
# SymPy's root approximations.
class I:
    def __init__(self,l,h=None): self.l=F(l); self.h=F(l if h is None else h)
    def __add__(self,o):
        o=cv(o); return I(self.l+o.l,self.h+o.h)
    __radd__=__add__
    def __neg__(self): return I(-self.h,-self.l)
    def __sub__(self,o): return self+-cv(o)
    def __rsub__(self,o): return cv(o)+-self
    def __mul__(self,o):
        o=cv(o); v=[self.l*o.l,self.l*o.h,self.h*o.l,self.h*o.h]; return I(min(v),max(v))
    __rmul__=__mul__
    def inv(self):
        require(not(self.l<=0<=self.h),'Interval division by possible zero')
        return I(1/self.h,1/self.l)
    def __truediv__(self,o): return self*cv(o).inv()
    def __rtruediv__(self,o): return cv(o)*self.inv()
    def __pow__(self,n):
        require(isinstance(n,int) and n>=0,'unsupported interval exponent')
        if n==0:return I(1)
        v=[self.l**n,self.h**n]
        return I(0 if n%2==0 and self.l<=0<=self.h else min(v),max(v))
    def inside(self,l,h): return F(l)<self.l and self.h<F(h)
    def decimal(self): return [float(self.l),float(self.h)]
def cv(o): return o if isinstance(o,I) else I(o)
zz=I(F(int(lo.p),int(lo.q)),F(int(hi.p),int(hi.q)))
dd=1/(1-9*zz**3); qq=(1-3*zz**2)*dd; kk=3*qq**3/(2*dd); aa=(-9*qq-2*kk+2*dd)/4
bb=4*kk+2+4*aa-aa*aa-dd
cc=kk*kk+2*kk-dd*(2*kk-aa*aa)
hh=-dd*kk*kk
pp=(27*hh-bb*cc)/(2*(bb*bb-9*cc))
ss=-bb/3-2*pp
Delta=aa*aa-4*kk
bounds={'d':(dd,'0.98511','0.98512'),'q':(qq,'0.94336','0.94337'),
        'k':(kk,'1.27833','1.27834'),'a':(aa,'-2.26919','-2.26918'),
        'p':(pp,'1.14494','1.14496'),'s':(ss,'0.40933','0.40935'),
        'quadratic_discriminant':(Delta,'0.03585','0.03586')}
for name,(interval,l,h) in bounds.items():require(interval.inside(l,h),'Failed enclosure '+name)
# Certified square-root bounds, verified by squaring rational endpoints.
def sqrt_bound(v,l,h):
    l=F(l);h=F(h)
    require(0<=l and l*l<v.l and v.h<h*h,'Failed exact square root enclosure')
    return I(l,h)
sp=sqrt_bound(pp,'1.0700','1.0701')
ssq=sqrt_bound(ss,'0.6397','0.6399')
sq=sqrt_bound(qq,'0.9712','0.9714')
sd=sqrt_bound(dd,'0.9925','0.9926')
sDel=sqrt_bound(Delta,'0.1893','0.1894')
rho1=(-aa-sDel)/2; rho2=(-aa+sDel)/2
require(rho1.inside('1.0398','1.0400'),'First quadratic root bound failed')
require(rho2.inside('1.2292','1.2294'),'Second quadratic root bound failed')
# Exact disjoint intervals for every one of the 15 active roots and forced root.
root_intervals=[ssq,-ssq,sp,-sp,sq,-sq,rho1,rho2,I(1),-rho1,-rho2,I(-1),I(0),sd,-sd,I(2)]
for i,j in itertools.combinations(range(16),2):
    x,y=root_intervals[i],root_intervals[j]
    require(x.h<y.l or y.h<x.l,'Root supports are not certified disjoint')

# Realize each divisor by ONE cycle on pairwise distinct exponents. The actual
# row offsets may be a_i=3-root_i, so they are positive as well as distinct.
cycles=[([0,1,2,4,6,3],[1,1,2,2,-3,-3]),
        ([7,8,9],[1,1,-2]),([10,11,12],[1,1,-2]),
        ([13,15,14],[2,-1,-1])]
all_e=[]; eps=[]
for exponents,diffs in cycles:
    require(len(set(exponents))==len(exponents),'Repeated cycle exponent')
    got=[exponents[(i+1)%len(exponents)]-exponents[i] for i in range(len(exponents))]
    require(got==diffs,'Cyclic divisor multiplicity mismatch')
    all_e+=exponents;eps.append((-1)**(len(exponents)-1))
all_e.append(5)
require(sorted(all_e)==list(range(16)),'Exponents are not exactly 0,...,15')
require(eps==[-1,1,1,1],'Wrong mixed parity character')

# Full complete additive cost fiber: unsupported edges cost 100, all supported
# A/B edges cost 0, except the first B edge on each cycle, which costs 1.
# Since the target is 2 and all costs are nonnegative, unsupported edges cannot
# occur in the fiber. Enumerate every supported perfect matching independently.
cost=[[100]*16 for _ in range(16)]
row=0
for exponents,_ in cycles:
    m=len(exponents)
    for j,e in enumerate(exponents):
        cost[row+j][e]=0
        cost[row+j][exponents[(j+1)%m]]=1 if j==0 else 0
    row+=m
cost[15][5]=0
perms=[]
all_supported=[]
def rec(i,used,perm,co):
    if i==16:
        all_supported.append((tuple(perm),co))
        if co==2:perms.append(tuple(perm))
        return
    for j in range(16):
        if j not in used and cost[i][j]<100:
            rec(i+1,used|{j},perm+[j],co+cost[i][j])
rec(0,set(),[],0)
require(len(all_supported)==16,'Support does not have exactly sixteen perfect matchings')
require(sorted(co for _,co in all_supported)==[0]+[1]*4+[2]*6+[3]*4+[4], 'Wrong complete supported cost distribution')
require(len(perms)==6,'Complete fiber is not exactly six matchings')
base=all_e
for perm in perms:
    choices=[];pos=0
    for exponents,_ in cycles:
        m=len(exponents); local=list(perm[pos:pos+m]);pos+=m
        if local==exponents:choices.append(0)
        elif local==exponents[1:]+exponents[:1]:choices.append(1)
        else:raise RuntimeError('Non-cycle local matching')
    require(sum(choices)==2,'Unexpected cost fiber vertex')
(OUT/'cost_matrix.json').write_text(json.dumps(cost,indent=2)+'\n')
(OUT/'complete_fiber.json').write_text(json.dumps(perms,indent=2)+'\n')
report={'status':'PASS','parameter_interval':[str(lo),str(hi)],'parameter_degree':51,
        'exact_symbolic_identities':True,'exact_root_interval_certificates':True,
        'bounds':{n:[l,h] for n,(_,l,h) in bounds.items()},
        'cycle_lengths':[6,3,3,3],'forced_rows':1,'column_exponents':list(range(16)),
        'supported_perfect_matchings':len(all_supported),'fiber_size':len(perms),'cost_target':2,'mixed_flip_parity':eps,
        'conclusion':'The complete six-term polynomial fiber is identically zero for the certified distinct algebraic row offsets.'}
(OUT/'VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
