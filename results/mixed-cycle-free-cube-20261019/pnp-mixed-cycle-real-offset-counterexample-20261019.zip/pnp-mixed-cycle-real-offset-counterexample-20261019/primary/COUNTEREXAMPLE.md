# Exact cancellation with four mixed-parity independent cycles

19 October 2026. This is a local exact algebraic counterexample to extending the arbitrary-distinct-real-offset noncancellation theorem from three active cycles to four active cycles of unrestricted flip parity. It is not a counterexample with canonical row offsets a_i=i, not a P-versus-NP result, and not a general classification. No repository, PR, release, or external service was changed.

## 1. Result

There are 15 distinct real row roots and 15 distinct nonnegative integer column exponents, with supported graph the disjoint union of alternating cycles on 6, 3, 3, and 3 rows, such that:

- the four local matching cost differences are all 1;
- the complete cost-two fiber consists of all six choices of two switched cycles;
- its signed matching polynomial is identically zero.

Adding one forced edge gives a 16-row counterexample with the full consecutive column exponent set {0,...,15}. The row roots remain noncanonical algebraic real numbers.

The result does not contradict Theorem A (at most three active cycles) or Theorem B (at most four active cycles, all local flips odd). It closes the proposed extension without the flip-parity hypothesis in the arbitrary-real-offset model.

## 2. Exact parameter, without decimal assumptions

Use a formal variable z, and define rational functions

    h = 1 - 9z^3
    d = 1/h
    q = (1 - 3z^2)/h
    k = 3q^3/(2d)
    a = (-9q - 2k + 2d)/4.

In an auxiliary variable u, put

    N(u) = 3u^3 + B u^2 + C u + E
    B = 4k + 2 + 4a - a^2 - d
    C = k^2 + 2k - d(2k - a^2)
    E = -d k^2.

The denominator-cleared polynomial Nhat(u,z) = 16h^5 N(u) lies in Z[u,z]. Its discriminant with respect to u has exactly one irreducible factor F(z) of degree 51 over Q. Define z to be the unique real root of F in

    -118854581048529 / 10^15 < z < -118854581048528 / 10^15.

This defines a specific real algebraic number. The verifier computes F exactly, uses Sturm root counting to establish uniqueness in this rational interval, and records every coefficient of F in CERTIFICATE.json. No floating-point value defines the example.

Let

    H = B^2 - 9C
    p = (27E - BC)/(2H)
    r = -B/3 - 2p.

Exact arithmetic modulo F establishes

    N(u) = 3(u-p)^2(u-r).

Rational interval arithmetic establishes H>0, p>0, r>0, d>0, q>0, and a^2-4k>0. For orientation only, the values are approximately

    z = -0.1188545810485284
    d = 0.9851140417856716
    q = 0.9433656629880820
    a = -2.2691836085379378
    k = 1.2783357754151780
    p = 1.1449462448515415
    r = 0.4093407181415711.

The exact interval certificates, rather than these display decimals, prove all inequalities below.

## 3. The rational identity

Define four monic, equal-numerator/denominator-degree rational functions in t:

    r1(t) = (t^2-p)^2(t^2-r)/(t^2-q)^3
    r2(t) = (t^2+a t+k)/(t-1)^2
    r3(t) = (t^2-a t+k)/(t+1)^2
    r4(t) = t^2/(t^2-d).

A direct calculation with u=t^2 gives

    (r2 r3 + r2 r4 + r3 r4)/(r2+r3+r4) = N(u)/Q(u),

where

    Q(u) = 3u^3 + (2k+4a-2d)u^2
           + [2k-2d(k+1+2a)+1]u - 2dk.

The displayed parametrization gives the rational-function identity

    Q(u) = 3(u-q)^3

for every admissible formal z, before specializing to the root of F. Together with the exact factorization of N, this proves

    -r1 r2 - r1 r3 - r1 r4 + r2 r3 + r2 r4 + r3 r4 = 0.

Every zero and pole of every rj is real, and all four divisor supports are disjoint. To see the supports explicitly, put

    alpha = (-a - sqrt(a^2-4k))/2
    beta  = (-a + sqrt(a^2-4k))/2.

Their lists are:

    r1: zeros -sqrt(r), +sqrt(r) of order 1;
        zeros -sqrt(p), +sqrt(p) of order 2;
        poles -sqrt(q), +sqrt(q) of order 3.
    r2: zeros alpha,beta of order 1; pole 1 of order 2.
    r3: zeros -alpha,-beta of order 1; pole -1 of order 2.
    r4: zero 0 of order 2; poles -sqrt(d),+sqrt(d) of order 1.

The verifier encloses all fifteen real numbers in pairwise disjoint rational intervals. Thus there are no hidden cancellations within a ratio or overlaps between cycle row supports.

## 4. Actual single-cycle exponent realizations

Write each cycle's rows in the exact order given below. Assign baseline A-exponents in the second list, and let the B-matching assign the next exponent cyclically to each row. The difference B-exponent minus A-exponent is therefore the signed divisor multiplicity at that row.

Cycle 1:

    row roots: (-sqrt(r), +sqrt(r), -sqrt(p), +sqrt(p), -sqrt(q), +sqrt(q))
    A-exponents: (0,1,2,4,6,3)
    cyclic differences: (1,1,2,2,-3,-3)

Cycle 2:

    row roots: (alpha,beta,1)
    A-exponents: (10,11,12)
    cyclic differences: (1,1,-2)

Cycle 3:

    row roots: (-alpha,-beta,-1)
    A-exponents: (20,21,22)
    cyclic differences: (1,1,-2)

Cycle 4:

    row roots: (0,-sqrt(d),+sqrt(d))
    A-exponents: (30,32,31)
    cyclic differences: (2,-1,-1)

All fifteen exponents are distinct and nonnegative. Each displayed B permutation is one cycle, not a union of smaller cycles. For a row root rho, the translated-power factor is (t-rho)^e, which is the requested (t+a_i)^e form with offset a_i=-rho. Consequently B_j/A_j is exactly r_j.

The local flip signs are (-1,+1,+1,+1), since their row counts are (6,3,3,3).

## 5. Full supported graph, costs, and original polynomial

For each component, include precisely its A matching edges and cyclic B matching edges. A simple alternating cycle has exactly these two perfect matchings. Disjoint components therefore have exactly 2^4=16 perfect matchings.

Give every A edge cost 0. In each component give one B edge cost 1 and all its other B edges cost 0. The A and B edges are distinct, so this defines consistent edge costs. Each component's switch has cost difference exactly 1. The complete target-two fiber is exactly the six two-element subsets of the four components.

Order columns so that the baseline A matching is the identity. The full signed matching sum over this fiber is then

    A1 A2 A3 A4
    * [-r1 r2 - r1 r3 - r1 r4 + r2 r3 + r2 r4 + r3 r4],

which is the zero polynomial by Section 3. This is an exact identity of the original translated-power matching products: all A_j are nonzero polynomials and the cyclic exponent differences in Section 4 identify each quotient exactly. The proof does not equate arbitrary synthesized rational functions with cycles without checking exponent realizability.

## 6. Consecutive column exponents in dimension 16

Replace the exponent lists for cycles 2, 3, and 4 by

    (7,8,9), (10,11,12), (13,15,14).

Their cyclic differences, and hence all four ratios, are unchanged. Keep cycle 1 unchanged. Add one forced matching edge with exponent 5, cost 0, and row root 2. The rational interval certificates show that 2 differs from every preceding row root.

The sixteen column exponents are now exactly 0,...,15. The forced edge multiplies the fiber polynomial by (t-2)^5, preserving its vanishing. The six-match complete fiber is unchanged. Canonical column exponents alone therefore do not rescue noncancellation for arbitrary distinct real row offsets.

This does not specialize the row offsets to a_i=i. No claim about that original canonical-row model follows.

## 7. Reproduction and falsification checks

Run:

    python verify_counterexample.py
    python -O verify_counterexample.py CERTIFICATE_OPTIMIZED.json

The verifier uses explicit exceptions rather than Python assert statements, so optimized execution retains every check. It uses SymPy for exact rational polynomial algebra, Sturm counting, and modular inverses; interval endpoints are Python Fractions. Floating-point midpoints are output only for readability.

Reject the construction if any of the following fails: isolated parameter existence; numerator factorization modulo F; denominator-cube identity; positivity and root separation; genuine single-cycle exponent differences; disjoint global exponents; full cost-fiber enumeration; or the exact six-term identity. Numerical near-cancellation alone would not establish the result.
