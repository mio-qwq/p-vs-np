#!/usr/bin/env python3
"""Exact algebraic certificate for a 15-row mixed-cycle fiber cancellation.

No floating-point assertion is used. SymPy does rational polynomial arithmetic,
Sturm root counting, and modular arithmetic over the parameter polynomial.
Run with normal Python or python -O; checks remain active in both modes.
"""
from fractions import Fraction as F
from math import isqrt
import json
import sys
from pathlib import Path
import sympy as s

z,u=s.symbols('z u')

def require(ok, label):
    if not ok:
        raise RuntimeError('FAILED: '+label)

# A compact exact specification is preferable to listing 52 large coefficients.
d=1/(1-9*z**3)
q=(1-3*z**2)*d
k=3*q**3/(2*d)
a=(-9*q-2*k+2*d)/4
B=s.cancel(4*k+2+4*a-a*a-d)
C=s.cancel(k*k+2*k-d*(2*k-a*a))
E=s.cancel(-d*k*k)
N=3*u**3+B*u*u+C*u+E
Q=3*u**3+(2*k+4*a-2*d)*u*u+(2*k-2*d*(k+1+2*a)+1)*u-2*d*k
require(s.cancel(Q-3*(u-q)**3)==0,'symbolic cube denominator')
Nclear=s.cancel(16*(1-9*z**3)**5*N)
require(s.denom(Nclear)==1,'polynomial denominator clearing')
D=s.discriminant(Nclear,u)
fac=s.factor_list(D)[1]
Fs=[f for f,m in fac if s.degree(f,z)==51]
require(len(Fs)==1,'unique degree-51 discriminant factor')
f=s.Poly(Fs[0],z,domain=s.QQ).monic()
lo=s.Rational(-118854581048529,10**15)
hi=s.Rational(-118854581048528,10**15)
require(f.count_roots(lo,hi)==1,'unique parameter root in isolating interval')
require(f.eval(lo)!=0 and f.eval(hi)!=0,'strict parameter isolation')

# Modular checks over Q[z]/(f), with every denominator explicitly invertible.
def mod(expr):
    num,den=s.cancel(expr).as_numer_denom()
    nn=s.Poly(num,z,domain=s.QQ).rem(f)
    dd=s.Poly(den,z,domain=s.QQ).rem(f)
    require(s.gcd(dd,f).degree()==0,'invertible modular denominator')
    return (nn*s.invert(dd,f)).rem(f)
def mul(x,y): return (x*y).rem(f)
Bm,Cm,Em=map(mod,(B,C,E))
H=(Bm*Bm-9*Cm).rem(f)
require(s.gcd(H,f).degree()==0,'nontriple discriminant root')
pm=((27*Em-Bm*Cm)*s.invert(2*H,f)).rem(f)
rm=(-Bm/3-2*pm).rem(f)
require((Bm+3*(2*pm+rm)).rem(f).is_zero,'factor coefficient u^2')
require((Cm-3*(mul(pm,pm)+2*mul(pm,rm))).rem(f).is_zero,'factor coefficient u')
require((Em+3*mul(mul(pm,pm),rm)).rem(f).is_zero,'factor constant')
p=s.cancel((27*E-B*C)/(2*(B*B-9*C)))
r=s.cancel(-B/3-2*p)

# Directed interval arithmetic on exact rational endpoints.
class I:
    def __init__(self,l,h=None):
        self.l=F(l); self.h=F(l if h is None else h)
        require(self.l<=self.h,'ordered interval')
    @staticmethod
    def box(x): return x if isinstance(x,I) else I(x)
    def __add__(self,x):
        x=self.box(x);return I(self.l+x.l,self.h+x.h)
    __radd__=__add__
    def __neg__(self):return I(-self.h,-self.l)
    def __sub__(self,x):return self+-self.box(x)
    def __rsub__(self,x):return self.box(x)+-self
    def __mul__(self,x):
        x=self.box(x);vs=[self.l*x.l,self.l*x.h,self.h*x.l,self.h*x.h]
        return I(min(vs),max(vs))
    __rmul__=__mul__
    def __truediv__(self,x):
        x=self.box(x);require(x.l>0 or x.h<0,'interval denominator excludes zero')
        return self*I(1/x.h,1/x.l)
    def __rtruediv__(self,x):return self.box(x)/self
    def __pow__(self,n):
        require(isinstance(n,int) and n>=0,'nonnegative interval power')
        out=I(1)
        for _ in range(n):out=out*self
        return out
    def positive(self):return self.l>0
    def sqrt(self):
        require(self.l>=0,'nonnegative square root interval')
        scale=10**15
        lower=isqrt((self.l.numerator*scale*scale)//self.l.denominator)
        upper=isqrt((self.h.numerator*scale*scale)//self.h.denominator)+1
        out=I(F(lower,scale),F(upper,scale))
        require(out.l*out.l<=self.l and out.h*out.h>=self.h,'square root containment')
        return out
    def record(self):return {'lower':str(self.l),'upper':str(self.h),'midpoint':float((self.l+self.h)/2)}

Z=I(F(int(lo.p),int(lo.q)),F(int(hi.p),int(hi.q)))
def poly_eval(poly):
    out=I(0)
    for c in s.Poly(poly,z,domain=s.QQ).all_coeffs():
        out=out*Z+F(int(c.p),int(c.q))
    return out
def eval_expr(expr):
    num,den=s.cancel(expr).as_numer_denom()
    return poly_eval(num)/poly_eval(den)
# Evaluate the short expressions directly, retaining narrow enclosures.
DI=1/(1-9*Z**3); QI=(1-3*Z**2)*DI
KI=3*QI**3/(2*DI); AI=(-9*QI-2*KI+2*DI)/4
BI=4*KI+2+4*AI-AI*AI-DI
CI=KI*KI+2*KI-DI*(2*KI-AI*AI)
EI=-DI*KI*KI
HI=BI*BI-9*CI
require(HI.positive(),'positive nontriple quantity')
PI=(27*EI-BI*CI)/(2*HI); RI=-BI/3-2*PI
DELTA=AI*AI-4*KI
for name,val in [('d',DI),('q',QI),('k',KI),('p',PI),('r',RI),('source discriminant',DELTA)]:
    require(val.positive(),'positive '+name)
alpha=(-AI-DELTA.sqrt())/2; beta=(-AI+DELTA.sqrt())/2
sqrtp,sqrtr,sqrtq,sqrtd=PI.sqrt(),RI.sqrt(),QI.sqrt(),DI.sqrt()
roots=[
 ('c1 zero simple minus',-sqrtr,1),('c1 zero simple plus',sqrtr,1),
 ('c1 zero double minus',-sqrtp,2),('c1 zero double plus',sqrtp,2),
 ('c1 pole triple minus',-sqrtq,-3),('c1 pole triple plus',sqrtq,-3),
 ('c2 zero alpha',alpha,1),('c2 zero beta',beta,1),('c2 pole',I(1),-2),
 ('c3 zero minus alpha',-alpha,1),('c3 zero minus beta',-beta,1),('c3 pole',I(-1),-2),
 ('c4 zero',I(0),2),('c4 pole minus',-sqrtd,-1),('c4 pole plus',sqrtd,-1)]
ordered=sorted(roots,key=lambda x:x[1].l)
for left,right in zip(ordered,ordered[1:]):
    require(left[1].h<right[1].l,'disjoint row roots: '+left[0]+' / '+right[0])

# The baseline exponent at each row; B sends the next listed exponent to it.
cycle_exponents=[[0,1,2,4,6,3],[10,11,12],[20,21,22],[30,32,31]]
cycle_steps=[[1,1,2,2,-3,-3],[1,1,-2],[1,1,-2],[2,-1,-1]]
all_exp=sum(cycle_exponents,[])
require(len(all_exp)==len(set(all_exp))==15,'globally distinct nonnegative exponents')
for es,ds in zip(cycle_exponents,cycle_steps):
    require(all(x>=0 for x in es),'nonnegative exponents')
    require([es[(i+1)%len(es)]-es[i] for i in range(len(es))]==ds,'exact cycle exponent differences')
require([(-1)**(len(es)-1) for es in cycle_exponents]==[-1,1,1,1],'mixed cycle sign')

# Independently enumerate perfect matchings of the actual degree-two graph.
lengths=list(map(len,cycle_exponents))
edges=[]; begin=0
for length in lengths:
    for local in range(length):
        edges.append([(begin+local,0),(begin+(local+1)%length,int(local==0))])
    begin+=length
matchings=[]
def enumerate_matchings(row,used,permutation,cost):
    if row==len(edges):
        inversions=sum(permutation[i]>permutation[j] for i in range(len(edges)) for j in range(i+1,len(edges)))
        matchings.append({'permutation':permutation,'cost':cost,'sign':(-1)**inversions})
        return
    for column,price in edges[row]:
        if column not in used:
            enumerate_matchings(row+1,used|{column},permutation+[column],cost+price)
enumerate_matchings(0,set(),[],0)
require(len(matchings)==16,'exactly sixteen supported perfect matchings')
fiber=[m for m in matchings if m['cost']==2]
require(len(fiber)==6,'exactly six full target-two matchings')
fiber_masks=[]
for matching in fiber:
    pos=0; mask=[]
    for length in lengths:
        block=matching['permutation'][pos:pos+length]
        av=[pos+i for i in range(length)]
        bv=[pos+(i+1)%length for i in range(length)]
        require(block==av or block==bv,'each matching uses a complete local orientation')
        mask.append(int(block==bv)); pos+=length
    require(sum(mask)==2,'target equals number of switched cycles')
    require(matching['sign']==(-1)**mask[0],'actual permutation sign agrees with mixed local character')
    fiber_masks.append(mask)
require(len(set(map(tuple,fiber_masks)))==6,'all six pairs occur once')


# The six complete target-two choices; symbolic factor identity already proved
# N/3=(u-p)^2(u-r), Q/3=(u-q)^3, and N/Q=e2/e1.
t=s.symbols('t')
r2=(t*t+a*t+k)/(t-1)**2
r3=(t*t-a*t+k)/(t+1)**2
r4=t*t/(t*t-d)
raw=s.cancel((r2*r3+r2*r4+r3*r4)/(r2+r3+r4))
require(s.cancel(raw-N.subs(u,t*t)/Q.subs(u,t*t))==0,'raw six-term identity')
canonical_cycles=[[0,1,2,4,6,3],[7,8,9],[10,11,12],[13,15,14]]
canonical_exponents=sum(canonical_cycles,[])+[5]
require(sorted(canonical_exponents)==list(range(16)),'canonical sixteen-column exponent set')
for es,ds in zip(canonical_cycles,cycle_steps):
    require([es[(i+1)%len(es)]-es[i] for i in range(len(es))]==ds,'canonical cycle exponent differences')
require(all(val.h<F(2) or val.l>F(2) for _,val,_ in roots),'fresh forced row root two')

# Exact original polynomial coefficient identity is obtained after multiplying
# the rational identity by the nonzero baseline product A1 A2 A3 A4.
report={
 'status':'PASS', 'arithmetic':'Exact rational, Sturm, and modular algebra; numeric midpoints are display only.',
 'scope':'Arbitrary distinct real row roots and distinct nonnegative integer column exponents. Not canonical a_i=i.',
 'parameter':{'polynomial_degree':f.degree(),'polynomial_coefficients':[str(v) for v in f.all_coeffs()], 'isolating_interval':[str(lo),str(hi)],'root_count':1},
 'quantities':{name:val.record() for name,val in [('d',DI),('q',QI),('a',AI),('k',KI),('p',PI),('r',RI),('r2_discriminant',DELTA)]},
 'ordered_row_roots':[{'name':name,'multiplicity_in_ratio':m,**val.record()} for name,val,m in ordered],
 'cycles':[{'exponents':es,'divisor_steps':ds,'flip_sign':(-1)**(len(es)-1)} for es,ds in zip(cycle_exponents,cycle_steps)],
 'canonical_columns_extension':{'rows':16,'cycle_exponents':canonical_cycles,'forced_exponent':5,'forced_row_root':2,'all_exponents':list(range(16)),'offsets_still_noncanonical':True},
 'fiber':{'positive_cost_differences':[1,1,1,1],'target':2,'number_of_matchings':6,'orientation_masks':fiber_masks,'matching_certificates':fiber,'signed_polynomial':'identically zero'},
 'checks':['cube denominator','unique isolated parameter','exact numerator factorization modulo parameter polynomial','positive real factor roots','all fifteen roots disjoint','four genuine cyclic exponent assignments','globally distinct nonnegative exponents','six-term rational identity and nonzero baseline clearing']}
output=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_name('CERTIFICATE.json'))
output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','output':str(output),'parameter_interval':report['parameter']['isolating_interval'],'rows':15,'fiber_size':6,'cycle_lengths':[6,3,3,3]},indent=2))
