#!/usr/bin/env python3
"""Replay both exact proofs and matching data, with optional mutation controls.
Uses disposable directories; never changes the packaged source or certificates.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
from fractions import Fraction
from collections import Counter
import argparse,hashlib,json,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent

def require(ok,msg):
    if not ok:raise RuntimeError(msg)

def run(source,optimized=False,change=None):
    with TemporaryDirectory(prefix='pnp-replay-') as td:
        folder=Path(td)
        text=(ROOT/source).read_text()
        if change:
            old,new=change
            require(text.count(old)==1,'Mutation anchor is not unique: '+old)
            text=text.replace(old,new)
        script=folder/'verify_counterexample.py'
        script.write_text(text)
        command=[sys.executable]+(['-O'] if optimized else [])+['-B',str(script)]
        cp=subprocess.run(command,cwd=folder,text=True,capture_output=True)
        results={p.name:p.read_bytes() for p in folder.glob('*.json')}
        if (folder/'parameter_polynomial.txt').is_file():results['parameter_polynomial.txt']=(folder/'parameter_polynomial.txt').read_bytes()
        return cp,results

def compare(actual,expected):
    require(actual==expected,'Fresh output differs from packaged '+str(expected))

def validate_matching_artifacts(cost,perms):
    require(len(cost)==16 and all(len(row)==16 for row in cost),'Wrong cost dimensions')
    require(all(type(x) is int and x in (0,1,100) for row in cost for x in row),'Invalid costs')
    require(all(len(p)==16 and sorted(p)==list(range(16)) for p in perms),'Malformed permutation')
    require(len(perms)==6 and len(set(map(tuple,perms)))==6,'Wrong fiber size')
    matches=[]
    def visit(i,used,p,c):
        if i==16:
            matches.append((tuple(p),c));return
        for j,price in enumerate(cost[i]):
            if j not in used and price<100:visit(i+1,used|{j},p+[j],c+price)
    visit(0,set(),[],0)
    histogram=dict(sorted(Counter(c for _,c in matches).items()))
    require(histogram=={0:1,1:4,2:6,3:4,4:1},'Supported cost histogram mismatch')
    require(set(map(tuple,perms))=={p for p,c in matches if c==2},'Published permutations differ from full cost-two fiber')
    base=[0,1,2,4,6,3,7,8,9,10,11,12,13,15,14,5]
    def sign(p):return (-1)**sum(p[i]>p[j] for i in range(16) for j in range(i+1,16))
    blocks=[(0,6),(6,9),(9,12),(12,15)]
    for p in perms:
        choices=[]
        for i,j in blocks:
            aa=base[i:j];bb=aa[1:]+aa[:1];part=p[i:j]
            require(part==aa or part==bb,'Unexpected local matching')
            choices.append(int(part==bb))
        require(sum(choices)==2,'Wrong orientation cost')
        require(sign(p)==sign(base)*(-1)**choices[0],'Actual permutation sign mismatch')
    return {'supported_matchings':len(matches),'histogram':histogram,'fiber_size':len(perms),'baseline_sign':sign(base),'fiber_signs':[sign(p) for p in perms]}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--negative-controls',action='store_true')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    report={'status':'PASS','normal_and_optimized':[],'artifact_check':{},'negative_controls':[]}
    for variant in ['primary','independent16row']:
        previous=None
        for optimized in [False,True]:
            cp,data=run(variant+'/verify_counterexample.py',optimized)
            require(cp.returncode==0,variant+' replay failed: '+cp.stderr)
            expected=['CERTIFICATE.json'] if variant=='primary' else ['VERIFICATION.json','cost_matrix.json','complete_fiber.json','parameter_polynomial.txt']
            for name in expected:
                require(name in data,'Missing replay output '+name)
                require(data[name]==(ROOT/variant/name).read_bytes(),'Replay output changed: '+variant+'/'+name)
            if previous is not None:require(previous==data,'Normal and optimized outputs differ')
            previous=data
            report['normal_and_optimized'].append({'verifier':variant,'mode':'optimized' if optimized else 'normal','status':'PASS','outputs_identical_to_packaged':True})
    cost=json.loads((ROOT/'independent16row/cost_matrix.json').read_text())
    perms=json.loads((ROOT/'independent16row/complete_fiber.json').read_text())
    report['artifact_check']=validate_matching_artifacts(cost,perms)
    # The primary isolating interval nests inside the independent interval;
    # both have a single root, and their normalized polynomial is identical.
    import sympy as s
    primary=json.loads((ROOT/'primary/CERTIFICATE.json').read_text())
    independent=json.loads((ROOT/'independent16row/VERIFICATION.json').read_text())
    z=s.Symbol('z')
    gp=s.Poly(s.sympify((ROOT/'independent16row/parameter_polynomial.txt').read_text()),z).monic()
    require([str(x) for x in gp.all_coeffs()]==primary['parameter']['polynomial_coefficients'],'Parameter polynomials differ')
    al,ah=map(Fraction,primary['parameter']['isolating_interval']);bl,bh=map(Fraction,independent['parameter_interval'])
    require(bl<al<ah<bh,'Root isolating intervals do not nest')
    report['same_algebraic_parameter']=True
    if args.negative_controls:
        mutations=[
          ('algebra','primary/verify_counterexample.py',('q=(1-3*z**2)*d','q=(1-4*z**2)*d'),'symbolic cube denominator'),
          ('root_interval','primary/verify_counterexample.py',('hi=s.Rational(-118854581048528,10**15)','hi=s.Rational(-118854581048529,10**15)'),'unique parameter root in isolating interval'),
          ('cost','independent16row/verify_counterexample.py',('cost[row+j][exponents[(j+1)%m]]=1 if j==0 else 0','cost[row+j][exponents[(j+1)%m]]=2 if j==0 else 0'),'Wrong complete supported cost distribution'),
          ('permutation','independent16row/verify_counterexample.py',('rec(0,set(),[],0)','rec(0,set(),[],0)\nperms[0]=tuple([0]*16)'),'Non-cycle local matching')]
        for name,source,change,expected_error in mutations:
            for optimized in [False,True]:
                cp,_=run(source,optimized,change)
                require(cp.returncode!=0,'Mutation was accepted: '+name)
                require(expected_error in cp.stderr,'Mutation failed for unexpected reason: '+name+' '+cp.stderr)
                report['negative_controls'].append({'mutation':name,'mode':'optimized' if optimized else 'normal','status':'REJECTED','expected_error':expected_error})
        # Data-only mutation controls exercise the serialized deliverables too.
        for name,mutcost,mutperms in [('serialized_cost',json.loads(json.dumps(cost)),json.loads(json.dumps(perms))),('serialized_permutation',json.loads(json.dumps(cost)),json.loads(json.dumps(perms)))]:
            if name=='serialized_cost':mutcost[0][1]=2
            else:mutperms[0][0]=mutperms[0][1]
            try:validate_matching_artifacts(mutcost,mutperms)
            except RuntimeError as exc:report['negative_controls'].append({'mutation':name,'status':'REJECTED','error':str(exc)})
            else:raise RuntimeError('Serialized mutation accepted: '+name)
    out=json.dumps(report,indent=2,sort_keys=True)+'\n'
    if args.output:args.output.write_text(out)
    print(out,end='')
if __name__=='__main__':main()
