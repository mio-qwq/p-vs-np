#!/usr/bin/env python3
"""Rebuild the byte-deterministic archive after checking MANIFEST.json."""
from pathlib import Path
import hashlib,json,sys,zipfile
ROOT=Path(__file__).resolve().parent
NAME='pnp-mixed-cycle-real-offset-counterexample-20261019'
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    expected={r['path'] for r in manifest['files']}|{'MANIFEST.json'}
    for row in manifest['files']:
        path=ROOT/row['path']
        require(path.is_file(),'Missing '+row['path'])
        require(path.stat().st_size==row['bytes'],'Size mismatch '+row['path'])
        require(digest(path)==row['sha256'],'SHA-256 mismatch '+row['path'])
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/(NAME+'.zip')
    require(not dest.is_relative_to(ROOT),'Write the archive outside the extracted package directory')
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_STORED) as z:
        for rel in sorted(expected):
            info=zipfile.ZipInfo(NAME+'/'+rel,date_time=(2026,10,19,0,0,0))
            info.compress_type=zipfile.ZIP_STORED
            info.create_system=3
            info.external_attr=0o100644<<16
            z.writestr(info,(ROOT/rel).read_bytes())
    print(json.dumps({'archive':str(dest),'bytes':dest.stat().st_size,'sha256':digest(dest),'files':len(expected)},indent=2))
if __name__=='__main__':main()
