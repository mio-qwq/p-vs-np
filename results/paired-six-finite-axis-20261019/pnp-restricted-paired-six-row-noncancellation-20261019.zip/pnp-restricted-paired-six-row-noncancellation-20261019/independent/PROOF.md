# Reflected-pair constraints and an independent six-row complete-fiber audit

19 October 2026. Exact finite mathematics, with a standalone independent implementation. No repository, merge, release, or external publication was changed. This is neither a P-versus-NP result nor an unrestricted six-row theorem.

## 1. Audited theorem and precise scope

Let rows and columns be numbered 0 through 5, and let

    f_p(L) = sgn(p) product_i (L+i)^p(i).

Suppose a bipartite support graph is invariant under each of the three row swaps `(0,5)`, `(1,4)`, `(2,3)`. Suppose supported edge costs satisfy

    w(i,j) = w(5-i,j).

For any real t, let F be the entire set of supported perfect matchings of total cost t.

**Restricted six-row theorem.** If F is nonempty, then `sum_(p in F) f_p(L)` is not identically zero.

The same conclusion holds if the differences `w(i,j)-w(5-i,j)` are constant in j for each row pair: subtracting row constants puts the costs in the displayed form and shifts every matching's cost by the same amount.

The costs may be arbitrary real numbers. Neither binary costs nor an exposed minimum-cost face is assumed. Pair-invariant support and pair-equal costs are actual restrictions. Arbitrary six-row supports or arbitrary six-row edge costs are not covered. In particular, mere row-swap invariance of a selected matching family does not justify the quotient affine-closure step below.

The primary independent implementation is `independent_audit.py`; its fresh ordinary and optimized-Python receipts are byte-identical. It reads no prior catalogue or primary-verifier data. The companion primary result is in `../six-row-fiber-search-20261019/`.

## 2. Row reversal and full pair orbits

For general n, put `N=n(n-1)/2` and `rho(i)=n-1-i`. Direct substitution gives

    f_p(-(n-1)-L) = f_(p composed with rho)(L).

Indeed, the factor `(-1)^N` from all powers is cancelled by the same reversal-permutation sign. There is no extra sign in odd total degree. A reversal-stable family therefore has an even polynomial in the centered variable.

For even n=2m, set `U=2L+2m-1` and `g_p(U)=2^N f_p((U-(2m-1))/2)`. Pair the rows by reflection and order the pairs by increasing positive radii `a=1,3,...,2m-1`. An allocation assigns an unordered two-column set to each row pair. For a pair assigned columns `u<v`, the sum over its two orientations contains the determinant

    D_uv(U;a) = (U-a)^u (U+a)^v - (U-a)^v (U+a)^u
              = (U^2-a^2)^u ((U+a)^(v-u)-(U-a)^(v-u)).

The sum of the scaled terms g_p over all `2^m` orientations of an allocation is a fixed permutation sign times the product of these m factors. The original f_p sum has the additional nonzero constant factor `2^(-N)`. Each factor has degree `u+v-1`, with nonzero leading coefficient `2a(v-u)`. Thus each orbit polynomial has exact degree `N-m=2m(m-1)`, and is even. In n=6, the 90 allocation polynomials therefore have only seven potentially nonzero coefficients in `z=U^2`, through `z^6`.

The independent verifier constructs these polynomials by binomial convolution of the 2-by-2 determinants, then separately reconstructs each of them by summing its eight original permutation terms with repeated linear-factor multiplication. All 720 terms and all coefficients are checked.

## 3. Why these complete fibers are exactly affine-closed allocation families

An allocation has a 3-by-6 incidence matrix A with entries zero or one, row sums two, and column sums one. There are 90 such allocations. Pair-invariant support allows either all eight orientations of an allocation or none. Pair-equal costs give all eight the same cost

    sum_(r,j) w(r,j) A(r,j).

Thus an entire supported cost fiber is exactly a union of entire allocation orbits, and its set S of allocation incidence matrices is affine-closed among the 90 points. An allocation in the affine hull has zero entries on every edge absent from union(S), hence remains supported; its cost remains t, so completeness includes it.

Conversely, every nonempty affine-closed allocation family is a complete fiber for some real costs on the full pair-symmetric support. Choose a generic linear functional annihilating the span of its differences and avoiding the finitely many outside-point hyperplanes. This is the same finite-hyperplane argument used in the accepted five-row proof. Rational, hence scaled integer, costs can be chosen. This converse is not needed for exclusion.

The argument concerns arbitrary cost hyperplane fibers, not only minimum-cost faces. It does not infer that an arbitrary polynomial-zero subset or row-swap-stable family is a complete fiber.

## 4. Exact incidence arithmetic, independently changed

The audit uses the augmented 11-vector

    h_A = (1, A(r,j) for r in {1,2}, j in {1,2,3,4,5}).

These are lower-right coordinates in the increasing-radius row order, unlike the primary verifier's upper-left coordinates and opposite radius order. Row and column sums reconstruct all omitted entries.

Each vector has at most five entries equal to one. Every square minor of size at most 11 has absolute value at most `5^(11/2)`. The audit proves by integer comparison that

    5^11 = 48,828,125 < 10007^2 = 100,140,049,

and verifies by trial division that 10007 is prime. Consequently every rank and span test modulo 10007 equals its rational and real counterpart. Projective quotient-residue comparisons are also rank tests on the original incidence vectors, so the same bound covers them. Python integer arithmetic has no overflow issue.

## 5. Endpoint slice regeneration

For an allocation, let r be the smaller column assigned to the outer pair `(0,5)`. Its orbit polynomial has exact order r at original `L=0`, equivalently at `U=5`. The two other pair determinants are nonzero there, and the smaller endpoint exponent gives the unique lowest power of `L` inside the outer determinant.

If a complete fiber cancels, take the least r present. Its intersection with that r-slice is nonempty, scalar-balanced in the order-r Taylor coefficient, and affine-closed relative to that slice. The audit regenerates every balanced subset by Gray-code enumeration on the two sign sides, retaining duplicate sums and every membership mask.

| Minimum r | Slice size | Positive / negative | Nonempty scalar-zero subsets | Affine-closed subsets |
|---|---:|---:|---:|---:|
| 0 | 30 | 16 / 14 | 16,974 | 44 |
| 1 | 24 | 12 / 12 | 144 | 6 |
| 2 | 18 | 10 / 8 | 14 | 3 |
| 3 | 12 | 6 / 6 | 4 | 0 |
| 4 | 6 | 4 / 2 | 0 | 0 |

There are exactly 53 endpoint candidates. The final r=4 row is explicitly examined; it is not omitted by a presumed bound.

## 6. The independent center restriction

At `U=0`, a pair determinant is nonzero exactly when its two columns have opposite parity. Thus only 36 of the 90 allocations contribute at the center. A balanced allocation is represented by two permutations sigma,tau of `{0,1,2}`: row pair i gets even column `2 sigma(i)` and odd column `2 tau(i)+1`.

Put `s=(1,9,25)` and

    a_sigma = sgn(sigma) product_i s_i^sigma(i).

In lexicographic order of the six permutations, these values are

    (5625, -2025, -625, 81, 25, -9).

For the scaled original polynomial `g_p(U)=2^15 f_p((U-5)/2)`, the balanced allocation center value is exactly

    120 a_sigma a_tau.

The audit derives these same values from its independent polynomial construction. There are 18 positive and 18 negative terms. Complete sign-side Gray-code enumeration finds exactly 1,156 nonempty scalar-zero subsets. Precisely six are affine-closed relative to the 36 balanced allocations; each has six members. Their closures among all 90 allocations still have six members.

Any complete zero fiber must have as its balanced intersection either one of those six sets **or the empty set**. The empty case is explicitly included, with all 36 balanced allocations forbidden. This step uses only the fact that an intersection of an affine-closed family with a fixed point subset is relatively affine-closed; the balanced predicate need not define a face or affine slice.

The center table was first obtained independently of the primary endpoint search. Its data are preserved in `CENTER_CATALOGUE.json`; the final audit regenerates everything without reading that file.

## 7. Independent complete traversal

Pair each of the 53 endpoint candidates with all seven center choices. Prescribe all forbidden endpoint and balanced-center memberships. Reject inconsistent unions or unions whose affine closure meets a forbidden point. Exactly 12 closed cores remain.

At a closed current family C, group outside points by proportional nonzero residues modulo the span of its augmented incidence vectors. Each group B is exactly the new part of `cl(C union {q})` for any q in B. Every closed extension contains all or none of B. Discard groups meeting forbidden points.

A canonical least-point traversal visits every permitted closed extension: the next point is the least point of a target extension missing from the current set, and its whole quotient group is forced. Requiring successive chosen least indices to increase excludes duplicates without excluding that canonical path. The audit reverses the primary allocation order and independently verifies closure at every visited state.

For pruning, the audit uses all 13 U-Taylor coefficients at each of `U=0,-1,1,-3,3,-5,5`, and evaluations at `U=-9,-7,7,9`. These 95 scalar projections differ from the primary implementation's original-L projections. For each projection, the negative of the current sum must lie between the sum of all negative allowed-block contributions and the sum of all positive allowed-block contributions, and must be divisible by their gcd. Both conditions are necessary for a zero descendant. The audit checks all intervals before all gcds, a different order from the primary verifier.

Every visited family is directly checked in all seven z coefficients, with no preliminary-evaluation shortcut.

Independent exhaustive result:

| Quantity | Count |
|---|---:|
| Consistent cores | 12 |
| Closed-set states visited | 2,049 |
| Quotient blocks | 106,073 |
| Forbidden blocks | 74,810 |
| Canonically excluded blocks | 18,067 |
| Interval-pruned states | 1,844 |
| Gcd-pruned states | 80 |
| Expanded states | 125 |
| Polynomial-zero states | 0 |

The state accounting is exact: `1844+80+125=2049`. There is no time limit, node cutoff, solver dependency, or unexplored branch. The different count from the primary verifier's 818 states is expected from the changed point order and scalar constraints; both independently exhaust the same specified model.

## 8. Adversarial complete-fiber control

The audit exhaustively finds all six polynomial-zero triples of allocation orbits. Each triple is a 24-permutation polynomial-zero subset. Each forces a fourth allocation by affine closure, and the resulting four-allocation polynomial is nonzero. Thus the implementation encounters genuine polynomial identities while correctly rejecting them as incomplete fibers.

For example, in increasing-radius row-pair order, these three allocations have zero polynomial sum:

    ((3,5),(2,4),(0,1)),
    ((3,5),(1,4),(0,2)),
    ((3,4),(1,5),(0,2)).

The first plus the third minus the second incidence vector equals that of

    ((3,4),(2,5),(0,1)).

The forced fourth allocation is absent from the zero triple. Its seven z coefficients, and hence the polynomial of the full four-allocation closure, are

    (-87480, 252720, -227880, 41760, 27000, -6480, 360).

This is a specific check against confusing zero subsets with complete cost fibers.

## 9. Additional center certificates, including an eight-row class

For general even n=2m and reflection-symmetric constant-cost support, let `B_even` and `B_odd` be the m-by-m matrices

    B_even(i,k) = support(pair i, column 2k) (2i+1)^(2k),
    B_odd(i,k)  = support(pair i, column 2k+1) (2i+1)^(2k).

At the center `L=-(2m-1)/2`, paired row sums and differences give the exact factorization

    Q(center) = [2^m product_i(2i+1) / 2^N] det(B_even) det(B_odd).

For m=3, the six unsigned determinant terms are, in descending order,

    5625, 2025, 625, 81, 25, 9.

Each is larger than the sum of all following ones. Therefore every nonempty signed subset sum is nonzero. Each parity block is nonsingular exactly when its support has a perfect matching. This provides an immediate center test for many n=6 constant-cost supports, although the main theorem above also covers those for which this center test vanishes.

The audit also exhausts every 4-by-4 zero-one mask at squared radii `(1,9,25,49)`. Of all 65,536 masks, exactly 37,823 have a perfect matching; none has zero supported determinant. Consequently, for n=8 reflection-symmetric constant-cost support, **separate even-column and odd-column perfect matchings imply noncancellation**. This is a substantial but restricted eight-row class, not a complete n=8 exclusion or an arbitrary-cost result.

## 10. Reproduction and rejection conditions

Run:

    python independent_audit.py --output INDEPENDENT_RESULT.json
    PYTHONOPTIMIZE=1 python -O independent_audit.py --output INDEPENDENT_OPTIMIZED_RESULT.json

The two JSON receipts are byte-identical. All verifier checks use explicit exceptions rather than removable assertions.

Suspend the theorem if a balanced endpoint/center slice is omitted, a rank or quotient-block test is wrong, a compatible flat is missing from the canonical traversal, a scalar rejection is unsound, a pair polynomial disagrees with the direct 720-term reconstruction, or a zero visited state is found. Preserve the allocation memberships, forbidden set, current span, canonical last index, and disputed scalar arithmetic. The theorem remains restricted to the stated row-pair cost and support symmetry.
