#!/usr/bin/env python3
"""Independent exact audit: reflected-row-pair equal costs, canonical n=6.
No prior catalogue or polynomial data is loaded. Coordinates, prime, point
ordering, polynomial construction and scalar projections differ from the
primary implementation. Standard library only.
"""
import itertools as it, math, collections, json, argparse, pathlib, hashlib, time
MOD=10007
ROOT=pathlib.Path(__file__).resolve().parent

def require(ok,msg):
    if not ok: raise RuntimeError(msg)

def mul(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return out

def add(a,b):return [a[i]+b[i] for i in range(len(a))]
def parity(p):return (-1)**sum(x>y for i,x in enumerate(p) for y in p[i+1:])
def factor_power(a,k):return [math.comb(k,j)*a**(k-j) for j in range(k+1)]
def paired_factor(a,u,v):
    left=mul(factor_power(-a,u),factor_power(a,v))
    right=mul(factor_power(-a,v),factor_power(a,u))
    return [x-y for x,y in zip(left,right)]
def evalp(p,x):return sum(a*x**i for i,a in enumerate(p))
def taylor(p,x,k):return sum(math.comb(j,k)*p[j]*x**(j-k) for j in range(k,len(p)))

def badd(B,row):
    v=list(row)
    for k,b in B:
        z=v[k]
        if z:v=[(x-z*y)%MOD for x,y in zip(v,b)]
    k=next((k for k,z in enumerate(v) if z),None)
    if k is None:return B
    inv=pow(v[k],-1,MOD)
    v=tuple(z*inv%MOD for z in v)
    return tuple(sorted(B+((k,v),)))
def basis(rows):
    B=()
    for row in rows:B=badd(B,row)
    return B
def residual(B,row):
    v=list(row)
    for k,b in B:
        z=v[k]
        if z:v=[(x-z*y)%MOD for x,y in zip(v,b)]
    return tuple(v)
def inspan(B,row):return not any(residual(B,row))
def subset_sums(ids,values):
    # Gray code updates rather than primary's doubling construction.
    out=collections.defaultdict(list);old=0;s=0;m=0
    out[0].append(0)
    for q in range(1,1<<len(ids)):
        g=q^(q>>1);bit=g^old;k=bit.bit_length()-1;i=ids[k]
        if g&bit:s+=abs(values[i]);m|=1<<i
        else:s-=abs(values[i]);m^=1<<i
        out[s].append(m);old=g
    return out

def generate_data():
    require(all(MOD%d for d in range(2,math.isqrt(MOD)+1)),"modulus not prime")
    require(5**11<MOD**2,"Hadamard bound failed")
    keys=[]
    for x in it.combinations(range(6),2):
        rem=set(range(6))-set(x)
        for y in it.combinations(sorted(rem),2):
            keys.append((x,y,tuple(sorted(rem-set(y)))))
    keys=list(reversed(keys)) # Different canonical traversal order.
    H=[(1,)+tuple(int(c in key[r]) for r in (1,2) for c in range(1,6)) for key in keys]
    G=[]
    for key in keys:
        p=[parity(sum((list(pair) for pair in key),[]))]
        for a,(u,v) in zip((1,3,5),key):p=mul(p,paired_factor(a,u,v))
        p+= [0]*(16-len(p))
        require(all(p[k]==0 for k in (1,3,5,7,9,11,13,14,15)),"pair symmetry/degree violation")
        G.append(p)
    # Independent direct reconstruction from each of 720 original terms,
    # using repeated factors, not paired binomial determinants.
    direct=[[0]*16 for _ in keys];lookup={key:i for i,key in enumerate(keys)}
    sizes=[0]*90
    for p in it.permutations(range(6)):
        key=tuple(tuple(sorted((p[r],p[5-r]))) for r in (2,1,0))
        idx=lookup[key];q=[parity(p)]
        for i,e in enumerate(p):
            for _ in range(e):q=mul(q,[2*i-5,1])
        for j,v in enumerate(q):direct[idx][j]+=v
        sizes[idx]+=1
    require(G==direct and sizes==[8]*90,"720-term independent reconstruction failed")
    Z=[p[::2][:7] for p in G]
    # Endpoint is outer reflected pair. Coefficient at U=5 has first degree r.
    endpoint_min=[min(key[2]) for key in keys]
    endpoint_val=[]
    for p,r in zip(G,endpoint_min):
        require(all(taylor(p,5,k)==0 for k in range(r)),"endpoint valuation too small")
        v=taylor(p,5,r);require(v!=0,"endpoint valuation too large");endpoint_val.append(v)
    centers=[p[0] for p in G]
    balanced=[i for i,key in enumerate(keys) if all((u-v)%2 for u,v in key)]
    require({i for i,v in enumerate(centers) if v}==set(balanced),"balanced support mismatch")
    return keys,H,G,Z,endpoint_min,endpoint_val,centers,balanced

def regenerate_catalogue(ids,values,H):
    pos=[i for i in ids if values[i]>0];neg=[i for i in ids if values[i]<0]
    require(len(pos)+len(neg)==len(ids),"zero scalar in slice")
    A=subset_sums(pos,values);B=subset_sums(neg,values)
    count=0;closed=[]
    for val in sorted(A.keys()&B.keys()):
        for a in A[val]:
            for b in B[val]:
                m=a|b
                if not m:continue
                count+=1
                chosen=[i for i in ids if m>>i&1];bs=basis(H[i] for i in chosen)
                if all((m>>i&1) or not inspan(bs,H[i]) for i in ids):closed.append(m)
    return {'size':len(ids),'positive':len(pos),'negative':len(neg),'balanced_nonempty':count,'affine_closed':len(closed)},sorted(closed)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=pathlib.Path,default=ROOT/'INDEPENDENT_RESULT.json');args=ap.parse_args()
    start=time.monotonic();keys,H,G,Z,emin,evals,center,balanced=generate_data()
    endpoints=[];slice_counts=[]
    for r in range(5):
        info,cat=regenerate_catalogue([i for i in range(90) if emin[i]==r],evals,H)
        slice_counts.append(info);endpoints += [(r,m) for m in cat]
    center_count,center_sets=regenerate_catalogue(balanced,center,H)
    require([x['affine_closed'] for x in slice_counts]==[44,6,3,0,0],"endpoint count mismatch")
    require(center_count['balanced_nonempty']==1156 and len(center_sets)==6,"center count mismatch")
    require(all(m.bit_count()==6 for m in center_sets),"center size mismatch")
    # Empty intersection is an explicit seventh case.
    center_sets=[0]+center_sets;balanced_mask=sum(1<<i for i in balanced)
    cores=[]
    for si,(r,sm) in enumerate(endpoints):
        for ci,cm in enumerate(center_sets):
            forbid=balanced_mask&~cm
            forbid|=sum(1<<i for i in range(90) if emin[i]<r or (emin[i]==r and not(sm>>i&1)))
            seed=sm|cm
            if seed&forbid:continue
            bs=basis(H[i] for i in range(90) if seed>>i&1)
            closure=sum(1<<i for i,h in enumerate(H) if inspan(bs,h))
            if closure&forbid:continue
            cores.append((closure,forbid,bs,si,ci))
    require(len(cores)==12,"core count mismatch")
    # Different scalar system: all 13 U-Taylor coefficients at seven centered
    # integer locations, plus four evaluations. No original-L scalar file used.
    checks=[[taylor(p,x,k) for x in (0,-1,1,-3,3,-5,5) for k in range(13)]+[evalp(p,x) for x in (-9,-7,7,9)] for p in G]
    stats=collections.Counter();percore=[];zeros=[];trace=hashlib.sha256()
    def dfs(mask,forbid,B,last):
        stats['nodes']+=1
        trace.update((str(mask)+':'+str(last)+'\n').encode())
        ids=[i for i in range(90) if mask>>i&1]
        pol=[sum(Z[i][k] for i in ids) for k in range(7)]
        if not any(pol):zeros.append(mask)
        # Verify closure for every visited state independently.
        require(all(bool(mask>>i&1)==inspan(B,h) for i,h in enumerate(H)),"nonclosed traversal state")
        groups=collections.defaultdict(int)
        for i,h in enumerate(H):
            if mask>>i&1:continue
            r=residual(B,h);k=next(k for k,z in enumerate(r) if z);inv=pow(r[k],-1,MOD)
            groups[tuple(z*inv%MOD for z in r)]|=1<<i
        allowed=[];sums=[]
        for m in groups.values():
            stats['quotient_blocks']+=1
            if m&forbid:stats['forbidden_blocks']+=1;continue
            i=(m&-m).bit_length()-1
            if i<=last:stats['canonical_blocks']+=1;continue
            allowed.append((i,m))
            bids=[j for j in range(90) if m>>j&1]
            sums.append([sum(checks[j][k] for j in bids) for k in range(len(checks[0]))])
        # Check all intervals before gcd checks (different from primary order).
        current=[sum(checks[i][k] for i in ids) for k in range(len(checks[0]))]
        for k,a in enumerate(current):
            vals=[v[k] for v in sums]
            if -a<sum(v for v in vals if v<0) or -a>sum(v for v in vals if v>0):
                stats['interval_rejected']+=1;return
        for k,a in enumerate(current):
            d=math.gcd(*(v[k] for v in sums))
            if d and a%d:stats['gcd_rejected']+=1;return
        stats['expanded']+=1
        for i,m in sorted(allowed,reverse=True):dfs(mask|m,forbid,badd(B,H[i]),i)
    for mask,forbid,B,si,ci in cores:
        old=stats.copy();dfs(mask,forbid,B,-1)
        percore.append({'endpoint':si,'center':ci,'core_size':mask.bit_count(),'rank':len(B),'statistics':dict(stats-old)})
    require(not zeros,"polynomial-zero complete fiber found")
    require(stats['nodes']==stats['interval_rejected']+stats['gcd_rejected']+stats['expanded'],"node accounting mismatch")
    # Adversarial control: every exact zero triple of full pair orbits must
    # fail affine closure, rather than being incorrectly called a cost fiber.
    triples=[]
    bypoly=collections.defaultdict(list)
    for i,p in enumerate(Z):bypoly[tuple(p)].append(i)
    for i in range(90):
        for j in range(i+1,90):
            for k in bypoly[tuple(-x-y for x,y in zip(Z[i],Z[j]))]:
                if k<=j:continue
                B=basis((H[i],H[j],H[k]))
                cl=[q for q,h in enumerate(H) if inspan(B,h)]
                require(len(cl)==4 and set(cl)!={i,j,k},'zero triple unexpectedly closed')
                require(any(sum(Z[q][d] for q in cl) for d in range(7)),'forced closure still zero')
                triples.append({'members':[i,j,k],'closure':cl})
    require(len(triples)==6,'zero-triple control count mismatch')
    # Additional center-factor checks for n=6 and n=8 constant-cost supports.
    masks={}
    for m in (3,4):
        xs=[(2*i+1)**2 for i in range(m)];ps=list(it.permutations(range(m)))
        pm=[sum(1<<(m*i+p[i]) for i in range(m)) for p in ps]
        vals=[parity(p)*math.prod(xs[i]**p[i] for i in range(m)) for p in ps]
        total=0;bad=[]
        for mask in range(1<<(m*m)):
            selected=[i for i,b in enumerate(pm) if mask&b==b]
            if selected:
                total+=1
                if sum(vals[i] for i in selected)==0:bad.append(mask)
        require(not bad,"masked center determinant vanished")
        masks[str(m)]={'nodes':xs,'masks_examined':1<<(m*m),'with_perfect_matching':total,'zero_with_perfect_matching':len(bad)}
    result={'scope':'Canonical n=6, arbitrary real costs equal within each mirrored row pair; pair-invariant support. Not arbitrary n=6 costs.','modulus':MOD,'incidence_coordinates':'constant, pair rows1,2 and columns1..5; increasing radii; reversed allocation order','endpoint_counts':slice_counts,'center_counts':center_count,'center_sizes':[m.bit_count() for m in center_sets],'cores':len(cores),'statistics':dict(stats),'polynomial_zero_states':len(zeros),'trace_sha256':trace.hexdigest(),'per_core':percore,'center_mask_corollaries':masks,'zero_triple_controls':triples,'complete':True}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));print('elapsed_seconds',time.monotonic()-start)
if __name__=='__main__':main()
