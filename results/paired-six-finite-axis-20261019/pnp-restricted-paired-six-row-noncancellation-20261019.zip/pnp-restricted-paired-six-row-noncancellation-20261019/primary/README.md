# Six-row restricted fiber result

Read `PROOF.md` for the precise result: noncancellation for arbitrary real costs when BOTH support and costs are invariant under independently swapping row pairs (0,5), (1,4), (2,3). Unrestricted six-row noncancellation is not proved.

Primary entrypoint: `python verify_pair_model.py --output REPLAY_DIRECTORY`.
Adversarial controls: `python negative_controls.py --output CONTROLS.json`.

Final proof sources are `verify_pair_model.py`, `traverse_pair_flats.cpp`, and `negative_controls.py`. Other scripts are exploratory and are not premises of the result. Final evidence is identified in `MANIFEST.json`.
