"""Standalone exact six-row paired-cost model verification. No imported research data."""
import argparse, collections, itertools, json, math, pathlib, subprocess
ROOT=pathlib.Path(__file__).resolve().parent
MOD=1000000007

def need(ok,why):
 if not ok:raise RuntimeError(why)
def sign(p):return (-1)**sum(p[i]>p[j]for i in range(6)for j in range(i+1,6))
def mul(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return c

def term(p,scaled=False):
 a=[sign(p)]
 for i,e in enumerate(p):
  for _ in range(e):a=mul(a,[2*i-5 if scaled else i,1])
 return a

def power(a,e):return [math.comb(e,k)*a**(e-k)for k in range(e+1)]
def grouped_factor(key):
 p=[0]*6;a=[1]
 for r,(u,v)in enumerate(key):
  p[r],p[5-r]=u,v
  x=mul(power(r,u),power(5-r,v));y=mul(power(r,v),power(5-r,u))
  a=mul(a,[z-w for z,w in zip(x,y)])
 a=[sign(p)*x for x in a]
 return a+[0]*(16-len(a))

def basis(rows):
 B={}
 for row in rows:
  v=[x%MOD for x in row]
  for k in sorted(B):
   x=v[k]
   if x:v=[(a-x*b)%MOD for a,b in zip(v,B[k])]
  pivot=next((k for k,x in enumerate(v)if x),None)
  if pivot is not None:
   inv=pow(v[pivot],MOD-2,MOD);B[pivot]=[x*inv%MOD for x in v]
 return B

def belongs(h,B):
 v=h[:]
 for k in sorted(B):
  x=v[k]
  if x:v=[(a-x*b)%MOD for a,b in zip(v,B[k])]
 return not any(v)

def subset_sums(ids,weights):
 out=[(0,0)]
 for i in ids:out += [(s+abs(weights[i]),m|(1<<i))for s,m in out]
 d=collections.defaultdict(list)
 for s,m in out:d[s].append(m)
 return d

def catalogue(ids,weights,H):
 pos=[i for i in ids if weights[i]>0];neg=[i for i in ids if weights[i]<0]
 need(len(pos)+len(neg)==len(ids),'zero scalar in enumerated slice')
 a,b=subset_sums(pos,weights),subset_sums(neg,weights);balanced=0;closed=[]
 for s,aa in a.items():
  for ma in aa:
   for mb in b.get(s,[]):
    m=ma|mb
    if not m:continue
    balanced+=1;chosen=[i for i in ids if m>>i&1];B=basis([H[i]for i in chosen])
    if all((m>>i&1)or not belongs(H[i],B)for i in ids):closed.append(chosen)
 return balanced,closed

def check_modulus(mod):
 need(mod>2 and all(mod%d for d in range(2,math.isqrt(mod)+1)),'nonprime rank modulus')
 need(5**11<mod**2,'Hadamard bound insufficient')
 need(mod*mod+mod<2**63,'unsafe modular products')

def check_orbit(key,poly,cen):
 need(poly==grouped_factor(key),'independent orbit factorization disagreement')
 need(all(cen[k]==0 for k in range(16)if k%2 or k>12),'orbit parity or degree disagreement')
 need(cen==[sum(poly[j]*math.comb(j,k)*(-5)**(j-k)*2**(15-j)for j in range(k,16))for k in range(16)],'centered transform disagreement')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--sanitize',action='store_true');args=ap.parse_args();out=pathlib.Path(args.output);out.mkdir(parents=True,exist_ok=True)
 check_modulus(MOD)
 ps=list(itertools.permutations(range(6)));groups={}
 for p in ps:
  key=tuple(tuple(sorted((p[r],p[5-r])))for r in range(3));groups.setdefault(key,[]).append(p)
 keys=list(groups);need(len(keys)==90 and all(len(g)==8 for g in groups.values()),'incorrect orbit partition')
 P=[];C=[];H=[]
 for key,members in groups.items():
  ordinary=[term(p)for p in members];centered=[term(p,True)for p in members]
  poly=[sum(x[k]for x in ordinary)for k in range(16)];cen=[sum(x[k]for x in centered)for k in range(16)]
  check_orbit(key,poly,cen)
  P.append(poly);C.append(cen)
  H.append([1]+[int(c in key[r])for r in range(2)for c in range(5)])
 need([sum(p[k]for p in P)for k in range(16)]==[34560]+[0]*15,'full Vandermonde control')
 def closure(ids):
  B=basis([H[i]for i in ids]);return [i for i,h in enumerate(H)if belongs(h,B)]
 endpoints=[];endpoint_counts=[]
 for r in range(5):
  ids=[i for i,k in enumerate(keys)if min(k[0])==r];w=[p[r]for p in P]
  for i in ids:need(all(P[i][k]==0 for k in range(r))and P[i][r]!=0,'incorrect endpoint order')
  balanced,closed=catalogue(ids,w,H);endpoint_counts.append([r,len(ids),balanced,len(closed)])
  endpoints += [{'minimum':r,'members':ids}for ids in closed]
 balanced_ids=[i for i,c in enumerate(C)if c[0]];center_count,centers=catalogue(balanced_ids,[c[0]for c in C],H)
 need(len(balanced_ids)==36,'incorrect balanced allocations')
 need(center_count==1156 and len(centers)==6,'center catalogue changed')
 for s in centers:need(set(closure(s))==set(s),'center closure changed')
 centers=[[]]+centers
 cores=[];center_set=set(balanced_ids)
 for si,s in enumerate(endpoints):
  for ci,cs in enumerate(centers):
   m=set(s['members'])|set(cs)
   forbidden={i for i,k in enumerate(keys)if min(k[0])<s['minimum']or(min(k[0])==s['minimum']and i not in s['members'])}|(center_set-set(cs))
   if m&forbidden:continue
   cl=set(closure(sorted(m)))
   if cl&forbidden:continue
   cores.append({'endpoint':si,'center':ci,'members':sorted(cl),'forbidden':sorted(forbidden),'rank':len(basis([H[i]for i in cl]))})
 checks=[]
 for key,poly in zip(keys,P):
  v=[]
  for x in range(-5,1):
   # Taylor coefficients reconstructed from orbit products, rather than translating saved coefficients.
   direct=[0]*16
   for p in groups[key]:
    a=[sign(p)]
    for i,e in enumerate(p):
     for _ in range(e):a=mul(a,[x+i,1])
    direct=[a+b for a,b in zip(direct,a)]
   translated=[sum(poly[j]*math.comb(j,k)*x**(j-k)for j in range(k,16))for k in range(16)]
   need(direct==translated,'Taylor projection mismatch');v+=direct
  for x in [1,2,-6,-7]:
   a=sum(sign(p)*math.prod((x+i)**p[i]for i in range(6))for p in groups[key]);need(a==sum(z*x**k for k,z in enumerate(poly)),'direct evaluation mismatch');v.append(a)
  checks.append(v)
 maxabs=max(sum(abs(v[k])for v in checks)for k in range(100));need(maxabs<2**63,'scalar arithmetic bound')
 inp=out/'INPUT.txt'
 with inp.open('w')as f:
  f.write(f'{len(cores)} 100\n')
  for h,p,v in zip(H,P,checks):f.write(' '.join(map(str,h+p+v))+'\n')
  for c in cores:f.write(' '.join(map(str,[c['endpoint'],c['center'],len(c['members']),len(c['forbidden'])]+c['members']+c['forbidden']))+'\n')
 (out/'CATALOGUES.json').write_text(json.dumps({'keys':keys,'endpoint_counts':endpoint_counts,'endpoint_slices':endpoints,'center_scalar_zero_subsets':center_count,'center_slices':centers,'cores':cores},indent=2)+'\n')
 binary=out/'traverse';flags=['-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=all']if args.sanitize else ['-O3']
 subprocess.run(['g++','-std=c++17',*flags,str(ROOT/'traverse_pair_flats.cpp'),'-o',str(binary)],check=True)
 prefix=out/'TRAVERSAL'
 with(out/'TRAVERSAL.log').open('w')as log:subprocess.run([str(binary),str(inp),str(prefix)],check=True,stdout=log,stderr=log)
 stats=json.loads((out/'TRAVERSAL_stats.json').read_text())
 need(not stats['capped']and not stats['candidates'],'traversal found a candidate or was incomplete')
 need(stats['nodes']==stats['interval_reject']+stats['gcd_reject']+stats['expanded'],'state accounting')
 expected={'cores':12,'nodes':818,'extensions':45365,'forbidden_reject':31761,'canonical_reject':7246,'terminal':0,'candidates':0,'capped':False,'interval_reject':728,'gcd_reject':47,'eval_zero':0,'expanded':43}
 need(stats==expected,'deterministic traversal counts changed')
 result={'status':'restricted paired-row finite model exhausted; no cancelling nonempty fiber','scope':'n=6; costs and support invariant under independently swapping rows 0 with 5, 1 with 4, and 2 with 3','endpoint_counts':endpoint_counts,'center_balanced_allocations':len(balanced_ids),'center_scalar_zero_subsets':center_count,'nonempty_center_slices':len(centers)-1,'max_sum_absolute_scalar_values':maxabs,'rank_modulus':MOD,'traversal':stats}
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
