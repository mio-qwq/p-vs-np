#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <stdexcept>
#include <vector>
using namespace std;
const int P=1000000007;
using V=array<int,11>;
int powmod(int a,int e){long long z=1;for(;e;e>>=1,a=(long long)a*a%P)if(e&1)z=z*a%P;return z;}
struct Basis {array<V,11>b{};int rank=0;bool add(V v){for(int i=0;i<11;++i){if(!v[i])continue;if(b[i][i]){int a=v[i];for(int j=i;j<11;++j)v[j]=(v[j]-(long long)a*b[i][j]%P+P)%P;}else{int z=powmod(v[i],P-2);for(int j=i;j<11;++j)b[i][j]=(long long)v[j]*z%P;++rank;return true;}}return false;}
 V residue(V v)const{for(int i=0;i<11;++i){if(!v[i]||!b[i][i])continue;int a=v[i];for(int j=i;j<11;++j)v[j]=(v[j]-(long long)a*b[i][j]%P+P)%P;}return v;}
 bool contains(V v)const{for(int i=0;i<11;++i){if(!v[i])continue;if(!b[i][i])return false;int a=v[i];for(int j=i;j<11;++j)v[j]=(v[j]-(long long)a*b[i][j]%P+P)%P;}return true;}
};
using Mask=__uint128_t;
Mask bit(int i){return (Mask)1<<i;}
array<V,90>vec;
array<array<long long,16>,90>poly;
array<long long,90>eval;
const int NC=100;
array<array<long long,NC>,90>checks;
long long cores=0,nodes=0,terminal=0,extensions=0,forbidden_reject=0,canonical_reject=0,candidates=0;
map<int,long long>core_ranks,node_ranks;
ofstream candidateout,evalout;
long long interval_reject=0,gcd_reject=0,eval_zero=0,expanded=0;
Mask close(const Basis&b,Mask forbidden,bool &bad){Mask m=0;bad=false;for(int i=0;i<90;++i)if(b.contains(vec[i])){m|=bit(i);if(forbidden&bit(i)){bad=true;return m;}}return m;}
void dfs(const Basis&bs,Mask m,Mask forbidden,int last,int a,int b){
 ++nodes;++node_ranks[bs.rank];if(nodes%100000==0)cerr<<"nodes="<<nodes<<" a="<<a<<" b="<<b<<" rank="<<bs.rank<<"\n";
 int sz=0;long long ev=0;for(int i=0;i<90;++i)if(m&bit(i)){++sz;ev+=eval[i];}
 if(ev==0){++eval_zero;array<long long,16>sum{};for(int i=0;i<90;++i)if(m&bit(i))for(int j=0;j<16;++j)sum[j]+=poly[i][j];evalout<<a<<' '<<b<<' '<<last<<' '<<bs.rank<<' '<<sz;for(int i=0;i<90;++i)if(m&bit(i))evalout<<' '<<i;for(auto x:sum)evalout<<' '<<x;evalout<<'\n';bool zero=true;for(auto z:sum)if(z)zero=false;if(zero){++candidates;candidateout<<a<<' '<<b<<' '<<bs.rank<<' '<<sz;for(int i=0;i<90;++i)if(m&bit(i))candidateout<<' '<<i;candidateout<<'\n';candidateout.flush();cerr<<"CANDIDATE "<<a<<' '<<b<<' '<<sz<<'\n';}}
 map<V,Mask> groups;
 for(int i=0;i<90;++i){if(m&bit(i))continue;V r=bs.residue(vec[i]);int j=0;while(j<11&&!r[j])++j;if(j==11)throw runtime_error("closure mismatch");int z=powmod(r[j],P-2);for(int k=j;k<11;++k)r[k]=(long long)r[k]*z%P;groups[r]|=bit(i);}
 vector<pair<int,Mask>> valid;
 array<long long,NC> total{},pos{},neg{},div{};
 for(int i=0;i<90;++i)if(m&bit(i))for(int j=0;j<NC;++j)total[j]+=checks[i][j];
 for(auto &item:groups){Mask g=item.second;++extensions;if(g&forbidden){++forbidden_reject;continue;}int i=0;while(!(g&bit(i)))++i;if(i<=last){++canonical_reject;continue;}valid.push_back({i,g});array<long long,NC>w{};for(int k=0;k<90;++k)if(g&bit(k))for(int j=0;j<NC;++j)w[j]+=checks[k][j];for(int j=0;j<NC;++j){if(w[j]>0)pos[j]+=w[j];else neg[j]+=w[j];div[j]=gcd(div[j],w[j]);}}
 for(int j=0;j<NC;++j){if(-total[j]<neg[j]||-total[j]>pos[j]){++interval_reject;return;}if(div[j]&&total[j]%div[j]){++gcd_reject;return;}}
 ++expanded;
 bool child=false;
 for(auto [i,g]:valid){Basis nb=bs;if(!nb.add(vec[i]))throw runtime_error("closure mismatch");child=true;dfs(nb,m|g,forbidden,i,a,b);}

 if(!child)++terminal;
}
int main(int argc,char**argv){
 if(argc!=3)return 1;
 ifstream in(argv[1]);int n=0,nc=0;if(!(in>>n>>nc)||n<0)throw runtime_error("invalid input header");if(nc!=NC)throw runtime_error("check count");
 for(int i=0;i<90;i++){for(auto&x:vec[i])in>>x;for(auto&x:poly[i])in>>x;for(auto&x:checks[i])in>>x;eval[i]=checks[i][96];}
 string prefix=argv[2];candidateout.open(prefix+"_candidates.txt");evalout.open(prefix+"_eval_zero.txt");
 for(int ix=0;ix<n;ix++){int a,b,sz,fs;in>>a>>b>>sz>>fs;Mask m=0,forbidden=0;for(int k=0;k<sz;k++){int x;in>>x;m|=bit(x);}for(int k=0;k<fs;k++){int x;in>>x;forbidden|=bit(x);}Basis bs;for(int i=0;i<90;i++)if(m&bit(i))bs.add(vec[i]);bool bad;Mask actual=close(bs,forbidden,bad);if(bad||actual!=m)throw runtime_error("bad input core");if(!in)throw runtime_error("truncated input");cores++;core_ranks[bs.rank]++;dfs(bs,m,forbidden,-1,a,b);cerr<<"core="<<ix<<" nodes="<<nodes<<" extensions="<<extensions<<'\n';}
 ofstream out(prefix+"_stats.json");out<<"{\"cores\":"<<cores<<",\"nodes\":"<<nodes<<",\"extensions\":"<<extensions<<",\"forbidden_reject\":"<<forbidden_reject<<",\"canonical_reject\":"<<canonical_reject<<",\"terminal\":"<<terminal<<",\"candidates\":"<<candidates<<",\"capped\":false,\"interval_reject\":"<<interval_reject<<",\"gcd_reject\":"<<gcd_reject<<",\"eval_zero\":"<<eval_zero<<",\"expanded\":"<<expanded<<"}\n";
}
