"""Exact adversarial controls for the six-row restricted theorem."""
import itertools,json,math,argparse
from pathlib import Path
import verify_pair_model as v
D=Path(__file__).resolve().parent

def rejected(fn):
 try:fn()
 except RuntimeError as e:return {'rejected':True,'reason':str(e)}
 raise RuntimeError('Expected rejection did not happen')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args();ps=list(itertools.permutations(range(6)));groups={}
 for p in ps:
  key=tuple(tuple(sorted((p[r],p[5-r])))for r in range(3));groups.setdefault(key,[]).append(p)
 keys=list(groups);key=keys[0];terms=[v.term(p)for p in groups[key]];cterms=[v.term(p,True)for p in groups[key]];poly=[sum(a[k]for a in terms)for k in range(16)];cen=[sum(a[k]for a in cterms)for k in range(16)]
 v.check_orbit(key,poly,cen);bad=poly[:];bad[0]+=1;badc=cen[:];badc[1]+=1
 report={'corrupt_orbit_coefficients':rejected(lambda:v.check_orbit(key,bad,cen)),'corrupt_centered_coefficients':rejected(lambda:v.check_orbit(key,poly,badc)),'composite_modulus':rejected(lambda:v.check_modulus(1000000005)),'insufficient_modulus':rejected(lambda:v.check_modulus(3))}
 # The first exploratory MILP zero triple, here reconstructed without reading solver output.
 orbit_ids=[7,9,19];members=sorted(p for i in orbit_ids for p in groups[keys[i]]);selected=[ps.index(p)for p in members]
 zero=[sum(v.term(p)[k]for p in members)for k in range(16)];v.need(not any(zero),'24-term control does not cancel')
 H=[[1]+[int(p[r]==c)for r in range(5)for c in range(5)]for p in ps];mod=1000000000039
 v.need(all(mod%d for d in range(2,math.isqrt(mod)+1))and 6**26<mod**2,'unrestricted rank modulus not certified')
 old=v.MOD;v.MOD=mod
 try:
  B=v.basis([H[i]for i in selected]);closure=[i for i,h in enumerate(H)if v.belongs(h,B)]
 finally:v.MOD=old
 outsider=next(i for i in closure if i not in selected);target=ps[outsider]
 # Search a short explicit affine identity in the selected full permutation incidence vectors.
 witness=None
 for a,b in itertools.combinations(selected,2):
  for c in selected:
   if [H[a][k]+H[b][k]-H[c][k]for k in range(26)]==H[outsider]:witness=[(a,1),(b,1),(c,-1)];break
  if witness:break
 v.need(witness is not None,'No three-term affine outsider witness')
 union={(r,p[r])for p in members for r in range(6)};actual=[i for i,p in enumerate(ps)if all((r,p[r])in union for r in range(6))]
 v.need(closure==actual and len(actual)==32,'32-term constant-cost complete fiber changed')
 actual_poly=[sum(v.term(ps[i])[k]for i in actual)for k in range(16)];v.need(any(actual_poly),'Actual full fiber must not cancel')
 report['zero_subset_is_not_complete_fiber']={'selected_permutations':[''.join(map(str,p))for p in members],'all_16_coefficients_zero':True,'augmented_incidence_rank':len(B),'full_incidence_closure_size':len(closure),'forced_outsider':''.join(map(str,target)),'affine_witness':[{'permutation':''.join(map(str,ps[i])),'coefficient':a}for i,a in witness],'actual_complete_fiber':[''.join(map(str,ps[i]))for i in actual],'actual_cost_certificate':'Cost zero on every edge in the union support; no other edges supported. Target cost zero. Exhaustive all720-permutation enumeration gives exactly the listed32 members.','actual_original_L_coefficients':actual_poly}
 report['status']='All adversarial controls passed.';Path(args.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
