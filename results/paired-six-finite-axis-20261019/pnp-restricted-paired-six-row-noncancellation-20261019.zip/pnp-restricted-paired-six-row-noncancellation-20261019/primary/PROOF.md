# Canonical six-row noncancellation with independently paired rows

19 October 2026. Exact restricted finite-model result. A separately written full audit has passed, using different incidence coordinates, a different certified prime, reversed allocation order, independently generated orbit polynomials, and different scalar projections. This is AI-assisted finite mathematics, not external peer review or proof-assistant formalization. It does not settle unrestricted six-row costs or any complexity-theoretic separation. No repository, merge, or release was changed.

## 1. Statement and precise scope

For p a permutation of {0,1,2,3,4,5}, let

    f_p(L) = sgn(p) product_(i=0)^5 (L+i)^(p(i)).

Pair the rows as (0,5), (1,4), and (2,3). Let G be a supported bipartite graph satisfying, for each r=0,1,2 and column j,

    (r,j) is supported if and only if (5-r,j) is supported.

Let its real edge costs satisfy

    w(r,j) = w(5-r,j)

on all supported edges. For any real t, form the **entire** supported cost fiber

    F = {p in PM(G): sum_i w(i,p(i)) = t}.

**Restricted finite theorem.** If F is nonempty, then sum_(p in F) f_p(L) is not the zero polynomial.

Both hypotheses matter: this theorem assumes pair-invariant support and pair-equal costs. It does not establish the assertion for arbitrary sparse support, arbitrary six-row costs, or merely a fiber invariant under simultaneous row reversal. It does not assume costs are rational, integer, binary, nonnegative, or bounded. The five-row theorem is not used as a premise.

## 2. The 90 allocation points

The three independent row-pair swaps generate eight orientations of each allocation

    A=(A_0,A_1,A_2),

where A_r is a two-element set of columns, the three sets are disjoint, and their union is {0,...,5}. There are 6!/(2!)^3 = 90 allocations. Pair-invariant support and pair-equal costs make each entire eight-permutation orbit either present or absent in F.

Write b_A(r,j)=1 if j belongs to A_r. Its row sums are two and its column sums are one. A supported allocation has cost

    sum_(r=0)^2 sum_(j in A_r) w(r,j).

Consequently a nonempty complete fiber of allocations S is affine-closed among all 90 incidence points. An affine-forced allocation uses no unsupported edge because every such coordinate is zero in every member of S. Its affine-combination cost is t, so completeness includes it.

Conversely, any nonempty affine-closed collection of the 90 allocations can be realized by pair-equal integer costs on full support: choose an allocation in S, annihilate the span of its differences from S, and choose a rational functional outside the finitely many proper hyperplanes supplied by all outside allocations. Scale to integer costs. Thus the quotient is exact for this restricted model.

Use the augmented incidence vector

    h_A = (1, b_A(r,j) for r=0,1 and j=0,...,4) in Z^11.

The margin constraints recover every omitted coordinate, so affine closure is linear span membership of these h_A. Each has at most five ones. Every square minor has absolute determinant at most 5^(11/2), by Hadamard. The verifier trial-divides 1000000007 to establish primality and checks

    5^11 < 1000000007^2.

Thus ranks and membership tests modulo this prime equal their rational and real values. Comparisons of quotient projective directions are also rank statements in the original vectors, so are exact. All modular products are bounded by p^2+p < 2^63.

## 3. Orbit polynomials and independent arithmetic checks

For A_r={u_r,v_r}, with u_r<v_r, let p_A assign u_r to row r and v_r to row 5-r. Summing all eight orientations gives

    g_A(L) = sgn(p_A) product_(r=0)^2 [
      (L+r)^u_r (L+5-r)^v_r
      - (L+r)^v_r (L+5-r)^u_r
    ].

The primary verifier computes g_A by adding eight individually expanded permutation polynomials and independently checks this product formula using binomial expansions. It checks all 90 orbits and the full-family identity

    sum_A g_A(L) = 34560.

Define U=2L+5 and G_A(U)=2^15 g_A((U-5)/2). Row reflection makes each G_A even, and each difference factor loses its top degree. Hence G_A has degree at most 12 and uses only the seven powers 1,U^2,...,U^12. The verifier independently constructs centered term products and checks the exact translated coefficient identity.

## 4. Exhaustive least-root catalogue

For each allocation A, g_A has order exactly min(A_0) at L=0. The row-pair (0,5) difference has that order, and the other two differences are nonzero at L=0 because their row arguments are distinct positive integers.

Suppose an affine-closed nonempty S has sum_A g_A=0. Let r be the minimum min(A_0) over A in S, and let E contain exactly the members attaining r. Its leading coefficient must sum to zero. E is affine-closed within that r-slice: an allocation in the slice affine-forced by E also belongs to S and hence to E.

The primary verifier enumerates every subset on each scalar sign side, retaining all equal subset sums and masks, then tests exact affine closure within the slice. No size cutoff is used.

| r | Allocation points | Nonempty scalar-zero subsets | Affine-closed slices |
|---|---:|---:|---:|
| 0 | 30 | 16,974 | 44 |
| 1 | 24 | 144 | 6 |
| 2 | 18 | 14 | 3 |
| 3 | 12 | 4 | 0 |
| 4 | 6 | 0 | 0 |

This gives exactly 53 possible nonempty endpoint slices.

## 5. Exhaustive center catalogue

At U=0 an allocation contributes nonzero G_A(0) precisely when each A_r has one even and one odd column. There are 36 such balanced allocations; the other 54 vanish at the center. A polynomial-zero S therefore has a scalar-zero intersection with these 36 points. This intersection is affine-closed relative to the 36, by the same closure argument.

The 36 nonzero scalar terms split into 18 positive and 18 negative terms. Enumeration of all 2^18 subsets on each side gives exactly 1,156 nonempty scalar-zero subsets. Exactly six are affine-closed in the 36-point restriction. All six have size six and are already affine-closed among all 90 allocations. The empty balanced intersection is also permitted. Thus there are exactly seven possible center restrictions.

The standalone verifier regenerates these scalars directly from its independently checked orbit polynomials. It does not read an external center catalogue or assume the algebraic formula used to discover it.

## 6. Twelve compatible closed cores

For every one of the 53 endpoint choices and seven center choices, take their union. Forbid:

- every allocation whose endpoint minimum is below the chosen r;
- every allocation at r absent from the chosen endpoint slice;
- every center-balanced allocation absent from the chosen center slice.

Reject a union that meets the forbidden set. Close the union among all 90 allocations and reject if the closure meets the forbidden set. Exactly 12 pairs survive. Their augmented ranks have distribution

    rank 2: 4, rank 3: 1, rank 4: 5, rank 5: 1, rank 7: 1.

Every hypothetical polynomial-zero complete fiber extends one of these cores and avoids its forbidden set. The endpoint and center restrictions are its actual intersections, so no hypothetical fiber is lost.

## 7. Complete canonical traversal and sound pruning

At a current closed family C, reduce every h_A modulo span(C). Group the nonzero residues by proportionality. Each resulting quotient block B satisfies

    cl(C union {A}) = C union B for every A in B.

Every closed extension therefore includes a whole block or none of it. Discard blocks meeting the fixed forbidden set.

Allocation indices have a fixed order. Start last=-1 and recurse on a block only when its least index is greater than last; update last to that least index. Every closed extension has exactly one canonical path, obtained by repeatedly choosing its least missing member. Each path step forces only members of the target closed extension. A skipped smaller-index block cannot later enter a canonical descendant. This gives a complete, nonduplicating traversal of every compatible flat.

The verifier uses 100 exact integer scalar projections:

- all 16 Taylor coefficients at each original L=-5,-4,-3,-2,-1,0;
- evaluations at L=1,2,-6,-7.

For a current scalar a and available block scalars b_B, a zero completion requires

    sum_(b_B<0) b_B <= -a <= sum_(b_B>0) b_B,
    gcd{b_B} divides a, when that gcd is nonzero.

Failure of either necessary condition rejects the branch. Passing is never treated as sufficient. Blocks excluded by the canonical index cannot occur in descendants and are omitted from these bounds.

Every visited closed C is first checked at L=1; if that value is zero, all 16 original coefficients are checked. No polynomial identity is inferred from a lone evaluation. There is no time limit, node limit, numerical optimization, or probabilistic pruning in the verifier.

## 8. Exhaustive primary result and independent audit

The complete primary traversal reports:

| Quantity | Count |
|---|---:|
| Compatible cores | 12 |
| Closed-set states | 818 |
| Quotient blocks inspected | 45,365 |
| Blocks excluded by forbidden membership | 31,761 |
| Blocks excluded by canonical index | 7,246 |
| States rejected by scalar interval | 728 |
| States rejected by scalar gcd | 47 |
| Expanded states | 43 |
| States with Q(1)=0 | 0 |
| Polynomial-zero states | 0 |

State accounting is 728+47+43=818. The 43 expanded states generate 806 child states; adding 12 cores gives 818.

The maximum sum of absolute values over the 90 allocations for any scalar projection is 794,119,671,360, well below signed 64-bit range. All Taylor projections are independently checked by direct products after translation; all four evaluations are checked by direct permutation products. Membership uses a 128-bit mask for 90 Boolean entries.

A separate implementation, `../general-fiber-constraints-20261019/independent_audit.py`, regenerates all mathematical data without reading this implementation's catalogues or coefficient files. It uses lower-right incidence coordinates, a different certified prime, reversed allocation order, orbit-factor polynomials checked against all 720 terms, and different centered projections. It reproduces the same 53 endpoint slices, six nonempty center slices, and 12 cores. Its different traversal order/pruning visits 2,049 states, rejects 1,844 by intervals and 80 by gcd, expands 125, and finds no zero polynomial. Consult its `INDEPENDENT_RESULT.json` for the separate receipt.

Normal, optimized-Python, and undefined-behavior-sanitized primary replays agree on deterministic catalogues, traversal inputs, and result counts. `REPLAY_CROSSCHECK.json` and the final manifest record the checked files.

## 9. Adversarial controls and failed counterexample routes

`negative_controls.py` checks that a corrupted orbit coefficient, corrupted centered coefficient, composite modulus, and insufficient rank modulus are rejected. It also reconstructs a 24-permutation zero polynomial found during bounded exploratory MILP. Crucially, it checks this subset in the full 720-point unrestricted incidence model, using a separately certified larger modulus and the 26-dimensional Hadamard bound. Its incidence closure contains 32 permutations. An explicit three-term affine outsider witness proves the 24-term subset cannot be any complete real-cost fiber. Its union-support zero-cost fiber contains exactly those 32 permutations and has a nonzero polynomial.

Thus the discarded candidate is not rejected merely because of the quotient restriction. All six exploratory 24-term zero subsets were separately checked against full 720-permutation incidence closure and each forced 32 members. Their records are exploratory evidence, not a premise of the restricted theorem.

Other bounded searches tried all 64^3 binary matrices and all 64^3 constant-cost supports for each of the 15 partitions of six rows into three equal-cost pairs, plus all 64^3 centrosymmetric binary matrices/supports. These are 4,194,304 matrix configurations in each category, with repeated matrices between categories possible. They produced 22,133,344 nonempty binary fibers and 1,617,342 nonempty support fibers; none cancelled. They do not exclude arbitrary real costs outside the proved reflected-pair model. The MILP was used only to seek candidates; its numerical feasibility, timeout, or infeasibility reports are not used as proofs.

## 10. Reproduction, next direction, and recovery conditions

From this directory:

    python verify_pair_model.py --output NEW_REPLAY
    PYTHONOPTIMIZE=1 python -O verify_pair_model.py --output NEW_OPTIMIZED_REPLAY
    python verify_pair_model.py --sanitize --output NEW_SANITIZED_REPLAY
    python negative_controls.py --output NEW_CONTROLS.json

The standalone verifier requires standard-library Python and a C++17 compiler with its 128-bit integer extension. It generates all data afresh and compiles the retained traversal source. It uses explicit exceptions rather than removable assertions.

The unrestricted six-row question remains open here. The next constructive search must leave pair-equal costs, pair-invariant support, or both. A polynomial-zero subset only counts after exact full 720-permutation affine closure and an explicit cost/support certificate. Pair-equal quotient closure alone must not be used to reject an unrestricted candidate; the full incidence test is needed.

Suspend the restricted theorem if review finds a missing endpoint or center slice, an invalid orbit factorization, incorrect incidence reconstruction, an invalid modular rank bound, an omitted compatible core or canonical extension, a wrong quotient block, an unsound scalar rejection, or a polynomial-zero visited state. Preserve exact allocation and permutation memberships, all coefficients, the entire forbidden set, current last index, allowed quotient blocks, disputed projection and values, and the branch path. Re-run using independently generated data before restoring the claim.
