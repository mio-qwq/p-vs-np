#!/usr/bin/env python3
"""Negative controls for package integrity; no mutation of the original tree."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def mutate(case, root):
    manifest = root / 'PACKAGE_MANIFEST.json'
    if case == 'corrupt_primary_proof':
        p = root / 'primary' / 'PROOF.md'; p.write_bytes(p.read_bytes() + b'corruption\n')
    elif case == 'corrupt_primary_code':
        p = root / 'primary' / 'verify_pair_model.py'; p.write_bytes(p.read_bytes() + b'# corruption\n')
    elif case == 'corrupt_independent_code':
        p = root / 'independent' / 'independent_audit.py'; p.write_bytes(p.read_bytes() + b'# corruption\n')
    elif case == 'missing_result':
        (root / 'independent' / 'INDEPENDENT_RESULT.json').unlink()
    elif case == 'extra_file':
        (root / 'unlisted.txt').write_text('unexpected\n')
    elif case == 'file_symlink':
        p = root / 'primary' / 'PROOF.md'; p.unlink(); p.symlink_to(ROOT / 'primary' / 'PROOF.md')
    elif case == 'directory_symlink':
        (root / 'unlisted-directory').symlink_to(ROOT / 'primary', target_is_directory=True)
    elif case == 'unsafe_path':
        data = json.loads(manifest.read_text()); data['files'][0]['path'] = '../escape'; write_json(manifest, data)
    elif case == 'duplicate_manifest_entry':
        data = json.loads(manifest.read_text()); data['files'].append(data['files'][0]); write_json(manifest, data)
    elif case == 'corrupt_acceptance_scope':
        p = root / 'FINAL_ACCEPTANCE.json'; data = json.loads(p.read_text())
        data['requires_pair_invariant_support'] = False; write_json(p, data)
    elif case == 'replace_accepted_manifest_and_rehash':
        p = root / 'primary' / 'MANIFEST.json'; data = json.loads(p.read_text())
        data['scope'] = 'unrestricted n6'; write_json(p, data)
        data = json.loads(manifest.read_text())
        for item in data['files']:
            if item['path'] == 'primary/MANIFEST.json':
                item.update(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        write_json(manifest, data)
    elif case == 'change_acceptance_and_rehash':
        p = root / 'FINAL_ACCEPTANCE.json'; data = json.loads(p.read_text())
        data['unrestricted_n6'] = 'SOLVED'; write_json(p, data)
        data = json.loads(manifest.read_text())
        for item in data['files']:
            if item['path'] == 'FINAL_ACCEPTANCE.json':
                item.update(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        write_json(manifest, data)
    else:
        raise RuntimeError('Unknown control')


def main():
    py = [sys.executable] + (['-O'] if sys.flags.optimize else [])
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONOPTIMIZE', None)
    good = subprocess.run(py + [str(ROOT / 'reproduce.py'), '--integrity-only'], env=env, capture_output=True)
    require(good.returncode == 0, 'Original package integrity failed')
    cases = ('corrupt_primary_proof', 'corrupt_primary_code', 'corrupt_independent_code',
             'missing_result', 'extra_file', 'file_symlink', 'directory_symlink', 'unsafe_path',
             'duplicate_manifest_entry', 'corrupt_acceptance_scope',
             'replace_accepted_manifest_and_rehash', 'change_acceptance_and_rehash')
    passed = []
    with tempfile.TemporaryDirectory(prefix='paired-six-row-package-controls-') as tmp:
        for case in cases:
            copy = Path(tmp) / case
            shutil.copytree(ROOT, copy)
            mutate(case, copy)
            bad = subprocess.run(py + [str(copy / 'reproduce.py'), '--integrity-only'],
                                 env=env, capture_output=True)
            require(bad.returncode != 0, 'Package corruption was not rejected: ' + case)
            passed.append(case)
    print(json.dumps({'status': 'PASS', 'negative_controls': len(passed), 'rejected': passed},
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
