#!/usr/bin/env python3
"""Rebuild the deterministic ZIP from only integrity-checked retained files."""
import argparse
import os
from pathlib import Path
import stat
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = 'pnp-restricted-paired-six-row-noncancellation-20261019'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('output', type=Path)
    args = ap.parse_args()
    dest = args.output.resolve()
    if dest.is_relative_to(ROOT):
        raise RuntimeError('Place the output archive outside the retained source directory')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    subprocess.run([sys.executable, '-B', str(ROOT / 'reproduce.py'), '--integrity-only'],
                   env=env, check=True, capture_output=True)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file():
                info = zipfile.ZipInfo(NAME + '/' + p.relative_to(ROOT).as_posix(), (1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


if __name__ == '__main__':
    main()
