#!/usr/bin/env python3
"""Verify pinned bytes, then replay the primary and independent finite audits."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
PRIMARY_PIN = 'a1300aaf97a3696a7bff8e0425b8e7b443982b3bd59774e89a2deb82be4cb946'
AUDIT_PIN = 'c1e54d96e2ccd06213802aeb2e6abb548c90bb3f39203925239208abe7d7196d'
REPLAY_FILES = ('INPUT.txt', 'CATALOGUES.json', 'TRAVERSAL_stats.json',
                'TRAVERSAL_candidates.txt', 'TRAVERSAL_eval_zero.txt', 'RESULT.json')


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_path(name):
    p = PurePosixPath(name)
    require(isinstance(name, str) and name and not p.is_absolute() and '..' not in p.parts
            and p.as_posix() == name and '\\' not in name, 'unsafe package path')
    return ROOT.joinpath(*p.parts)


def integrity():
    require(not (ROOT / 'PACKAGE_MANIFEST.json').is_symlink(), 'manifest is a symlink')
    manifest = json.loads((ROOT / 'PACKAGE_MANIFEST.json').read_text())
    require(manifest['schema'] == 1, 'unknown package schema')
    wanted = {'PACKAGE_MANIFEST.json'}
    for item in manifest['files']:
        path = safe_path(item['path'])
        require(item['path'] not in wanted, 'duplicate package path')
        wanted.add(item['path'])
        require(path.is_file() and not path.is_symlink(), 'missing or symlink file: ' + item['path'])
        data = path.read_bytes()
        require(len(data) == item['bytes'] and sha(data) == item['sha256'],
                'package byte mismatch: ' + item['path'])
    actual = set()
    for path in ROOT.rglob('*'):
        require(not path.is_symlink(), 'symlink content')
        if path.is_file():
            actual.add(path.relative_to(ROOT).as_posix())
    require(actual == wanted, 'unexpected or missing package content')
    original = ROOT / 'primary' / 'MANIFEST.json'
    require(sha(original.read_bytes()) == PRIMARY_PIN, 'accepted primary manifest changed')
    primary = json.loads(original.read_text())
    for item in primary['files']:
        path = safe_path('primary/' + item['path'])
        data = path.read_bytes()
        require(sha(data) == item['sha256'] and len(data) == item['bytes'], 'primary manifest mismatch')
    require(primary['independent_audit_sha256'] == AUDIT_PIN, 'independent audit pin changed')
    original_sums = (ROOT / 'independent' / 'SHA256SUMS.original').read_text().splitlines()
    require(len(original_sums) == 4, 'independent original checksum count changed')
    for line in original_sums:
        digest, original_path = line.split(maxsplit=1)
        path = ROOT / 'independent' / Path(original_path).name
        require(sha(path.read_bytes()) == digest, 'independent original checksum mismatch')
    require(sha((ROOT / 'independent' / 'INDEPENDENT_RESULT.json').read_bytes()) == AUDIT_PIN,
            'accepted independent result changed')
    require((ROOT / 'independent' / 'INDEPENDENT_RESULT.json').read_bytes()
            == (ROOT / 'independent' / 'INDEPENDENT_OPTIMIZED_RESULT.json').read_bytes(),
            'independent original modes disagree')
    acceptance = json.loads((ROOT / 'FINAL_ACCEPTANCE.json').read_text())
    require(acceptance['status'] == 'ACCEPTED_LOCAL_RESTRICTED_RESULT'
            and acceptance['primary_manifest_sha256'] == PRIMARY_PIN
            and acceptance['independent_result_sha256'] == AUDIT_PIN
            and acceptance['requires_pair_equal_costs'] is True
            and acceptance['requires_pair_invariant_support'] is True
            and acceptance['unrestricted_n6'] == 'OPEN'
            and acceptance['n8_content'] == 'SECONDARY_NOT_ACCEPTED_BY_THIS_PACKAGE'
            and acceptance['remote_changes'] is False, 'acceptance scope mismatch')
    old = json.loads((ROOT / 'historical' / 'ROOT_REPLAY_RESULT.json').read_text())
    require(old['independent_external_audit'] == 'pending', 'historical pending receipt changed')
    return len(wanted)


def run(command, cwd):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    env.pop('PYTHONOPTIMIZE', None)
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True)
    require(result.returncode == 0, 'Replay failed: ' + ' '.join(map(str, command))
            + '\n' + result.stdout.decode() + result.stderr.decode())
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--integrity-only', action='store_true')
    ap.add_argument('--sanitize', action='store_true')
    args = ap.parse_args()
    count = integrity()
    report = {'status': 'PASS', 'package_files_verified': count,
              'scope': 'n=6 with BOTH pair-equal costs and pair-invariant support; pairs (0,5),(1,4),(2,3)',
              'primary_manifest_sha256': PRIMARY_PIN, 'independent_result_sha256': AUDIT_PIN,
              'unrestricted_n6': 'OPEN', 'n8_content': 'SECONDARY_NOT_ACCEPTED_BY_THIS_PACKAGE'}
    if not args.integrity_only:
        py = [sys.executable] + (['-O'] if sys.flags.optimize else [])
        with tempfile.TemporaryDirectory(prefix='paired-six-row-replay-') as tmp:
            work = Path(tmp)
            out = work / 'primary'
            cmd = py + [str(ROOT / 'primary' / 'verify_pair_model.py'), '--output', str(out)]
            if args.sanitize:
                cmd.append('--sanitize')
            run(cmd, work)
            generated = {}
            for name in REPLAY_FILES:
                data = (out / name).read_bytes()
                for mode in ('FINAL_REPLAY', 'FINAL_OPTIMIZED', 'FINAL_SANITIZED'):
                    require(data == (ROOT / 'primary' / mode / name).read_bytes(),
                            'primary replay differs: ' + mode + '/' + name)
                generated[name] = sha(data)
            negative = work / 'negative.json'
            run(py + [str(ROOT / 'primary' / 'negative_controls.py'), '--output', str(negative)], work)
            data = negative.read_bytes()
            require(data == (ROOT / 'primary' / 'NEGATIVE_CONTROLS.json').read_bytes()
                    == (ROOT / 'primary' / 'NEGATIVE_CONTROLS_OPTIMIZED.json').read_bytes(),
                    'negative-control receipt changed')
            audit = work / 'independent.json'
            run(py + [str(ROOT / 'independent' / 'independent_audit.py'), '--output', str(audit)], work)
            require(sha(audit.read_bytes()) == AUDIT_PIN, 'independent replay differs')
            audit_result = json.loads(audit.read_text())
            require(audit_result['complete'] is True and audit_result['statistics']['nodes'] == 2049
                    and audit_result['polynomial_zero_states'] == 0, 'independent traversal incomplete')
            report.update(primary_replay_hashes=generated, primary_nodes=818, independent_nodes=2049,
                          polynomial_zero_states=0, primary_negative_controls=5,
                          independent_zero_triple_controls=len(audit_result['zero_triple_controls']),
                          negative_controls_sha256=sha(data), all_replay_bytes_match=True)
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
