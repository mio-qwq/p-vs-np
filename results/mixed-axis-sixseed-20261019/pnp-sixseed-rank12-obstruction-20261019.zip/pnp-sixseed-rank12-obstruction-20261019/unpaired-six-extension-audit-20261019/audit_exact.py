"""Independent exact-rational geometry and integer polynomial audit; no finite fields.
Inputs are the six seed memberships only. Primary result files are comparison targets.
"""
from collections import Counter
from functools import reduce
from itertools import permutations, combinations
from math import comb,gcd,isqrt
from pathlib import Path
import argparse,hashlib,json,time
import sympy as sp
D=Path(__file__).resolve().parent
SRC=D/'inputs'

def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def primitive(v):
 g=reduce(gcd,v,0)
 if not g:return tuple(v)
 first=next(x for x in v if x)
 if first<0:g=-g
 return tuple(x//g for x in v)
def conv(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return c

def term(p,center=False):
 sign=(-1)**sum(p[i]>p[j] for i in range(6)for j in range(i+1,6))
 q=[sign]
 for i,e in enumerate(p):
  t=2*i-5 if center else i
  q=conv(q,[comb(e,k)*t**(e-k)for k in range(e+1)])
 return tuple(q)
def add(qs):return tuple(map(sum,zip(*qs)))
def evalpoly(q,x):return sum(c*x**i for i,c in enumerate(q))

def signature(a,b):
 pa=next(i for i,x in enumerate(a)if x);pb=next(i for i,x in enumerate(b)if x)
 if pa>pb:a,b,pa,pb=b,a,pb,pa
 w=primitive(tuple(a[pa]*y-b[pa]*x for x,y in zip(a,b)))
 need(any(w),'Duplicate projective point')
 pw=next(i for i,x in enumerate(w)if x)
 need(pw>pa,'Invalid two-row elimination')
 z=primitive(tuple(w[pw]*x-a[pw]*y for x,y in zip(a,w)))
 return z,w

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);args=ap.parse_args();O=args.output.resolve();O.mkdir(parents=True,exist_ok=True)
 start=time.time();ps=list(permutations(range(6)));idx={p:i for i,p in enumerate(ps)}
 # Lower-right coordinates, with original zero-based row/column 0 omitted.
 H=[[1]+[int(p[r]==c)for r in range(1,6)for c in range(1,6)]for p in ps]
 words=list(map(int,(SRC/'repair_seeds.txt').read_text().split()));seeds=[];pos=1
 for j in range(words[0]):
  n=words[pos];pos+=1;seeds.append(words[pos:pos+n]);pos+=n
 need(pos==len(words)and len(seeds)==6,'Malformed seeds')
 original=[term(p)for p in ps];centered=[term(p,True)for p in ps]
 eval1=[evalpoly(q,1)for q in original]
 for p,q,c,e in zip(ps,original,centered,eval1):
  independent=(-1)**sum(p[i]>p[j]for i in range(6)for j in range(i+1,6))
  for i,k in enumerate(p):independent*=(i+1)**k
  need(e==independent,'Direct product evaluation mismatch')
  for k in range(16):
   translated=sum(q[j]*2**(15-j)*comb(j,k)*(-5)**(j-k)for j in range(k,16))
   need(c[k]==translated,'Centered change-of-variable mismatch')
 need(add(original)==(34560,)+(0,)*15,'Full Vandermonde identity failed')
 p=1000000000039
 need(all(p%d for d in range(2,isqrt(p)+1)),'Primary modulus composite')
 need(6**26<p*p,'Primary modular minor bound insufficient')
 scalar_bound=720*6**15
 need(scalar_bound<2**63,'64-bit arithmetic bound fails')
 primary=[json.loads(x)for x in (SRC/'AFFINE_REPAIR_RESULT.jsonl').read_text().splitlines()]
 primarysurv=[json.loads(x)for x in (SRC/'affine_repair_survivors.jsonl').read_text().splitlines()]
 reports=[];all_surv=[];geometry=[]
 for sid,seed in enumerate(seeds):
  need(len(seed)==24 and len(set(seed))==24,'Malformed seed membership')
  need(not any(add([original[i]for i in seed])),'Seed does not cancel')
  R,piv=sp.Matrix([H[i]for i in reversed(seed)]).rref()
  rank=len(piv);R=R[:rank,:];free=[k for k in range(26)if k not in piv]
  residual=[]
  for h in H:
   v=[sp.Rational(h[k])-sum(h[t]*R[l,k]for l,t in enumerate(piv))for k in free]
   need(all(x.q==1 for x in v),'Nonintegral quotient requires generalized handling')
   residual.append(tuple(map(int,v)))
  core=[i for i,v in enumerate(residual)if not any(v)]
  union={(r,ps[i][r])for i in seed for r in range(6)}
  supported=[i for i,p in enumerate(ps)if all((r,p[r])in union for r in range(6))]
  need(core==supported,'Core differs from complete union-support matching family')
  groups={}
  for i,v in enumerate(residual):
   if any(v):groups.setdefault(primitive(v),[]).append(i)
  # Order by vector, not primary's least permutation index.
  blocks=sorted(groups.items());dirs=[x[0]for x in blocks];members=[x[1]for x in blocks]
  qp=[add([original[i]for i in ids])for ids in members]
  qe=[sum(eval1[i]for i in ids)for ids in members]
  cq=add([original[i]for i in core]);ce=sum(eval1[i]for i in core)
  lines={}
  for a,b in combinations(range(len(dirs)),2):
   key=signature(dirs[a],dirs[b]);line=lines.setdefault(key,set());line.add(a);line.add(b)
  sizes=Counter();rankcounts=Counter();survivors=[];zero=[];maxsig=max(abs(v)for k in lines for row in k for v in row)
  # Every pair contained in each line must regenerate precisely the same signature.
  # Counting all pair contributions is a separate completeness/duplicate check.
  need(sum(comb(len(line),2)for line in lines.values())==comb(len(dirs),2),'Pair partition failed')
  memberhash=hashlib.sha256()
  def check(extra):
   ids=sorted(core+[i for b in extra for i in members[b]])
   r=rank+(0 if not extra else 1 if len(extra)==1 else 2)
   sizes[len(ids)]+=1;rankcounts[r]+=1
   memberhash.update((','.join(map(str,ids))+'\n').encode())
   e=ce+sum(qe[b]for b in extra)
   if e:return
   q=add([cq]+[qp[b]for b in extra])
   need(evalpoly(q,1)==0,'Evaluation filter mismatch')
   c=add([centered[i]for i in ids])
   rec={'seed':sid,'rank':r,'members':ids,'original_coefficients':q,'centered_coefficients':c}
   survivors.append(rec)
   if not any(q):zero.append(rec)
   # Rational direct closure of every evaluation survivor, independent of quotient lines.
   Z,zp=sp.Matrix([H[i]for i in ids]).rref();Z=Z[:len(zp),:]
   closure=[]
   for j,h in enumerate(H):
    if all(sp.Rational(h[k])-sum(h[t]*Z[l,k]for l,t in enumerate(zp))==0 for k in range(26)):
     closure.append(j)
   need(closure==ids and len(zp)==r,'Survivor full720 exact closure mismatch')
  check([])
  for b in range(len(dirs)):check([b])
  for line in lines.values():check(sorted(line))
  row=primary[sid]
  expected={'core_size':len(core),'core_rank':rank,'rank_one_extensions':len(dirs),'rank_two_extensions':len(lines),'states':sum(sizes.values()),'eval1_zero_states':len(survivors),'zero_polynomial_states':len(zero),'size_distribution':{str(k):v for k,v in sorted(sizes.items())}}
  for k,v in expected.items():need(row[k]==v,f'Primary count differs: seed {sid} {k}')
  want={tuple(x['members']):tuple(x['centered_coefficients'])for x in primarysurv if x['seed']==sid}
  got={tuple(x['members']):tuple(x['centered_coefficients'])for x in survivors}
  need(got==want,'Primary survivor membership/coefficient mismatch')
  expected.update({'seed':sid,'rank_distribution':dict(rankcounts),'quotient_max_abs':max(abs(v)for h in residual for v in h),'canonical_two_span_max_abs':maxsig,'block_size_distribution':dict(Counter(map(len,members))),'line_point_count_distribution':dict(Counter(map(len,lines.values()))),'all_seed_coefficients_zero':True,'core_equals_union_support':True,'core_members':core,'core_original_coefficients':cq,'state_order_sha256':memberhash.hexdigest()})
  reports.append(expected);all_surv.extend(survivors);geometry.append({'seed':sid,'rref_pivots':piv,'rref_rows':[[int(x)for x in R.row(k)]for k in range(rank)],'free_columns':free})
  print(json.dumps(expected),flush=True)
 # Find explicit row/column relabelings from first seed to each seed.
 maps=[];source=[ps[i]for i in seeds[0]];p0=source[0]
 for sid,seed in enumerate(seeds):
  target={ps[i]for i in seed};found=None
  for r in ps:
   for q0 in target:
    c=[0]*6
    for i in range(6):c[p0[i]]=q0[r[i]]
    image=set()
    for s in source:
     q=[0]*6
     for i in range(6):q[r[i]]=c[s[i]]
     image.add(tuple(q))
    if image==target:found={'seed':sid,'row_map':r,'column_map':c};break
   if found:break
  need(found is not None,'No explicit seed geometric equivalence found')
  maps.append(found)
 # The six sets are precisely the seed-0 orbit under permuting the three
 # reflected row pairs and adding 3 modulo 6 to every column index.
 orbit={}
 for perm3 in permutations(range(3)):
  r=[0]*6
  for k in range(3):r[k]=perm3[k];r[5-k]=5-perm3[k]
  for shift in (0,3):
   transformed=[]
   for perm in source:
    q=[0]*6
    for k in range(6):q[r[k]]=(perm[k]+shift)%6
    transformed.append(idx[tuple(q)])
   key=tuple(sorted(transformed))
   orbit.setdefault(key,[]).append({'pair_permutation':perm3,'column_shift_mod6':shift})
 need(set(orbit)=={tuple(sorted(s))for s in seeds},'Six-set geometric orbit incomplete')
 for seed in seeds:
  for row in range(3):
   flipped=[]
   for i in seed:
    q=list(ps[i]);q[row],q[5-row]=q[5-row],q[row];flipped.append(idx[tuple(q)])
   need(set(flipped)==set(seed),'Seed is not invariant under an independent pair swap')
 orbit_records=[{'seed':next(k for k,s in enumerate(seeds)if tuple(sorted(s))==key),'transformations':v}for key,v in orbit.items()]
 out={'status':'PASS independent exact integer audit','scope':'Closed complete fibers containing one of the six listed seeds, augmented incidence rank at most 12; unrestricted n=6 remains unresolved.','primary_prime':p,'primary_prime_trial_division_passed':True,'six_to_26':6**26,'primary_prime_squared':p*p,'integer_scalar_abs_bound':scalar_bound,'seeds':reports,'explicit_geometric_relabelings':maps,'complete_six_seed_geometric_orbit':orbit_records,'elapsed_seconds':round(time.time()-start,3)}
 (O/'AUDIT_RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
 (O/'EXACT_GEOMETRY.json').write_text(json.dumps(geometry,indent=2)+'\n')
 (O/'EXACT_SURVIVORS.json').write_text(json.dumps(all_surv,indent=2)+'\n')
 print('PASS',out['elapsed_seconds'],flush=True)
if __name__=='__main__':main()
