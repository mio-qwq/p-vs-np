# Independent audit: six-row bounded completion obstruction

19 October 2026. Verdict: **PASS for the stated bounded, seed-conditioned result.** This is an independently reproduced finite calculation, not a proof of unrestricted six-row noncancellation or a complexity-theoretic result. No repository, merge, or release was changed.

## Accepted statement

Index the 720 permutations of 0,...,5 lexicographically, and put

    f_p(L) = sign(p) product_(i=0)^5 (L+i)^(p(i)).

Let S be any of the six explicit 24-permutation subsets in `inputs/repair_seeds.txt`. Let F be an entire nonempty cost fiber of perfect matchings of any supported six-by-six bipartite graph, with arbitrary real edge costs. If S is contained in F and the augmented incidence rank of F is at most 12, then

    sum_(p in F) f_p(L) is not identically zero.

Each S has zero polynomial but is not itself a complete fiber. Its full-720 incidence closure C has 32 members and augmented rank 10, or affine dimension 9. The theorem excludes every completion of C by at most two additional independent affine directions. It does not merely test adding one or two permutations: closure may force many further members, and the enumerated families have up to 52 members.

The six seeds are specified inputs, not a proved catalogue of all zero subsets. Fibers containing none of them, and fibers of augmented rank 13 or larger, are outside the result.

## 1. Complete-fiber closure for arbitrary real costs and sparse support

Use the augmented permutation-incidence coordinates

    h_p = (1, 1[p(r)=c] for r,c=1,...,5) in Z^26.

The omitted row and column are recovered from the fixed row/column sums. Thus these coordinates preserve affine relations among the full 36-entry permutation matrices.

If h_q is in the linear span of {h_p : p in F}, its representing coefficients sum to one because the first coordinate of every h_p is one. It is therefore an affine combination of the full incidence vectors. Every unsupported edge has coordinate zero in all members of F, hence also in q. So q is supported. The same affine combination preserves the real cost value t, with no rationality assumption on the costs. Completeness forces q into F.

Consequently every complete real-cost fiber is closed among all 720 points, even when the graph has missing edges. Deleting support cannot evade a forced outsider, since an outsider's incidence vector cannot gain a nonzero unsupported coordinate under an affine combination.

Conversely, every nonempty closed family C of this finite rational configuration is a full-support integer-cost fiber. Set V=span{h_p:p in C}. Choose a rational vector a in V-perpendicular that avoids h_q-perpendicular for each q outside C. Each excluded condition is a proper subspace because h_q is not in V; finitely many proper rational subspaces cannot cover V-perpendicular. Clear denominators. Writing a=(a0,a_rc), set w(r,c)=a_rc on the retained five-by-five block and zero elsewhere, with target -a0. This realizes exactly C. This converse is useful for interpreting the enumerated closed sets as actual complete fibers, although necessity alone proves the obstruction.

## 2. The 26-dimensional modular bound is valid

The primary implementation uses the upper-left rather than lower-right five-by-five block; either has dimension 26 after augmentation. Every original incidence row has at most six ones. Every k-by-k minor, k<=26, has absolute determinant at most

    6^(k/2) <= 6^13 = 13,060,694,016.

The primary prime is p=1,000,000,000,039, which exceeds this bound. Independent exhaustive trial division through floor(sqrt(p)) verifies primality. The audit also verifies the equivalent squared inequality

    6^26 = 170,581,728,179,578,208,256
           < p^2 = 1,000,000,000,078,000,000,001,521.

Hence no nonzero original incidence minor becomes zero modulo p, and every rank and span-membership test agrees over the finite field, rationals, and reals. Quotient-point proportionality and quotient-line membership are rank statements about the original incidence vectors, so the same bound covers them. Bounding entries of intermediate normalized modular quotient vectors is neither needed nor an appropriate substitute.

The audit does not depend on this modular argument: it uses rational RREF, then primitive integer quotient coordinates. For all six seeds those quotient coordinates are integral and bounded in absolute value by 2. The canonical two-row span signatures produced by the independent implementation have maximum absolute entry 3.

## 3. Complete independent rank-one and rank-two enumeration

The audit regenerates all 720 permutations and takes rational RREF of each seed in reversed insertion order using the lower-right coordinates. It computes all residues modulo the core span, projects onto the 16 nonpivot coordinates, and normalizes each nonzero integer residue by its gcd and the sign of its leading entry.

There are exactly 382 distinct projective directions, with block-size distribution

    size 1: 232 blocks
    size 2: 88 blocks
    size 4: 54 blocks
    size 8: 8 blocks.

Their members total 688, the complement of the 32-member core. Each rank-11 closed extension is precisely C plus one entire block, so all 382 are tested.

For rank 12, the audit uses a different canonicalization from the primary implementation. It enumerates all unordered pairs of the 382 directions, 72,771 pairs in total. For each independent pair a,b, it eliminates their first pivot, divides the second vector by its gcd, eliminates the second pivot from the first vector, and gcd-normalizes the first vector. With positive leading entries, this two-row signature is the uniquely scaled rational reduced-row-echelon representation of their two-dimensional span.

A dictionary keyed by this exact signature accumulates every direction occurring in any pair spanning that plane. This accumulates the entire intersection of that plane with the 382-point quotient configuration: if c lies in span(a,b), then some pair among (a,c),(b,c) spans the same plane, and that pair occurs in the enumeration. Thus each dictionary entry gives a complete closed rank-12 extension, not a partial subset of one.

Conversely, every rank-12 closed extension contains two independent quotient directions, and their pair occurs. Unique signatures prevent duplicates. The pair partition is independently checked:

    69,177 lines contain exactly 2 quotient points
     1,198 lines contain exactly 3 quotient points
    69,177 + 3 * 1,198 = 72,771 pairs
    69,177 + 1,198 = 70,375 lines.

This applies separately to every seed. The primary implementation instead anchors each line at one point, groups the other directions after quotienting by that anchor, and emits only from the least-index point of the line. Its guard is sound because the grouped block-index lists are constructed in increasing index order. Both algorithms enumerate the same geometric objects with different ordering and exact arithmetic.

## 4. Polynomial arithmetic and all surviving candidates

The audit independently generates every original-L term polynomial by binomial convolution. It also generates every centered-U term polynomial with offsets -5,-3,-1,1,3,5, and checks all coefficients against

    centered_p(U) = 2^15 f_p((U-5)/2).

It verifies the signed permutation products at L=1 directly and the full-family Vandermonde identity

    sum_(all 720 p) f_p(L) = 34,560.

No polynomial identity is inferred merely from Q(1)=0. Every enumerated state's value at L=1 is checked; all states surviving that necessary filter have all 16 original and centered coefficients computed. Every survivor also undergoes a separate rational full-720 closure/rank check from its member list.

The exact per-seed counts are:

- Seed 0: 70,758 states; 1 evaluation-zero survivor; 0 zero polynomials
- Seed 1: 70,758 states; 6 evaluation-zero survivors; 0 zero polynomials
- Seed 2: 70,758 states; 0 evaluation-zero survivors; 0 zero polynomials
- Seed 3: 70,758 states; 2 evaluation-zero survivors; 0 zero polynomials
- Seed 4: 70,758 states; 2 evaluation-zero survivors; 0 zero polynomials
- Seed 5: 70,758 states; 5 evaluation-zero survivors; 0 zero polynomials

Each 70,758 is 1 core + 382 rank-11 extensions + 70,375 rank-12 extensions. All 16 survivors have rank 12. Their exact memberships and both coefficient systems agree with the primary survivor records. Do not describe the sum across seeds as a count of distinct global families; no global deduplication is claimed.

A conservative signed-64-bit scalar/coefficient bound is

    720 * 6^15 = 338,533,188,894,720 < 2^63.

For original or centered term polynomials the coefficient l1 norm is at most 6^15, since the sum of all permutation exponents is 15 and every factor has coefficient l1 norm at most 6. This also bounds every original evaluation at L=1. Partial products and subset sums satisfy the same bound, so the primary signed coefficient arithmetic cannot overflow. Modular multiplication uses signed 128-bit intermediates and has absolute product below p^2, far below 2^127; modular subtraction is likewise safely bounded.

## 5. The six-seed orbit, and a limit on using symmetry

The six seed sets are exactly the orbit of seed 0 obtained by permuting the three reflected row pairs (0,5),(1,4),(2,3), together with the optional column map j -> j+3 modulo 6. The 6*2 group elements yield six distinct seed sets, each twice. Independent row swaps within each pair fix each seed, so adding those generators changes no seed set.

Explicit row/column relabelings and the complete 12-transformation check are retained in `AUDIT_RESULT.json`. These maps are incidence-geometry automorphisms; they explain identical closure and extension counts.

They must not by themselves be treated as polynomial symmetries for fixed offsets 0,...,5 and fixed exponent labels. The audit checks all six sets' zero identities and all six extension families separately. No transfer of noncancellation through an arbitrary row/column relabeling is used.

## 6. Is the result redundant with the paired-row theorem?

It is not entirely redundant. The rank-10 cores are paired families, but each seed has 232 rank-11 extensions of size 33. A family invariant under all three independent reflected row swaps is a disjoint union of eight-element permutation orbits, so its size is divisible by 8. These 33-member complete fibers cannot meet that invariance hypothesis. Thus the new bounded obstruction genuinely tests some unpaired complete fibers.

Its scope remains sharply local. It neither exhausts unpaired six-row fibers nor supplies a universal structural invariant. It establishes that these six known false zero candidates cannot be repaired within two additional affine dimensions. That is useful rejection evidence, not a global six-row theorem.

## Reproduction and evidence

Requires Python 3 and SymPy. Run from any directory:

    python audit_exact.py --output NEW_REPLAY
    python -O audit_exact.py --output NEW_OPTIMIZED_REPLAY

The script reads only the copied seed memberships to generate the mathematical candidates. Copied primary aggregates and survivors are used solely as comparison targets after independent computation. It does not import the primary search code or use primary quotient blocks or line catalogues. All correctness checks use explicit exceptions, not optimization-removable assertions.

Evidence files:

- `audit_exact.py`: separately written exhaustive checker
- `inputs/repair_seeds.txt`: the six specified seed memberships
- `AUDIT_RESULT.json`: complete counters, geometry summaries, exact bounds, and orbit maps
- `EXACT_GEOMETRY.json`: rational-RREF pivot/row certificates
- `EXACT_SURVIVORS.json`: all 16 evaluation survivors with original and centered coefficients
- `AUDIT_RUN.log`, `AUDIT_OPTIMIZED_RUN.log`: ordinary and optimized execution receipts
- `SHA256SUMS.txt`: hashes of retained source, inputs, and reports

The required output-directory argument directs all generated JSON into a separate chosen directory; replay does not alter the retained inputs. The optimized replay reproduces the same deterministic state hashes and counts. Runtime is descriptive, not a mathematical bound. The original source provenance is `/workspace/shared/unpaired-six-search-20261019`; these local audit paths are for research coordination, not a public distribution URL.
