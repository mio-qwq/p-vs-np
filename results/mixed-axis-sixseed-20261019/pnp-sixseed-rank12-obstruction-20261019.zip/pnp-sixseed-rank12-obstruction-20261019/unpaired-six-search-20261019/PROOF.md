# Six-row unpaired searches and a bounded affine-repair obstruction

19 October 2026. Local finite mathematics and bounded exploration. No repository, pull request, merge, release, or external service was changed. This does not settle the unrestricted six-row question or P versus NP. The primary bounded exhaustion, independent survivor checks, and a separately implemented exact-rational/integer full extension audit all pass. The separate audit is in `../unpaired-six-extension-audit-20261019`. This is AI-assisted finite mathematics, not external peer review or proof-assistant formalization.

## 1. Result and limits

For a permutation p of 0,...,5 define

    f_p(L) = sign(p) product_i (L+i)^(p(i)).

No cancelling nonempty complete fiber was found.

The most useful negative result is stronger than a collection of random trials. The six previously known 24-permutation polynomial-zero subsets, saved as standalone lexicographic permutation IDs in `repair_seeds.txt`, each have a full 720-point incidence closure of size 32 and augmented rank 10. For each such core, the primary search enumerated every closed extension of augmented rank at most 12, without imposing any row-pair invariance. Every resulting polynomial is nonzero.

Consequently, any cancelling complete real-additive-cost fiber that contains one of these six specific 24-term subsets must have augmented incidence rank at least 13, equivalently affine dimension at least 12. Throughout, augmented rank is affine dimension plus one. The conclusion concerns fibers containing these seeds; it is not a lower bound for all possible six-row cancelling fibers. It does not exclude rank 13 or higher repairs. There is no cardinality cutoff in the rank-at-most-12 exhaustion.

Separately, 376,770 structured or seeded small-integer configurations produced 2,277,447 nonempty fiber occurrences and no zero polynomial. Configurations and fibers can repeat within and between families. This is a bounded search, not an exhaustive search of arbitrary costs.

## 2. Full incidence closure and arithmetic

The primary representation is

    h_p = (1, indicator[p(i)=j] for 0<=i,j<5) in Z^26.

Fixed row and column sums recover omitted incidence entries, so linear span of augmented vectors is the same condition as affine span of full permutation matrices. Each h_p has at most six ones. Every square minor of any matrix of these rows has absolute value at most 6^(26/2), by Hadamard. The primary modulus is 1000000000039. The independent verifier trial-divides this number through its square root and checks

    6^26 < 1000000000039^2.

Thus every rank or span-membership comparison modulo the primary prime is exact over the rationals and reals. Quotient projective membership is also a rank statement in the original vectors. Modular products use signed 128-bit arithmetic; reduced residues and differences are safely stored in signed 64-bit integers.

Every complete supported cost fiber is affine-closed among all 720 points: an affine-forced point uses no edge absent from the union of the fiber and has the same additive cost. This implication does not assume paired support or paired costs. Conversely, any finite affine-closed subset can be realized by integer additive costs on full support: choose a rational functional annihilating all member differences while avoiding the finitely many hyperplanes imposed by outside points, then clear denominators. This converse is useful context but is not needed for the repair obstruction.

The independent checks use lower-right 5-by-5 incidence coordinates, reversed basis insertion, and the different certified prime 1000000000061. They recover all six seed closures and check all retained scalar survivors against all 720 points.

## 3. Exact exhaustion of repairs with two new affine directions

For each seed, close it among all 720 permutations to obtain C of augmented rank 10. Reduce every h_p modulo span(C), discard zero residues, and group nonzero residues by proportionality. This yields 382 projective blocks. Each block B obeys

    closure(C union {p}) = C union B for p in B.

All rank-11 closed extensions of C therefore appear exactly once as C union B.

For every projective block a, reduce every other block direction modulo a, and group the resulting nonzero residues by proportionality. Each group together with a consists of all projective blocks on one two-dimensional quotient subspace. Its union with C is exactly a rank-12 closed extension. Order base blocks by their least original permutation ID. Retain a group only when all its other block indices exceed a. Thus the extension is generated only from its least base block. Every rank-12 extension is generated, because it has a least block and every remaining direction on its quotient line is in that unique proportional-residue group. No extension is generated twice for the same seed.

The algorithm does not assume polynomial symmetry in these extensions. It includes one-point blocks and fully asymmetric additions. In particular, each core has 232 one-point blocks, giving 232 size-33 rank-11 closed families. Their odd cardinality alone places them outside the three-independent-row-pair orbit model, whose nonempty families have cardinality divisible by eight. It does not use floating-point decisions, optimization results, scalar pruning, time limits, or node limits. It merely evaluates every generated closed family and checks all 16 polynomial coefficients whenever evaluation at L=1 is zero.

For each of the six seeds:

- Original zero subset: 24 permutations
- Full incidence closure C: 32 permutations, augmented rank 10
- Rank-11 extensions: 382
- Rank-12 extensions: 70,375
- Total closed states including C: 70,758
- Polynomial-zero states: 0

The six Q(1)=0 survivor counts are respectively 1, 6, 0, 2, 2, and 5. All 16 survivors have augmented rank 12. The total is 424,548 seed-relative states; states from different seeds are not asserted distinct. Membership sizes range from 32 to 52.

## 4. Structured costs and support searches

`search_structured.cpp` checks these exact finite parameter lists:

1. Reflected antisymmetric binary costs: choose independently the 18 bits w(i,j) for i=0,1,2; set w(5-i,j)=-w(i,j). Enumerate all 262,144 matrices and every nonempty cost fiber. Results: 1,773,088 nonempty fibers; 132 have Q(1)=0; none cancels.
2. Normalized ternary rank-one costs: w(i,j)=a_i b_j, with a_0=b_0=0 and all other a_i,b_j in {0,1,2}. Enumerate all 59,049 parameter pairs. Results: 334,133 fibers; 135 Q(1)=0; none cancels.
3. Distinct-row rank-one costs: w(i,j)=i b_j, with each b_j in {0,1,2,3}. Enumerate all 4,096 choices. Results: 78,556 fibers; no Q(1)=0.
4. Ternary circulant costs: w(i,j)=b_((i+j) mod 6), with each b_j in {0,1,2}. Enumerate all 729 choices. Results: 7,473 fibers; no Q(1)=0.
5. Cyclic three-column supports: independently choose a starting column b_i in {0,...,5} for each row and support b_i,b_i+1,b_i+2 modulo six. All supported edges have cost zero. Enumerate all 46,656 supports. Results: 39,840 nonempty fibers; 38 Q(1)=0; none cancels.
6. A fixed bounded sample of 4,096 general matrices with entries in {-1,0,1}, generated by the saved unsigned 64-bit xorshift procedure and seed. Results: 44,357 fibers; seven Q(1)=0; none cancels. This sample is not an exhaustive ternary search.

The raw unequal-row count and the count genuinely outside the reflected paired hypotheses are retained separately. For costs, a row-pair difference that is constant across columns can be removed by row gauges without changing fibers, so it does not qualify as genuinely unpaired. Counts genuinely outside the reflected pair hypothesis are, in the order above: 262,136; 56,628; 4,092; 726; 46,440; 4,096. For support searches this means the support is not pair-invariant.

A separate reversal-invariant MILP route received a 25-second solver time limit and returned no incumbent. It contributed no mathematical exclusion result and no candidate. Its full status is retained in `REVERSAL_RESULT.json`. No larger random or indefinite solver run was undertaken.

## 5. Polynomial checks, a concrete false positive, and audit coverage

The C++ searches construct

    C_p(U) = 2^15 f_p((U-5)/2)

by repeated multiplication of integer linear factors. Evaluations at L=1 are independently computed directly as signed integer products. A nonzero evaluation proves the polynomial is nonzero; a zero evaluation triggers comparison of every one of the 16 coefficients.

`verify_results.py` independently generates original-L polynomials by convolution with binomial expansions, then translates them exactly to U. It verifies direct products at seven integer arguments for all 720 terms and verifies that the sum of all terms is the constant 34560. It reconstructs every structured scalar survivor from its explicit matrix/support and checks complete membership against all 720 permutations. It also checks full incidence closure for all 312 structured survivors and all 16 repair survivors. All 328 full coefficient comparisons pass and all polynomials are nonzero.

Maximum sum of absolute values of any centered coefficient over all terms is 21,987,534,708. The sum of absolute Q(1) term values is 159,676,348,608. Every subset sum used by the searches is consequently safely inside signed 64-bit range.

`EXPLICIT_NONCANCELLING_FIBER.json` gives a full-support integer cost certificate for a genuinely unpaired 34-member, rank-12 fiber with Q(1)=0. Its target cost is 6282 and its cost matrix is

    -4470 -4470 -4470    1    2  0
        4  2048  2048 2480 8192  0
        8    16    32  512 8192  0
       64   128   256  512 8192  0
     1024  2048  2048 4096 8192  0
        0     0     0    0    0  0

Its exact polynomial is

    -(L-1)(L+1)^2(L+4)^2 times
    (4L^9 + 134L^8 + 1903L^7 + 15135L^6 + 74060L^5
     + 228935L^4 + 439655L^3 + 493730L^2 + 286740L + 68040).

This is an explicit warning that evaluation at L=1 alone is insufficient. It is not a counterexample. Its full cost membership and coefficient lists are independently checked by `verify_results.py`.

The independent survivor verifier is not an independent complete re-enumeration of all structured parameter values or all affine extensions. The separate full extension audit supplies that stronger check for all six core-extension exhaustions. It regenerates lower-right exact rational RREF geometry, orders primitive integer quotient directions by vector value, and classifies every unordered pair by the canonical exact two-dimensional RREF signature of its span. It uses no modular geometry. For each seed, all 72,771 unordered pairs of the 382 directions partition into 69,177 two-point lines and 1,198 three-point lines, giving 70,375 rank-two extensions. The identity 69,177 + 3*1,198 = 72,771 accounts for every pair. Its aggregate counts and size distributions match the primary results. Full polynomial coefficients, memberships, and ranks of all 16 scalar survivors also match. See `../unpaired-six-extension-audit-20261019/AUDIT_RESULT.json`. This independent audit does not re-enumerate the separate structured-cost searches. Normal and undefined-behavior-sanitized primary replays match byte-for-byte on aggregate counts, survivor records, and empty candidate files. Normal and optimized-Python survivor checks agree. Separate mutation controls reject a corrupted centered coefficient, corrupted seed membership, corrupted integer-cost certificate, and a rank modulus too small for the determinant bound; see `NEGATIVE_CONTROLS.json`.

## 6. Reproduction and recovery

From this directory:

    g++ -std=c++17 -O3 search_structured.cpp -o search_structured
    ./search_structured > STRUCTURED_RESULT.jsonl
    g++ -std=c++17 -O3 search_affine_repairs.cpp -o search_affine_repairs
    ./search_affine_repairs > AFFINE_REPAIR_RESULT.jsonl
    python verify_results.py
    python negative_controls.py

The two searches and independent verifier require a C++17 compiler with signed 128-bit extension and standard-library Python. The optional bounded MILP script requires NumPy and SciPy; it is not part of the negative exhaustion proof. Saved inputs are standalone, and the primary searches read no sibling research directory.

Suspend the rank-at-most-12 repair conclusion if any seed fails exact polynomial cancellation, any full closure changes, the rank modulus bound fails, a quotient block is missing, a projective line is omitted or incorrectly grouped, canonical least-block selection drops a line, an arithmetic discrepancy appears, or a polynomial-zero state is found. Retain the full membership, seed ID, rank, generating block or line, all original and centered coefficients, and every omitted/forced permutation.

A future productive continuation must either examine other seeds or allow at least three new independent affine directions above these six cores. Merely selecting another nonclosed 24-term zero subset or another Q(1)=0 fiber does not solve the complete-fiber problem. No claim is made that any such continuation must succeed.
