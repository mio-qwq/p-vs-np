"""Mutation controls for the independent replay; all modified inputs are temporary."""
import json,subprocess,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent
inputs=['repair_seeds.txt','structured_survivors.jsonl','affine_repair_survivors.jsonl','EXPLICIT_NONCANCELLING_FIBER.json']
cases=[('corrupt_centered_coefficient','C++ centered coefficients differ'),('corrupt_seed_membership','Seed is not polynomial-zero'),('corrupt_integer_cost_certificate','Explicit example cost certificate fails'),('insufficient_rank_modulus','Rank modulus fails determinant bound')]
results=[]
for name,expected in cases:
 with tempfile.TemporaryDirectory(prefix='control-',dir=D)as tmp:
  target=Path(tmp)
  for f in inputs:(target/f).write_bytes((D/f).read_bytes())
  source=(D/'verify_results.py').read_text()
  if name=='corrupt_centered_coefficient':
   p=target/'structured_survivors.jsonl';lines=p.read_text().splitlines();row=json.loads(lines[0]);row['centered_coefficients'][0]+=1;lines[0]=json.dumps(row);p.write_text('\n'.join(lines)+'\n')
  elif name=='corrupt_seed_membership':
   p=target/'repair_seeds.txt';lines=p.read_text().splitlines();row=list(map(int,lines[1].split()));row[0]-=1;row.pop();lines[1]=' '.join(map(str,row));p.write_text('\n'.join(lines)+'\n')
  elif name=='corrupt_integer_cost_certificate':
   p=target/'EXPLICIT_NONCANCELLING_FIBER.json';row=json.loads(p.read_text());row['target_cost']+=1;p.write_text(json.dumps(row)+'\n')
  else:source=source.replace('M=1000000000061','M=3')
  (target/'verify_results.py').write_text(source)
  run=subprocess.run([sys.executable,'-O',str(target/'verify_results.py')],capture_output=True,text=True)
  if run.returncode==0 or expected not in run.stderr:raise RuntimeError(f'{name}: mutation was not rejected in the expected way: {run.stderr}')
  results.append({'control':name,'rejected':True,'reason':expected});print(json.dumps(results[-1]),flush=True)
(D/'NEGATIVE_CONTROLS.json').write_text(json.dumps({'status':'passed','controls':results},indent=2)+'\n')
