"""Bounded candidate generation. Solver outcomes are never proof of exclusion."""
import itertools,json,math,time
from pathlib import Path
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import csr_matrix,vstack
D=Path(__file__).resolve().parent
ps=list(itertools.permutations(range(6))); pi={p:i for i,p in enumerate(ps)}
def poly(p,shift=0,scale=1):
 a=[(-1)**sum(p[i]>p[j] for i in range(6) for j in range(i+1,6))]
 for i,e in enumerate(p):
  for _ in range(e):
   b=[0]*(len(a)+1)
   for k,x in enumerate(a): b[k]+=(scale*i+shift)*x;b[k+1]+=x
   a=b
 return a
P0=[poly(p,-5,2) for p in ps]
seen=set();groups=[]
for i,p in enumerate(ps):
 if i in seen: continue
 j=pi[p[::-1]];groups.append([i,j]);seen|={i,j}
n=len(groups);gi={j:k for k,g in enumerate(groups) for j in g}
P=np.array([[sum(P0[j][k] for j in g) for g in groups] for k in range(16)],dtype=np.int64)
H=[[1]+[int(p[r]==c) for r in range(5) for c in range(5)] for p in ps]
MOD=1000000000039
if not 6**26<MOD**2 or any(MOD%d==0 for d in range(2,math.isqrt(MOD)+1)):raise RuntimeError('Invalid exact-rank modulus')
def closure(ids):
 B=[];chosen=[]
 for ix in ids:
  a=H[ix][:]
  for pivot,b in B:
   z=a[pivot]
   if z:a=[(x-z*y)%MOD for x,y in zip(a,b)]
  piv=next((k for k,x in enumerate(a) if x),None)
  if piv is not None:
   inv=pow(a[piv],-1,MOD);B.append((piv,[x*inv%MOD for x in a]));chosen.append(ix)
 out=[]
 for ix,h in enumerate(H):
  a=h[:]
  for pivot,b in B:
   z=a[pivot]
   if z:a=[(x-z*y)%MOD for x,y in zip(a,b)]
  if not any(a):out.append(ix)
 return out,chosen
rows=[]
for row in P:
 g=math.gcd(*map(int,row))
 if g:rows.append(row.astype(float)/g)
A=csr_matrix(rows);lo=np.zeros(len(rows));hi=lo.copy()
A=vstack([A,csr_matrix(np.ones((1,n)))]).tocsr();lo=np.r_[lo,1.];hi=np.r_[hi,np.inf]
start=time.monotonic();history=[];found=None
for it in range(8):
 res=milp(np.ones(n)+np.arange(n)*1e-7,integrality=np.ones(n),bounds=Bounds(0,1),constraints=LinearConstraint(A,lo,hi),options={'time_limit':25,'mip_rel_gap':0})
 if res.x is None:
  history.append({'iteration':it,'solver_status':int(res.status),'message':res.message});break
 gids=[j for j,x in enumerate(res.x) if x>.5];ids=sorted(j for k in gids for j in groups[k]);exact=[sum(P0[j][k] for j in ids) for k in range(16)]
 if any(exact):
  history.append({'iteration':it,'status':'numerically_proposed_subset_fails_exact_polynomial','members':ids,'centered_coefficients':exact,'solver_status':int(res.status)});break
 cl,bas=closure(ids);outs=sorted(set(cl)-set(ids));entry={'iteration':it,'solver_status':int(res.status),'members':ids,'permutations':[''.join(map(str,ps[j])) for j in ids],'cardinality':len(ids),'basis':bas,'incidence_rank':len(bas),'closure':cl,'closure_size':len(cl),'outsiders':outs,'all_16_centered_coefficients_zero':True}
 if outs:
  target=outs[0];witness=None
  for a,b in itertools.combinations(ids,2):
   for c in ids:
    if all(H[a][k]+H[b][k]-H[c][k]==H[target][k] for k in range(26)):
     witness=[a,b,c];break
   if witness:break
  entry['three_term_affine_outsider_witness']=None if witness is None else {'outsider':target,'positive':witness[:2],'negative':witness[2]}
 history.append(entry)
 print(json.dumps({'iteration':it,'cardinality':len(ids),'closure_size':len(cl),'incidence_rank':len(bas),'elapsed':round(time.monotonic()-start,2)}),flush=True)
 if not outs:found=entry;break
 bg=sorted(set(gi[j] for j in bas));new=[]
 for qg in sorted(set(gi[j] for j in outs)):
  row=np.zeros(n);row[bg]=1;row[qg]=-1;new.append(row)
 A=vstack([A,csr_matrix(new)]).tocsr();lo=np.r_[lo,np.full(len(new),-np.inf)];hi=np.r_[hi,np.full(len(new),len(bg)-1)]
 (D/'REVERSAL_PROGRESS.json').write_text(json.dumps({'history':history},indent=2)+'\n')
 if time.monotonic()-start>160:break
report={'scope':'At most eight solver calls, 25 seconds each; no numerical solver outcome is an exclusion proof. Every proposed exact-zero subset is tested against all 720 incidence vectors.','groups':groups,'modulus':MOD,'hadamard_bound_check':'6^26 < modulus^2; modulus trial-divided through square root','history':history,'found':found,'elapsed_seconds':time.monotonic()-start}
(D/'REVERSAL_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'finished':True,'found':bool(found),'iterations':len(history),'elapsed':report['elapsed_seconds']}),flush=True)
