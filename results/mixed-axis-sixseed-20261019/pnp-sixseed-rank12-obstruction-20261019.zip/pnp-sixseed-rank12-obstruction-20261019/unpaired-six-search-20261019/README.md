# Unpaired six-row bounded search

No cancelling complete fiber found. The substantive scoped result is a rank-at-most-12 repair obstruction for the six saved 24-term zero seeds, using the full 720-point incidence model.

- `PROOF.md`: scope, exact enumeration, counts, recovery conditions
- `search_affine_repairs.cpp`, `repair_seeds.txt`: standalone primary bounded exhaustion
- `AFFINE_REPAIR_RESULT.jsonl`: six complete per-seed receipts
- `search_structured.cpp`, `STRUCTURED_RESULT.jsonl`: bounded cost/support families
- `verify_results.py`, `INDEPENDENT_CHECKS.json`: independent full-coefficient and full-incidence checks of all 328 scalar survivors
- `EXPLICIT_NONCANCELLING_FIBER.json`: genuinely unpaired integer-cost fiber with Q(1)=0 but nonzero polynomial
- `SANITIZED/`: undefined-behavior-sanitized deterministic replay
- `search_reversal_milp.py`, `REVERSAL_RESULT.json`: unsuccessful bounded solver attempt, not a proof premise

The full separate extension audit is in the sibling `unpaired-six-extension-audit-20261019` directory. Nothing here establishes an unrestricted six-row theorem or complexity separation. No external writes were made.
