#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;using V=array<int64_t,26>;using P=array<int64_t,16>;
const int64_t M=1000000000039LL;
int64_t mul(int64_t a,int64_t b){return (__int128)a*b%M;}
int64_t power(int64_t a,int64_t n){int64_t out=1;for(;n;n>>=1,a=mul(a,a))if(n&1)out=mul(out,a);return out;}
void sub(V&a,const V&b,int64_t z){for(int k=0;k<26;k++){a[k]-=mul(z,b[k]);if(a[k]<0)a[k]+=M;}}
int pivot(const V&a){for(int k=0;k<26;k++)if(a[k])return k;return -1;}
void norm(V&a){int p=pivot(a);if(p<0)return;int64_t inv=power(a[p],M-2);for(auto&x:a)x=mul(x,inv);}
struct Term {V h{};P q{};int64_t ev=0;};vector<Term>T;
void init(){array<int,6>p={0,1,2,3,4,5};do{Term t{};t.h[0]=1;for(int i=0;i<5;i++)for(int j=0;j<5;j++)t.h[1+i*5+j]=p[i]==j;int inv=0;for(int i=0;i<6;i++)for(int j=i+1;j<6;j++)inv+=p[i]>p[j];int sign=inv%2?-1:1;t.q[0]=sign;int deg=0;for(int i=0;i<6;i++)for(int z=0;z<p[i];z++){for(int k=deg+1;k>=0;k--)t.q[k]=(k?t.q[k-1]:0)+(2*i-5)*(k<=deg?t.q[k]:0);deg++;}t.ev=sign;for(int i=0;i<6;i++)for(int z=0;z<p[i];z++)t.ev*=i+1;T.push_back(t);}while(next_permutation(p.begin(),p.end()));}
struct Block {V v;vector<int> ids;P q{};int64_t ev=0;};
void add(P&a,const P&b){for(int k=0;k<16;k++)a[k]+=b[k];}
void emit(ofstream&f,int seed,int rank,const vector<int>&ids,const P&q){f<<"{\"seed\":"<<seed<<",\"rank\":"<<rank<<",\"members\":[";for(int k=0;k<(int)ids.size();k++){if(k)f<<',';f<<ids[k];}f<<"],\"centered_coefficients\":[";for(int k=0;k<16;k++){if(k)f<<',';f<<q[k];}f<<"]}\n";}
int main(){init();ifstream in("repair_seeds.txt");ofstream surv("affine_repair_survivors.jsonl"),cand("affine_repair_candidates.jsonl");int ns;in>>ns;for(int seed=0;seed<ns;seed++){int n;in>>n;vector<int>selected(n);for(int&i:selected)in>>i;vector<pair<int,V>>basis;for(int i:selected){V a=T[i].h;for(auto&pb:basis)sub(a,pb.second,a[pb.first]);int p=pivot(a);if(p>=0){norm(a);basis.push_back({p,a});}}map<V,vector<int>>gm;vector<int>core;P coreq{};int64_t coreev=0;for(int i=0;i<720;i++){V a=T[i].h;for(auto&pb:basis)sub(a,pb.second,a[pb.first]);if(pivot(a)<0){core.push_back(i);add(coreq,T[i].q);coreev+=T[i].ev;}else{norm(a);gm[a].push_back(i);}}vector<Block>blocks;for(auto&kv:gm){Block b{};b.v=kv.first;b.ids=kv.second;for(int i:b.ids){add(b.q,T[i].q);b.ev+=T[i].ev;}blocks.push_back(b);}sort(blocks.begin(),blocks.end(),[](const Block&a,const Block&b){return a.ids.front()<b.ids.front();});uint64_t states=1,rankone=0,ranktwo=0,evalzero=0,polyzero=0;map<int,uint64_t>sizes;sizes[core.size()]++;
auto check=[&](const vector<int>&extra,const P&q,int64_t ev,int rank){if(ev)return;evalzero++;vector<int> ids=core;for(int k:extra)ids.insert(ids.end(),blocks[k].ids.begin(),blocks[k].ids.end());sort(ids.begin(),ids.end());emit(surv,seed,rank,ids,q);if(all_of(q.begin(),q.end(),[](int64_t z){return z==0;})){polyzero++;emit(cand,seed,rank,ids,q);}};
check({},coreq,coreev,basis.size());for(int a=0;a<(int)blocks.size();a++){P q=coreq;add(q,blocks[a].q);check({a},q,coreev+blocks[a].ev,basis.size()+1);states++;rankone++;sizes[core.size()+blocks[a].ids.size()]++;int p=pivot(blocks[a].v);map<V,vector<int>>lines;for(int b=0;b<(int)blocks.size();b++){if(b==a)continue;V v=blocks[b].v;sub(v,blocks[a].v,v[p]);if(pivot(v)<0)abort();norm(v);lines[v].push_back(b);}for(auto&kv:lines){auto ids=kv.second;if(ids.front()<a)continue;ids.push_back(a);P qq=coreq;int64_t ev=coreev;int size=core.size();for(int k:ids){add(qq,blocks[k].q);ev+=blocks[k].ev;size+=blocks[k].ids.size();}states++;ranktwo++;sizes[size]++;check(ids,qq,ev,basis.size()+2);}}
cout<<"{\"seed\":"<<seed<<",\"seed_members\":"<<n<<",\"core_size\":"<<core.size()<<",\"core_rank\":"<<basis.size()<<",\"rank_one_extensions\":"<<rankone<<",\"rank_two_extensions\":"<<ranktwo<<",\"states\":"<<states<<",\"eval1_zero_states\":"<<evalzero<<",\"zero_polynomial_states\":"<<polyzero<<",\"size_distribution\":{";bool first=true;for(auto&kv:sizes){if(!first)cout<<',';first=false;cout<<'"'<<kv.first<<"\":"<<kv.second;}cout<<"}}"<<endl;}}
