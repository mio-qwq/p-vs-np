"""Independent exact checks of every scalar survivor and the saved seed cores.
This does not independently enumerate every structured matrix or affine extension.
"""
import itertools,json,math,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
ps=list(itertools.permutations(range(6)))
def need(ok,msg):
 if not ok: raise RuntimeError(msg)
def conv(a,b):
 out=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return out
def original(p):
 a=[(-1)**sum(p[i]>p[j]for i in range(6)for j in range(i+1,6))]
 for i,e in enumerate(p):a=conv(a,[math.comb(e,k)*i**(e-k)for k in range(e+1)])
 return a
def centered(c):return [sum(c[d]*math.comb(d,k)*(-5)**(d-k)*2**(15-d)for d in range(k,16))for k in range(16)]
P=[original(p)for p in ps];C=[centered(c)for c in P]
EV=[sum(c)for c in P]
need([sum(c[k]for c in P)for k in range(16)]==[34560]+[0]*15,'Full Vandermonde identity fails')
for p,c in zip(ps,P):
 for x in [-7,-6,-2,0,1,2,3]:
  direct=(-1)**sum(p[i]>p[j]for i in range(6)for j in range(i+1,6))*math.prod((x+i)**e for i,e in enumerate(p))
  need(sum(a*x**k for k,a in enumerate(c))==direct,'Binomial coefficients disagree with direct products')
M=1000000000061
for modulus in [1000000000039,M]:
 need(all(modulus%d for d in range(2,math.isqrt(modulus)+1)),'Rank modulus not prime')
 need(6**26<modulus**2,'Rank modulus fails determinant bound')
need(6**26<M*M,'Insufficient determinant bound')
# Different coordinates from the C++ primary: lower-right five by five.
H=[[1]+[int(p[r]==c)for r in range(1,6)for c in range(1,6)]for p in ps]
def closure(ids):
 B=[]
 for j in reversed(ids):
  a=H[j][:]
  for piv,b in B:
   z=a[piv]
   if z:a=[(x-z*y)%M for x,y in zip(a,b)]
  piv=next((k for k,x in enumerate(a)if x),None)
  if piv is not None:
   z=pow(a[piv],-1,M);B.append((piv,[x*z%M for x in a]))
 out=[]
 for j,h in enumerate(H):
  a=h[:]
  for piv,b in B:
   z=a[piv]
   if z:a=[(x-z*y)%M for x,y in zip(a,b)]
  if not any(a):out.append(j)
 return out,len(B)
def aggregate(ids,table):return [sum(table[j][k]for j in ids)for k in range(16)]
seed_lines=(D/'repair_seeds.txt').read_text().splitlines();need(int(seed_lines[0])==len(seed_lines)-1,'Seed count mismatch');seeds=[]
for line in seed_lines[1:]:
 fields=list(map(int,line.split()));ids=fields[1:];need(fields[0]==len(ids),'Seed length mismatch');need(not any(aggregate(ids,P)),'Seed is not polynomial-zero');cl,rank=closure(ids);need(len(ids)==24 and len(cl)==32 and rank==10,'Seed core changed');need(any(aggregate(cl,P)),'Core unexpectedly zero');seeds.append({'members':ids,'closure':cl,'rank':rank,'original_coefficients':aggregate(cl,P)})
checks=[]
for filename in ['structured_survivors.jsonl','affine_repair_survivors.jsonl']:
 rows=[json.loads(line)for line in (D/filename).read_text().splitlines()];ranks={}
 for ri,row in enumerate(rows):
  ids=row['members'];need(sorted(set(ids))==ids,'Membership is not a sorted set')
  coeff=aggregate(ids,P);cen=aggregate(ids,C);need(row['centered_coefficients']==cen,'C++ centered coefficients differ from independent binomial translation')
  need(sum(coeff)==0,'Saved survivor does not vanish at L=1');need(any(coeff),'Found exact zero polynomial: requires cost certificate and independent review')
  cl,rank=closure(ids);need(cl==ids,'Saved affine-closed family is not closed in full 720 model');ranks[str(rank)]=ranks.get(str(rank),0)+1
  if 'family' in row:
   w=row['costs'];target=row['target'];actual=[j for j,p in enumerate(ps)if (all(w[i][p[i]]!=0 for i in range(6))if row['support']else sum(w[i][p[i]]for i in range(6))==target)]
   need(actual==ids,'Explicit cost/support certificate does not give exact complete fiber')
  else:
   need(rank==row['rank'],'Primary rank differs from independent rank');need(set(seeds[row['seed']]['closure'])<=set(ids),'Repair does not contain seed closure');need(rank<=12,'Repair exceeded search scope')
 checks.append({'file':filename,'exact_coefficient_checks':len(rows),'full720_incidence_closure_checks':len(rows),'augmented_rank_distribution':ranks})
 print(json.dumps(checks[-1]),flush=True)
example=json.loads((D/'EXPLICIT_NONCANCELLING_FIBER.json').read_text());w=example['explicit_full_support_integer_costs'];target=example['target_cost'];actual=[j for j,p in enumerate(ps)if sum(w[i][p[i]]for i in range(6))==target]
need(actual==example['members'],'Explicit example cost certificate fails')
need(aggregate(actual,P)==example['original_L_coefficients'],'Explicit example original coefficients fail')
need(aggregate(actual,C)==example['centered_coefficients'],'Explicit example centered coefficients fail')
need(sum(aggregate(actual,P))==0 and any(aggregate(actual,P)),'Explicit example should vanish at L=1 but not identically')
need(any(w[i][j]-w[5-i][j]!=w[i][0]-w[5-i][0]for i in range(3)for j in range(6)),'Example is gauge-equivalent to reflected paired costs')
report={'explicit_nonpaired_example_verified':True,'status':'passed','independently_reconstructed_terms':720,'direct_integer_evaluations_per_term':7,'independent_prime':M,'hadamard_check':'6^26 < prime^2','seeds':seeds,'survivor_checks':checks,'max_sum_absolute_centered_coefficient':max(sum(abs(c[k])for c in C)for k in range(16)),'sum_absolute_Q1':sum(map(abs,EV)),'scope':'Independent checks of all scalar survivors and seed closures, not independent complete re-enumeration of every matrix or rank-two extension.'}
(D/'INDEPENDENT_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','total_survivors':sum(x['exact_coefficient_checks']for x in checks)}),flush=True)
