#!/usr/bin/env python3
"""Canonical ZIP builder; fixed order, timestamp, Unix mode, compression."""
import argparse,stat
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import sys
sys.dont_write_bytecode=True
from reproduce import D,integrity,load,need
NAME='pnp-sixseed-rank12-obstruction-20261019'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('output',type=Path);args=ap.parse_args();integrity()
 out=args.output.resolve();need(out!=D and D not in out.parents,'Archive output must be outside source package')
 names=sorted([x['path']for x in load(D/'PNP_MANIFEST.json')['files']]+['PNP_MANIFEST.json'])
 with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=9)as z:
  for name in names:
   info=ZipInfo(NAME+'/'+name,(1980,1,1,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=ZIP_DEFLATED
   z.writestr(info,(D/name).read_bytes(),compress_type=ZIP_DEFLATED,compresslevel=9)
 print(str(out))
if __name__=='__main__':main()
