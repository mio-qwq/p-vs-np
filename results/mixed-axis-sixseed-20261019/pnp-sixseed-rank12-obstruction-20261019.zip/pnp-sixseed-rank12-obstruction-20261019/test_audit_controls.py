#!/usr/bin/env python3
"""Independent audit rejects corrupted seed, count, and coefficient inputs."""
import json,shutil,subprocess,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
from reproduce import D,A,ENV,need,integrity

def main():
 integrity();reports=[]
 cases=[('seed','Seed does not cancel'),('count','Primary count differs: seed 0 states'),('coefficient','Primary survivor membership/coefficient mismatch')]
 for mode,args in [('normal',[]),('optimized',['-O'])]:
  for case,expected in cases:
   with tempfile.TemporaryDirectory(prefix='pnp-audit-mutation-')as temp:
    root=Path(temp);shutil.copyfile(D/A/'audit_exact.py',root/'audit_exact.py');shutil.copytree(D/A/'inputs',root/'inputs')
    if case=='seed':
     p=root/'inputs'/'repair_seeds.txt';lines=p.read_text().splitlines();words=lines[1].split();words[-1]=str((int(words[-1])+1)%720);lines[1]=' '.join(words);p.write_text('\n'.join(lines)+'\n')
    elif case=='count':
     p=root/'inputs'/'AFFINE_REPAIR_RESULT.jsonl';lines=p.read_text().splitlines();row=json.loads(lines[0]);row['states']+=1;lines[0]=json.dumps(row);p.write_text('\n'.join(lines)+'\n')
    else:
     p=root/'inputs'/'affine_repair_survivors.jsonl';lines=p.read_text().splitlines();row=json.loads(lines[0]);row['centered_coefficients'][0]+=1;lines[0]=json.dumps(row);p.write_text('\n'.join(lines)+'\n')
    result=subprocess.run([sys.executable]+args+[str(root/'audit_exact.py'),'--output',str(root/'output')],env=ENV,capture_output=True,text=True)
    need(result.returncode!=0 and expected in result.stderr,'Audit mutation was not rejected as expected: '+case+'\n'+result.stderr)
    reports.append({'mode':mode,'mutation':case,'rejected':True,'reason':expected})
 print(json.dumps({'status':'PASS','negative_controls_rejected':len(reports),'controls':reports},sort_keys=True))
if __name__=='__main__':main()
