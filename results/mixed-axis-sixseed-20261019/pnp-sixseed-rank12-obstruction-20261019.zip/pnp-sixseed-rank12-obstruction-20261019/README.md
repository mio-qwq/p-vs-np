# Six saved seeds: rank-at-most-12 completion obstruction

This is a local, finite, seed-conditioned result. For the six saved 24-term
polynomial-zero permutation subsets, every complete cancelling cost fiber that
contains any one of them must have augmented incidence rank at least 13,
equivalently affine dimension at least 12. The result applies to arbitrary real
additive costs and sparse support because complete fibers are incidence-closed.
It does not give a global six-row bound, exhaust all zero subsets, exclude higher
rank repairs, or resolve P versus NP.

For each seed the closure has 32 members and rank 10. The complete rank-at-most-12
exhaustion checks 1 + 382 + 70,375 = 70,758 closed states, with no size cutoff.
Across six seeds this is 424,548 seed-relative states, not a globally deduplicated
count. All 16 evaluation-zero survivors have nonzero full polynomials. A separate
exact-rational/integer audit independently enumerates the same closed extensions.
The structured-cost searches are bounded negative exploration, not a new theorem.

## Contents and provenance

- `unpaired-six-search-20261019/PROOF.md`: preserved primary statement and proof.
- `unpaired-six-extension-audit-20261019/AUDIT.md`: preserved independent audit.
- Both exact checkers, six seeds, compact result summaries, exact geometry and
  survivor certificates, and the explicit noncancelling cost certificate.
- `PNP_MANIFEST.json`: authoritative package inventory and content hashes.
- `PNP_PIN_RECONCILIATION.json`: additive reconciliation of two historical audit
  hashes in the primary manifest. The accepted current audit is pinned here.
  No old manifest or original source file has been edited.

Original manifests and original logs are provenance records. Some of their paths
refer to omitted regenerable ledgers and replay directories. Their presence is
not a claim that every historical path is an archive member. Reproduction below
regenerates the structured survivor ledger and verifies its original SHA-256;
it also regenerates all primary counts and audit certificates. Binaries, the
structured survivor ledger, duplicate replay directories, and temporary controls
are excluded from the archive. Optional MILP exploration is preserved for context
but is not rerun and contributes no exclusion theorem.

## Offline reproduction

Prerequisites must already be installed: Python 3, SymPy, and a C++17 compiler
named `g++` with signed 128-bit support and UBSan. The checkpoint was verified
with Python 3.12.14, SymPy 1.14.0, and GCC 14.2.0. No network is needed.

From this package directory:

    python -B reproduce.py --integrity-only
    python -B reproduce.py --output /tmp/pnp-fresh-replay
    python -B test_package.py
    python -B test_audit_controls.py
    python -B build_archive.py /tmp/pnp-sixseed-rank12-obstruction-20261019.zip

The replay output path must not already exist and must be outside this package.
The default replay runs primary C++ at -O0, -O3, and with undefined-behavior
sanitization; each regenerated output must match the original SHA-256. Each
primary replay also runs the polynomial/closure verifier and its four mutation
controls under ordinary and optimized Python. Independent complete extension
replays run under ordinary and optimized Python; every mathematical audit field
must match, ignoring only elapsed_seconds. Exact geometry and survivor files
must match byte-for-byte. Use `--suite primary-normal`, `primary-optimized`,
`primary-ubsan`, `independent-normal`, or `independent-optimized` to run one suite.
All package and mathematical checks use exceptions, not removable assertions.

`test_package.py` corrupts every pinned file in turn, then tests a missing file
and an unlisted file. `test_audit_controls.py` separately corrupts independent
audit seed membership, an expected count, and a survivor coefficient in both
Python modes. Temporary controls never edit the retained source package.

ZIP member order, timestamp (1980-01-01), Unix regular-file mode (0644), and
compression settings are fixed. Rebuilding from an extracted package in the
same Python/zlib toolchain reproduces identical archive bytes. The external
archive checksum is the trust anchor for the included manifest.

No repository, PR, merge, release, or other external publication is included.
This is AI-assisted finite mathematics, not external peer review or a
proof-assistant formalization.
