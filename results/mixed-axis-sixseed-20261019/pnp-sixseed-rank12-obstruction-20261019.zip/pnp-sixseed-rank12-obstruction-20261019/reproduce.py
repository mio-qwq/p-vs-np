#!/usr/bin/env python3
"""Offline checked replay. All correctness checks survive python -O."""
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path, PurePosixPath
D=Path(__file__).resolve().parent
P='unpaired-six-search-20261019'; A='unpaired-six-extension-audit-20261019'
SUITES=['primary-normal','primary-optimized','primary-ubsan','independent-normal','independent-optimized']
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
ENV.pop('PYTHONOPTIMIZE',None)
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(data):return hashlib.sha256(data).hexdigest()
def load(p):return json.loads(p.read_text())
def normalized(report):
 report=dict(report);report.pop('elapsed_seconds',None);return report
def integrity(root=D):
 m=load(root/'PNP_MANIFEST.json');expected=set()
 for row in m['files']:
  name=row['path'];p=PurePosixPath(name)
  need(not p.is_absolute() and '..' not in p.parts and str(p)==name,'Unsafe manifest path')
  need(name not in expected,'Duplicate manifest path');expected.add(name)
  q=root/name;need(q.is_file() and not q.is_symlink(),'Missing/nonregular package file: '+name)
  b=q.read_bytes();need(len(b)==row['bytes'] and sha(b)==row['sha256'],'Package hash mismatch: '+name)
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() or p.is_symlink()}
 need(actual==expected|{'PNP_MANIFEST.json'},'Unexpected package file inventory')
 original=load(root/P/'MANIFEST.json');recon=load(root/'PNP_PIN_RECONCILIATION.json')
 need(sha((root/P/'MANIFEST.json').read_bytes())==recon['primary_manifest_sha256'],'Primary manifest provenance differs')
 for row in original['allowlist']:
  q=root/P/row['path']
  if q.is_file():need(sha(q.read_bytes())==row['sha256'],'Preserved primary allowlist mismatch')
 for name,digest in load(root/A/'PRIMARY_PIN.json')['files'].items():need(sha((root/P/name).read_bytes())==digest,'Audit primary pin mismatch')
 for q in (root/A/'inputs').iterdir():need(q.read_bytes()==(root/P/q.name).read_bytes(),'Audit input differs from primary')
 for row in recon['audit_pin_reconciliation']:
  need(sha((root/row['accepted_packaged_path']).read_bytes())==row['accepted_sha256'],'Accepted audit pin mismatch')
 return {'status':'PASS','package_files':len(expected)+1,'stale_historical_audit_pins_reconciled':sum(not x['historical_pin_matches']for x in recon['audit_pin_reconciliation'])}
def command(args,cwd,output,label):
 run=subprocess.run(list(map(str,args)),cwd=cwd,env=ENV,capture_output=True)
 (output/(label+'.stdout.log')).write_bytes(run.stdout);(output/(label+'.stderr.log')).write_bytes(run.stderr)
 need(run.returncode==0,'Command failed: '+label+'\n'+run.stderr.decode(errors='replace'))
 return run.stdout

def primary(suite,out):
 work=out/'work';shutil.copytree(D/P,work)
 flags={'primary-normal':['-O0'],'primary-optimized':['-O3'],'primary-ubsan':['-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=all']}[suite]
 original=load(work/'MANIFEST.json');pins={x['path']:x['sha256']for x in original['allowlist']}
 hashes={}
 for stem,result in [('search_structured','STRUCTURED_RESULT.jsonl'),('search_affine_repairs','AFFINE_REPAIR_RESULT.jsonl')]:
  exe=work/stem;command(['g++','-std=c++17']+flags+[work/(stem+'.cpp'),'-o',exe],work,out,'compile-'+stem)
  data=command([exe],work,out,stem);(work/result).write_bytes(data)
 for name in ['STRUCTURED_RESULT.jsonl','structured_survivors.jsonl','structured_candidates.jsonl','AFFINE_REPAIR_RESULT.jsonl','affine_repair_survivors.jsonl','affine_repair_candidates.jsonl']:
  hashes[name]=sha((work/name).read_bytes());need(hashes[name]==pins[name],'Primary replay differs: '+name)
 checks={}
 for mode,args in [('normal',[]),('optimized',['-O'])]:
  command([sys.executable]+args+[work/'verify_results.py'],work,out,'verify-'+mode)
  need(sha((work/'INDEPENDENT_CHECKS.json').read_bytes())==pins['INDEPENDENT_CHECKS.json'],'Survivor checks changed')
  command([sys.executable]+args+[work/'negative_controls.py'],work,out,'negative-'+mode)
  need(sha((work/'NEGATIVE_CONTROLS.json').read_bytes())==pins['NEGATIVE_CONTROLS.json'],'Negative controls changed')
  checks[mode]={'survivor_checks':328,'negative_controls_rejected':4}
 need((out/'verify-normal.stdout.log').read_bytes()==(out/'verify-optimized.stdout.log').read_bytes(),'Python mode receipts differ')
 rows=[json.loads(x)for x in (work/'AFFINE_REPAIR_RESULT.jsonl').read_text().splitlines()]
 need(sum(r['states']for r in rows)==424548 and sum(r['zero_polynomial_states']for r in rows)==0,'Repair count mismatch')
 return {'status':'PASS','suite':suite,'compiler_flags':flags,'output_hashes':hashes,'python_checks':checks,'seed_relative_states':424548,'zero_polynomial_states':0,'structured_search_is_bounded_exploration_only':True}

def independent(suite,out):
 args=['-O']if suite.endswith('optimized')else []
 generated=out/'generated';command([sys.executable]+args+[D/A/'audit_exact.py','--output',generated],out,out,'audit')
 got=load(generated/'AUDIT_RESULT.json');want=load(D/A/'AUDIT_RESULT.json')
 need(normalized(got)==normalized(want),'Independent audit mathematical fields differ')
 hashes={}
 for name in ['EXACT_GEOMETRY.json','EXACT_SURVIVORS.json']:
  data=(generated/name).read_bytes();need(data==(D/A/name).read_bytes(),'Independent exact certificate differs: '+name);hashes[name]=sha(data)
 need(sum(x['states']for x in got['seeds'])==424548,'Independent state count differs')
 need(sum(x['zero_polynomial_states']for x in got['seeds'])==0,'Independent zero found')
 return {'status':'PASS','suite':suite,'seed_relative_states':424548,'zero_polynomial_states':0,'scalar_survivors':16,'certificate_hashes':hashes,'mathematical_report_sha256':sha(json.dumps(normalized(got),sort_keys=True,separators=(',',':')).encode()),'elapsed_seconds_only_ignored':True}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--integrity-only',action='store_true');ap.add_argument('--suite',choices=SUITES+['all'],default='all');ap.add_argument('--output',type=Path);args=ap.parse_args()
 checked=integrity()
 if args.integrity_only:print(json.dumps(checked,sort_keys=True));return
 need(args.output is not None,'Supply a new --output directory outside this package')
 output=args.output.resolve();need(output!=D and D not in output.parents,'Output must be outside package')
 need(not output.exists(),'Output directory already exists');output.mkdir(parents=True)
 reports=[]
 for suite in SUITES if args.suite=='all' else [args.suite]:
  out=output/suite;out.mkdir();report=primary(suite,out)if suite.startswith('primary-')else independent(suite,out);reports.append(report)
 result={'status':'PASS','integrity':checked,'suites':reports};(output/'REPLAY_RECEIPT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
