#!/usr/bin/env python3
"""Corruption, missing-file and extra-file controls, without using assertions."""
import json,shutil,tempfile
from pathlib import Path
import sys
sys.dont_write_bytecode=True
from reproduce import D,integrity,load,need

def main():
 tests=[]
 with tempfile.TemporaryDirectory(prefix='pnp-package-controls-')as temp:
  root=Path(temp)/'package';shutil.copytree(D,root)
  for row in load(root/'PNP_MANIFEST.json')['files']:
   p=root/row['path'];old=p.read_bytes();p.write_bytes(old+b'\nCORRUPTED\n')
   try:integrity(root)
   except RuntimeError as e:need('hash mismatch' in str(e),'Unexpected mutation rejection');tests.append({'control':'corrupt:'+row['path'],'rejected':True})
   else:raise RuntimeError('Corruption accepted: '+row['path'])
   p.write_bytes(old)
  p=root/'README.md';old=p.read_bytes();p.unlink()
  try:integrity(root)
  except RuntimeError as e:need('Missing/nonregular' in str(e),'Unexpected missing-file rejection');tests.append({'control':'missing:README.md','rejected':True})
  else:raise RuntimeError('Missing file accepted')
  p.write_bytes(old);extra=root/'unlisted.txt';extra.write_text('unlisted')
  try:integrity(root)
  except RuntimeError as e:need('inventory' in str(e),'Unexpected inventory rejection');tests.append({'control':'unexpected:file','rejected':True})
  else:raise RuntimeError('Extra file accepted')
  extra.unlink();integrity(root)
 print(json.dumps({'status':'PASS','controls':tests,'negative_controls_rejected':len(tests)},sort_keys=True))
if __name__=='__main__':main()
