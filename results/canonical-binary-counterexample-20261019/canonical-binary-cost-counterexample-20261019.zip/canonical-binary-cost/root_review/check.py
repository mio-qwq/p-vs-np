import sympy as s,itertools,json
from pathlib import Path
t=s.symbols('t'); ds=[s.Rational(-1,6),s.Integer(-6),s.Rational(2,3),s.Rational(3,2)]
roots=[(-d,d) for d in ds]+[(s.Integer(1),s.Integer(-1))]
exps=[(0,1),(2,3),(4,5),(6,7),(8,10)]
rows=[tuple(int(36-6*r) for r in pair) for pair in roots]
if len(set(sum([list(x) for x in rows],[])))!=10: raise ValueError('rows')
ratios=[s.prod((t-r)**(ep[1-j]-ep[j]) for j,r in enumerate(pair)) for pair,ep in zip(roots,exps)]
fiber=[]; total=0; hist={}
for bits in itertools.product([0,1],repeat=5):
 cost=sum(bits[:4])+2*bits[4]; hist[cost]=hist.get(cost,0)+1
 if cost==3:
  sign=(-1)**sum(bits); total+=sign*s.prod(r for r,b in zip(ratios,bits) if b); fiber.append(bits)
if len(fiber)!=8 or s.cancel(total)!=0: raise ValueError('identity')
usedrows=set(sum([list(x) for x in rows],[])); usedcols=set(sum([list(x) for x in exps],[]))
forced=list(zip(sorted(set(range(73))-usedrows),sorted(set(range(73))-usedcols)))
edges=[]
for k,(rr,ee) in enumerate(zip(rows,exps)):
 for j in range(2):
  edges.append((rr[j],ee[j],0))
  edges.append((rr[j],ee[1-j],1 if k==4 or j==0 else 0))
edges += [(r,c,0) for r,c in forced]
if len(edges)!=83 or any(c not in (0,1) for r,e,c in edges):raise ValueError('edges')
# Explicit graph DFS: forced and disjoint K2,2 supports, all 32 matchings.
adj={r:[] for r in range(73)}
for r,c,w in edges:adj[r].append((c,w))
order=sorted(adj,key=lambda r:len(adj[r])); counts={}; n=0

def visit(k,used,cost):
 global n
 if k==73: counts[cost]=counts.get(cost,0)+1;n+=1;return
 for c,w in adj[order[k]]:
  if c not in used:visit(k+1,used|{c},cost+w)
visit(0,set(),0)
if n!=32 or counts!=hist:raise ValueError('fullfiber')
result={'status':'exact_pass','rows':rows,'exponents':exps,'forced':forced,'supported_edges':edges,'dimension':73,'costs':[0,1],'target':3,'fiber_bits':fiber,'matching_count':n,'cost_histogram':hist,'identity':str(s.cancel(total)),'substitution':'t=(L+36)/6; L+i=6(t-rho)','scope':'Sparse canonical support, full cost fiber. Complete matrix works if forbidden edges cost4, not claimed complete0/1.'}
print(json.dumps(result,indent=2))
