#!/usr/bin/env python3
"""Run clean, independent exact checks in disposable directories. No network use."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent

def require(value, message):
    if not value:
        raise RuntimeError(message)

def verify_inventory():
    manifest = json.loads((HERE / 'MANIFEST.json').read_text())
    require(manifest['format'] == 'sha256-source-package-v1', 'manifest format')
    for name, info in manifest['files'].items():
        path = HERE / name
        require(not path.is_symlink() and path.is_file(), 'missing or symlink: ' + name)
        data = path.read_bytes()
        require(len(data) == info['bytes'], 'file size: ' + name)
        require(hashlib.sha256(data).hexdigest() == info['sha256'], 'file digest: ' + name)
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}
    require(actual == set(manifest['files']) | {'MANIFEST.json', 'SHA256SUMS'}, 'unlisted package files')
    expected_sums = ''.join(info['sha256'] + '  ' + name + '\n' for name, info in sorted(manifest['files'].items()))
    require((HERE / 'SHA256SUMS').read_text() == expected_sums, 'text hash inventory')

def clean_run(source, optimized, extra=(), required_inputs=(), result=None):
    with tempfile.TemporaryDirectory(prefix='canonical-proof-') as directory:
        root = Path(directory)
        dest = root / source
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(HERE / source, dest)
        for name in required_inputs:
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(HERE / name, target)
        command = [sys.executable, '-I', '-B'] + (['-O'] if optimized else []) + [str(dest), *extra]
        process = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=180)
        payload = json.loads((dest.parent / result).read_text()) if result and process.returncode == 0 else None
        return process, payload

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--with-sympy', action='store_true', help='also replay the supplementary symbolic review')
    args = parser.parse_args()
    verify_inventory()
    jobs = [('author/verify_candidate.py', 'VERIFICATION.json'),
            ('independent_fraction/verify.py', 'AUDIT.json'),
            ('integer_bridge/verify_bridge_counterexample.py', 'INDEPENDENT_CERTIFICATE.json')]
    report = {'status': 'PASS', 'inventory_verified': True, 'clean_exact_replays': [], 'fraction_mutations': []}
    for source, filename in jobs:
        reference = json.loads((HERE / Path(source).parent / filename).read_text())
        reference.pop('python', None)
        results = []
        for optimized in (False, True):
            process, data = clean_run(source, optimized, result=filename)
            require(process.returncode == 0, source + ': ' + process.stderr)
            data.pop('python', None)
            require(data == reference, source + ': generated certificate differs')
            results.append(data)
            report['clean_exact_replays'].append({'checker': source, 'optimized': optimized, 'exit_code': 0, 'certificate_matches': True})
        require(results[0] == results[1], source + ': mode disagreement')
    for optimized in (False, True):
        process, unused = clean_run('verify_sparse_certificate.py', optimized,
            required_inputs=['author/canonical_sparse_edges.json'])
        require(process.returncode == 0, 'sparse certificate: ' + process.stderr)
        data = json.loads(process.stdout)
        require(data['status'] == 'PASS' and len(data['mutation_controls']) == 4, 'sparse audit controls')
        report['clean_exact_replays'].append({'checker': 'verify_sparse_certificate.py', 'optimized': optimized,
            'exit_code': 0, 'full_zero_coefficients': data['full_zero_coefficients'], 'mutation_controls': data['mutation_controls']})
        for mutation in ('row', 'exponent', 'cost', 'sign'):
            process, unused = clean_run('independent_fraction/verify.py', optimized, extra=['--mutation', mutation])
            expected = 'RuntimeError: full raw fiber' if mutation == 'cost' else 'RuntimeError: raw exact zero polynomial'
            require(process.returncode == 1 and process.stderr.strip().splitlines()[-1] == expected,
                    'mutation rejection ' + mutation)
            report['fraction_mutations'].append({'mutation': mutation, 'optimized': optimized, 'exit_code': 1, 'failure': expected})
    process, data = clean_run('integer_bridge/test_mutations.py', False,
        required_inputs=['integer_bridge/verify_bridge_counterexample.py'], result='MUTATION_RESULTS.json')
    require(process.returncode == 0, 'integer source mutations: ' + process.stderr)
    require(data == json.loads((HERE / 'integer_bridge/MUTATION_RESULTS.json').read_text()), 'integer mutation receipt')
    report['integer_mutation_controls'] = data
    if args.with_sympy:
        reference = json.loads((HERE / 'root_review/CERTIFICATE.json').read_text())
        for optimized in (False, True):
            process, unused = clean_run('root_review/check.py', optimized)
            require(process.returncode == 0, 'symbolic review: ' + process.stderr)
            require(json.loads(process.stdout) == reference, 'symbolic certificate mismatch')
            report['clean_exact_replays'].append({'checker': 'root_review/check.py', 'optimized': optimized, 'exit_code': 0, 'certificate_matches': True})
    verify_inventory()
    print(json.dumps(report, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
