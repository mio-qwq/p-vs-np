# Public-source boundary

Source checked on 2026-10-19: Yuefeng Du, *Bipartite Exact Matching in P*, arXiv:2604.01571v3, https://arxiv.org/html/2604.01571v3.

Theorem 1.2 restricts affine-slice nonvanishing to bipartite braces. Remark 1.4 explicitly permits cancellation for non-brace graphs and describes testing brace blocks separately. Proposition 2.3 describes the corresponding decomposition and target-partition procedure.

The certificate in this package has five disjoint K2,2 components and 63 isolated matching-edge components. Its 68-component graph is not a brace. It disproves unrestricted canonical full-fiber nonvanishing and any arbitrary-support decision rule that identifies a nonempty fiber solely through the nonvanishing of this single whole-graph polynomial. It does not refute the stated brace-only theorem or establish failure of the paper's blockwise algorithm. It makes no claim about P versus NP.

The sparse graph has only binary edge costs. Completing it to a dense matrix assigns cost 4 to every absent edge; the dense alphabet is {0,1,4}, not {0,1}.
