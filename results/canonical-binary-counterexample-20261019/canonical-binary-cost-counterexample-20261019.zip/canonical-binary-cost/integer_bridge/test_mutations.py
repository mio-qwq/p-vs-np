#!/usr/bin/env python3
"""Prove the independent checker rejects three material source mutations."""
import json
import subprocess
import sys
import tempfile
from pathlib import Path


def main():
    source = Path(__file__).with_name("verify_bridge_counterexample.py").read_text()
    mutations = {
        "change_one_row_offset": ("[(35, 37), (0, 72)", "[(34, 37), (0, 72)"),
        "remove_second_red_edge": ("costs[b, u] = int(k == 4)", "costs[b, u] = 0"),
        "lower_forbidden_edge_cost": ("costs.get((i, j), 4)", "costs.get((i, j), 3)"),
    }
    output = {}
    with tempfile.TemporaryDirectory() as tmp:
        for name, (old, new) in mutations.items():
            if source.count(old) != 1:
                raise ValueError("mutation source anchor is not unique: " + name)
            path = Path(tmp) / (name + ".py")
            path.write_text(source.replace(old, new))
            mode_results = {}
            for flags in ([], ["-O"]):
                run = subprocess.run([sys.executable, *flags, str(path)], capture_output=True, text=True)
                if run.returncode == 0:
                    raise ValueError("incorrectly accepted mutation: " + name)
                last = run.stderr.strip().splitlines()[-1]
                if not last.startswith("ValueError:"):
                    raise ValueError("mutation did not reach a scientific check: " + name + " " + last)
                mode_results["optimized" if flags else "normal"] = last
            output[name] = mode_results
    serialized = json.dumps(output, sort_keys=True, indent=2) + "\n"
    Path(__file__).with_name("MUTATION_RESULTS.json").write_text(serialized)
    print(serialized, end="")


if __name__ == "__main__":
    main()
