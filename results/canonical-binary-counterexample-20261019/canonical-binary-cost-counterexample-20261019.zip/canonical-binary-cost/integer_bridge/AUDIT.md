# Canonical full-fiber noncancellation: exact algorithm bridge and counterexample scope

19 October 2026. Independent integer-only audit. This review began as a positive-algorithm bridge audit; the new five-cycle construction changed its conclusion. No repository, PR, tag, release, or remote file was changed.

## 1. Results first

1. **The universal canonical specialization is false even for sparse red/blue input graphs.** An explicit graph on 73 rows and 73 columns, using exactly the canonical offsets and exponents `0,...,72`, has 83 allowed edges, all colored 0 or 1, and eight perfect matchings of red count 3. Their entire signed Vandermonde polynomial is identically zero.
2. **Dense completion is a different claim.** Giving every missing edge cost 4 preserves this entire target fiber and gives a complete finite cost matrix with alphabet `{0,1,4}`. This is not a counterexample with a complete graph and only 0/1 costs.
3. **This is not a counterexample to a brace-only noncancellation assertion.** The sparse support consists of five disjoint four-cycles and 63 forced edges. It is disconnected and not a brace. Du v3 expressly restricts its noncancellation theorem to braces and allows cancellation on non-brace graphs. The existing tight-cut compatibility audit is separate.
4. **The earlier conditional bit-complexity proof remains logically correct, but its universal noncancellation premise is now refuted.** More samples of the same scalar shift cannot repair an identically zero target polynomial.
5. **Binary-encoded weights introduce an independent coefficient-extraction barrier.** A positive-sign disjoint-six-cycle construction below already encodes SUBSET-SUM while noncancellation holds unconditionally. This is an explanatory refinement of the earlier weighted reduction, not a claimed literature novelty.

## 2. Exact problem and hypothesis

An input consists of an explicitly represented bipartite support graph with `n` named vertices on each side, an allowed-edge cost `w(i,j)`, and target `T`. A *complete fiber* means all supported perfect matchings whose additive cost equals T. It does not mean that the support graph is complete.

Define

    M(x,L)[i,j] = x^w(i,j) (L+i)^j  on allowed edges,
                 0                  on absent edges,
    P_T(L) = [x^T] det M(x,L).

For nonnegative integer costs, this is an ordinary bivariate polynomial. For negative integral costs one may shift all allowed edges by the same integer, changing all matching costs by the same `n`-fold amount, or work first with Laurent polynomials. Arbitrary exact real costs do not automatically supply an effective polynomial exponent encoding.

The universal red/blue hypothesis U-ASNC says that for **every** explicit graph, **every** cost map into `{0,1}`, and every T, a nonempty complete fiber implies `P_T != 0`. The reverse implication is automatic. This hypothesis is stronger than brace-only ASNC and stronger than any theorem for a special color mask or component family.

The 73-row certificate below refutes this U-ASNC. The full weighted version on complete finite cost matrices is refuted by its dense completion. Neither statement is a complexity-class separation or a lower bound on all exact-matching algorithms.

## 3. Independent reconstruction of the canonical red/blue instance

Use these row pairs and column-exponent pairs in the indicated order:

    row pairs:     (35,37), (0,72), (40,32), (45,27), (30,42)
    column pairs:  (0,1),   (2,3),  (4,5),   (6,7),   (8,10).

For a row pair `(a,b)` and column pair `(u,v)`, retain all four edges. Its baseline matching A uses `(a,u),(b,v)`; its other matching B uses `(a,v),(b,u)`. Color both A edges blue. For the first four blocks, color `(a,v)` red and `(b,u)` blue. For the fifth block, color **both** B edges red. The local B-minus-A costs are therefore `(1,1,1,1,2)`, despite every individual edge cost being 0 or 1. No subdivision gadget is needed.

There are 63 unused rows and 63 unused columns. Sort each list increasingly, pair the lists in order, and retain only those blue forced edges. Every offset and exponent in `0,...,72` is now present exactly once.

The support has exactly `5*4+63=83` edges. A perfect matching makes one independent choice in each four-cycle, so there are exactly 32. Its cost-generating count polynomial is

    (1+x)^4(1+x^2),

whose coefficient list is `(1,4,7,8,7,4,1)`. The cost-three fiber consists precisely of:

* three B choices among the first four and A on the fifth: four matchings;
* one B choice among the first four and B on the fifth: four matchings.

The full baseline permutation has sign +1 for the specified forced-edge bijection. Each B choice swaps the two assigned columns and reverses the permutation sign. The first group has sign -1 and the second group sign +1. These are the full global permutation signs, not an informal local-sign convention.

### Exact identity

The ratios of the unsigned B and A contributions of the five blocks are

    R1=(L+35)/(L+37),       R2=L/(L+72),
    R3=(L+40)/(L+32),       R4=(L+45)/(L+27),
    R5=((L+30)/(L+42))^2.

They satisfy exactly

    e3(R1,R2,R3,R4) = R5 e1(R1,R2,R3,R4).

One way to see this is to put `t=(L+36)/6` and

    d=(-1/6,-6,2/3,3/2),    r_i=(t+d_i)/(t-d_i).

Direct algebra gives, with `Q=(t+6)(2t-3)(3t-2)(6t+1)`,

    e1(r)=144(t-1)(t+1)^3/Q,
    e3(r)=144(t-1)^3(t+1)/Q.

Thus their ratio is `(t-1)^2/(t+1)^2`, exactly R5 after the substitution. Multiplication by the common A products and forced-edge products clears all denominators and gives a polynomial identity. It is valid at the former poles as a polynomial identity as well.

The target polynomial is the nonzero common baseline/forced factor times

    -e3(R1,R2,R3,R4) + R5 e1(R1,R2,R3,R4),

so it vanishes identically although all eight matchings exist.

### Independent integer certificate

`verify_bridge_counterexample.py` does not read any construction-worker output or certificate. It builds the 73-row graph directly from the displayed arrays and enumerates all supported perfect matchings using ordinary backtracking. For each of the eight target matchings it computes the actual 73-element permutation sign and expands its active-row product with integer coefficient convolution.

The active exponents sum to 46, so every active unsigned term is monic of degree 46. All 47 coefficients of their signed sum are exactly zero. The 63 forced edges give a common monic polynomial of degree 2582. Hence the full matching terms have degree `46+2582=2628=73*72/2`, and the full target sum is zero. Factoring the forced polynomial is exact and avoids an unnecessarily large expansion.

The checker also verifies that all eight individual active products differ, both signs occur four times, all forced edges are shared, and the costs form exactly the complete target fiber. Its negative control recolors one fifth-block B edge blue: the target then has ten same-sign terms with a nonzero leading coefficient, so the precise binary coloring is essential.

Normal and optimized Python runs both pass. The certificate SHA-256 is

    9a306008b892a98b93d51f2f038e3bed4d166bc4e7000f3a563d91c23ddc128b.

## 4. Dense completion, index conventions, and public theorem scope

Set the cost of every absent edge to 4. A permutation using even one such edge has total cost at least 4 because every other edge cost is nonnegative. Therefore the target-three fiber in the complete matrix consists **exactly** of the eight supported matchings. Its signed target polynomial is the same zero polynomial. This proves dense full-fiber failure for costs `{0,1,4}`; replacing cost 4 by color 1 would require a new complete-fiber analysis and is not justified.

If the canonical convention uses both row offsets and exponents `1,...,73`, add one to each. Every matching contribution becomes its zero-based contribution evaluated at `L+1`, multiplied by the same nonzero factor `product_(i=0)^72(L+i+1)`. The zero identity survives. This handles an index convention, not an arbitrary relabeling: selecting a different graph-dependent order can change the specialization.

The current primary source [Du, v3, Sections 1.2 and 2.2](https://arxiv.org/html/2604.01571v3) states ASNC only for bipartite braces. Its Remark 1.4 explicitly excludes a universal non-brace assertion and discusses cancellation under convolution. Our disconnected graph therefore does not refute that stated theorem. It does refute the all-support hypothesis used in the earlier conditional direct-determinant bridge. Whether a particular decomposition algorithm is valid is a separate question; this instance itself is easily solved by independent-component count dynamic programming.

## 5. What the earlier algorithm bridge established

The prior local review `constructive-cost-audit-20261019/PROOF.md` already established the following precise conditional statement, with no unit-cost big-integer loophole:

* Input costs are edge colors 0/1 on an explicit graph.
* `deg_x(det M)<=n`, while `deg_L(P_T)<=D=n(n-1)/2`.
* The grid `x=0,...,n` and `L=0,...,D` contains O(n^3) determinant evaluations.
* At this grid, all minors have O(n^2 log(n+2)) bits.
* Fraction-free determinant evaluation and integer-cleared Lagrange interpolation give a conservative `O(n^10 log^2(n+2))` schoolbook bit-operation bound.
* If a target coefficient is nonzero at some L, Laplace expansion at that fixed L recovers a matching while retaining original row/column labels. Residual noncancellation is not needed for this positive witness extraction.

Under U-ASNC this would decide and search red/blue bipartite Exact Matching. The algebraic algorithm and the bit accounting are not refuted. What fails is the assertion that zero means the fiber is empty: the present input yields a false NO at every L. Enlarging the shift grid, using arbitrary exact evaluation points, or improving interpolation cannot fix this particular loss of information. A repair must change the specialization, introduce additional data, or use independently justified structural decomposition.

This does not establish that all graph-dependent row/column permutations fail, nor does it disprove the existence of a deterministic algorithm for Exact Matching. It invalidates a specified universal fixed-specialization certificate.

## 6. Encoding and sparse support remain separate algorithmic obligations

For nonnegative integer edge weights bounded numerically by W,

    deg_x(det M)<=nW.

With binary-encoded weights, W may be exponential in input length. Full interpolation in x is then pseudopolynomial, even though the L-degree stays only quadratic in n. Sparse matrices do not eliminate this cost: a disjoint union of fixed-size cycles has only O(n) edges but exponentially many perfect matchings and potentially exponentially many attainable weighted costs. Fast exponentiation supplies short circuits for individual monomials; it does not provide all target coefficients in polynomial time.

If row exponents are arbitrary binary-encoded integers `e_j`, even the second degree becomes `sum e_j` and can be exponential. Clearing rational offsets by affine scaling and padding to canonical labels preserves existence, but the required dimension depends on their numerical normalized span. It is not generally polynomial in their bit length. In the present counterexample the actual normalized span is 72, so the explicit 73-row construction has no hidden large-input issue.

### A sign-positive coefficient-extraction reduction

This strengthens the route diagnosis independently of the new cancellation example. Given positive binary integers `w_1,...,w_r` and target T, take r disjoint six-cycles, using three rows and three columns per component. Each has exactly two perfect matchings: the diagonal assignment A and a cyclic assignment B. A three-cycle is an even permutation, so both local determinant terms have positive sign. Assign weight `w_h` to one B edge in component h and weight zero to all other edges. Use canonical global offsets and exponents `0,...,3r-1`.

At the fixed value L=1 every translated-power factor is a positive integer. The determinant is

    product_(h=1)^r (A_h + B_h x^w_h),   A_h>0, B_h>0.

Its target coefficient is nonzero exactly when a subset of the supplied integers sums to T. Every nonempty weighted fiber is noncancelling, at L=1 already. Thus binary-encoded weighted target-coefficient nonzeroness is NP-hard even under this explicit noncancellation guarantee and with linear-size sparse support. The classical hardness source is [Karp's exact knapsack formulation](https://www.cs.umd.edu/~gasarch/BLOGPAPERS/Karp.pdf), reprinting the 1972 paper. The reduction here is given completely; no literature-novelty claim is made.

This example isolates the two failure modes:

* The 73-row red/blue instance has polynomial degree, but the fixed specialization erases a nonempty fiber.
* The sign-positive six-cycle family has no cancellation, but binary-weight coefficient extraction has the SUBSET-SUM obstacle.

Neither observation shows P differs from NP. A polynomial-time algorithm extracting these succinct weighted coefficients would imply P=NP; its existence is not asserted or ruled out.

## 7. Recovery contracts and source provenance

For the counterexample to fail, one must identify an exact defect in at least one of: the displayed graph/coloring, complete-fiber enumeration, global sign computation, integer coefficient calculation, or common forced-factor argument. A near-zero numerical result or a different labeling does not refute the displayed exact instance.

For a replacement positive algorithm, state separately:

1. the exact graph class and input representation;
2. the specialization or structural certificate it computes;
3. why every nonempty target fiber survives that certificate;
4. coefficient degree, arithmetic bit sizes, and constructor size;
5. any interface compatibility obligations in a decomposition;
6. the reduction from the desired source problem, if a P-versus-NP consequence is claimed.

Recovered local foundations, rather than repeated as new research:

* `constructive-cost-audit-20261019/PROOF.md`: conditional red/blue algorithm, bit bounds, tight-cut compatibility counterexample, and weighted encoding barrier.
* `binary-fiber-complexity-audit-20261019/AUDIT.md`: explicit-list versus circuit representations, output-size caveats, and polynomial-bit affine cost construction.
* `exact-fiber-reductions-20261019/PROOF.md` and paired independent audit: supplied-color completeness versus Exact Matching, and maximum-degree-two count dynamic programming.
* `rational-offset-obstruction-20261019-1406/CANONICAL_EMBEDDING.md`: rational-to-canonical existence-preserving padding.
* `rational-centering-source-archive-20261019/remote/p-vs-np/README.md`: the prior checkpoint's then-open universal rational/canonical status. The present certificate changes that all-support status, without contradicting its reflected-family exclusion.

The checker was written independently after receiving the exact rational candidate. The candidate construction is credited to the parallel five-cycle search. The integer audit and scope/algorithm review are separate corroboration. This is exact algebra with independently written code, not proof-assistant verification or external peer review.
