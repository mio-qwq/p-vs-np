#!/usr/bin/env python3
"""Independent integer-only reconstruction. No partner checker or certificate is read."""
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path


def require(value, message):
    if not value:
        raise ValueError(message)


def mul(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def linear_power(a, e):
    out = [1]
    for _ in range(e):
        out = mul(out, [a, 1])
    return out


def parity(p):
    return -1 if sum(p[i] > p[j] for i in range(len(p)) for j in range(i + 1, len(p))) % 2 else 1


def enumerate_matchings(edges):
    n = len(edges)
    order = sorted(range(n), key=lambda i: len(edges[i]))
    p = [-1] * n
    def visit(k, used):
        if k == n:
            yield tuple(p)
            return
        i = order[k]
        for j in edges[i]:
            if not (used >> j) & 1:
                p[i] = j
                yield from visit(k + 1, used | (1 << j))
    return list(visit(0, 0))


def main():
    n = 73
    row_pairs = [(35, 37), (0, 72), (40, 32), (45, 27), (30, 42)]
    col_pairs = [(0, 1), (2, 3), (4, 5), (6, 7), (8, 10)]
    core_rows = {i for pair in row_pairs for i in pair}
    core_cols = {j for pair in col_pairs for j in pair}
    require(len(core_rows) == len(core_cols) == 10, "distinct core rows/columns")
    edges = [[] for _ in range(n)]
    costs = {}
    baseline = [-1] * n
    for k, ((a, b), (u, v)) in enumerate(zip(row_pairs, col_pairs)):
        for i in (a, b):
            edges[i] = [u, v]
        costs[a, u] = costs[b, v] = 0
        costs[a, v] = 1
        costs[b, u] = int(k == 4)
        baseline[a], baseline[b] = u, v
    forced = list(zip(sorted(set(range(n)) - core_rows), sorted(set(range(n)) - core_cols)))
    for i, j in forced:
        edges[i] = [j]
        costs[i, j] = 0
        baseline[i] = j
    require(sorted(baseline) == list(range(n)), "baseline is a permutation")
    require(len(forced) == 63 and sum(map(len, edges)) == 83, "support inventory")
    require(set(costs.values()) == {0, 1}, "all allowed costs are binary colors")
    matchings = enumerate_matchings(edges)
    require(len(matchings) == 32, "full sparse enumeration")
    histogram = Counter(sum(costs[i, p[i]] for i in range(n)) for p in matchings)
    require([histogram[t] for t in range(7)] == [1, 4, 7, 8, 7, 4, 1], "complete cost histogram")
    target = [p for p in matchings if sum(costs[i, p[i]] for i in range(n)) == 3]
    require(len(target) == 8, "exact target cardinality")
    require(Counter(parity(p) for p in target) == Counter({-1: 4, 1: 4}), "both global signs")

    core_degree = sum(core_cols)
    coefficients = [0] * (core_degree + 1)
    term_coefficients = []
    choices = []
    for p in target:
        term = [1]
        for i in sorted(core_rows):
            term = mul(term, linear_power(i, p[i]))
        require(len(term) == core_degree + 1 and term[-1] == 1, "monic degree46 core term")
        sign = parity(p)
        for k, c in enumerate(term):
            coefficients[k] += sign * c
        term_coefficients.append(term)
        x = [int(p[a] == v) for (a, b), (u, v) in zip(row_pairs, col_pairs)]
        choices.append(x)
        require(sum(x[:4]) + 2 * x[4] == 3, "choice vector complete fiber")
        require(sign == parity(baseline) * (-1) ** sum(x), "global determinant sign")
        require(all(p[i] == j for i, j in forced), "common forced factor")
    require(coefficients == [0] * 47, "all47 integer coefficients vanish")
    require(core_degree == 46, "exact active degree")
    require(len({tuple(a) for a in term_coefficients}) == 8, "distinct individual terms")

    # A deliberately wrong edge coloring leaves only five active cost1 blocks.
    bad_costs = dict(costs)
    bad_costs[row_pairs[-1][1], col_pairs[-1][0]] = 0
    bad_target = [p for p in matchings if sum(bad_costs[i, p[i]] for i in range(n)) == 3]
    require(len(bad_target) == 10, "negative control changes whole fiber")
    bad_leading = sum(parity(p) for p in bad_target)
    require(abs(bad_leading) == 10, "negative control cannot cancel")

    # Dense completion uses cost4 on every absent edge. Every cost3 permutation
    # necessarily stays within the sparse support because all costs are >=0.
    dense = [[costs.get((i, j), 4) for j in range(n)] for i in range(n)]
    require(set(c for row in dense for c in row) == {0, 1, 4}, "dense cost alphabet")
    require(all(dense[i][j] >= 4 for i in range(n) for j in range(n) if j not in edges[i]), "dense exclusion")
    output = {
        "scope": "canonical arbitrary-support 0/1 full-fiber counterexample; dense completion costs0,1,4",
        "dimension": n,
        "rows": list(range(n)),
        "exponents": list(range(n)),
        "core_row_pairs": row_pairs,
        "core_column_pairs": col_pairs,
        "forced_edges": forced,
        "allowed_edges": [[i, j, costs[i, j]] for i in range(n) for j in edges[i]],
        "total_allowed_edges": 83,
        "total_perfect_matchings": 32,
        "target": 3,
        "cost_histogram": dict(sorted(histogram.items())),
        "target_matchings": target,
        "target_choice_vectors": choices,
        "baseline_sign": parity(baseline),
        "target_sign_counts": dict(sorted(Counter(parity(p) for p in target).items())),
        "active_degree": 46,
        "forced_factor_degree": sum(j for i, j in forced),
        "full_term_degree": n * (n - 1) // 2,
        "active_fiber_coefficients_low_to_high": coefficients,
        "distinct_active_unsigned_terms": 8,
        "negative_control_target_count": len(bad_target),
        "negative_control_leading_coefficient": bad_leading,
        "dense_forbidden_edge_cost": 4,
        "dense_cost_alphabet": [0, 1, 4],
    }
    serialized = json.dumps(output, indent=2, sort_keys=True) + "\n"
    dest = Path(__file__).with_name("INDEPENDENT_CERTIFICATE.json")
    dest.write_text(serialized)
    print(json.dumps({"verified": True, "dimension": n, "full_fiber_size": 8,
                      "allowed_costs": [0, 1], "zero_integer_coefficients": len(coefficients),
                      "certificate_sha256": hashlib.sha256(serialized.encode()).hexdigest()}, sort_keys=True))


if __name__ == "__main__":
    main()
