#!/usr/bin/env python3
"""Deterministic ZIP: sorted files, fixed metadata, stored bytes, no timestamps."""
import argparse
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent

def build(destination):
    destination = Path(destination).resolve()
    if HERE == destination or HERE in destination.parents:
        raise ValueError('write the archive outside the payload directory')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_STORED) as archive:
        for path in sorted(HERE.rglob('*')):
            if path.is_symlink():
                raise ValueError('symlinks are not permitted')
            if path.is_file():
                name = 'canonical-binary-cost/' + path.relative_to(HERE).as_posix()
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_STORED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                archive.writestr(info, path.read_bytes())

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('destination', type=Path)
    build(parser.parse_args().destination)
