# Sparse canonical binary-cost cancellation certificate

Exact, reproducible result: a 73-by-73 bipartite instance has canonical row offsets and column exponents 0 through 72, 83 allowed edges of costs 0 or 1, and eight perfect matchings of target cost 3, but its entire signed target polynomial is identically zero.

For an allowed edge `(i,j)` put `M(x,L)[i,j] = x^cost(i,j) (L+i)^j`, and put zero on absent edges. Then `[x^3] det M(x,L) = 0` as a polynomial in L even though its complete target fiber is nonempty. All 2629 coefficients through degree 2628 have been checked exactly, with no numerical premise.

## Construction

Five independent two-row blocks use these ordered row and column pairs:

    rows:    (35,37), (0,72), (40,32), (45,27), (30,42)
    columns: (0,1),   (2,3),  (4,5),   (6,7),   (8,10)

In each block, keep all four edges. Both diagonal edges cost zero. The first off-diagonal edge costs one; the second costs zero for the first four blocks and one for the fifth. Pair the remaining 63 rows and 63 columns in increasing order, using one zero-cost edge per pair.

Every supported perfect matching independently chooses one of the two assignments in each block. The complete matching-count polynomial is `(1+z)^4(1+z^2)`, giving counts `(1,4,7,8,7,4,1)` and exactly eight matchings at cost 3. The full permutation signs split four positive and four negative. The active terms have degree 46; their 47 coefficients cancel exactly. The common forced-edge factor is monic of degree 2582.

The supplied sparse edge list, not a dense matrix, is the primary input certificate: `author/canonical_sparse_edges.json`. Its rows, columns, and costs are zero-indexed.

## Exact scope

- This refutes unrestricted canonical full-fiber nonvanishing for arbitrary sparse bipartite supports with binary edge costs, and a direct whole-graph decision test that treats this particular zero polynomial as proof of an empty fiber.
- Filling missing edges with cost 4 preserves the target fiber. This dense completion has alphabet `{0,1,4}`. No complete-graph binary-cost counterexample is claimed.
- The graph has five K2,2 components and 63 isolated matching-edge components. It is disconnected and not a brace.
- Du v3, Theorem 1.2, states ASNC for braces; Remark 1.4 explicitly allows cancellation on non-brace graphs. This construction does not refute that brace theorem or establish failure of its blockwise algorithm. See [the versioned primary source](https://arxiv.org/html/2604.01571v3) and `SOURCE_BOUNDARY.md`.
- There is no P-versus-NP conclusion, no minimal-dimension claim, and no claim of historical novelty or formal proof-assistant verification. The earlier four-cycle exclusion mentioned in the author derivation is background, not reproved by this package.

## Replay

Python 3.10 or later; the required checks use only the standard library:

    python replay_all.py

For the supplementary symbolic review, install SymPy in your usual environment and run:

    python replay_all.py --with-sympy

The replay verifies the SHA-256 inventory, runs every required checker in both normal and optimized Python in fresh temporary directories, compares regenerated certificates, rejects all recorded mutations, and rechecks the inventory. It does not alter package files or access the network. The supplementary SymPy checker is not needed for the result.

To inspect only the supplied edge certificate and its mutation controls:

    python verify_sparse_certificate.py
    python -O verify_sparse_certificate.py

No check relies on Python assertions. The mutation controls cover rational row/exponent/cost/sign changes; integer row/coloring/forbidden-cost changes; and sparse-certificate row-label, coloring, missing-edge, and nonbinary-cost changes.

## Contents

- `author/`: original rational construction proof, independent enumerator, sparse edge list, eight-term raw and canonical fibers, and normal/optimized certificate.
- `independent_fraction/`: separately written Fraction/polynomial audit; all 2629 full coefficients; row/exponent/cost/sign mutations.
- `integer_bridge/`: independently reconstructed integer-only audit, algorithm-scope review, sparse certificate, and source mutation harness.
- `root_review/`: supplementary symbolic identity and independent graph enumeration.
- `verify_sparse_certificate.py`: certificate-consuming integer validator, whole-support enumeration, all full coefficients, connected components, and adversarial input checks.
- `replay_all.py`: clean integrated replay and certificate equality checks.
- `REPLAY_RESULTS.json`: integrated clean-run receipt, including supplementary symbolic review.
- `MANIFEST.json` and `SHA256SUMS`: complete payload inventory, excluding the inventories themselves.
- `rebuild_zip.py`: deterministic sorted, fixed-metadata, uncompressed ZIP writer. The ZIP contains this directory under `canonical-binary-cost/`.

The original author checker also reconstructs dense matrices on demand. Those generated matrices are deliberately omitted here; references to them in the original proof name these reproducible outputs. Integrated replay creates them only inside temporary directories.

Prepared 2026-10-19. This package contains research material and local verification only; it performs no upload, repository write, PR action, merge, tag, or release.
