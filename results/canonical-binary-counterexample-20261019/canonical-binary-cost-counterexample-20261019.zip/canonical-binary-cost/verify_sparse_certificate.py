#!/usr/bin/env python3
"""Validate the supplied sparse certificate, not a hard-coded list of matchings.
Standard library only. Explicit exceptions remain active under python -O.
"""
import argparse
from collections import Counter
import copy
import json
from math import comb
from pathlib import Path

HERE = Path(__file__).resolve().parent

def require(value, message):
    if not value:
        raise ValueError(message)

def multiply(left, right):
    out = [0] * (len(left) + len(right) - 1)
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            out[i + j] += a * b
    return out

def term_polynomial(rows, permutation):
    out = [1]
    for row in rows:
        exponent = permutation[row]
        out = multiply(out, [comb(exponent, k) * row ** (exponent - k)
                             for k in range(exponent + 1)])
    return out

def parity(p):
    return (-1) ** sum(p[i] > p[j] for i in range(len(p)) for j in range(i + 1, len(p)))

def validate(records, full=True):
    n = 73
    require(isinstance(records, list) and len(records) == 83, '83 edge records required')
    edges = {}
    adjacency = [[] for _ in range(n)]
    for record in records:
        require(set(record) == {'row', 'column', 'cost'}, 'edge schema')
        row, col, cost = (record[key] for key in ('row', 'column', 'cost'))
        require(all(type(v) is int for v in (row, col, cost)), 'integer edge data')
        require(0 <= row < n and 0 <= col < n and cost in (0, 1), 'canonical binary edge')
        require((row, col) not in edges, 'distinct edges')
        edges[row, col] = cost
        adjacency[row].append(col)
    require(all(adjacency), 'every canonical row represented')
    order = sorted(range(n), key=lambda row: len(adjacency[row]))
    permutation = [-1] * n
    matchings = []
    def visit(k, used, cost):
        if k == n:
            matchings.append((tuple(permutation), cost))
            return
        row = order[k]
        for col in sorted(adjacency[row]):
            if not (used >> col) & 1:
                permutation[row] = col
                visit(k + 1, used | (1 << col), cost + edges[row, col])
    visit(0, 0, 0)
    require(len(matchings) == 32, 'complete support has 32 perfect matchings')
    histogram = Counter(cost for p, cost in matchings)
    require(dict(histogram) == dict(enumerate([1, 4, 7, 8, 7, 4, 1])), 'complete cost histogram')
    target = [p for p, cost in matchings if cost == 3]
    require(len(target) == 8, 'entire target fiber contains eight matchings')
    require(Counter(map(parity, target)) == Counter({-1: 4, 1: 4}), 'global signs')
    forced = [row for row in range(n) if len(adjacency[row]) == 1]
    active = [row for row in range(n) if len(adjacency[row]) != 1]
    require(len(forced) == 63 and len(active) == 10, '63 forced and 10 active rows')
    require(all(p[row] == target[0][row] for p in target for row in forced), 'common forced edges')
    active_sum = [0] * 47
    unsigned_terms = []
    for p in target:
        term = term_polynomial(active, p)
        require(len(term) == 47 and term[-1] == 1, 'active terms monic degree 46')
        unsigned_terms.append(term)
        for k, coefficient in enumerate(term):
            active_sum[k] += parity(p) * coefficient
    require(active_sum == [0] * 47, '47 exact active coefficients must vanish')
    require(len({tuple(p) for p in unsigned_terms}) == 8, 'eight distinct unsigned terms')
    require(sum(target[0][row] for row in forced) == 2582, 'forced degree 2582')
    # Verify all 2629 full coefficients, retaining the monic nonzero common factor.
    if full:
        common = term_polynomial(forced, target[0])
        require(len(common) == 2583 and common[-1] == 1, 'common factor monic degree 2582')
        full_sum = multiply(active_sum, common)
        require(len(full_sum) == 2629 and all(v == 0 for v in full_sum), 'full polynomial coefficients')
    # Determine connected components directly in the bipartite graph.
    neighbors = [set() for _ in range(2 * n)]
    for row, col in edges:
        neighbors[row].add(n + col)
        neighbors[n + col].add(row)
    unseen = set(range(2 * n)); sizes = []
    while unseen:
        start = min(unseen); unseen.remove(start); stack = [start]; size = 0
        while stack:
            node = stack.pop(); size += 1
            new = neighbors[node] & unseen
            unseen.difference_update(new); stack.extend(new)
        sizes.append(size)
    require(Counter(sizes) == Counter({2: 63, 4: 5}), 'explicitly disconnected non-brace support')
    # Removing any one target term destroys the identity: each term is monic.
    require(all(abs(-parity(p)) == 1 for p in target), 'omitted term leading coefficient')
    return {'status': 'PASS', 'dimension': n, 'allowed_edges': len(edges),
            'allowed_costs': [0, 1], 'perfect_matchings': len(matchings),
            'target': 3, 'target_matchings': len(target),
            'cost_histogram': dict(sorted(histogram.items())), 'components': len(sizes),
            'active_zero_coefficients': 47, 'full_zero_coefficients': 2629,
            'dense_completion_cost': 4, 'dense_costs': [0, 1, 4]}

def rejection(records):
    try:
        validate(records, full=False)
    except ValueError as error:
        return str(error)
    raise RuntimeError('mutation wrongly accepted')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--certificate', type=Path, default=HERE / 'author/canonical_sparse_edges.json')
    parser.add_argument('--no-mutations', action='store_true')
    args = parser.parse_args()
    records = json.loads(args.certificate.read_text())
    report = validate(records)
    if not args.no_mutations:
        controls = {}
        changed = copy.deepcopy(records)
        for record in changed:
            if (record['row'], record['column']) == (42, 8):
                record['cost'] = 0
        controls['one_red_edge_recolored_blue'] = rejection(changed)
        changed = copy.deepcopy(records)
        for record in changed:
            record['row'] = {35: 34, 34: 35}.get(record['row'], record['row'])
        controls['canonical_row_labels_exchanged'] = rejection(changed)
        controls['one_support_edge_deleted'] = rejection(copy.deepcopy(records[:-1]))
        changed = copy.deepcopy(records); changed[0]['cost'] = 4
        controls['nonbinary_allowed_cost'] = rejection(changed)
        report['mutation_controls'] = controls
    print(json.dumps(report, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
