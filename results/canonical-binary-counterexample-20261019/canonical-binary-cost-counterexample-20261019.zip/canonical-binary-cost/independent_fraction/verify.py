#!/usr/bin/env python3
"""Independent standard-library check, no imported candidate files."""
from fractions import Fraction as Q
from itertools import product, combinations
from math import comb
import argparse,hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--mutation',choices=['row','exponent','cost','sign'])
args=parser.parse_args()
b=[Q(-1,6),Q(1,6),Q(-6),Q(6),Q(2,3),Q(-2,3),Q(3,2),Q(-3,2),Q(-1),Q(1)]
e=list(range(9))+[10]
delta=[1,1,1,1,2]
if args.mutation=='row': b[0]+=Q(1,60)
if args.mutation=='exponent': e[-1]=9

def require(p,m):
    if not p: raise RuntimeError(m)
def mul(f,g):
    h=[0]*(len(f)+len(g)-1)
    for i,a in enumerate(f):
        for j,c in enumerate(g): h[i+j]+=a*c
    return h

def poly(roots,exps):
    f=[1]
    for a,k in zip(roots,exps): f=mul(f,[comb(k,j)*a**(k-j) for j in range(k+1)])
    return f

def sgn(p): return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
def perm(bits):
    p=list(range(10))
    for j,x in enumerate(bits):
        if x: p[2*j],p[2*j+1]=p[2*j+1],p[2*j]
    return p

def cost_matrix(n,allowed,vals):
    C=[[4]*n for _ in range(n)]
    for edge in allowed: C[edge[0]][edge[1]]=vals.get(edge,0)
    return C

allowed={(2*j+i,2*j+k) for j in range(5) for i in range(2) for k in range(2)}
vals={(2*j,2*j+1):1 for j in range(5)}
vals[(9,8)]=1
if args.mutation=='cost': vals[(0,1)]=2
C=cost_matrix(10,allowed,vals)
# Complete DFS through every eligible edge (cost <=target), not assumed cube fibers.
def enumerate_fiber(C,target=3):
    n=len(C); result=[]
    def rec(row,used,cost,p):
        if row==n:
            if cost==target: result.append(tuple(p))
            return
        for col in range(n):
            if not used>>col&1 and cost+C[row][col]<=target:
                rec(row+1,used|1<<col,cost+C[row][col],p+[col])
    rec(0,0,0,[])
    return result
fiber=enumerate_fiber(C)
expected=[tuple(perm(x)) for x in product([0,1],repeat=5) if sum(a*c for a,c in zip(x,delta))==3]
require(set(fiber)==set(expected) and len(fiber)==8,'full raw fiber')
coeff=[Q(0)]*(sum(e)+1)
term_records=[]
for p in fiber:
    f=poly(b,[e[j] for j in p]); sign=sgn(p)
    if args.mutation=='sign' and p==fiber[0]: sign=-sign
    coeff=[a+sign*c for a,c in zip(coeff,f)]
    term_records.append({'permutation':list(p),'sign':sign,'cost':sum(C[i][p[i]] for i in range(10))})
require(all(v==0 for v in coeff),'raw exact zero polynomial')
require(len(set(b))==10 and len(set(e))==10,'distinct offsets/exponents')
# Separate direct cross-multiplied rational-function identity using small linear factors.
ds=[Q(-1,6),Q(-6),Q(2,3),Q(3,2)]
nums=[[d,1] for d in ds]; dens=[[-d,1] for d in ds]
E1=[Q(0)]*5;E3=[Q(0)]*5
for k,E in [(1,E1),(3,E3)]:
    for X in combinations(range(4),k):
        f=[1]
        for j in range(4): f=mul(f,nums[j] if j in X else dens[j])
        for i,a in enumerate(f): E[i]+=a
require(E1==[Q(-4),Q(-8),Q(0),Q(8),Q(4)],'e1 numerator =4(t-1)(t+1)^3')
require(E3==[Q(-4),Q(8),Q(0),Q(-8),Q(4)],'e3 numerator =4(t-1)^3(t+1)')
require(mul(E3,[1,2,1])==mul(E1,[1,-2,1]),'cross multiplied ratio identity')
# Independently build completely canonical offsets/exponents 0..72.
c=[int(6*(a+6)) for a in b];N=73
require(len(set(c))==10 and min(c)==0 and max(c)==72,'embedding row indices')
missing_rows=sorted(set(range(N))-set(c));missing_cols=sorted(set(range(N))-set(e))
forced=dict(zip(missing_rows,missing_cols))
canonical_allowed={(c[i],e[j]) for i,j in allowed}|set(forced.items())
canonical_vals={(c[i],e[j]):v for (i,j),v in vals.items()}
CC=cost_matrix(N,canonical_allowed,canonical_vals)
canonical_fiber=enumerate_fiber(CC)
require(len(canonical_fiber)==8,'complete canonical fiber count')
# Verify the correspondence, actual global permutation signs, and exact 46th-degree
# active factors. The omitted common forced factor is separately computed degree-wide.
base=dict(forced)
for i in range(10): base[c[i]]=e[i]
basep=tuple(base[i] for i in range(N));basesign=sgn(basep)
active_sum=[0]*(sum(e)+1)
can_records=[]
for P in canonical_fiber:
    local_p=tuple(e.index(P[c[i]]) for i in range(10))
    require(local_p in set(fiber),'canonical matching extends raw matching')
    require(all(P[r]==q for r,q in forced.items()),'all added edges forced')
    sign=sgn(P)
    require(sign==basesign*sgn(local_p),'global permutation sign factor')
    f=poly(c,[P[row] for row in c])
    active_sum=[a+sign*v for a,v in zip(active_sum,f)]
    can_records.append({'permutation':list(P),'sign':sign,'cost':sum(CC[i][P[i]] for i in range(N))})
require(all(v==0 for v in active_sum),'canonical active factor exact zero')
forced_degree=sum(forced.values());D=N*(N-1)//2
require(forced_degree+sum(e)==D,'canonical degree decomposition')
# Independently verify complete 2628-degree polynomial at coefficient level by
# multiplying the computed active sum by the actual forced-edge polynomial.
H=poly(list(forced),list(forced.values()))
full=mul(active_sum,H)
require(len(full)==D+1 and all(v==0 for v in full),'entire canonical polynomial zero')
# Nonzero individual terms, equal degree, four signs of each orientation.
require(sorted(sgn(p) for p in fiber)==[-1]*4+[1]*4,'raw 4+4 signs')
require(len(H)==forced_degree+1 and H[-1]==1,'nonzero monic forced polynomial')
report={'status':'PASS','raw_dimension':10,'raw_offsets':list(map(str,b)),
'raw_exponents':e,'raw_degree':sum(e),'raw_cost_matrix':C,'raw_complete_fiber':term_records,
'raw_zero_coefficient_count':len(coeff),'identity_e1_numerator':list(map(str,E1)),
'identity_e3_numerator':list(map(str,E3)),'canonical_dimension':N,
'canonical_active_rows':c,'canonical_active_columns':e,'canonical_forced_edges':[[r,q] for r,q in forced.items()],
'canonical_forbidden_cost':4,'target_cost':3,'canonical_baseline_sign':basesign,
'canonical_degree':D,'canonical_forced_degree':forced_degree,'canonical_complete_fiber':can_records,
'canonical_zero_coefficient_count':len(full),'scope':'Exact complete finite-cost counterexample; no P-vs-NP conclusion.'}
(ROOT/'AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','raw_dimension','raw_degree','canonical_dimension','canonical_degree','canonical_zero_coefficient_count','canonical_baseline_sign']}))
