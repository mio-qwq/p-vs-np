# Independent exact audit of the rational five-cycle cancellation

19 October 2026. Local mathematical verification only. No external repository or release was changed. This checker was constructed independently after receiving the candidate ratios; it imports neither another worker's checker nor its certificate.

## Result

The candidate is an exact counterexample to universal noncancellation of complete additive-cost fibers for arbitrary distinct rational row offsets and distinct nonnegative integer column exponents. Padding gives a canonical 73-row counterexample with row offsets and exponents both exactly 0,...,72. Its allowed graph is 5 disjoint two-row cycles plus 63 forced edges. Every allowed-edge cost is 0 or 1; the target cost is 3.

Making the cost matrix fully finite by assigning cost 4 to all other edges preserves exactly that fiber. This dense finite completion has costs in {0,1,4}. Thus the certificate directly covers sparse supports with binary allowed costs and dense matrices with these three costs. It does not assert a dense all-0/1 matrix counterexample.

## Rational data and exact identity

The ten row offsets, in the original order, are

    (-1/6,1/6,-6,6,2/3,-2/3,3/2,-3/2,-1,1).

The ten ordered column exponents are

    (0,1,2,3,4,5,6,7,8,10).

They are pairwise distinct in each list. Group consecutive rows and consecutive columns into five 2 by 2 blocks. The baseline matching is diagonal in every block; its sign is +1. Swapping a block reverses its permutation sign. For the first four blocks the swapped-to-baseline ratio is

    r_j(t)=(t+d_j)/(t-d_j),
    (d_1,d_2,d_3,d_4)=(-1/6,-6,2/3,3/2).

For the fifth block it is

    r_5(t)=((t-1)/(t+1))^2.

The fifth exponent gap is exactly 2; all other gaps are 1. All ten zeros and poles are distinct, so these are genuine disjoint matching cycles.

Let P(t)=product_{j=1}^4(t-d_j). Direct multiplication gives

    P e_1(r_1,r_2,r_3,r_4)=4(t-1)(t+1)^3,
    P e_3(r_1,r_2,r_3,r_4)=4(t-1)^3(t+1).

Consequently -e_3+r_5 e_1 is identically zero. This is checked by exact rational coefficients and cross multiplication, so no evaluation near a root or numerical tolerance is involved.

## Complete cost fiber and signs

Set every baseline edge cost to 0. In each of the first four blocks give the first row's swapped edge cost 1 and the second row's swapped edge cost 0. Give both swapped edges of the fifth block cost 1. All other edges have cost 4.

Every target-cost-3 matching avoids cost-4 edges, since costs are nonnegative. It is therefore determined by a five-bit orientation x and has cost

    x_1+x_2+x_3+x_4+2x_5.

The entire fiber consists of exactly eight orientations:

- x_5=0 and exactly three of the first four bits are 1: four terms, each with sign -1;
- x_5=1 and exactly one of the first four bits is 1: four terms, each with sign +1.

Let A be the product of the five baseline monomials. The fiber polynomial is A(-e_3+r_5e_1)=0. Each individual term is nonzero and monic up to its sign, with degree 46. This is cancellation in a nonempty full fiber, not cancellation in an arbitrary selected subcollection.

The independent checker enumerates the fiber by a row-by-row perfect-matching DFS on the actual finite 10 by 10 cost matrix, compares it to the eight orientations, computes each sign by inversion count, expands all eight polynomials using Fraction arithmetic, and finds all 47 coefficients zero.

## Fully canonical padding

Transform the offsets by c_i=6(b_i+6). They become, in the same order,

    (35,37,0,72,40,32,45,27,30,42).

Retain the ten original exponents as column labels in 0,...,72. Add one row for every missing offset and pair the sorted missing rows with the sorted missing columns by forced cost-0 edges. There are 63 such edges. All edges outside the five blocks and forced pairs receive cost 4.

The checker independently enumerates all target-cost-3 matchings of this actual 73 by 73 matrix and finds exactly eight. It compares each to its underlying ten-row matching and verifies every forced edge. It computes all 73-row permutation signs by direct inversion counting. The extension of the original baseline has sign +1, and every other sign agrees with its ten-row matching sign.

The active factors still have degree 46. The common forced polynomial is explicitly expanded; it is monic of degree 2582. The complete canonical degree is 2628, equal to 0+1+...+72. All 2629 coefficients of the full fiber polynomial are checked to be zero.

For the one-based convention, increasing every offset and exponent by 1 multiplies the shifted zero polynomial by the common nonzero factor product_{i=0}^{72}(t+i+1). Thus there is also a canonical instance with both lists exactly 1,...,73.

## Relation to existing theorems

This example has five cost-active cycles. It is outside both the theorem with at most three active cycles and the theorem with at most four even-row active cycles. It is also outside the reflected four-cycle family excluded by the rational-offset obstruction. Hence it contradicts none of those scoped results.

It refutes any unrestricted extension that claims all nonempty complete cost fibers in this canonical model have a nonzero signed polynomial. It does not prove P != NP, P = NP, an efficient coefficient-extraction algorithm, or any broader complexity-class conclusion. The four-active-cycle rational question remains open in the cited work.

## Reproduction and mutation controls

Run from any directory:

    python /path/to/verify.py
    python -O /path/to/verify.py

Both runs use explicit RuntimeError checks, not assert statements, and produce identical AUDIT.json certificates. The report contains the ten-row finite cost matrix, exact row/exponent data, all complete-fiber permutations and signs, canonical row/column mapping, every forced edge, and all eight canonical permutations.

The checker also supports four deliberate corruptions:

    --mutation row
    --mutation exponent
    --mutation cost
    --mutation sign

Each must exit nonzero before replacing a passing certificate. The row, exponent, and sign changes break the exact zero-polynomial check; the cost change breaks the complete-fiber comparison. MUTATION_CONTROLS.json records all eight failing normal/optimized tests.
