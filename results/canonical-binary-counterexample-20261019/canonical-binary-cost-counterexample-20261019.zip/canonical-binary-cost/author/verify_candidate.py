#!/usr/bin/env python3
"""Exact direct-permutation verifier; no input certificate is trusted."""
import argparse, hashlib, itertools, json, math, platform
from fractions import Fraction as Q
from pathlib import Path

HERE=Path(__file__).resolve().parent

def check(v,msg):
    if not v: raise RuntimeError(msg)

def mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return c

def power_linear(b,e):
    return [math.comb(e,k)*b**(e-k) for k in range(e+1)]

def add(a,b):
    c=[0]*max(len(a),len(b))
    for i,x in enumerate(a): c[i]+=x
    for i,x in enumerate(b): c[i]+=x
    return c

def product_polynomial(offsets,exponents,perm):
    p=[1]
    for i,j in enumerate(perm): p=mul(p,power_linear(offsets[i],exponents[j]))
    return p

def parity(p):
    return -1 if sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))%2 else 1

def matching_enumeration(cost,target):
    # Every edge has nonnegative cost; edges larger than target provably cannot occur.
    n=len(cost); rows=sorted(range(n),key=lambda i:sum(c<=target for c in cost[i])); p=[-1]*n
    out=[]
    def visit(k,used,total):
        if k==n:
            if total==target: out.append(tuple(p))
            return
        i=rows[k]
        for j,c in enumerate(cost[i]):
            if total+c<=target and j not in used:
                p[i]=j; visit(k+1,used|{j},total+c)
    visit(0,set(),0)
    return sorted(out)

def complete_supported(cost,K):
    # Counts all and only matchings using edges <K, including every target fiber.
    n=len(cost); rows=sorted(range(n),key=lambda i:sum(c<K for c in cost[i])); p=[-1]*n
    out=[]
    def visit(k,used,total):
        if k==n: out.append((total,tuple(p))); return
        i=rows[k]
        for j,c in enumerate(cost[i]):
            if c<K and j not in used:
                p[i]=j; visit(k+1,used|{j},total+c)
    visit(0,set(),0)
    return sorted(out)

def dump(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='VERIFICATION.json');args=ap.parse_args()
    d=[Q(-1,6),Q(-6),Q(2,3),Q(3,2)]
    check(sum(d)==-4,'sum d');check(math.prod(d)==1,'prod d')
    s3=sum(math.prod(d[j] for j in S) for S in itertools.combinations(range(4),3))
    check(s3==-4,'third elementary')
    A=[[x,1] for x in d];B=[[-x,1] for x in d]
    P=[0];R=[0]
    for i in range(4):
        p=[1];r=[1]
        for j in range(4):
            p=mul(p,B[j] if i==j else A[j]);r=mul(r,A[j] if i==j else B[j])
        P=add(P,p);R=add(R,r)
    check(P==[Q(-4),Q(8),Q(0),Q(-8),Q(4)],'e3 numerator')
    check(R==[Q(-4),Q(-8),Q(0),Q(8),Q(4)],'e1 numerator')
    check(mul(P,power_linear(1,2))==mul(R,power_linear(-1,2)),'five-ratio identity')
    offsets=[z for x in d for z in (x,-x)]+[Q(-1),Q(1)]
    exponents=[0,1,2,3,4,5,6,7,8,10]
    deltas=[1,1,1,1,2];n=10;target=3;K=4
    check(len(set(offsets))==n and len(set(exponents))==n,'distinct labels')
    C=[[K]*n for _ in range(n)]
    for j,delta in enumerate(deltas):
        i=2*j;C[i][i]=C[i+1][i+1]=0;C[i][i+1]=1;C[i+1][i]=delta-1
    supported=complete_supported(C,K);F=matching_enumeration(C,target)
    check(len(supported)==32,'support count');check(len(F)==8,'target count')
    hist={str(c):sum(x==c for x,p in supported) for c,p in supported}
    check(hist=={'0':1,'1':4,'2':7,'3':8,'4':7,'5':4,'6':1},'cost histogram')
    expected=[]
    for bits in itertools.product(range(2),repeat=5):
        if sum(x*d for x,d in zip(bits,deltas))==target:
            p=list(range(n))
            for j,x in enumerate(bits):
                if x:p[2*j],p[2*j+1]=p[2*j+1],p[2*j]
            expected.append(tuple(p))
    check(F==sorted(expected),'complete fiber cube identity')
    total=[0]*(sum(exponents)+1);term_records=[]
    for p in F:
        sg=parity(p);v=product_polynomial(offsets,exponents,p)
        total=add(total,[sg*x for x in v]);term_records.append({'permutation':p,'sign':sg,'coefficients':[str(x) for x in v]})
    check(all(x==0 for x in total),'direct rational full polynomial zero')
    # Integer affine normalization and actual canonical 73-row matrix.
    scale=6;minimum=min(offsets);embedded=[int(scale*(b-minimum)) for b in offsets]
    check(all(Q(c)==scale*(b-minimum) for b,c in zip(offsets,embedded)),'integer normalization')
    N=max(max(embedded),max(exponents))+1;check(N==73,'padded dimension')
    newrows=sorted(set(range(N))-set(embedded));newcols=sorted(set(range(N))-set(exponents));forced=dict(zip(newrows,newcols))
    CC=[[K]*N for _ in range(N)]
    for i in range(n):
        for j in range(n):
            if C[i][j]<K:CC[embedded[i]][exponents[j]]=C[i][j]
    for i,j in forced.items():CC[i][j]=0
    FF=matching_enumeration(CC,target);check(len(FF)==8,'canonical full fiber size')
    expanded=[];sign_ratios=set()
    for p in F:
        q=[-1]*N
        for i,j in forced.items():q[i]=j
        for i,j in enumerate(p):q[embedded[i]]=exponents[j]
        expanded.append(tuple(q));sign_ratios.add(parity(q)*parity(p))
    check(sorted(expanded)==FF,'canonical fiber bijection');check(len(sign_ratios)==1,'constant sign extension')
    # Direct reduced factors in the canonical variable; forced factors common and nonzero.
    reduced_total=[0]*(sum(exponents)+1)
    for q in FF:
        v=[1]
        for i in embedded:v=mul(v,power_linear(i,q[i]))
        reduced_total=add(reduced_total,[parity(q)*x for x in v])
    check(all(x==0 for x in reduced_total),'canonical exact reduced polynomial zero')
    # Numeric evaluations of complete terms are independent supplementary checks only.
    evaluations={}
    for t in [1,2,3,7,19]:
        z=sum(parity(q)*math.prod((t+i)**q[i] for i in range(N)) for q in FF)
        check(z==0,'full73 evaluation');evaluations[str(t)]=z
    # Reject one cost mutation and one exponent mutation. Use exact full polynomials.
    CM=[r[:] for r in C];CM[8][9]=2
    FM=matching_enumeration(CM,target);tm=[0]
    for p in FM:tm=add(tm,[parity(p)*x for x in product_polynomial(offsets,exponents,p)])
    check(len(FM)==5 and any(tm),'cost negative control')
    EM=exponents[:];EM[-1]=11;tm=[0]
    for p in F:tm=add(tm,[parity(p)*x for x in product_polynomial(offsets,EM,p)])
    check(any(tm),'exponent negative control')
    data={'status':'PASS','arithmetic':'exact integers and fractions; no numerical premise','n_rational':n,'offsets':[str(x) for x in offsets],'exponents':exponents,'cycle_cost_differences':deltas,'target':target,'forbidden_cost':K,'allowed_cost_alphabet':sorted(set(c for row in C for c in row if c<K)),'supported_matching_count':len(supported),'support_cost_histogram':hist,'fiber_count':len(F),'fiber_even':sum(parity(p)==1 for p in F),'fiber_odd':sum(parity(p)==-1 for p in F),'direct_coefficient_count':len(total),'direct_coefficients':[str(x) for x in total],'canonical_N':N,'embedded_rows':embedded,'forced_row_column_pairs':sorted(forced.items()),'canonical_sign_ratio':next(iter(sign_ratios)),'canonical_reduced_coefficients':[str(x) for x in reduced_total],'full_canonical_integer_evaluations':evaluations,'negative_controls':{'cost_change_rejects_zero':True,'exponent_change_rejects_zero':True},'python':platform.python_version()}
    dump(HERE/args.output,data)
    dump(HERE/'rational_cost_matrix.json',C);dump(HERE/'rational_fiber.json',term_records);dump(HERE/'canonical_cost_matrix.json',CC);dump(HERE/'canonical_fiber.json',[{'permutation':p,'sign':parity(p)} for p in FF])
    print(json.dumps({k:data[k] for k in ['status','n_rational','fiber_count','canonical_N','negative_controls']},sort_keys=True))
if __name__=='__main__':main()
