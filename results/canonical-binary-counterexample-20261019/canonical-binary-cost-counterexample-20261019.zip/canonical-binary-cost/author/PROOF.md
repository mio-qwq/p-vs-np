# Five-cycle rational cancellation and a canonical 73-row counterexample

19 October 2026. Exact construction and independently reproducible local certificate. No external write, merge, release, or publication was performed by this investigation.

## Result and scope

There is a bipartite graph on 73 ordered rows and 73 ordered columns, with canonical row offsets and column exponents both exactly `0,1,...,72`, and allowed-edge costs only `0` and `1`, such that its complete cost-three perfect-matching fiber has eight members and its signed translated-power polynomial is identically zero.

Its allowed support has five disjoint `K_2,2` components and 63 forced edges. Each nontrivial cycle flip is odd. The active cost differences are `(1,1,1,1,2)`. Thus the previously proved four-active-odd-cycle noncancellation bound is sharp: five active odd cycles can cancel even with canonical integer labels.

Equivalently, one may fill every absent edge with cost `4`. This gives a full finite cost matrix with alphabet `{0,1,4}` and exactly the same complete target-three fiber. The construction does **not** establish a zero fiber for a complete graph whose every edge has cost only zero or one. It establishes the sparse-support binary-cost version and the dense bounded-integer-cost version.

This refutes the corresponding unrestricted noncancellation assertion. It is not a resolution of P versus NP, and makes no claim about algorithms not relying on that assertion.

**Paper scope is narrower.** Yuefeng Du's [arXiv:2604.01571v3, Theorem 1.2 and Remark 1.4](https://arxiv.org/html/2604.01571v3#S1.SS2) restrict ASNC to bipartite braces and expressly allow cancellation in non-brace convolutions. [Proposition 2.3](https://arxiv.org/html/2604.01571v3#S2.SS2) tests blocks separately and combines feasibility by dynamic programming. The disconnected graph constructed here is not a brace. It therefore does not contradict that stated brace theorem or establish failure of that blockwise algorithm. It supplies an explicit exact counterexample to a stronger all-graphs noncancellation assertion and to a direct global-polynomial zero test. The source was checked on 19 October 2026; no historical novelty claim or comprehensive literature review is made.

## 1. The rational identity

Put

    (d1,d2,d3,d4)=(-1/6,-6,2/3,3/2),
    rj(t)=(t+dj)/(t-dj)       for j=1,2,3,4,
    r5(t)=(t-1)^2/(t+1)^2.

Let `e1` and `e3` denote the first and third elementary symmetric functions of `r1,...,r4`. Write `Aj=t+dj`, `Bj=t-dj`. The chosen rational numbers satisfy

    sum dj = -4,
    sum_(i<j<k) di dj dk = -4,
    product dj = 1.

Consequently, direct expansion gives

    P(t) = sum_i Bi product_(j!=i) Aj
         = 4t^4 - 8t^3 + 8t - 4
         = 4(t-1)^3(t+1),
    Q(t) = sum_i Ai product_(j!=i) Bj
         = 4t^4 + 8t^3 - 8t - 4
         = 4(t-1)(t+1)^3.

Since `e3=P/product Bj` and `e1=Q/product Bj`, there is an exact rational-function identity

    e3(r1,r2,r3,r4) = r5 e1(r1,r2,r3,r4).

There is no numerical approximation or root-isolation premise. After clearing denominators this is an identity over the integers or rationals.

All row roots in these five ratios are distinct: their absolute values are `1/6,6,2/3,3/2,1`. In particular the apparent common factors at `t=±1` inside `P/Q` do not identify any row root of the first four components. They are precisely what permits the fifth component to be a genuine two-row cycle with exponent gap two.

## 2. Genuine ten-row realization

Use the following ordered pairs of row offsets and baseline column exponents:

    cycle 1: offsets (-1/6, 1/6), exponents (0,1), B-edge costs (1,0)
    cycle 2: offsets (-6, 6),     exponents (2,3), B-edge costs (1,0)
    cycle 3: offsets (2/3,-2/3),  exponents (4,5), B-edge costs (1,0)
    cycle 4: offsets (3/2,-3/2),  exponents (6,7), B-edge costs (1,0)
    cycle 5: offsets (-1,1),      exponents (8,10),B-edge costs (1,1)

Within each component allow all four edges of its `2 by 2` block. The A matching is the displayed baseline assignment; the B matching swaps the two exponents. Each A edge has cost zero. The ordered B-edge costs above give a complete specification of the allowed costs. All allowed costs are zero or one.

The quotient of the unsigned B term by the unsigned A term is exactly `rj` in every component. The ten column exponents are distinct nonnegative integers. Every B flip is a transposition and reverses sign. If `Aj_local` is the nonzero unsigned A product of cycle j, the full fiber polynomial is

    product_j Aj_local * (-e3(r1,r2,r3,r4) + r5 e1(r1,r2,r3,r4)) = 0.

The use of `Aj_local` here is distinct from the linear factor `Aj` in Section 1.

### Completeness of the eight-term fiber

Every supported perfect matching chooses either A or B independently in each component. Hence there are exactly 32 supported perfect matchings. Its cost is

    x1+x2+x3+x4+2x5,  xj in {0,1}.

At cost three there are exactly:

- the four choices of three B components among the first four, with `x5=0`, each with sign minus;
- the four choices of one B component among the first four together with B in the fifth, each with sign plus.

These are the **entire** fiber, not a selected subsum. Its cost generating polynomial is `(1+z)^4(1+z^2)`, with coefficient sequence `(1,4,7,8,7,4,1)`. A high-cost completion with all missing edges of cost four cannot introduce a target-three matching, because all costs are nonnegative.

## 3. Canonical padding, explicitly

For each original offset `b`, set

    i = 6(b+6),    t = (L+36)/6.

Then `L+i = 6(t+b)`. The original ten row offsets in their original order embed into the canonical row indices

    (35,37,0,72,40,32,45,27,30,42).

The column indices are exactly the original exponents

    (0,1,2,3,4,5,6,7,8,10).

Take all row and column labels `0,...,72`. For each of the 63 unused rows, in increasing order, add one forced edge to the corresponding unused column, also in increasing order. All forced edges have cost zero. Retain exactly the 20 original block edges and these 63 forced edges as allowed support.

Every supported matching is an extension of one of the 32 original matchings, and each original matching has exactly one extension. The target-three fiber therefore has exactly eight matchings. Extending a permutation changes its sign by a common constant; for the explicit ordering just specified that constant is `+1`, as checked directly on all eight permutations.

Let `H(L)` be the product of the factors on the forced edges. It is a nonzero polynomial. The total degree of each original ten-row unsigned term is `46`. The canonical fiber polynomial is therefore exactly

    H(L) 6^46 F_original((L+36)/6) = 0.

This proves cancellation with consecutive canonical offsets **and** consecutive canonical exponents. The explicit `73 by 73` completed matrix in `canonical_cost_matrix.json` uses costs zero, one, and four. To read it as the binary-cost sparse graph, omit every entry of cost four.

The one-based variant follows by shifting every row label and exponent up by one. Its polynomial is the zero-based polynomial evaluated at `L+1`, times the common nonzero factor `product_(i=0)^72(L+i+1)`.

## 4. Exact verification

`verify_candidate.py` is self-contained and uses only the Python standard library. It does not read any stored certificate as input. Run:

    python verify_candidate.py
    python -O verify_candidate.py --output VERIFICATION_OPTIMIZED.json

The two receipts are byte-identical. All checks use explicit exceptions and remain active under optimization. The verifier:

1. Reconstructs and compares every coefficient in the rational identity.
2. Checks disjoint row offsets and distinct exponents.
3. Builds the actual ten-row cost matrix and backtracks through actual column-disjoint perfect matchings.
4. Enumerates every target-three matching, independently of the subset formula, and checks all 47 coefficients of the direct signed degree-46 polynomial.
5. Builds the actual canonical 73-row cost matrix and independently enumerates its entire target-three fiber.
6. Checks the extension bijection and the exact permutation signs.
7. Expands the full signed sum of its unfactored ten active-row products, proving the zero after extraction of only the explicitly common forced-edge factor.
8. Evaluates the full 73-row products at five integers as supplementary checks, not as the proof of identity.
9. Rejects exact cost and exponent mutations: raising the first B-edge cost of cycle five from one to two changes the complete target fiber to five terms and yields a nonzero polynomial; changing the last exponent from ten to eleven also yields a nonzero polynomial.

`rational_fiber.json` contains the eight raw ten-row permutations, their signs, and every unsigned coefficient. `canonical_fiber.json` contains the eight raw 73-row permutations and signs. Matrix entries and rows are zero-indexed throughout.

## 5. How the family was found

The four-cycle reflected family was already obstructed over the rationals. This construction changes the Boolean fiber: five odd flips with cost differences `(1,1,1,1,2)` require `r5=e3/e1`, instead of the four-cycle mixed-parity equation.

Choose the source rows in reciprocal symmetric pairs `d,1/d,e,1/e`. Both the sum and the third elementary symmetric sum of these four numbers equal `d+1/d+e+1/e`. Requiring that expression to equal `-4` makes the two quartics factor with the required triple/simple pattern. The rational curve

    (d+e)(de+1)+4de=0

has a node at `(-1,-1)`. A line through that node gives the rational parametrization

    d=(1-k)/(k(k+1)),
    e=k(k-1)/(k+1).

For `k=2`, this yields `d=-1/6` and `e=2/3`, and the four parameters used above. Thus the construction was found algebraically, rather than by an exhaustive or probabilistic search. Other parameters are admissible only if all displayed denominators are nonzero and the ten row roots remain distinct. No classification of all admissible parameters or minimality of dimension 73 is claimed.

## 6. Failure conditions and boundary

Suspend the result if the cleared-denominator identity fails; any row offsets or column exponents coincide; the local exponent swaps do not realize the ratios; the cost fiber has additional matchings; the canonical extension changes signs nonuniformly; or the direct coefficient sum is nonzero. The recorded checks pass each of these requirements.

Adding all missing edges with binary costs is **not** justified: new perfect matchings could enter the target-three fiber. That is a separate model. The exact repaired completion here uses forbidden cost four, which is safely above the target. Likewise, omitting one of the eight terms destroys the identity and cannot be described as this complete fiber.

The proof requires no relaxation to irrational offsets, no reused row roots, no repeated exponents, no subset selection, and no approximate equality.
