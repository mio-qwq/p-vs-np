#!/usr/bin/env python3
from itertools import permutations
from math import comb
import json

def multiply(p,q):
    out=[0]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):out[i+j]+=a*b
    return out
states=((0,0),(0,1),(1,0),(1,1))
colors=({0:0,1:0,2:1,3:1},{0:1,1:0,2:1,3:0})
terms=[];total=[0]*7
for perm in permutations(range(4)):
    if any(colors[r][c]!=k for (r,k),c in zip(states,perm)):continue
    sign=(-1)**sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))
    poly=[1]
    for (r,k),c in zip(states,perm):poly=multiply(poly,[comb(c,j)*r**(c-j) for j in range(c+1)])
    for i,v in enumerate(poly):total[i]+=sign*v
    terms.append({'permutation':list(perm),'sign':sign,'coefficients':poly})
if len(terms)!=2 or any(total) or terms[0]['coefficients']!=terms[1]['coefficients']:raise RuntimeError('supplemental exact singularity failed')
print(json.dumps({'status':'PASS','terms':terms,'determinant':[0],'scope':'Repeated graph-row doubled-state packet only; not a graph perfect matching or an ASNC counterexample.'},indent=2,sort_keys=True))
