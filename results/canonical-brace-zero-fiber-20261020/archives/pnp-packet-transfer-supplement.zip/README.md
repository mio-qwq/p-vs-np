# Private packet-transfer supplement, 19 October 2026 16:07 UTC

This source-only checkpoint supplements, and does not replace or modify, the private 15:01 brace archive. It contains the exact superfluous-edge witness e=(42,8), the actual minimal cofactor circuit T={(42,1),(30,0)}, and the distinct matching-induced support S={(42,1),(30,1)}. The circuit pair minor is zero; the matching-induced minor is nonzero. There are 146 literal Schur survivors when the lower packet is empty, not two. The failed inference is transfer between different row/layer supports, not an invertible pivot change on a fixed survivor space.

Read construction/PROOF.md and independent_audit/AUDIT.md. Both independently reconstruct the complete eight-term target-three fiber, its two nonzero four-term branches, exact cofactors, and all 24,291 disjoint-edge-pair extensions in H=G-e. prior_brace contains the frozen earlier proof and edge certificate. SOURCE_PROVENANCE.json records original source pins and the unchanged prior archive hash.

The separate 4x4 doubled-state example is a narrow supplemental observation about repeated bases and disjoint color support. verify_small_packet.py independently checks its exact polynomial cancellation. It is not a graph-perfect-matching witness or an ASNC counterexample, and is not covered by the main independent audit.

Replay offline with Python 3 standard library:

    python -B verify_bundle.py
    python -O -B verify_bundle.py

Each command checks the complete inventory, runs both original and assertion-preserving exact scripts in temporary copies, compares fresh receipts byte-for-byte, and rejects targeted mathematical, receipt, and integrity mutations. Imported originals are not modified. All checks use explicit exceptions or the assertion-preserving runner, including under -O. Rebuild outside this folder with python -B build_zip.py /chosen/path.zip.

Boundary: no P-versus-NP/P-versus-RP separation, no general algorithm exclusion, no compiled Lean verification, and no external peer review is claimed. The manuscript's Hall-plus-two endpoint caveat and standard 2-extendability interpretation remain explicit. No upload, commit, PR, merge, release, or contact was performed. Any publication or research merge remains outside this local checkpoint.

Original imported checksum/manifests retain the historical source inventory, including any omitted duplicate receipts. The authoritative self-contained bundle inventory is the root SHA256SUMS.
