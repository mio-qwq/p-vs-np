# A brace-preserving, binary-cost completion of the canonical 73-row zero fiber

19 October 2026. Local mathematical construction and exact certificate. No repository write, merge, release, external message, or publication was performed.

## Result

Keep the 73 canonical row offsets and column exponents exactly `0,...,72`. The original five-cycle construction has eight perfect matchings of red count three whose signed translated-power polynomial is zero. It has five disjoint `K_2,2` components and 63 singleton matching components.

Add the 141 explicitly specified red edges below. The resulting graph has 224 edges, is a bipartite brace under the standard 2-extendability definition, and has **exactly the same entire target-three fiber**. Its signed target-three polynomial is therefore still identically zero. No high costs, repeated labels, extra vertices, or selected subsum are used.

This construction satisfies the intended standard brace hypothesis and binary coloring of the ASNC statement in Yuefeng Du, [arXiv:2604.01571v3, Theorem 1.2](https://arxiv.org/html/2604.01571v3#S1.SS2). Subject to independent checking of the certificate, it is an exact counterexample to that statement with its displayed canonical Vandermonde weighting. It does not settle the complexity of Exact Matching or P versus NP, and gives no conclusion about algorithms that do not depend on this asserted nonvanishing.

### Definition caution

The paper's [Definition 3.1](https://arxiv.org/html/2604.01571v3#S3.SS1) gives the usual 2-extendability characterization, but its displayed Hall-plus-two condition literally includes sets of size `n−1`, for which it is impossible. We use the standard, nonvacuous meaning: every matching of size at most two extends to a perfect matching; equivalently the Hall-plus-two inequality applies to `1≤|S|≤n−2`, together with the usual matching/connectedness conditions. The graph below is proved to satisfy that corrected inequality and is also checked directly for every disjoint pair of edges. The result does not exploit the apparent endpoint typo.

## 1. Fixed canonical labels and baseline matching

The ordered active row and column lists are

    R_active = (35,37, 0,72, 40,32, 45,27, 30,42),
    C_active = (0,1, 2,3, 4,5, 6,7, 8,10).

Append the unused row labels in increasing order to form a permutation `R=(R_0,...,R_72)` of `0,...,72`. Independently append the unused column labels in increasing order to form `C=(C_0,...,C_72)`.

The baseline matching has edges `(R_i,C_i)`, all blue. For each `k=0,...,4`, also permit the two swap edges in positions `2k,2k+1`:

    (R_(2k), C_(2k+1)) is red;
    (R_(2k+1), C_(2k)) is blue for k<4 and red for k=4.

These are exactly the 83 original allowed edges. The five two-row components occupy consecutive positions `0,1; 2,3; ...; 8,9`; the 63 remaining components are singletons. There are `q=68` balanced components in their cyclic order.

Crucially, `R,C` are only an abstract ordering for constructing extra edges. The matrix entry at actual labels `(r,c)` remains `(lambda+r)^c` multiplied by the color variable. No row offset or column exponent is replaced by its abstract position.

## 2. Added edges

For every `i` modulo 73, add any missing edges

    (R_i, C_(i+1)),
    (R_i, C_(i+2)),

and color each newly added edge red. Existing edges keep their original color.

There are 141 new edges. The final graph contains the 219-edge circulant support

    (R_i,C_(i+d)),  d in {0,1,2},

plus the five old backward swap edges. Thus its total edge count is 224.

All added edges join distinct old components: inside a two-row component the sole possible forward edge already exists. Every added edge advances by one or two positions in the cyclic order of the 68 components. Both the step bound and the red coloring are essential; merely coloring arbitrary added edges red would not establish fiber preservation.

## 3. Why the graph is a brace

Write `S+1` for cyclic successor on the abstract index set `Z/73Z`. For a nonempty proper subset `S`, the union `S union (S+1)` has at least `|S|+1` members. Otherwise `S+1=S`, and invariance under cyclic successor would force `S` to be empty or all indices.

Apply this fact twice. If `1≤|S|≤71`, then

    |S union (S+1) union (S+2)| ≥ |S|+2.

Indeed, the first union either already has at least `|S|+2` elements, or has `|S|+1≤72` elements and grows again under successor. The circulant spanning subgraph therefore satisfies the robust Hall inequality, as does the graph with the five extra edges.

For completeness this directly gives the extension property. Remove the endpoints of any two disjoint allowed edges. For every nonempty subset `S` of the 71 remaining rows, its original neighbor set had at least `|S|+2` vertices; removing the two occupied columns leaves at least `|S|` neighbors. Hall's theorem supplies a residual perfect matching, and reinserting the two fixed edges gives a perfect matching of the full graph. The analogous one-edge extension follows either from the same bound or by completing that edge to a disjoint pair. The baseline matching handles the empty set. The shifts zero and one form a spanning alternating cycle, so the support is connected.

This proves standard 2-extendability without appealing to a claim that arbitrary graph-edge additions preserve braces. As a separate finite check, the verifier actually finds a perfect-matching extension for all **24,508** disjoint pairs of edges and checks every returned witness.

## 4. Why no new edge enters the target-three fiber

Consider any perfect matching in the completed graph. Within each old component the numbers of row and column vertices are equal. Hence, after contracting old components, the number of selected cross-component edges leaving each component equals the number entering it. A nonempty set of selected cross-component edges is a nonempty balanced directed multigraph and decomposes into directed cycles.

Each cross-component edge advances by one or two modulo 68. On a directed cycle of length `l`, the sum of these positive increments is a positive multiple of 68, while it is at most `2l`. Therefore

    l ≥ ceil(68/2) = 34.

Every cross-component edge is a newly added red edge. Consequently **any perfect matching containing even one added edge has at least 34 red edges**. It cannot have red count three.

Conversely each old target-three matching remains present, with all colors and canonical labels unchanged. Thus the completed graph's entire target-three fiber is exactly the original eight-member fiber. The same argument preserves every fiber of red count below 34.

This circulation proof allows arbitrary internal old matching choices. It does not assume that a partial cross-component walk must close immediately, and it does not rely on the weights of the five active cycles for its exclusion bound.

## 5. Exact polynomial cancellation

The old matching choices are five independent transpositions with red-cost differences `(1,1,1,1,2)`. Their complete target-three fiber comprises four choices of three flips among the first four and four choices of one flip among the first four together with the fifth flip. There are four negative and four positive permutation signs, respectively.

One derivation of their zero identity uses

    d=(-1/6,-6,2/3,3/2),
    r_i(t)=(t+d_i)/(t-d_i),
    r_5(t)=(t-1)^2/(t+1)^2.

The first four parameters have first and third elementary sums both `−4` and product `1`. The numerators of `e_3(r_1,...,r_4)` and `e_1(r_1,...,r_4)` after using their common denominator factor as

    P(t)=4(t−1)^3(t+1),
    Q(t)=4(t−1)(t+1)^3.

It follows that `e_3=r_5 e_1`. The active canonical row labels are obtained from the corresponding ten rational offsets by `r=6(b+6)`, and the active exponents are exactly `C_active`. This affine change multiplies every ten-row term by the same scalar and substitutes the same variable, preserving zero. The 63 remaining matching factors are common to every fiber term.

The included verifier does not rely on this symbolic derivation or the prior source receipt. It constructs the actual canonical graph, exhaustively enumerates its complete red-count-three fiber directly, computes full permutation signs on 73 labels, multiplies out the ten active row factors over the integers, and verifies that all 47 coefficients of their signed sum vanish. The common 63-row factor has degree 2582 and is nonzero; the active terms have degree 46, giving total degree 2628. The exact zero active sum therefore proves the full canonical polynomial identity.

Five complete 73-row integer evaluations are additional checks, not the identity proof.

## 6. General completion lemma behind the example

Let `H` be a disjoint union of complete balanced bipartite components, with a fixed baseline perfect matching and binary edge colors. Arrange its matched pairs cyclically with every component consecutive. Add missing red edges from each row position to column positions one and two steps forward.

The resulting graph contains the same circulant support and is 2-extendable when its size permits the standard definition. If there are `q` original components, every newly added edge advances one or two components, and any matching using a new edge has at least `ceil(q/2)` red edges. Thus every lower-red-count fiber is unchanged, including its labels, signs, terms, and full polynomial.

The completeness of each old component ensures no new internal edge is added. For arbitrary noncomplete components, this hypothesis must be replaced by a separate verification that all added edges cross components. No unrestricted brace-preserving padding lemma for arbitrary supported graphs is asserted.

## 7. Reproduce and falsify

Run the self-contained standard-library checker:

    python verify_brace.py
    python -O verify_brace.py --output VERIFICATION_OPTIMIZED.json

Both runs retain all checks, since failures use explicit exceptions rather than assertions. Their receipts are deterministic and must agree byte-for-byte.

Files:

- `verify_brace.py`: construction, full target enumeration, polynomial arithmetic, and exhaustive two-edge extension checks.
- `brace_edges.json`: all 224 actual-label edges and binary costs.
- `brace_fiber.json`: all eight full 73-label permutations, signs, and active polynomial coefficients.
- `VERIFICATION.json`, `VERIFICATION_OPTIMIZED.json`: full exact receipts.
- `SHA256SUMS`: frozen file hashes.

Negative controls alter one original red cost, obtaining a different complete fiber and a nonzero signed polynomial, and test that adding a single one-way cross-component edge does not produce a matching-covered graph. They demonstrate that the checker is sensitive to relevant changes, not that arbitrary mutations have been exhausted.

The construction must be rejected if even one purported target matching is missing, any additional target matching appears, an extension witness fails, labels are reassigned to abstract positions, any active coefficient is nonzero, or the new-edge exclusion fails. None of these conditions is waived by the prior disconnected counterexample.

## Prior-work boundary

Recovered before building this extension:

- The canonical five-cycle certificate in `/workspace/shared/five-cycle-rational-search-20261019-1436` supplied the fixed eight-term zero fiber.
- The rational-to-canonical padding audits correctly warned that high-cost completion did not preserve the binary brace model.
- The earlier scope audits correctly separated unrestricted noncancellation from the paper's brace-only statement.

The new content here is the binary-red circulant completion, its robust Hall proof, its cross-component circulation exclusion, and the complete finite certificate for the resulting brace. The older scope warning remains correct for the older disconnected graph; this separate completed graph removes that particular boundary.
