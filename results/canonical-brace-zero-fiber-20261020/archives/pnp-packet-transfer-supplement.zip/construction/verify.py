#!/usr/bin/env python3
"""Self-contained exact private audit of a two-row packet support-transfer failure.
Only standard-library arithmetic; no downloaded research code, no network calls.
"""
from itertools import permutations, combinations
from math import comb
from pathlib import Path
import json, hashlib

ROOT=Path(__file__).resolve().parent
N=73
RA=[35,37,0,72,40,32,45,27,30,42]
CA=[0,1,2,3,4,5,6,7,8,10]

def check(b,msg):
    if not b: raise RuntimeError(msg)
def trim(p):
    while len(p)>1 and p[-1]==0: p.pop()
    return p

def add(p,q):
    out=[0]*max(len(p),len(q))
    for i,x in enumerate(p): out[i]+=x
    for i,x in enumerate(q): out[i]+=x
    return trim(out)
def scale(p,s): return trim([s*x for x in p])
def mul(p,q):
    z=[0]*(len(p)+len(q)-1)
    for i,x in enumerate(p):
        for j,y in enumerate(q): z[i+j]+=x*y
    return trim(z)
def linpow(r,k): return [comb(k,j)*r**(k-j) for j in range(k+1)]
def sign(p): return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
def val(p,x): return sum(c*x**i for i,c in enumerate(p))

R=RA+sorted(set(range(N))-set(RA))
C=CA+sorted(set(range(N))-set(CA))
baseline=dict(zip(R,C)); old={(r,c):0 for r,c in baseline.items()}
for k in range(5):
    a,b=R[2*k:2*k+2]; x,y=C[2*k:2*k+2]
    old[a,y]=1; old[b,x]=int(k==4)
E=dict(old)
for i,r in enumerate(R):
    for s in [1,2]: E.setdefault((r,C[(i+s)%N]),1)
e=(42,8); H=dict(E); del H[e]
check(len(E)==224 and len(H)==223,'edge counts')
check(all((R[i],C[(i+s)%N]) in H for i in range(N) for s in [0,1,2]),'H retains spanning circulant')

def fiber(edges,target,missing=None):
    omitted_row,omitted_col=missing if missing else (-1,-1)
    order=[r for r in R if r!=omitted_row]
    adj={r:sorted((c,w) for (rr,c),w in edges.items() if r==rr and c!=omitted_col) for r in order}
    p=[-1]*N
    if missing:p[omitted_row]=omitted_col
    out=[]
    def walk(k,used,cost):
        if k==len(order):
            if cost==target:out.append(tuple(p))
            return
        r=order[k]
        for c,w in adj[r]:
            if cost+w<=target and not (used>>c)&1:
                p[r]=c;walk(k+1,used|(1<<c),cost+w)
    walk(0,0,0)
    return sorted(out)

def poly(fs,omitted_row=None):
    out=[0]
    for p in fs:
        term=[1]
        for r in RA:
            if r!=omitted_row:term=mul(term,linpow(r,p[r]))
        out=add(out,scale(term,sign(p)))
    return out

F=fiber(E,3); FH=fiber(H,3)
Fe=[p for p in F if p[42]==8]
check(len(F)==8 and len(FH)==4 and len(Fe)==4,'fiber split 4+4')
check(set(FH).isdisjoint(Fe) and set(FH)|set(Fe)==set(F),'exact disjoint split')
check(all(sign(p)==-1 for p in FH) and all(sign(p)==1 for p in Fe),'branch signs')
PG=poly(F); PH=poly(FH); PE=poly(Fe)
check(PG==[0] and PH!=[0] and PE!=[0] and add(PH,PE)==[0],'branch polynomial identity')
check(PH[-1]==-4 and PE[-1]==4,'branch leading terms')
rowterms={}
for (r,c),cost in sorted(E.items()):
    if r!=42:continue
    fs=fiber(H,3-cost,(r,c))
    cp=poly(fs,r)
    rowterms[c]={'cost':cost,'count':len(fs),'cofactor':cp}
check([c for c,v in rowterms.items() if v['cofactor']!=[0]]==[8,10],'active row42 columns')
check(rowterms[8]['count']==4 and rowterms[10]['count']==4,'row expansion fiber sizes')
check(mul(linpow(42,8),rowterms[8]['cofactor'])==PE,'e contribution')
check(mul(linpow(42,10),rowterms[10]['cofactor'])==PH,'other contribution')

# U^(8) has the signed cofactor coefficient [x^(3-k)] at state (r,k).
# Every listed minor has the same common singleton-row factor of degree2582.
U={}; Ucounts={}
for r in [30,42]:
    for k in [0,1]:
        fs=fiber(H,3-k,(r,8)); U[r,k]=poly(fs,r);Ucounts[r,k]=len(fs)
check(Ucounts=={(30,0):4,(30,1):6,(42,0):6,(42,1):4},'cofactor layer counts')
check(all(p!=[0] for p in U.values()),'four nonzero cofactor entries')
check(sign(tuple(baseline[r] for r in range(N)))==1,'positive baseline sign')
Q=[[1]]
for k in range(4):
    r,s=RA[2*k:2*k+2];c,d=CA[2*k:2*k+2]
    A=mul(linpow(r,c),linpow(s,d));B=mul(linpow(r,d),linpow(s,c))
    new=[[0] for _ in range(len(Q)+1)]
    for j,p in enumerate(Q):
        new[j]=add(new[j],mul(p,A))
        new[j+1]=add(new[j+1],scale(mul(p,B),-1))
    Q=new
check(mul(linpow(42,2),Q[3])==mul(linpow(30,2),Q[1]),'b squared Q3 equals a squared Q1')
check(U[30,0]==mul(linpow(42,10),Q[3]),'explicit U30,0 formula')
check(U[30,1]==mul(linpow(42,10),Q[2]),'explicit U30,1 formula')
check(U[42,0]==scale(mul(linpow(30,10),Q[2]),-1),'explicit U42,0 formula')
check(U[42,1]==scale(mul(linpow(30,10),Q[1]),-1),'explicit U42,1 formula')
# New-edge states entering these two columns have zero relevant cofactors.
for r,k in [(27,1),(45,1)]:
    fs=fiber(H,3-k,(r,8));cp=poly(fs,r)
    # Here no common-factor normalization is needed: the fibers are actually empty.
    check(len(fs)==0,'new-edge cofactor fiber empty')

def entry(state,c):
    r,k=state
    return linpow(r,c) if E.get((r,c))==k else [0]
def pairminor(states,c,d):
    s,t=states
    return add(mul(entry(s,c),entry(t,d)),scale(mul(entry(s,d),entry(t,c)),-1))
q=(42,1);a=(30,0);b=(30,1);a2=(42,0)
T=[q,a]; TM=[q,b]
gpair=add(mul(entry(q,8),U[q]),mul(entry(a,8),U[a]))
upair=add(mul(entry(b,10),U[b]),mul(entry(a2,10),U[a2]))
check(gpair==[0] and upair==[0],'two separate exact cofactor cancellations')
check(entry(q,8)!=[0] and entry(a,8)!=[0],'T genuine two-row g circuit')
check(entry(q,10)==[0] and entry(a,10)==[0],'upper column vanishes on T')
check(entry(a,9)==[0] and mul(entry(q,9),U[q])!=[0],'circuit restriction does not preserve column9 duplicate identity')
MT=pairminor(T,8,10);MM=pairminor(TM,8,10)
check(MT==[0],'circuit pair minor zero')
check(MM==mul(linpow(42,8),linpow(30,10)),'matching-induced minor')
check(MM!=[0],'matching-induced minor nonzero')
check(all(p[30]==10 and p[42]==8 for p in Fe),'matching induces TM')
check(mul(entry(q,8),U[q])!=[0] and mul(entry(b,10),U[b])!=[0], 'restriction TM loses both annihilations')

# Supplement: disjoint paired-state supports do not imply the masked-minor claim.
# This is a packet of a genuine all-supported K4,4 coloring, NOT an ASNC example.
smallstates=[(0,0),(0,1),(1,0),(1,1)]
smallE={(r,c):0 for r in range(4) for c in range(4)}
for c in [2,3]:smallE[0,c]=1
for c in [0,2]:smallE[1,c]=1
smallW=[[linpow(r,c) if smallE[r,c]==k else [0] for c in range(4)] for r,k in smallstates]
sdet=[0];sterms=[]
for p in permutations(range(4)):
    if any(smallW[i][p[i]]==[0] for i in range(4)):continue
    term=[1]
    for i in range(4):term=mul(term,smallW[i][p[i]])
    sterms.append({'permutation':p,'sign':sign(p),'coefficients':term})
    sdet=add(sdet,scale(term,sign(p)))
check(len(sterms)==2 and sdet==[0],'doubled-state singular example')
check(sterms[0]['coefficients']==sterms[1]['coefficients']==mul(linpow(0,3),linpow(1,3)),'small equal unsigned products')

# Independently check every disjoint pair extends in H, retaining witness digests.
adj={r:sorted(c for rr,c in H if rr==r) for r in range(N)}
def extend(es):
    er={r for r,c in es}; ec={c for r,c in es}; matching={}
    def aug(r,seen):
        for c in adj[r]:
            if c in ec or c in seen:continue
            seen.add(c)
            if c not in matching or aug(matching[c],seen):matching[c]=r;return True
        return False
    for r in R:
        if r not in er and not aug(r,set()):return None
    p=[-1]*N
    for c,r in matching.items():p[r]=c
    for r,c in es:p[r]=c
    check(sorted(p)==list(range(N)) and all((r,c) in H for r,c in enumerate(p)),'valid extension')
    check(all(p[r]==c for r,c in es),'contains fixed edges')
    return p
paircount=0;hh=hashlib.sha256()
for f,g in combinations(sorted(H),2):
    if f[0]==g[0] or f[1]==g[1]:continue
    p=extend([f,g]);check(p is not None,'H pair extension')
    paircount+=1;hh.update(bytes([*f,*g,*p]))

result={'status':'PASS','N':N,'e':e,'G_edge_count':len(E),'H_edge_count':len(H),
 'H_all_disjoint_pairs_extend':paircount,'H_pair_witness_hash':hh.hexdigest(),
 'G_fiber_count':len(F),'H_fiber_count':len(FH),'using_e_count':len(Fe),
 'common_factor_degree':sum(baseline[r] for r in set(range(N))-set(RA)),
 'G_active_polynomial':PG,'H_active_polynomial':PH,'e_active_polynomial':PE,
 'row42_cofactors':rowterms,'D_minus':[],'D_plus':[10],
 'cofactor_entries':{str(s):{'count':Ucounts[s],'coefficients':p} for s,p in U.items()},
 'four_block_polynomials':Q,'circuit_states':T,'matching_states':TM,'circuit_minor':MT,'matching_minor':MM,
 'matching_minor_value_at_lambda1':val(MM,1),
 'lower_rank_on_circuit':0,'augmented_g_rank_on_circuit':1,
 'small_doubled_packet_states':smallstates,'small_doubled_packet_terms':sterms,
 'small_doubled_packet_determinant':sdet,
 'boundary':'Private exact verification; no repository mutation or public communication.'}
(ROOT/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(ROOT/'GRAPH.json').write_text(json.dumps([{'row':r,'col':c,'color':w} for (r,c),w in sorted(E.items())],indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','H_all_disjoint_pairs_extend','G_fiber_count','H_fiber_count','using_e_count','D_minus','D_plus','circuit_minor','matching_minor_value_at_lambda1']}))
