# Exact two-row failure of the matching-to-circuit packet transfer

19 October 2026 UTC. Private derivation and standalone exact checks. No repository mutation, author contact, public submission, release, or downloaded-code execution occurred.

## Result

For the completed canonical 73-row binary brace, take the red edge e=(42,8). Deleting e leaves a brace. The target-three polynomial splits into two nonzero four-term polynomials which cancel exactly.

More locally, the actual exact-layer cofactor vector has a genuine two-row cancellation circuit

    T = {(42,1), (30,0)}.

The lower active packet is empty. On T the distinguished column w8 is nonzero and the upper active column w10 is identically zero, so their pair minor is zero. The matching-induced rows used by the paper's two-extra argument are instead

    T_match = {(42,1), (30,1)},

where the same two columns form a diagonal matrix with determinant

    (lambda+42)^8 (lambda+30)^10 != 0.

Thus the inference transferring a nonzero matching-induced minor to this circuit support is false. Both restrictions use the SAME empty lower pivot. Changing the surviving rows is not a change of pivot coordinates.

This pinpoints a proof-interface failure in addition to the full counterexample. The matching-induced nonzero minor itself is correct here. The calculation does not claim to invalidate sound linear algebra about invertible changes of basis on one fixed quotient.

## 1. Sources, prior recovery, and limitations

The live version-pinned manuscript was checked:

- https://arxiv.org/html/2604.01571v3#S7.SS2
- https://arxiv.org/html/2604.01571v3#S7.SS3
- https://arxiv.org/html/2604.01571v3#A1

Source mapping: Definition 7.4 supplies the doubled states. Theorem 7.21 constructs a matching-induced square minor, then its final proof paragraph transfers nonvanishing to the circuit support via Lemma 7.3. Proposition 7.20 requires an actual survivor space of dimension two for its projective-collapse conclusion. Appendix A lists graph-to-packet extraction among its assumed formalization inputs. These are source descriptions, not additional verified Lean facts.

The linked formal source https://anonymous.4open.science/r/exact-matching-lean-FFD2 could not be read: both direct web-tool requests returned that the URL was inaccessible. Searches did not recover the actual declarations. No Lean theorem signature, build, or current source commitment has been inspected. Consequently this report identifies an exact mismatch in the public mathematical argument and its described extraction interface; it does not assert that a specific compiled Lean theorem is false.

Recovered before this derivation: the earlier limited claim audit, its nonmonic masked-minor counterexample and monic valuation gap; the canonical brace construction; the independent completion audit; and the 15:01 source comparison. The old C6/tight-cut analysis was not repeated. The new two-row calculation is independent of that issue.

## 2. Fixed graph and superfluous edge

Use rows and columns 0,...,72 with unchanged weights (lambda+r)^c. List the active rows and columns as

    R_active=(35,37,0,72,40,32,45,27,30,42),
    C_active=(0,1,2,3,4,5,6,7,8,10).

Append unused labels in increasing order to obtain lists R,C. Include the blue baseline edges (R_i,C_i). For k=0,...,4, also include the red edge (R_(2k),C_(2k+1)); include the backward swap (R_(2k+1),C_(2k)) blue for k<4 and red for k=4. Finally add all missing edges (R_i,C_(i+1)) and (R_i,C_(i+2)), cyclically modulo73, colored red.

Call the result G. It has 224 edges. The edge e=(42,8) is the backward swap in the fifth block, abstract index 9 to8. It is not in the three-shift spanning support. Therefore H=G-e, with 223 edges, still contains every shift 0,1,2 edge.

For a nonempty proper set X of cyclic row positions, X union(X+1) grows by at least one unless it is the full cycle. Applying this twice gives at least |X|+2 neighbors for 1<=|X|<=71. This proves 2-extendability of H and G by Hall after deleting any two matched row/column pairs. The shift 0/1 support also proves connectedness.

The checker separately tests all 24,291 disjoint edge pairs of H and verifies a full matching extension for each. In particular e is superfluous in the standard brace sense.

Definition caution: the manuscript's literal Hall+2 endpoint for |X|=n-1 is impossible. This analysis uses its expressly stated equivalent standard 2-extendability interpretation, as in the preceding brace certificates.

## 3. Why the low fibers and row expansion are exact

The original five K2,2 blocks and 63 singleton blocks give 68 balanced components. Each added edge advances one or two components cyclically and is red. A perfect matching using any added edge produces a balanced nonempty directed graph on components, hence a directed cycle with at least 34 arcs. Such a matching has at least 34 red edges.

Therefore all fibers with target below 34 retain exactly the original graph's matchings. At target 3 there are:

- Four matchings flipping three of the first four blocks and not the fifth. They avoid e, and all have global sign -1.
- Four matchings flipping one of the first four blocks and the fifth. They use e, and all have global sign +1.

They are the complete fiber. The signed sums of each branch are nonzero: their reduced degree 46 leading coefficients are -4 and +4. Their sum is exactly zero in all 47 coefficients.

Row42 is incident to columns 8,9,10,11, of colors1,1,0,1. The cofactor fibers associated to columns 9 and11 are empty at target 2, because adjoining the corresponding newly added red edge would create a target 3 matching using such an edge. The columns 8 and10 have four cofactor matchings each and nonzero signed cofactor polynomials. Consequently, in the paper's row 42 notation,

    D_minus = empty,
    D_plus = {10},
    R8 != 0,
    P3(H) = (lambda+42)^10 R10 != 0,
    contribution_using_e = (lambda+42)^8 R8 != 0,
    P3(G) = (lambda+42)^10 R10 + (lambda+42)^8 R8 = 0.

The verifier enumerates the actual 73-row graph and the actual deleted-row/deleted-column minors. It does not assume these counts from the block discussion.

## 4. Explicit actual cofactor vector

Write a=lambda+30 and b=lambda+42. Let S be the common product of the 63 singleton-row factors, of degree 2582. The global baseline permutation has positive sign.

For each of the first four K2,2 blocks, let A_i be its unsigned baseline product and B_i its unsigned swapped product. Define Q_j by

    Q(x)=product_(i=1)^4(A_i-x B_i)=sum_(j=0)^4 Q_j x^j.

Each Q_j is nonzero and has degree 28, with leading coefficient (-1)^j binomial(4,j). For the fifth block the determinant factor is

    a^8 b^10 - x^2 a^10 b^8.

The target-three cancellation is exactly

    b^2 Q3 = a^2 Q1.

The signed column 8 cofactor is independent of whether e itself is in G or H, because column 8 is deleted. At doubled state (r,k), let U_(r,k) be its coefficient of x^(3-k). For the four relevant states:

    U_(30,0) = S b^10 Q3,
    U_(30,1) = S b^10 Q2,
    U_(42,0) = -S a^10 Q2,
    U_(42,1) = -S a^10 Q1.

All four are nonzero. Their minor matching counts are respectively 4,6,6,4; their reduced leading coefficients are -4,+6,-6,+4. The standalone checker reconstructs all four by exact enumeration and polynomial expansion.

The only remaining states supporting column 8 are (27,1) and (45,1), each corresponding to a newly added red edge into column 8. Their target 2 cofactor fibers are empty. Thus the actual column 8 pairing is supported precisely on

    T={q=(42,1), a0=(30,0)}.

It vanishes:

    w8^T U = b^8(-S a^10 Q1) + a^8(S b^10 Q3) = 0.

The upper active column 10 instead pairs with (30,1) and (42,0), and their contributions cancel separately:

    a^10(S b^10 Q2) + b^10(-S a^10 Q2) = 0.

The other column 10-support state, (27,1), has zero cofactor as already checked.

## 5. Two different restrictions, two different minors

On ordered rows T=(q,a0), the packet with columns(8,10) is

    [[b^8, 0],
     [a^8, 0]].

Because the lower packet V has no columns, rank(V_T)=0. The nonzero column w8 gives rank([V_T|w8_T])=1. Each individual row is nonzero, so T is genuinely minimally dependent, with m=2 and rank(V_T)=m-2. A basis of ker(V_T^T) is the two coordinate vectors; its pair minor is zero. The actual restriction U|T is nonzero and annihilates w8_T, while w10_T=0.

Every target 3 matching using e also uses the red edge(30,10). Thus the matching construction chooses ordered doubled states T_match=(q,b1), with b1=(30,1). On these rows the same columns are

    [[b^8, 0],
     [0,   a^10]].

Its determinant is b^8 a^10, nonzero. At lambda=1 it is 9579979571418630342357338401.

These calculations refute the transfer of nonvanishing from the matching-induced restriction to the circuit restriction. There is no normalization ambiguity: in both calculations the lower pivot is the empty 0x0 matrix with determinant1. The operation that changes the result is replacing state(30,0) by state(30,1), not changing coordinates in a fixed survivor space.

This does not assert that H satisfies ASNC for every target or coloring: the checked nonvanishing of H is for this target-three instance. The intermediate packet transfer itself has the stated cancellation hypotheses, all of which are instantiated here.

The actual cofactor vector confirms why the transfer is unavailable. Restricting it to T_match loses both annihilations: its w8 pairing is b^8 U_q !=0, and its w10 pairing is a^10 U_b1 !=0. The cancelling partners lie outside T_match. Conversely the actual circuit T does satisfy the required annihilation, but its upper active column vanishes.

The circuit restriction also fails to preserve other duplicate-column equations. For example, column 9 restricts to [b^9,0] on T, so its pairing with U|T is b^9 U_q !=0. The corresponding full-space pairing still vanishes by the exact duplicate-column identity. Column9 is inactive in the row 42 expansion (R9=0), which is why this failure does not conflict with the two active-column annihilations just checked.

A full Schur elimination on the empty lower packet leaves all 146 doubled states, not two. That full space does contain independent columns w8,w10 and a common nonzero annihilator; no collinearity follows in such dimension. Passing to a two-dimensional circuit support requires an additional extraction theorem preserving the relevant identities and matching witness. The displayed graph demonstrates the incompatibility of those requirements for the transfer used here.

## 6. Separate small check: disjoint colors do not repair repeated bases

The claim that disjoint color supports make the pairwise-coprime masked-minor criterion applicable to arbitrary doubled-state minors also has a 4x4 counterexample.

Take the complete graph K4,4. Color row 0 blue in columns 0,1 and red in 2,3. Color row 1 blue in 1,3 and red in 0,2. Other rows can be all blue. Let a=lambda, b=lambda+1. On doubled states(0,0),(0,1),(1,0),(1,1), columns 0,1,2,3 give

    [[1, a, 0,   0],
     [0, 0, a^2, a^3],
     [0, b, 0,   b^3],
     [1, 0, b^2, 0]].

The two support permutations are(0,3,1,2), of positive sign, and(1,2,3,0), of negative sign. Both products equal a^3 b^3, so the determinant is zero. Paired states have disjoint supports as required by the coloring construction, but share the same base, contrary to pairwise coprimality across all packet rows.

This does not contradict the distinct-row-base hypothesis of Proposition 7.1. Nor is it an ASNC counterexample for K4,4: the packet selects each of two graph rows twice, so its support matching is not induced by a graph perfect matching. It specifically disproves the claimed sufficiency of disjoint color supports for the broader doubled-state application. The 73-row transfer failure in Sections 4–5 does not depend on this supplementary example.

## 7. Reproduction and precise boundary

Run:

    python verify.py
    python -O verify.py

Both runs retain checks through explicit exceptions. The script independently reconstructs G and H; checks the full low-cost fibers and all relevant cofactor fibers; computes polynomial coefficients and signs; checks all 24,291 edge-pair extensions in H; and verifies both the 2x2 transfer failure and the 4x4 supplemental singular packet. RESULT.json and GRAPH.json contain the deterministic receipts.

This establishes an exact failed intermediate inference in the public proof, with actual canonical labels, actual binary coloring, actual superfluous edge, and actual cofactor coefficients. It does not establish a P/NP or P/RP separation, exclude other deterministic Exact Matching algorithms, inspect inaccessible Lean declarations, or confer external peer-review validation. No public claim or repository operation was authorized or performed.
