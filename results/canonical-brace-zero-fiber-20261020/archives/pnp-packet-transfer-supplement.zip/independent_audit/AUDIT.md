# Independent audit: a row-support change in the two-extra argument

19 October 2026. Private local mathematical audit. No repository modification, release, publication, or third-party communication was performed.

## Verdict and exact scope

The proposed witness passes the independent checks. It isolates an unsupported transfer at the end of the proof of [Theorem 7.21](https://arxiv.org/html/2604.01571v3#S7.Thmtheorem21): a nonzero determinant on matching-selected doubled states does not imply a nonzero determinant after restricting to a different circuit support.

The matching-selected determinant in this example is genuinely nonzero. This audit does **not** refute that existence statement. It also does **not** identify the two-state circuit with the full Schur survivor set. Those distinctions are essential.

In fact the lower packet has no columns here. Its only pivot is the empty matrix, and its full survivor space still has 146 coordinates. The two 2-by-2 matrices below use different row supports. Their discrepancy therefore cannot be attributed to changing a lower pivot.

## 1. Independent reconstruction and hypothesis checks

The checker reconstructs the 73-by-73 graph from the ten actual row labels

    (35,37,0,72,40,32,45,27,30,42)

and ten actual column labels

    (0,1,2,3,4,5,6,7,8,10).

It appends the unused labels in increasing order; uses the resulting paired lists for a blue baseline matching; adds the five internal swap pairs with cost differences 1,1,1,1,2; and adds missing red edges one and two positions forward cyclically. All weights retain their actual canonical labels. The resulting graph has 224 edges.

Let e=(42,8), colored red, and H=G−e. The edge e is an old backward swap edge; deleting it retains the entire spanning support with forward steps 0,1,2. Hence H is a standard bipartite brace: for every nonempty row subset S of size at most 71, cyclic expansion gives |S∪(S+1)∪(S+2)|≥|S|+2. Removing the endpoints of two prescribed disjoint edges preserves Hall's inequality. Independently, the checker finds and verifies extensions of all 24,291 disjoint edge pairs in H.

Every newly added edge crosses between the 68 old balanced components and advances one or two components. A perfect matching using any such edge must contain a directed cycle of cross-component edges, of length at least 34. All those edges are red. The target-three fiber therefore uses only old edges. The independent direct enumerator nevertheless searches the completed graph itself and finds:

- G: eight target-three perfect matchings; its exact signed polynomial is zero.
- H: four target-three perfect matchings, each with negative permutation sign.
- The e-branch: four target-three perfect matchings, each with positive permutation sign.

For clarity, this uses the standard nonvacuous brace definition. It does not exploit the paper's separate Hall-bound endpoint issue.

## 2. Closed-form exact cofactors

Put μ_i=λ+i, a=μ_30, and b=μ_42. Let

    C = product over the 63 padding rows i of μ_i^(BASE(i)),
    F = μ_0^2 μ_72^2 μ_40^4 μ_32^4 μ_45^6 μ_27^6.

The baseline map BASE is specified completely in the checker. C has degree 2582 and F has degree 24. Both are nonzero polynomials.

The actual row-42 expansion coefficients, using the signed cofactors and color extraction prescribed in [Section 7.3](https://arxiv.org/html/2604.01571v3#S7.SS3), are

    R_8  =  4 C F a^11 b^3,
    R_10 = −4 C F a^11 b,
    R_9 = R_11 = 0.

These are all the possible neighbors of row 42. Thus D− is empty, D+={10}, and R_8 is nonzero. The two full branches are

    P_3(H) = b^10 R_10 = −4 C F a^11 b^11,
    e-branch = b^8 R_8 = +4 C F a^11 b^11.

Their sum is identically zero. These formulas are checked by coefficient equality, not inferred from evaluations.

For the column-8 cofactor vector U=U^(8), the [Definition 7.4](https://arxiv.org/html/2604.01571v3#S7.Thmtheorem4) coordinates use coefficient x^(3−κ) at state (i,κ). The two relevant coordinates are exactly

    U_(42,1) =  4 C F a^11 b^3,
    U_(30,0) = −4 C F a^3 b^11.

Both are nonzero. Deleting column 8 removes e, so computing these cofactors in G or H gives the same result. The other column-8 packet states, (27,1) and (45,1), have empty target-two residual fibers and zero coordinates. Consequently the following two-state calculation accounts for the entire column-8 pairing, not an arbitrary selected subsum.

## 3. The circuit really is legitimate

Set q=(42,1) and T=(q,(30,0)), in this order. The actual packet has

    w_8|T  = [b^8, a^8]^T,
    w_10|T = [0, 0]^T.

Since V has zero columns, B|T=[w_8|T] has two nonzero rows in a one-dimensional space. Each singleton is independent, so T is a genuine minimal dependent row set containing q, of exactly the form used by [Proposition 7.6](https://arxiv.org/html/2604.01571v3#S7.Thmtheorem6). It satisfies

    m=2, rank(B|T)=1=m−1, rank(V|T)=0=m−2.

Let K=4 C F a^3 b^3. The actual restricted cofactor is

    U|T = K [a^8, −b^8]^T.

It annihilates both active packet columns on T. In particular,

    det([w_8|T, w_10|T]) = 0.

No abstract, unrealizable cofactor vector has been substituted. The residual fibers and signs producing both coordinates are enumerated in the receipt.

## 4. The matching-selected determinant remains true

Any target-three matching containing e also uses the red edge (30,10). The states induced by these two matching edges are

    S=((42,1),(30,1)).

On S the same packet columns give

    [w_8|S, w_10|S] = diag(b^8,a^10),
    det([w_8|S,w_10|S]) = b^8 a^10 ≠ 0.

The receipt includes a complete 73-row matching inducing these states. This is precisely a valid nonzero matching-selected minor.

Crucially, S contains (30,1), whereas T contains (30,0). The two layers have disjoint supports. Replacing one by the other changes the row restriction. The actual cofactor restricted to S does not annihilate w_8|S: its pairing is b^8 U_(42,1), which is nonzero.

## 5. Where the inference fails, and what is not established

[Theorem 7.21's final proof paragraph](https://arxiv.org/html/2604.01571v3#S7.Thmtheorem21) uses [Lemma 7.3](https://arxiv.org/html/2604.01571v3#S7.Thmtheorem3) to connect the matching minor with the circuit support used in the collapse argument. The valid pairing principle compares lower-column subtraction for one fixed vector in the fixed ambient kernel. It does not identify different row-restricted minors.

Here this distinction is especially sharp: D− is empty, so the lower pivot and Schur column operation are already fixed and trivial. The two determinants are respectively nonzero and zero solely because S and T are different row supports.

There is a second indispensable qualification. [Proposition 7.20](https://arxiv.org/html/2604.01571v3#S7.Thmtheorem20) describes all survivors after a Hall pivot, whereas Proposition 7.6 describes a minimal circuit. In this example all 146 doubled states survive the empty pivot. The two-row T is an additional restriction, not that survivor set. Its two-dimensional quotient cannot be substituted for the 146-dimensional full survivor space without a further justified reduction.

This restriction also does not preserve every duplicate-column identity. For graph column 9,

    w_9|T = [b^9,0]^T,
    (w_9|T)^T(U|T) = b^9 U_(42,1) ≠ 0.

Globally the column-9 pairing is zero by the duplicate-column determinant identity, so contributions outside T are essential. The checker explicitly verifies the nonzero restricted pairing. Columns 8 and 10 are the active row-42 columns; their restricted pairings were separately verified above.

Thus the supported conclusion is narrow and decisive: the move from a matching-selected minor to the circuit-restricted minor is unjustified and fails on this graph. The valid matching-minor existence claim and the full-space Schur pairing identity are not refuted by this calculation. Separately, the full canonical brace fiber itself supplies an exact zero-polynomial counterexample to the stated ASNC claim.

## 6. Reproduction and independence

Run:

    python verify_packet_transfer.py
    python -O verify_packet_transfer.py --output VERIFICATION_OPTIMIZED.json
    cmp VERIFICATION.json VERIFICATION_OPTIMIZED.json

This checker was independently written for this audit, imports no earlier checker or result receipt, and uses only the Python standard library. It independently reconstructs the graph, enumerates the full and needed residual fibers, calculates full-label permutation/cofactor signs, expands exact integer polynomials, verifies the factored formulas, checks the two row restrictions and the column-9 negative control, and verifies every two-edge extension in H. There are no assertions disabled by −O.

Artifacts:

- verify_packet_transfer.py: standalone independent checker.
- VERIFICATION.json and VERIFICATION_OPTIMIZED.json: identical exact receipts.
- GRAPH.json: complete reconstructed colored graph.
- source.html: fresh independent retrieval of arXiv:2604.01571v3.
- SHA256SUMS: frozen artifact hashes.

No claim here settles Exact Matching's complexity or P versus NP.
