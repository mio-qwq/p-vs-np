#!/usr/bin/env python3
"""Independent exact audit. Standard library only. No receipt import; no assertions."""
import argparse, hashlib, itertools, json, math
from pathlib import Path
HERE=Path(__file__).resolve().parent
N=73
AR=(35,37,0,72,40,32,45,27,30,42)
AC=(0,1,2,3,4,5,6,7,8,10)
R=AR+tuple(i for i in range(N) if i not in AR)
C=AC+tuple(i for i in range(N) if i not in AC)
BASE=dict(zip(R,C))

def check(a,msg):
    if not a: raise ValueError(msg)
def digest(a): return hashlib.sha256(json.dumps(a,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def trim(p):
    while len(p)>1 and p[-1]==0:p.pop()
    return p
def add(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def scale(a,s):return trim([s*x for x in a])
def mul(a,b):
    r=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):r[i+j]+=x*y
    return trim(r)
def power(a,k):return [math.comb(k,j)*a**(k-j) for j in range(k+1)]
def sign(seq):return 1 if sum(x>y for i,x in enumerate(seq) for y in seq[i+1:])%2==0 else -1

def graph():
    g={(r,c):0 for r,c in BASE.items()}
    for k in range(5):
        g[R[2*k],C[2*k+1]]=1
        g[R[2*k+1],C[2*k]]=1 if k==4 else 0
    old=set(g)
    for i,r in enumerate(R):
        for d in (1,2):g.setdefault((r,C[(i+d)%N]),1)
    h=dict(g);del h[42,8]
    for d in (0,1,2):
        check(all((R[i],C[(i+d)%N]) in h for i in range(N)), 'H lost spanning circulant')
    check(len(g)==224 and len(h)==223,'size')
    blocks=[i//2 if i<10 else i-5 for i in range(N)]
    rb=dict(zip(R,blocks));cb=dict(zip(C,blocks))
    check(all(g[r,c]==1 and (cb[c]-rb[r])%68 in (1,2) for r,c in set(g)-old),'cross-component edges')
    return g,h

def enumerate_partial(g,cost,remove_row=None,remove_col=None):
    ro=[r for r in R if r!=remove_row]
    adj={r:sorted((c,k) for (i,c),k in g.items() if i==r and c!=remove_col) for r in ro}
    p=[-1]*N;out=[];visits=0
    def rec(k,used,remaining):
        nonlocal visits
        visits+=1
        if k==len(ro):
            if remaining==0:out.append(tuple(p))
            return
        r=ro[k]
        for c,w in adj[r]:
            if w<=remaining and not (used>>c)&1:
                p[r]=c;rec(k+1,used|(1<<c),remaining-w)
        p[r]=-1
    rec(0,0,cost)
    return sorted(out),visits

def polynomial(terms,remove_row=None,remove_col=None):
    total=[0];records=[]
    for p in terms:
        check(all(p[r]==BASE[r] for r in range(N) if r not in AR),'padding factor varies')
        seq=[p[r] for r in range(N) if r!=remove_row]
        s=sign(seq)
        if remove_row is not None:s*=(-1)**(remove_row+remove_col)
        a=[1]
        for r in AR:
            if r!=remove_row:a=mul(a,power(r,p[r]))
        total=add(total,scale(a,s))
        records.append({'permutation':p,'cofactor_or_permutation_sign':s})
    return total,records

def check_extensions(h):
    adj={r:[c for i,c in h if i==r] for r in range(N)}
    count=0;sha=hashlib.sha256()
    for (r,c),(s,d) in itertools.combinations(sorted(h),2):
        if r==s or c==d:continue
        match={}
        def visit(i,seen):
            for j in adj[i]:
                if j in (c,d) or j in seen:continue
                seen.add(j)
                if j not in match or visit(match[j],seen):match[j]=i;return True
            return False
        check(all(visit(i,set()) for i in range(N) if i not in (r,s)), 'H edge pair does not extend')
        p=[-1]*N;p[r]=c;p[s]=d
        for j,i in match.items():p[i]=j
        check(sorted(p)==list(range(N)) and all((i,j) in h for i,j in enumerate(p)), 'invalid extension')
        sha.update(bytes([r,c,s,d,*p]));count+=1
    return {'pairs':count,'witness_digest':sha.hexdigest()}

def packet(g,states,columns):
    return [[power(i,d) if g.get((i,d))==k else [0] for d in columns] for i,k in states]
def det2(a):return add(mul(a[0][0],a[1][1]),scale(mul(a[0][1],a[1][0]),-1))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='VERIFICATION.json');args=ap.parse_args()
    g,h=graph()
    f,v=enumerate_partial(g,3);fh,vh=enumerate_partial(h,3)
    pg,fg=polynomial(f);ph,hg=polynomial(fh)
    fe=[p for p in f if p[42]==8];pe,eg=polynomial(fe)
    check(len(f)==8 and len(fh)==4 and len(fe)==4,'fibers')
    check(pg==[0] and ph!=[0] and pe!=[0] and add(ph,pe)==[0],'polynomial split')
    check(all(x['cofactor_or_permutation_sign']==-1 for x in hg),'H signs')
    check(all(x['cofactor_or_permutation_sign']==1 for x in eg),'e signs')
    Rco={};co_records={}
    for d in sorted(c for r,c in g if r==42):
        ps,vs=enumerate_partial(h,3-g[42,d],42,d)
        co,rs=polynomial(ps,42,d)
        Rco[d]=co;co_records[str(d)]={'count':len(ps),'visits':vs,'reduced_coefficients':co,'matchings':rs}
    active=[d for d,a in Rco.items() if a!=[0]]
    check(active==[8,10],'active row-42 columns')
    check(mul(power(42,8),Rco[8])==pe,'edge cofactor')
    check(mul(power(42,10),Rco[10])==ph,'blue cofactor')
    U={};ur={}
    for i,k in ((42,1),(30,0),(42,0),(30,1),(27,1),(45,1)):
        ps,vs=enumerate_partial(h,3-k,i,8)
        co,rs=polynomial(ps,i,8)
        U[i,k]=co;ur[f'{i},{k}']={'count':len(ps),'visits':vs,'reduced_coefficients':co,'matchings':rs}
    check(U[42,1]==Rco[8] and U[42,1]!=[0] and U[30,0]!=[0], 'nonzero actual q circuit cofactors')
    check(U[27,1]==[0] and U[45,1]==[0], 'extra column-8 states contribute')
    F=[1]
    for a,b,c in ((35,37,0),(0,72,2),(40,32,4),(45,27,6)):
        F=mul(F,mul(power(a,c),power(b,c)))
    check(U[42,1]==scale(mul(mul(F,power(30,11)),power(42,3)),4), 'factored q cofactor')
    check(U[30,0]==scale(mul(mul(F,power(30,3)),power(42,11)),-4), 'factored partner cofactor')
    check(ph==scale(mul(mul(F,power(30,11)),power(42,11)),-4), 'factored H polynomial')
    T=((42,1),(30,0));S=((42,1),(30,1))
    wt=packet(g,T,(8,10));ws=packet(g,S,(8,10))
    check(wt[0][0]!=[0] and wt[1][0]!=[0], 'T both nonzero B rows')
    check(wt[0][1]==[0] and wt[1][1]==[0], 'upper column on T')
    check(det2(wt)==[0] and det2(ws)==mul(power(42,8),power(30,10)),'row-dependent determinants')
    w9=packet(g,T,(9,))
    w9pair=add(mul(w9[0][0],U[T[0]]),mul(w9[1][0],U[T[1]]))
    check(w9==[[power(42,9)],[[0]]] and w9pair!=[0], 'T must not inherit all graph-column pairings')
    for j in (0,1):
        check(add(mul(wt[0][j],U[T[0]]),mul(wt[1][j],U[T[1]]))==[0], 'actual cofactor restriction is not annihilator')
    check(add(mul(ws[0][0],U[S[0]]),mul(ws[1][0],U[S[1]]))!=[0],'matching restriction unexpectedly annihilates g')
    # The blue/red counterpart states give a separate duplicate-column relation for d=10.
    opposite=((42,0),(30,1));wo=packet(g,opposite,(10,))
    check(add(mul(wo[0][0],U[opposite[0]]),mul(wo[1][0],U[opposite[1]]))==[0], 'column 10 counterpart identity')
    # Pick a concrete full exact-3 matching using e; induced states for cols8,10 are S.
    m=fe[0]
    check(m[30]==10 and g[30,10]==1,'matching-induced row')
    extensions=check_extensions(h)
    out={'status':'PASS','n':73,'target':3,'e':[42,8],'edge_count':len(g),'H_edge_count':len(h),
         'H_spanning_circulant_steps':[0,1,2],'H_two_extendability_check':extensions,
         'fiber_counts':{'G':len(f),'H':len(fh),'using_e':len(fe)},'G_visits':v,'H_visits':vh,
         'G_reduced_polynomial':pg,'H_reduced_polynomial':ph,'using_e_reduced_polynomial':pe,
         'common_padding_degree':sum(BASE[r] for r in range(N) if r not in AR),
         'R':co_records,'active_row42_columns':active,'D_minus':[],'D_plus':[10],
         'actual_cofactor_coordinates':ur,'T':T,'matching_induced_S':S,'W_T':wt,'W_S':ws,
         'W_T_determinant':det2(wt),'W_S_determinant':det2(ws),
         'T_B_rank':1,'T_V_rank':0,'T_size':2,'T_is_minimal_q_circuit':True,
         'T_actual_cofactors_nonzero':True,'T_actual_cofactor_annihilates_active_columns':True,
         'matching_support_actual_cofactor_does_not_annihilate_g':True,
         'full_matching_using_e':m,'no_pivot_choice_when_D_minus_empty':True,
         'full_survivor_state_count_before_additional_restriction':146,
         'T_is_not_literal_full_survivor_set':True,
         'inactive_row42_column9_packet_on_T':w9,
         'column9_pairing_with_restricted_cofactor_nonzero':True,
         'column9_pairing_reduced_coefficients':w9pair,
         'source':'https://arxiv.org/html/2604.01571v3#S7.Thmtheorem21',
         'source_html_sha256':hashlib.sha256((HERE/'source.html').read_bytes()).hexdigest(),
         'scope':'Exact failure of row-support transfer; matching-induced diagonal determinant is nonzero.'}
    (HERE/args.output).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    (HERE/'GRAPH.json').write_text(json.dumps([{'row':i,'column':j,'cost':k} for (i,j),k in sorted(g.items())],indent=2)+'\n')
    print(json.dumps({'status':out['status'],'fiber_counts':out['fiber_counts'],'active_columns':active,'H_extension_checks':extensions,'T':'minimal q-circuit; actual cofactor restriction annihilates active columns','S':'nonzero diagonal matching-induced determinant'},sort_keys=True))
if __name__=='__main__':main()
