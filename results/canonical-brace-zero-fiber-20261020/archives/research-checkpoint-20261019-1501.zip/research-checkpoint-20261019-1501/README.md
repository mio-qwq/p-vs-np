# Private review checkpoint: canonical brace zero fiber

19 October 2026 UTC. **Private local preparation only.** This bundle has not been uploaded, committed, submitted as a PR, merged, released, or sent to the manuscript's author. External publication of the new major conclusion requires explicit approval. This checkpoint does not replace any older archive or inherit approval from an earlier publication batch.

## Result

A fully specified bipartite graph with 73 vertices on each side and 224 binary-colored edges is a standard 2-extendable brace. The 141 added red edges preserve the entire exact-three-red-edge fiber of the prior five-cycle example. That fiber contains eight perfect matchings, but its canonical signed translated-power polynomial is identically zero.

The graph's numerical row offsets and column exponents are exactly 0 through 72. No labels are changed when the extra edges are chosen. Every matching using any new edge has at least 34 red edges. All 24,508 disjoint edge pairs have been checked for a perfect-matching extension, in addition to a Hall-theoretic proof.

This directly challenges Theorem 1.2 in [Yuefeng Du, arXiv:2604.01571v3](https://arxiv.org/html/2604.01571v3#S1.SS2) under the paper's expressly stated, standard 2-extendability interpretation of a brace. The literal Hall-plus-two endpoint in Definition 3.1 is impossible for a subset of size n−1; that apparent typo is disclosed rather than exploited. See `review/SOURCE_COMPARISON.md`.

This is not a P-versus-NP conclusion, an impossibility result for deterministic Exact Matching, a claim about all relabelings, or a confirmed novelty claim. Independent mathematical review remains appropriate before any external claim.

## Read in this order

1. `REVIEW_ZH.md`: concise Chinese review summary.
2. `construction/PROOF.md`: main construction and mathematical proof.
3. `independent_audit/AUDIT.md`: separately reconstructed proof and audit.
4. `review/SOURCE_COMPARISON.md`: precise source/claim boundary.
5. `review/VERIFICATION_GUIDE.md`: checks, limitations, and mutation controls.
6. `prior_five_cycle/PROOF.md`: rational cancellation and canonical-label origin.

The original proof/readme files preserve their source-time wording, including the earlier disconnected example's narrower scope and the construction's pre-audit wording. The current package includes the completed independent audit. These earlier statements are not claims that the new completed graph is disconnected.

## Reproduce

Requirements: Python 3.10 or newer, standard library only. Tested with Python 3.12.14.

From the extracted bundle directory:

```sh
sha256sum -c SHA256SUMS
python verify_bundle.py
python -O verify_bundle.py
```

The harness copies each checker into fresh temporary directories and runs it normally and under `-O`. Frozen input files are not modified. It compares reconstructed graph/fiber certificates exactly and compares receipts after ignoring only interpreter version and elapsed time. It also tests explicit tampering of the certificates.

To retain a new receipt, use `--output /absolute/path/outside-this-bundle/receipt.json`. Do not overwrite the frozen package receipts unless intentionally creating a new checkpoint.

The three source checkers can also be run separately in disposable directories. The prior five-cycle checker regenerates a dense cost matrix for its earlier bounded-integer completion; this output is not part of the new binary brace certificate.

## Contents and provenance

- `construction/`: full main proof, standalone checker, 224 sparse edge records, eight full permutations with exact active-factor coefficients, and original receipts.
- `independent_audit/`: independent standalone checker, proof, reconstructed sparse graph/fiber, and original receipts.
- `prior_five_cycle/`: necessary five-cycle derivation, standalone checker, sparse canonical edges, rational and canonical fiber certificates, and original receipts. The redundant dense 73-by-73 cost matrix is omitted; the checker regenerates it exactly.
- `root_replay/RESULT.json`: another run of the independent audit checker. It is additional replay evidence, not a third independent implementation.
- `review/`: source comparison, verification guidance, clean replay receipts, and provenance hashes.
- `verify_bundle.py`: clean replay and 14 certificate-tampering controls.
- `build_zip.py`: deterministic ZIP builder with fixed member metadata and sorted names.
- `SHA256SUMS`: hashes every included regular file except itself. Hashes attest the snapshot, not mathematical correctness.

The source snapshot provenance is in `review/PROVENANCE.json`. No external runtime dependencies or source downloads are required to rerun the mathematical certificate.
