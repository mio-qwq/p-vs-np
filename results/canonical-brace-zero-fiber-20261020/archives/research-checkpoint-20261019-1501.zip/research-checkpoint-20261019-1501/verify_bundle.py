#!/usr/bin/env python3
"""Private review harness: clean reconstruction, exact certificate comparison, tamper controls.
Only Python standard library is required. Frozen input files are never overwritten.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def read_json(path):
    return json.loads(path.read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def normalized(value):
    result = copy.deepcopy(value)
    if isinstance(result, dict):
        result.pop('elapsed_seconds', None)
        result.pop('python', None)
    return result

def compare_exact(actual, expected, label):
    need(actual == expected, label + ' differs from independent reconstruction')

def compare_certificates(edges, fiber, audit_graph, audit_fiber, prior_edges, prior_fiber):
    compare_exact(edges, audit_graph['edges'], '224-edge certificate')
    need(len(edges) == 224, 'edge count')
    need(len({(e['row'], e['column']) for e in edges}) == 224, 'duplicate edge')
    need(all(type(e['row']) is int and type(e['column']) is int and type(e['cost']) is int
             and 0 <= e['row'] < 73 and 0 <= e['column'] < 73 and e['cost'] in (0, 1)
             for e in edges), 'invalid edge labels/colors')
    edge_map = {(e['row'], e['column']): e['cost'] for e in edges}
    permutations = [f['permutation'] for f in fiber]
    compare_exact(permutations, audit_fiber, 'complete eight-member target fiber')
    compare_exact(permutations, [f['permutation'] for f in prior_fiber], 'prior target fiber')
    need(len(fiber) == len({tuple(p) for p in permutations}) == 8, 'fiber count/duplicates')
    sums = [0] * 47
    for f in fiber:
        p = f['permutation']
        need(sorted(p) == list(range(73)), 'fiber record is not a canonical permutation')
        need(all((r, c) in edge_map for r, c in enumerate(p)), 'unsupported matching edge')
        need(sum(edge_map[r, c] for r, c in enumerate(p)) == 3, 'incorrect matching target')
        parity = -1 if sum(p[i] > p[j] for i in range(73) for j in range(i + 1, 73)) % 2 else 1
        need(f['sign'] == parity, 'incorrect global permutation sign')
        active = [35, 37, 0, 72, 40, 32, 45, 27, 30, 42]
        poly = [1]
        for r in active:
            for _ in range(p[r]):
                nxt = [0] * (len(poly) + 1)
                for i, x in enumerate(poly):
                    nxt[i] += r * x
                    nxt[i + 1] += x
                poly = nxt
        compare_exact(f['active_coefficients'], poly, 'active integer polynomial')
        need(len(poly) == 47, 'active polynomial degree')
        sums = [a + parity * b for a, b in zip(sums, poly)]
    need(sums == [0] * 47, 'nonzero signed coefficient sum')
    old = {(e['row'], e['column']): e['cost'] for e in prior_edges}
    need(len(old) == 83 and all(edge_map.get(k) == v for k, v in old.items()), 'old graph preservation')
    added = set(edge_map) - set(old)
    need(len(added) == 141 and all(edge_map[e] == 1 for e in added), 'added red edges')
    return True

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', help='Optional receipt filename; default is stdout only.')
    ap.add_argument('--skip-hashes', action='store_true', help='For initial sealing before SHA256SUMS exists.')
    args = ap.parse_args()
    checked_hashes = 0
    if not args.skip_hashes:
        manifest = HERE / 'SHA256SUMS'
        need(manifest.is_file(), 'SHA256SUMS is missing')
        entries = [line.split('  ', 1) for line in manifest.read_text().splitlines()]
        names = [rel for expected, rel in entries]
        need(len(names) == len(set(names)), 'duplicate manifest paths')
        actual_names = {p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p != manifest}
        need(set(names) == actual_names, 'manifest inventory mismatch: unexpected or missing files')
        for expected, rel in entries:
            path = HERE / rel
            need(not path.is_symlink() and HERE in path.resolve().parents, 'unsafe manifest path')
            need(path.is_file() and digest(path) == expected, 'hash mismatch: ' + rel)
            checked_hashes += 1
    jobs = [('construction', 'verify_brace.py'), ('independent_audit', 'verify.py'),
            ('prior_five_cycle', 'verify_candidate.py')]
    run_results = {}
    with tempfile.TemporaryDirectory(prefix='private-brace-review-') as temporary:
        temp = Path(temporary)
        for optimized in (False, True):
            mode = 'optimized' if optimized else 'normal'
            run_results[mode] = {}
            for folder, script in jobs:
                work = temp / mode / folder
                work.mkdir(parents=True)
                shutil.copyfile(HERE / folder / script, work / script)
                cmd = [sys.executable] + (['-O'] if optimized else []) + [script]
                env = dict(os.environ, PYTHONHASHSEED='0', PYTHONDONTWRITEBYTECODE='1')
                proc = subprocess.run(cmd, cwd=work, env=env, text=True, capture_output=True)
                need(proc.returncode == 0, folder + '/' + mode + ' failed: ' + proc.stderr)
                need(not proc.stderr.strip(), folder + '/' + mode + ' emitted unexpected stderr')
                if folder == 'independent_audit':
                    receipt = json.loads(proc.stdout)
                else:
                    receipt = read_json(work / 'VERIFICATION.json')
                expected = read_json(HERE / folder / 'VERIFICATION.json')
                compare_exact(normalized(receipt), normalized(expected), folder + '/' + mode + ' receipt')
                compare_exact(normalized(receipt), normalized(read_json(HERE / folder / 'VERIFICATION_OPTIMIZED.json')),
                              folder + '/' + mode + ' optimized source receipt')
                run_results[mode][folder] = normalized(receipt)
                names = {'construction': ['brace_edges.json', 'brace_fiber.json'],
                         'independent_audit': ['RECONSTRUCTED_GRAPH.json', 'RECONSTRUCTED_FIBER.json'],
                         'prior_five_cycle': ['rational_cost_matrix.json', 'rational_fiber.json', 'canonical_fiber.json']}[folder]
                for name in names:
                    compare_exact(read_json(work / name), read_json(HERE / folder / name), folder + '/' + name)
            compare_certificates(read_json(temp / mode / 'construction/brace_edges.json'),
                                 read_json(temp / mode / 'construction/brace_fiber.json'),
                                 read_json(temp / mode / 'independent_audit/RECONSTRUCTED_GRAPH.json'),
                                 read_json(temp / mode / 'independent_audit/RECONSTRUCTED_FIBER.json'),
                                 read_json(HERE / 'prior_five_cycle/canonical_sparse_edges.json'),
                                 read_json(temp / mode / 'prior_five_cycle/canonical_fiber.json'))
        compare_exact(run_results['normal'], run_results['optimized'], 'normal versus optimized runs')
        compare_exact(normalized(read_json(HERE / 'root_replay/RESULT.json')),
                      run_results['normal']['independent_audit'], 'root replay receipt')

    certificates = [read_json(HERE / 'construction/brace_edges.json'),
                    read_json(HERE / 'construction/brace_fiber.json'),
                    read_json(HERE / 'independent_audit/RECONSTRUCTED_GRAPH.json'),
                    read_json(HERE / 'independent_audit/RECONSTRUCTED_FIBER.json'),
                    read_json(HERE / 'prior_five_cycle/canonical_sparse_edges.json'),
                    read_json(HERE / 'prior_five_cycle/canonical_fiber.json')]
    compare_certificates(*certificates)
    mutations = {}
    def reject(name, alter):
        changed = copy.deepcopy(certificates)
        alter(changed)
        try:
            compare_certificates(*changed)
        except (RuntimeError, KeyError, TypeError, IndexError):
            mutations[name] = 'REJECTED'
        else:
            raise RuntimeError('certificate mutation escaped detection: ' + name)
    reject('delete_edge', lambda x: x[0].pop())
    reject('duplicate_edge', lambda x: x[0].append(copy.deepcopy(x[0][0])))
    reject('change_binary_cost', lambda x: x[0][0].__setitem__('cost', 1 - x[0][0]['cost']))
    reject('relabel_row', lambda x: x[0][0].__setitem__('row', 73))
    reject('delete_matching', lambda x: x[1].pop())
    reject('duplicate_matching', lambda x: x[1].append(copy.deepcopy(x[1][0])))
    reject('alter_permutation', lambda x: x[1][0]['permutation'].__setitem__(0, 72))
    reject('reverse_permutation_sign', lambda x: x[1][0].__setitem__('sign', -x[1][0]['sign']))
    reject('change_active_coefficient', lambda x: x[1][0]['active_coefficients'].__setitem__(0, x[1][0]['active_coefficients'][0] + 1))
    reject('truncate_active_coefficients', lambda x: x[1][0]['active_coefficients'].pop())
    reject('alter_independent_graph', lambda x: x[2]['edges'].pop())
    reject('alter_independent_fiber', lambda x: x[3].pop())
    reject('alter_prior_graph', lambda x: x[4][0].__setitem__('cost', 1 - x[4][0]['cost']))
    reject('alter_prior_fiber', lambda x: x[5].pop())
    out = {
        'status': 'PASS', 'scope': 'Private local review only; no external publication or repository write.',
        'clean_reconstruction_runs': 6, 'normal_optimized_receipts_agree': True,
        'receipt_fields_ignored_for_comparison': ['elapsed_seconds', 'python'],
        'frozen_hash_entries_checked': checked_hashes,
        'canonical_dimension': 73, 'edge_count': 224, 'added_red_edges': 141,
        'all_disjoint_edge_pairs_extend': 24508, 'target': 3, 'target_fiber_size': 8,
        'active_coefficients': 47, 'all_active_coefficients_zero': True,
        'common_nonzero_factor_degree': 2582, 'total_term_degree': 2628,
        'minimum_new_edge_matching_red_count_proved': 34,
        'independent_target_counts_0_through_6': [1, 4, 7, 8, 7, 4, 1],
        'root_replay_agrees': True, 'prior_five_cycle_certificates_agree': True,
        'certificate_mutations': mutations,
        'construction_negative_controls': run_results['normal']['construction']['negative_controls'],
        'prior_negative_controls': run_results['normal']['prior_five_cycle']['negative_controls'],
        'independence_note': 'Construction and audit reconstruct separately. Root replay reruns the audit code; it is not a third implementation.'
    }
    text = json.dumps(out, indent=2, sort_keys=True) + '\n'
    if args.output:
        Path(args.output).write_text(text)
    print(text, end='')

if __name__ == '__main__':
    main()
