#!/usr/bin/env python3
"""Exact standalone construction/checker of a binary-cost canonical brace fiber.

No input receipt or external module is trusted. 73 canonical labels are immutable.
The cyclic order below is used only to add graph edges, not to reassign weights.
"""
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
N = 73
TARGET = 3
ACTIVE_ROWS = [35, 37, 0, 72, 40, 32, 45, 27, 30, 42]
ACTIVE_COLS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 10]


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def parity(p):
    return (-1) ** sum(p[i] > p[j] for i in range(len(p)) for j in range(i + 1, len(p)))


def mul(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def power_linear(b, e):
    return [math.comb(e, k) * b ** (e - k) for k in range(e + 1)]


def construct():
    rows = ACTIVE_ROWS + sorted(set(range(N)) - set(ACTIVE_ROWS))
    cols = ACTIVE_COLS + sorted(set(range(N)) - set(ACTIVE_COLS))
    require(sorted(rows) == list(range(N)) and sorted(cols) == list(range(N)), 'canonical labels')
    baseline = dict(zip(rows, cols))
    old = {(r, c): 0 for r, c in baseline.items()}
    for k in range(5):
        a, b = rows[2 * k:2 * k + 2]
        x, y = cols[2 * k:2 * k + 2]
        old[a, y] = 1
        old[b, x] = int(k == 4)
    edges = old.copy()
    for i, r in enumerate(rows):
        for step in (1, 2):
            edges.setdefault((r, cols[(i + step) % N]), 1)
    blocks = [i // 2 if i < 10 else i - 5 for i in range(N)]
    row_block = dict(zip(rows, blocks))
    col_block = dict(zip(cols, blocks))
    added = sorted(set(edges) - set(old))
    require(len(old) == 83 and len(edges) == 224 and len(added) == 141, 'edge counts')
    require(set(edges.values()) == {0, 1}, 'binary costs')
    require(all(row_block[r] == col_block[c] for r, c in old), 'old edges internal')
    require(all(edges[r, c] == 1 and (col_block[c] - row_block[r]) % 68 in (1, 2)
                for r, c in added), 'new edges red and forward on 68 blocks')
    require(all((rows[i], cols[(i + step) % N]) in edges
                for i in range(N) for step in (0, 1, 2)), 'circulant spanning support')
    return rows, cols, baseline, old, edges, added, row_block, col_block


def enumerate_fiber(edges, row_order, target):
    adjacency = {r: sorted((c, w) for (rr, c), w in edges.items() if rr == r)
                 for r in range(N)}
    p = [-1] * N
    out = []
    visits = 0

    def visit(k, used, total):
        nonlocal visits
        visits += 1
        if k == N:
            if total == target:
                out.append(tuple(p))
            return
        r = row_order[k]
        for c, w in adjacency[r]:
            if not (used >> c) & 1 and total + w <= target:
                p[r] = c
                visit(k + 1, used | (1 << c), total + w)

    visit(0, 0, 0)
    return sorted(out), visits


def extension_witness(edges, edge_pair, rows):
    adjacency = {r: sorted(c for rr, c in edges if rr == r) for r in range(N)}
    excluded_rows = {e[0] for e in edge_pair}
    excluded_cols = {e[1] for e in edge_pair}
    matched = {}

    def augment(r, seen):
        for c in adjacency[r]:
            if c in excluded_cols or c in seen:
                continue
            seen.add(c)
            if c not in matched or augment(matched[c], seen):
                matched[c] = r
                return True
        return False

    for r in rows:
        if r not in excluded_rows and not augment(r, set()):
            return None
    p = [-1] * N
    for c, r in matched.items():
        p[r] = c
    for r, c in edge_pair:
        p[r] = c
    require(sorted(p) == list(range(N)), 'extension is a permutation')
    require(all((r, c) in edges for r, c in enumerate(p)), 'extension has allowed edges')
    require(all(p[r] == c for r, c in edge_pair), 'extension contains requested pair')
    return p


def verify_all_pairs(edges, rows):
    count = 0
    witness_hash = hashlib.sha256()
    for e, f in itertools.combinations(sorted(edges), 2):
        if e[0] == f[0] or e[1] == f[1]:
            continue
        witness = extension_witness(edges, [e, f], rows)
        require(witness is not None, 'nonextendable edge pair: ' + str((e, f)))
        witness_hash.update(bytes([*e, *f, *witness]))
        count += 1
    require(count == 24508, 'disjoint edge-pair count')
    return count, witness_hash.hexdigest()


def reduced_coefficients(fiber, rows=ACTIVE_ROWS):
    out = [0] * (sum(ACTIVE_COLS) + 1)
    records = []
    for p in fiber:
        term = [1]
        for r in rows:
            term = mul(term, power_linear(r, p[r]))
        require(len(term) == len(out), 'common active degree')
        sign = parity(p)
        out = [a + sign * b for a, b in zip(out, term)]
        records.append({'permutation': p, 'sign': sign, 'active_coefficients': term})
    return out, records


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', default='VERIFICATION.json')
    args = ap.parse_args()
    rows, cols, baseline, old, edges, added, row_block, col_block = construct()
    fiber, visits = enumerate_fiber(edges, rows, TARGET)
    original, old_visits = enumerate_fiber(old, rows, TARGET)
    require(len(fiber) == 8 and fiber == original, 'complete target fiber preserved')
    require(all(all((r, c) in old for r, c in enumerate(p)) for p in fiber), 'no new-edge target matching')
    require(all(sum(edges[r, c] for r, c in enumerate(p)) == TARGET for p in fiber), 'cost-three fiber')
    forced_rows = sorted(set(range(N)) - set(ACTIVE_ROWS))
    require(all(all(p[r] == baseline[r] for r in forced_rows) for p in fiber), 'common padding factors')
    coefficients, records = reduced_coefficients(fiber)
    require(coefficients == [0] * 47, 'exact 47-coefficient signed polynomial zero')
    require(sum(parity(p) == 1 for p in fiber) == 4, 'four positive terms')
    full_checks = {}
    for t in (1, 2, 3, 7, 19):
        value = sum(parity(p) * math.prod((t + r) ** p[r] for r in range(N)) for p in fiber)
        require(value == 0, 'full product evaluation')
        full_checks[str(t)] = value
    pair_count, witness_hash = verify_all_pairs(edges, rows)
    # Exact mutation controls, separate from the proof of the unmutated instance.
    changed_cost = edges.copy()
    changed_cost[30, 10] = 0
    changed_fiber, _ = enumerate_fiber(changed_cost, rows, TARGET)
    changed_coefficients, _ = reduced_coefficients(changed_fiber)
    require(changed_fiber != fiber and any(changed_coefficients), 'cost mutation must be rejected')
    # Break the circulant into the old disconnected graph: exhibit a pair of edges
    # not extendable after adding just one one-way cross edge.
    one_way = old.copy()
    witness_bad_edge = added[0]
    one_way[witness_bad_edge] = 1
    require(extension_witness(one_way, [witness_bad_edge], rows) is None, 'one-way edge fails matching-coveredness')
    edge_records = [{'row': r, 'column': c, 'cost': w} for (r, c), w in sorted(edges.items())]
    result = {
        'status': 'PASS', 'n': N, 'target': TARGET, 'cost_alphabet': sorted(set(edges.values())),
        'edge_count': len(edges), 'original_edge_count': len(old), 'added_red_edges': len(added),
        'component_count': 68, 'cross_component_forward_steps': [1, 2],
        'minimum_new_matching_red_count_lower_bound': 34,
        'circulant_steps_in_support': [0, 1, 2],
        'disjoint_edge_pairs_checked': pair_count, 'extension_witness_sha256': witness_hash,
        'target_fiber_count': len(fiber), 'fiber_sign_counts': {'positive': 4, 'negative': 4},
        'exact_backtracking_states': visits, 'original_backtracking_states': old_visits,
        'original_fiber_equal': True, 'canonical_rows': list(range(N)), 'canonical_exponents': list(range(N)),
        'abstract_row_order': rows, 'abstract_column_order': cols,
        'polynomial_total_degree': N * (N - 1) // 2, 'common_factor_degree': sum(baseline[r] for r in forced_rows),
        'active_factor_degree': sum(ACTIVE_COLS), 'exact_reduced_coefficients': coefficients,
        'supplementary_full_integer_evaluations': full_checks,
        'edge_records_sha256': sha(edge_records), 'fiber_sha256': sha(fiber),
        'negative_controls': {'one_cost_mutation_changes_fiber_and_polynomial': True,
                              'one_way_completion_not_matching_covered': True},
        'source': 'https://arxiv.org/html/2604.01571v3#S1.SS2',
        'scope': 'Local exact certificate; no repository write or external publication.'
    }
    (HERE / args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    (HERE / 'brace_edges.json').write_text(json.dumps(edge_records, indent=2) + '\n')
    (HERE / 'brace_fiber.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'n', 'edge_count', 'target_fiber_count',
                                           'disjoint_edge_pairs_checked', 'negative_controls']}, sort_keys=True))


if __name__ == '__main__':
    main()
