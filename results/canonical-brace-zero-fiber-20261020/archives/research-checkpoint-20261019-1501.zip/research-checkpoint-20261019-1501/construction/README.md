# Canonical brace completion: local exact certificate

The five-cycle 73-row zero fiber admits a binary-red, brace-preserving completion that leaves its entire target-three matching fiber unchanged. Actual canonical row and column labels remain `0,...,72`.

- 224 edges, including 141 newly added red edges.
- Standard 2-extendability proved by a circulant Hall-plus-two argument.
- Every 24,508 disjoint edge pair checked for a perfect-matching extension.
- Every new-edge perfect matching has at least 34 red edges by a balanced component-flow argument.
- Direct target-three enumeration yields exactly eight matchings.
- All 47 active polynomial coefficients cancel exactly; no numerical premise.

Read `PROOF.md`. Run `python verify_brace.py`, then `python -O verify_brace.py --output VERIFICATION_OPTIMIZED.json` and compare receipts.

This is a local research artifact awaiting independent audit. No repository write or external publication is authorized by its creation. The statement concerns the displayed ASNC theorem under the standard 2-extendability reading of brace; it is not a P versus NP result.
