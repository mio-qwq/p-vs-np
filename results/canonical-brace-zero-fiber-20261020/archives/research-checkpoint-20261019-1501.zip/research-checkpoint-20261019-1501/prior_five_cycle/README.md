# Exact five-cycle canonical cancellation

Read `PROOF.md`. The complete target-three fiber of an explicit sparse binary-cost canonical 73-row graph has eight permutations and an identically zero signed translated-power polynomial. A full-matrix completion has costs `{0,1,4}`. This is not a complete-graph binary-cost result or a P-versus-NP resolution. The graph is disconnected and not a brace. [Du's v3 Theorem 1.2 and Remark 1.4](https://arxiv.org/html/2604.01571v3#S1.SS2) restrict ASNC to braces and already allow non-brace convolution cancellation; this construction does not refute that stated theorem or its blockwise algorithm. It refutes the stronger all-graphs noncancellation assertion/direct global-polynomial zero test.

Reproduce locally with `python verify_candidate.py` and `python -O verify_candidate.py --output VERIFICATION_OPTIMIZED.json`. The verifier uses only Python standard-library exact arithmetic and actual perfect-matching enumeration. It writes the complete matrices, raw fibers, and coefficient certificates.

No external writes or publications were performed. The construction is ready for independent audit; SHA256 hashes attest the recorded artifact snapshot, not mathematical truth.
