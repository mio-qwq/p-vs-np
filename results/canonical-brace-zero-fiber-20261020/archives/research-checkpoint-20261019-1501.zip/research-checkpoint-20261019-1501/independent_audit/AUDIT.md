# Independent audit: a low-target-preserving brace completion

19 October 2026 UTC. This is an independent local reconstruction and mathematical audit. No external submission, repository mutation, merge, release, or publication was made. No downloaded research code was executed.

## Verdict

The proposed 73-by-73, 224-edge red/blue graph passes the audit. It is 2-extendable in the standard graph-theoretic sense, its entire red-count-three perfect-matching fiber consists of exactly eight matchings, and its canonical signed translated-power polynomial is identically zero. The row offsets and column exponents remain exactly the original integers 0 through 72.

This is stronger than the earlier disconnected 83-edge example. It contradicts the nonvanishing assertion for standard bipartite braces, equivalently the 2-extendable interpretation expressly stated in Du v3. It does not imply a complexity-class separation or rule out other deterministic Exact Matching algorithms.

**Definition caveat.** The live manuscript's Definition 3.1 imposes Hall+2 for every proper nonempty row subset; at subset size n−1 that is impossible. The same definition immediately says “equivalently” 2-extendable. We use that standard, intended meaning and prove Hall+2 for subsets of size at most n−2. We do not claim to meet the impossible literal n−1 condition.

Primary source checked: https://arxiv.org/html/2604.01571v3, especially Theorem 1.2, Remark 1.4, Definition 3.1, Proposition 2.3. The source says brace-only ASNC; the earlier disconnected example alone did not contradict it.

## 1. Independent construction

Let N=73. The five active row pairs, in order, are

    (35,37), (0,72), (40,32), (45,27), (30,42).

The associated ordered column pairs are

    (0,1), (2,3), (4,5), (6,7), (8,10).

For each ordered pair (a,b) with columns (u,v), include the four edges. The baseline edges (a,u),(b,v) are blue. The edge (a,v) is red. The edge (b,u) is blue in the first four components and red in the fifth.

Pair the unused rows in increasing order with the unused columns in increasing order, using 63 blue singleton edges. This produces 68 balanced complete components: five K2,2 blocks and 63 K1,1 blocks, with 83 edges.

Form a cyclic list of matched baseline pairs (R_i,C_i), i=0,...,72. First list the five active ordered pairs in the displayed order, producing ten list positions. Then list the 63 singleton pairs. These list positions are used only to choose new graph edges. They do not replace the numerical row offsets or column exponents.

For each i and each d in {1,2}, add the edge (R_i,C_(i+d mod 73)) if missing, and color it red. Retain the color of every preexisting edge. Exactly 141 edges are added, for 224 total. The graph remains simple and every allowed cost is 0 or 1.

The full construction is independently encoded by verify.py; RECONSTRUCTED_GRAPH.json contains all edges and the cyclic lists.

## 2. Brace proof, independent of numerical testing

The graph contains all edges (R_i,C_(i+d)) for d=0,1,2, with indices modulo 73. The d=0 edges are the baseline matching.

For a nonempty proper subset T of the 73 cyclic positions, T+1 cannot equal T: invariance under the cyclic successor would force T to be empty or the whole cycle. Consequently

    |T union (T+1)| >= min(73, |T|+1).

Apply this expansion twice. The neighbors of the row-position set T in the three-shift subgraph include T union (T+1) union (T+2), so

    |N(T)| >= min(73, |T|+2).

In particular, Hall+2 holds whenever 1<=|T|<=71. The graph is connected because the shift-0 and shift-1 edges already form a spanning bipartite cycle.

To prove 2-extendability directly, take any two disjoint edges and remove their two row endpoints and two column endpoints. For any subset S of the remaining rows, |S|<=71 and its old neighborhood has at least |S|+2 vertices; removing two columns leaves at least |S|. Hall's condition therefore gives a perfect matching of the residual graph. Adding back the two selected edges gives a perfect matching extending them. The analogous argument works for one selected edge. This proves the stated graph property without enumerating subsets or trusting a brace-recognition implementation.

An independent finite check also tests every disjoint edge pair in the actual 224-edge graph: all 24,508 pairs extend.

## 3. Exact low-target preservation

Label the 68 original components cyclically 0,...,67. Every old edge stays within one component. Because component positions are consecutive in the cyclic list, every added edge advances by either one or two components modulo 68. All added edges are red.

For any perfect matching M of the completed graph, make a directed multigraph on these 68 components. Insert an arc from the row's component to the column's component for every added edge of M. At every component, the number of matching edges leaving the component equals the number entering: the component has equally many rows and columns, and each internally used edge consumes one of each. Thus this directed multigraph is balanced.

If M uses any added edge, the nonempty finite balanced directed multigraph contains a directed cycle. Give each cycle arc its positive increment in {1,2}. The sum of these increments is a positive multiple of 68, and hence is at least 68. A cycle of ell arcs has sum at most 2*ell, so ell>=34.

Every arc is a distinct selected red edge, and all other selected costs are nonnegative. Therefore every matching using any added edge has at least 34 red edges.

It follows that for EVERY target t<34, not just t=3, the entire matching fiber in the completed graph equals the original fiber. This is an exact combinatorial equality, independent of determinant cancellation. In particular, the target-three fiber has eight members.

The independent completed-graph enumerator verified equality at all targets 0 through 6 and found counts

    1, 4, 7, 8, 7, 4, 1.

These searches operate on all 224 edges and do not assume the circulation argument or restrict search to the old graph.

## 4. Canonical polynomial identity

For a perfect matching represented by the permutation sigma of canonical column labels, use

    weight(sigma; L) = sign(sigma) product_(r=0)^72 (L+r)^sigma(r).

No labels are changed by the completion. Each original component has baseline choice A and swapped choice B. Their B-minus-A red counts are (1,1,1,1,2). Thus target 3 consists of the four choices with three B states among the first four components, and the four choices with one B state among the first four and B in the fifth.

The unsigned B/A ratios are

    R1=(L+35)/(L+37),
    R2=L/(L+72),
    R3=(L+40)/(L+32),
    R4=(L+45)/(L+27),
    R5=((L+30)/(L+42))^2.

They satisfy e3(R1,R2,R3,R4)=R5*e1(R1,R2,R3,R4). Hence the signed target polynomial is a common nonzero baseline factor times

    -e3(R1,R2,R3,R4) + R5*e1(R1,R2,R3,R4) = 0.

Clearing denominators gives an identity of polynomials, including the values at the apparent poles.

The independent checker avoids relying on that rational simplification. It constructs each of the eight actual 73-element permutations, computes its global parity by inversion counting, and expands the products for the ten active rows with exact integer coefficient convolution. There are four positive and four negative signs. All eight unsigned active polynomials are distinct and monic of degree 46. Every one of the 47 coefficients in their signed sum is zero. The common contribution of the 63 forced edges is monic of degree 2582, so the full matching-term degree is 2628=73*72/2.

Thus the zero polynomial concerns the complete target-three fiber in a genuine 2-extendable graph; it is not cancellation in a selected subsum, a boundary minor, a graph with changed labels, or a nonbinary weighted graph.

## 5. A general completion lemma

The mechanism is not specific to the numerical cancellation identity.

**Lemma.** Let H be a disjoint union of m balanced complete bipartite blocks, with any nonnegative edge costs, and fix a baseline perfect matching in each block. Order its N matched pairs cyclically with every block consecutive. For an integer k with 1<=k<m, add every missing forward-shift edge (R_i,C_(i+d)) for 1<=d<=k, giving each added edge cost 1. Then:

1. The completed graph is k-extendable, provided the standard size requirement is met.
2. Every perfect matching using an added edge has cost at least ceil(m/k).
3. Every target fiber below ceil(m/k) is exactly preserved, with the same original vertex labels.

**Proof.** The shifts 0 through k give |N(S)|>=min(N,|S|+k) by repeated cyclic successor expansion. After deleting q<=k rows and q columns belonging to selected disjoint edges, this lower bound leaves at least |S| neighbors for every remaining row subset, whether the minimum is N or |S|+k. Hall gives extendibility. The shifts 0 and 1 imply connectivity.

Every added edge is interblock because each original block is complete. It advances at least one and at most k components; k<m prevents a full turn within one edge. Matching conservation yields a directed cycle of added edges. Its positive increments sum to a positive multiple of m, so the cycle contains at least ceil(m/k) arcs. Nonnegative costs give the cost bound and therefore exact target preservation.

The present construction is m=68,k=2,N=73. This lemma explains why a sufficient collection of forced singleton components can protect a small cancellation fiber while the support is made highly extendable. It is a directly proved construction here, without a literature-novelty claim.

## 6. What was recovered and superseded

The prior constructive-cost audit already gave a correct C6 counterexample to independent count-set convolution across a tight cut, plus the shared-crossing-edge-conditioned recurrence. That work was recovered before starting this audit. Fresh per-brace canonical relabeling is harmless if one independently tests a block under a valid brace theorem; inherited boundary polynomials require separate label handling.

The new completion is stronger for the immediate claim: it gives a standard brace itself whose target polynomial vanishes, so repairing the old tight-cut interface alone cannot rescue this specific nonvanishing assertion. It does not prove that all relabelings of this graph cancel, nor that all deterministic Exact Matching algorithms fail.

## 7. Reproduction

    python verify.py
    python -O verify.py

Both runs reconstruct the graph and fibers from the displayed constants, perform exact polynomial checks, and verify all disjoint edge-pair extensions. No dependencies beyond Python's standard library are used. Runtime is approximately three to four seconds in this environment. VERIFICATION.json and VERIFICATION_OPTIMIZED.json record the checks; elapsed time is the only expected changing field.
