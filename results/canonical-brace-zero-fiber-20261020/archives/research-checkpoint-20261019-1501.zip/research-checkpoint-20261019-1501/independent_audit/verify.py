#!/usr/bin/env python3
"""Independent exact reconstruction. No research code or input certificates imported."""
import itertools, json, hashlib, pathlib, time
START=time.time(); N=73
RP=((35,37),(0,72),(40,32),(45,27),(30,42))
CP=((0,1),(2,3),(4,5),(6,7),(8,10))
R=[a for p in RP for a in p]; C=[a for p in CP for a in p]
R += sorted(set(range(N))-set(R)); C += sorted(set(range(N))-set(C))
base={}
for k,((a,b),(u,v)) in enumerate(zip(RP,CP)):
    base[a,u]=base[b,v]=0
    base[a,v]=1; base[b,u]=int(k==4)
for a,b in zip(R[10:],C[10:]): base[a,b]=0
E=dict(base)
for i in range(N):
    for step in (1,2): E.setdefault((R[i],C[(i+step)%N]),1)

def need(v,msg):
    if not v: raise RuntimeError(msg)
need(len(base)==83 and len(E)==224,'edge counts')
need(set(R)==set(C)==set(range(N)), 'canonical labels')
need(all(c in (0,1) for c in E.values()),'binary colors')
blocks=[list(p) for p in RP]+[[i] for i in R[10:]]
rblock={r:k for k,rs in enumerate(blocks) for r in rs}
cblock={c:(i//2 if i<10 else i-5) for i,c in enumerate(C)}
need(len(blocks)==68,'component count')
need(all(rblock[r]==cblock[c] for r,c in base),'baseline internal')
new={e:E[e] for e in E.keys()-base.keys()}
increments={str(e):(cblock[e[1]]-rblock[e[0]])%68 for e in new}
need(all(v in (1,2) for v in increments.values()),'new edge orientation')
need(all(v==1 for v in new.values()),'new edges red')
need(all((R[i],C[(i+d)%N]) in E for i in range(N) for d in (0,1,2)), 'circulant containment')

# Exact target enumerator on the completed graph, independent of circulation proof.
adj={r:sorted((c,w) for (a,c),w in E.items() if a==r) for r in range(N)}
def enumerate_target(target):
    ans=[]; calls=0
    def rec(rem, free, budget, partial):
        nonlocal calls; calls+=1
        if budget<0 or budget>len(rem): return
        if not rem:
            if budget==0: ans.append(tuple(partial[i] for i in range(N)))
            return
        options=[]
        for r in rem:
            opts=[(c,w) for c,w in adj[r] if c in free and w<=budget]
            if not opts: return
            options.append((len(opts),r,opts))
        _,r,opts=min(options)
        rest=rem-{r}
        for c,w in opts:
            partial[r]=c
            rec(rest, free-{c}, budget-w, partial)
        partial.pop(r,None)
    rec(set(range(N)),set(range(N)),target,{})
    return sorted(ans),calls

fiber_counts=[]; target_fiber=[]; calls=[]
for target in range(7):
    matches,count=enumerate_target(target); calls.append(count)
    expected=[]
    for choices in itertools.product((0,1),repeat=5):
        p=dict(zip(R,C))
        for bit,(a,b),(u,v) in zip(choices,RP,CP):
            if bit: p[a],p[b]=v,u
        tup=tuple(p[i] for i in range(N))
        if sum(base[i,tup[i]] for i in range(N))==target: expected.append(tup)
    need(matches==sorted(expected),'complete target fiber mismatch')
    fiber_counts.append(len(matches))
    if target==3: target_fiber=matches
need(fiber_counts==[1,4,7,8,7,4,1],'fiber count list')

# Polynomial arithmetic using only exact Python integers.
def mul(p,q):
    out=[0]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q): out[i+j]+=a*b
    return out

def parity(p): return -1 if sum(p[i]>p[j] for i in range(N) for j in range(i+1,N))%2 else 1
active=set(R[:10]); polynomials=[]; signs=[]; zero=[0]*47
for p in target_fiber:
    poly=[1]
    for r in sorted(active):
        for unused in range(p[r]): poly=mul(poly,[r,1])
    need(len(poly)==47, 'active degree')
    sign=parity(p); signs.append(sign); polynomials.append(poly)
    zero=[a+sign*b for a,b in zip(zero,poly)]
need(not any(zero),'nonzero target polynomial')
need(len(set(tuple(p) for p in polynomials))==8,'distinct summands')
need(signs.count(-1)==signs.count(1)==4,'sign count')
forced_degree=sum(p for r,p in zip(R[10:],C[10:]))
need(forced_degree==2582 and forced_degree+46==N*(N-1)//2,'degrees')

# Independent finite 2-extendibility check: every pair of disjoint edges extends.
plain={r:[c for c,w in adj[r]] for r in range(N)}
def residual_pm(blockrows, blockcols):
    matched={}
    def augment(r,seen):
        for c in plain[r]:
            if c in blockcols or c in seen: continue
            seen.add(c)
            if c not in matched or augment(matched[c],seen):
                matched[c]=r; return True
        return False
    return all(augment(r,set()) for r in range(N) if r not in blockrows)
checked_pairs=0
for (r,c),(s,d) in itertools.combinations(E,2):
    if r==s or c==d: continue
    need(residual_pm({r,s},{c,d}),'two edges fail extension')
    checked_pairs+=1

out={'n':N,'base_edges':len(base),'completed_edges':len(E),'added_red_edges':len(new),'original_components':68,
     'component_increments':sorted(set(increments.values())),'minimum_new_red_edges_proved':34,
     'target':3,'target_counts_0_through_6':fiber_counts,'search_calls_0_through_6':calls,
     'target_fiber_size':len(target_fiber),'positive_signs':4,'negative_signs':4,
     'active_degree':46,'forced_degree':forced_degree,'all_47_coefficients_zero':not any(zero),
     'disjoint_edge_pairs_checked':checked_pairs,'all_two_edge_matchings_extend':True,'elapsed_seconds':time.time()-START}
here=pathlib.Path(__file__).parent
(here/'RECONSTRUCTED_GRAPH.json').write_text(json.dumps({'rows_cyclic':R,'cols_cyclic':C,'edges':[{'row':r,'column':c,'cost':w} for (r,c),w in sorted(E.items())]},indent=2)+'\n')
(here/'RECONSTRUCTED_FIBER.json').write_text(json.dumps(target_fiber,indent=2)+'\n')
print(json.dumps(out,indent=2))
