#!/usr/bin/env python3
"""Deterministic local ZIP; never uploads or writes a repository."""
import argparse
import hashlib
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
PREFIX = 'research-checkpoint-20261019-1501'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('output', help='ZIP path outside the source bundle')
    args = ap.parse_args()
    out = Path(args.output).resolve()
    if out == HERE or HERE in out.parents:
        raise RuntimeError('ZIP output must be outside the source bundle')
    files = sorted(p for p in HERE.rglob('*') if p.is_file())
    if any(p.is_symlink() or '__pycache__' in p.parts or p.suffix == '.pyc' for p in files):
        raise RuntimeError('Unexpected symlink or bytecode cache in source bundle')
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_STORED) as z:
        for path in files:
            member = PREFIX + '/' + path.relative_to(HERE).as_posix()
            info = zipfile.ZipInfo(member, date_time=(2026, 10, 19, 15, 1, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED
            info.flag_bits = 0
            z.writestr(info, path.read_bytes())
    print(hashlib.sha256(out.read_bytes()).hexdigest() + '  ' + out.name)

if __name__ == '__main__':
    main()
