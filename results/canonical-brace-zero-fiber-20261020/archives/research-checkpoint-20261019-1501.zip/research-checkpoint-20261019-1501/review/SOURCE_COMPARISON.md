# Exact source comparison and claim boundary

Source checked on 19 October 2026 UTC: Yuefeng Du, *Bipartite Exact Matching in P*, arXiv:2604.01571v3, dated 9 April 2026. Version-pinned source: https://arxiv.org/html/2604.01571v3 . No author contact or repository action was performed.

## Source propositions checked

1. [Section 1.2 / Theorem 1.2](https://arxiv.org/html/2604.01571v3#S1.SS2) uses row and column indices 0 through n−1, with an allowed matrix entry x^{rho(i,j)}(lambda+i)^j. Its asserted nonvanishing implication applies to every binary edge coloring and every nonempty exact-target fiber of a bipartite brace.
2. [Remark 1.4](https://arxiv.org/html/2604.01571v3#S1.SS2) limits ASNC itself to braces; the prior disconnected example alone did not contradict that scope.
3. [Definition 3.1](https://arxiv.org/html/2604.01571v3#S3.SS1) describes connectedness, a perfect matching and Hall+2 for all proper nonempty row subsets, and immediately states an equivalent 2-extendability characterization.

## Exact match to the present construction

The new graph has n=73, the prescribed numerical labels, binary colors, and eight matchings at target t=3. Its full signed polynomial uses precisely the source's displayed weighting. Two separate checkers reconstruct the complete target fiber and establish exact zero. A mathematical expansion proof and exhaustive edge-pair extension check establish standard 2-extendability.

The definition's literal endpoint |S|=72 would demand at least 74 distinct neighbors in a 73-column graph, which is impossible. The nonvacuous standard interpretation restricts Hall+2 to 1≤|S|≤71, together with connectedness and a perfect matching. The graph satisfies this and the expressly stated extension property. The contradiction is to Theorem 1.2 under that standard interpretation, not to the impossible literal endpoint condition.

## Wording appropriate for review

“The supplied exact construction is a counterexample to Du v3 Theorem 1.2 under its stated equivalent standard 2-extendable-brace interpretation. The manuscript's Hall endpoint inconsistency is disclosed explicitly.”

This is a mathematical conclusion drawn from the included proofs and certificates, not a statement conceded by the source. It does not settle the complexity of Exact Matching, P versus NP, P versus RP, the existence of other deterministic algorithms, or whether every labeling of this graph cancels. Literature novelty and external peer review are unconfirmed.
