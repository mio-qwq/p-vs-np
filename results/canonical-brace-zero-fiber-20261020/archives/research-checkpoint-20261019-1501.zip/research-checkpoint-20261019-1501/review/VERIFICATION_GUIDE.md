# Verification guide

## Clean replay

`verify_bundle.py` starts each of three source checkers in an otherwise empty temporary directory, once normally and once with Python `-O`. The source checkers reconstruct their input graphs from displayed constants and use exact integer or rational arithmetic. No downloaded executable research code or external package is required.

The main and independent brace checkers are distinct implementations. The prior checker verifies the rational five-cycle identity, affine canonical embedding, complete original fiber and exact cancellation. Root replay uses the independent audit implementation again; it is not counted as another independent implementation.

The independent completed-graph search covers all target counts 0 through 6 and returns 1, 4, 7, 8, 7, 4, 1. The main checker also compares the target-three old and new fibers directly. Both brace checkers test all 24,508 disjoint edge pairs. The main checker validates each returned full extension witness and records a witness-stream digest.

The full degree-2628 polynomials are not materialized as duplicate dense coefficient vectors. Each matching has the same degree-2582 factor on 63 forced rows. That factor is nonzero; exact expansion of the eight remaining degree-46 terms establishes all 47 signed coefficients vanish. Full 73-row integer evaluations are supplementary checks only.

Receipts may record runtime and Python version. Those are the only fields normalized in cross-run receipt comparisons. Graphs, permutations, signs, integer coefficients, search-state counts and witness digests must agree exactly.

## Certificate mutations

The source checkers reconstruct rather than trust stored certificates. The bundle harness additionally compares the frozen certificates against reconstruction and runs 14 separate rejection tests:

1. Delete an edge.
2. Duplicate an edge.
3. Change an edge's binary cost.
4. Move a row label outside the canonical range.
5. Delete a matching.
6. Duplicate a matching.
7. Alter a matching permutation.
8. Reverse a permutation sign.
9. Change an active polynomial coefficient.
10. Truncate an active coefficient vector.
11. Alter the independent graph record.
12. Alter the independent fiber record.
13. Alter the prior sparse graph record.
14. Alter the prior fiber record.

These are integrity and sensitivity tests, not an exhaustive mathematical adversary search. Their rejection is separate from the proof of the unmutated instance.

The construction checker also changes an original red cost and obtains a different, nonzero target polynomial; it verifies that a single one-way cross-component completion is not matching-covered. The prior checker changes a cost and an exponent and obtains nonzero polynomials.

## Review questions

- Does the displayed 224-edge graph use precisely the source's numerical row/column weighting?
- Does the cyclic-support argument prove Hall+2 for all necessary subset sizes?
- Does component balance force every new-edge matching to contain at least 34 red edges?
- Are all eight target matchings enumerated, with no selected-subsum shortcut?
- Are the global permutation signs and common-factor extraction correct?
- Is the Definition 3.1 endpoint caveat stated wherever the theorem comparison is used?

Novelty and any broader algorithmic interpretation need separate review. No minimality of 73 vertices per side is claimed.
