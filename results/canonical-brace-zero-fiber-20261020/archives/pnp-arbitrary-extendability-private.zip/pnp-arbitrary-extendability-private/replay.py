#!/usr/bin/env python3
"""Replay clean checkpoint sources in normal/-O modes with active fault controls."""
import argparse, ast, hashlib, json, os, platform, subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def verify_manifest():
    entries = []
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        expected, rel = line.split('  ', 1)
        p = ROOT/rel
        require(not p.is_symlink() and p.is_file(), 'Missing or linked payload: ' + rel)
        require(p.resolve().is_relative_to(ROOT), 'Escaping payload: ' + rel)
        require(digest(p.read_bytes()) == expected, 'Hash mismatch: ' + rel)
        entries.append(rel)
    actual = sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file())
    require(actual == sorted(entries + ['SHA256SUMS']), 'Unexpected or missing extracted files')
    return len(entries)

def run_file(path, optimize, args, cwd, env):
    command = [sys.executable] + (['-O'] if optimize else []) + [str(path)] + args
    return subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, timeout=600)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--receipt', type=Path)
    args = ap.parse_args()
    count = verify_manifest()
    plan = json.loads((ROOT/'REPLAY_PLAN.json').read_text())
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    results = []
    with tempfile.TemporaryDirectory(prefix='local-checkpoint-replay-') as temporary:
        work = Path(temporary)
        for case in plan['cases']:
            path = ROOT/case['script']
            original = path.read_text()
            tree = ast.parse(original)
            require(not any(isinstance(n, ast.Assert) for n in ast.walk(tree)), 'Bare assert would disappear under -O: ' + case['script'])
            expected = json.loads((ROOT/case['expected']).read_text())
            outputs = []
            for optimize in (False, True):
                extra = ['--output', str(work/'source-output.json')] if case.get('writes_output') else []
                run = run_file(path, optimize, extra, ROOT, env)
                require(run.returncode == 0, case['script'] + ': clean replay failed\n' + run.stderr)
                actual = json.loads(run.stdout)
                require(actual == expected, case['script'] + ': output differs from recorded expected result')
                outputs.append(run.stdout)
            require(outputs[0] == outputs[1], case['script'] + ': normal/-O output bytes differ')
            find, replacement = case['mutation']['find'], case['mutation']['replacement']
            require(original.count(find) == 1, case['script'] + ': fault mutation anchor not unique')
            mutant = work/path.name
            mutant.write_text(original.replace(find, replacement, 1))
            faults = []
            for optimize in (False, True):
                extra = ['--output', str(work/'fault-output.json')] if case.get('writes_output') else []
                run = run_file(mutant, optimize, extra, work, env)
                expected_error = case['mutation']['expected_error']
                require(run.returncode != 0 and expected_error in run.stderr, case['script'] + ': intended fault escaped checks')
                faults.append({'mode': 'optimized' if optimize else 'normal', 'returncode': run.returncode, 'intended_error': expected_error})
            results.append({'script': case['script'], 'status': 'PASS', 'normal_optimized_stdout_identical': True, 'expected_json_matches': True, 'source_sha256': digest(path.read_bytes()), 'stdout_sha256': digest(outputs[0].encode()), 'fault_controls': faults})
    require(verify_manifest() == count, 'Extracted package changed during replay')
    versions = {'python': platform.python_version(), 'python_implementation': platform.python_implementation()}
    if plan.get('numpy_required'):
        import numpy
        versions['numpy'] = numpy.__version__
    result = {'status': 'PASS', 'payload_files_verified': count, 'versions': versions, 'normal_and_optimized_checker_runs': 2*len(results), 'intended_fault_rejections': 2*len(results), 'cases': results, 'scope': plan['scope'], 'network_or_repository_actions': 'None'}
    payload = json.dumps(result, indent=2, sort_keys=True) + '\n'
    if args.receipt:
        require(not args.receipt.resolve().is_relative_to(ROOT), 'Write receipt outside the immutable extracted package')
        args.receipt.write_text(payload)
    print(payload, end='')

if __name__ == '__main__':
    main()
