# Private proposed arbitrary-extendability completion

For every positive integer k there is a canonical binary-coloured bipartite k-extendable graph with a nonempty cost-3 perfect-matching fibre whose signed canonical polynomial vanishes. This is a strengthening of the private brace construction, pending independent audit. It makes no P versus NP claim.

Take the existing canonical 73-by-73 seed, consisting of five complete K2,2 components and 63 singleton matching components. Append forced pairs with new equal actual row and column labels until the number m of components exceeds 3k and the total n exceeds k+1. The original cost-3 fibre multiplies by a common nonzero canonical polynomial and has the same eight matchings and cancellation.

Order each component consecutively, aligning an existing perfect matching as abstract shift 0. Retain actual labels, exponents, and all old colours. Add every missing edge of abstract shifts 1 through k cyclically, colouring additions red.

Every added edge crosses components: each original component is complete bipartite. For an added edge the clockwise advance on the m-component circle is between 1 and k. Any perfect matching induces equal incoming and outgoing crossing counts at every balanced component. Its crossing edges therefore decompose into directed cycles. A directed cycle has total clockwise advance a positive multiple of m, and uses at least ceil(m/k)>3 edges, all newly red. Consequently cost-3 matchings cannot use additions; the fibre and cancellation remain unchanged.

The graph contains all shifts 0 through k. For any nonempty row-index set S, cyclic expansion satisfies |S union (S+1)| >= min(n,|S|+1). Iterating k times gives |N(S)| >= min(n,|S|+k). If k disjoint edges are prescribed, remove their endpoints. For any nonempty residual row subset S, |S|<=n-k, and deleting k columns leaves at least |S| neighbours. Hall gives a perfect matching of the residual graph. Shifts 0 and 1 ensure connectivity. Thus every k-matching extends and the graph is k-extendable under the usual n>=k+1 convention.

Scope: k is arbitrary, while graph size grows. This is not a dense-graph theorem, a fixed-order all-k statement, or a Boolean complexity separation. External publication requires separate specific approval.

Explicit size: n(k)=max(73,3k+6) and m=n−5 satisfy all conditions. Thus a fixed completed order-n graph from this recipe can achieve extendability floor((n−6)/3). At n=73, k=22 needs no new forced labels. This strengthens robustness to linearly growing extendability, while still not implying dense complete-support cancellation. Added red cycles have at least ceil((n−5)/k)>=4 edges.
