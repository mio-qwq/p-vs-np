# PRIVATE arbitrary-extendability strengthening

19 October 2026. Private local checkpoint. External disclosure/publication remains pending fresh specific major-claim approval. No research PR merge or research release is authorized by this archive.

## Exact mathematical scope

For each integer k>=1, set n=max(73,3k+6) and m=n-5. Starting from the exact canonical 73-row seed, append blue singleton pairs and add missing red shifts 1 through k in a consecutive-component matched-pair ordering. The completed binary-coloured bipartite graph is connected and k-extendable. Each perfect matching using an added edge has at least ceil(m/k)>=4 red edges. Thus the entire nonempty target-three fiber remains exactly the same eight padded matchings, with identically zero signed translated-power polynomial using actual canonical labels 0,...,n-1.

Read audit/AUDIT.md for the audited all-k proof. The complete balanced base components, retained original colours/labels, n>k, and strict m>kT condition are essential. Both the strict-threshold and completeness failures have explicit negative controls. The graph size grows with k; this is not a fixed-order all-k result, a claim about all dense supports, a P versus NP separation, or a resolution of Exact Matching complexity.

The checker reconstructs the seed independently, proves all 47 active polynomial coefficients vanish using integer arithmetic, completely enumerates the target fiber for k=1,2,3,4, and checks construction/seed data at k=22,23,50,100. It also performs 81,858 expansion and 107,777 component-step checks. The theorem for all k is established by the proof, not inferred from finite testing. Root PROPOSITION.md is the preserved pre-audit proposal; audit/AUDIT.md is its subsequent completed independent audit.

## Prerequisites

Python 3.10 or later; standard library only. Verified here with CPython 3.12.14. No network or prior data files are required for replay. Hall's theorem and elementary permutation/polynomial algebra are the mathematical inputs. The exact prior canonical seed proof is bundled in prerequisites/CANONICAL_SEED_PROOF.md for provenance; the audit and checker also reconstruct its necessary data directly. The root's duplicate checker and duplicate JSON receipts were omitted after their byte identities were verified.

## Replay and archive integrity

Extract this ZIP into a new empty directory. From its extracted root run:

    python replay.py --receipt ../replay-receipt.json

This verifies every SHA-256, rejects unexpected payload files, runs every checker normally and with python -O, compares full JSON results with the bundled expected outputs, and requires normal/optimized stdout to be byte-identical. It then changes one checked mathematical invariant in a temporary copy of every checker and requires the intended exception in both modes. All checkers use explicit exceptions; no bare assert is relied upon. Temporary fault copies are discarded. The payload and original source files are not changed.

To reproduce the exact ZIP, choose a nonexistent output path outside the extracted root:

    python rebuild.py ../rebuilt.zip

The file list, byte contents, root name, sorted order, timestamp (2026-10-19 17:04:00 UTC), Unix file mode 0644 and DEFLATE level 9 are fixed. SHA256SUMS covers every payload file except itself; the outer archive SHA-256 covers that manifest too. The original packaging process verified byte-identical clean-extraction rebuilds, normal/optimized replay, and intended fault rejections. Original receipts are retained once as expected JSON, rather than duplicated normal/-O outputs. No cache, bytecode, temporary mutation, prior ZIP or redundant checker copy is included.

PROVENANCE.json maps each preserved file to its original local path, SHA-256 and byte size. Original document wording and historical absolute references are intentionally preserved. Use that map to locate bundled prerequisite copies; historical status phrases in old source notes are not current checkpoint status. The current independent audits and this README define the checkpoint status. No repository push, PR, merge, release, upload, or external communication is part of this checkpoint.
