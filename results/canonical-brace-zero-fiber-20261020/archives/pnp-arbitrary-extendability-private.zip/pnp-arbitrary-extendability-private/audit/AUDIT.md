# Independent audit: arbitrary-extendability completion preserves canonical cancellation

19 October 2026. Private mathematical audit. No repository changes, upload, publication, release, merge, or communication with a third party.

## Verdict

**PASS**, with the hypotheses and endpoint ranges below. For every integer `k >= 1`, there is a connected, binary-colored, `k`-extendable bipartite graph on `n+n` vertices with actual canonical row offsets and column exponents `0,...,n-1`, and a nonempty entire target-three matching fiber whose signed translated-power polynomial is identically zero.

An explicit choice is

```
n(k) = max(73, 3k+6),
m(k) = n(k)-5,
L(k) = n(k)-73 = max(0,3k-67).
```

Here `m` is the number of complete balanced base components and `L` is the number of extra singleton components appended to the original 73-row seed. Every perfect matching using any new edge has at least `ceil(m/k) >= 4` red edges. Thus its entire target-three fiber is exactly the padded old eight-member fiber.

The construction needs no extra vertices for `1 <= k <= 22`. For larger `k` it has `n=3k+6`, so the result also permits extendability growing linearly with size. It does not show persistence at every extendability fraction, and it makes no complexity-class claim.

## 1. Precise completion lemma

Let `H` be a disjoint union of `m` complete balanced bipartite graphs, of respective positive sizes `b_a+b_a`; let `n=sum(b_a)`. Give its edges binary colors, red cost one and blue cost zero. Choose a perfect matching inside every component. Order these matched pairs cyclically so that the pairs in each component are consecutive.

Use `R_i,C_i`, `i in Z/nZ`, for the row and column vertices of the chosen matched pairs. These are auxiliary positions, **not replacements for actual polynomial labels**. Fix integers `k>=1`, `n>k`, and `m>k`. For every `i`, add every missing edge

```
(R_i, C_(i+j)),  j=1,...,k modulo n,
```

and color the added edge red. Keep every original color unchanged. Call the resulting graph `G`.

Then:

1. `G` is connected, has a perfect matching, has at least `2k+2` vertices, and every matching of size at most `k` extends to a perfect matching.
2. Every added edge joins different components of `H`.
3. Every perfect matching containing an added edge uses at least `ceil(m/k)` added edges, hence at least that many red edges.
4. For every integer `T>=0` with `T<ceil(m/k)`, the entire red-count-`T` fiber is unchanged. Equivalently, the convenient strict condition is `m>kT`.

The complete-component hypothesis in item 2 is essential. A condition ensuring separately that no added edge is internal would also suffice.

### 1.1 Expansion, including the endpoint

The spanning cyclic interval graph has neighborhood

```
N(S) = S + {0,1,...,k}  in Z/nZ.
```

For any nonempty proper set `A`, its successor translate satisfies `|A union (A+1)|>=|A|+1`. Otherwise the translate, which has equal size, would be equal to `A`; invariance under the single `n`-cycle forces `A` to be empty or all of `Z/nZ`.

Let `A_t=S+{0,...,t}`. At each step `A_(t+1)=A_t union (A_t+1)`, so its size grows by at least one until reaching `n`. Therefore, for **every nonempty** `S`,

```
|N_G(S)| >= min(n, |S|+k).
```

In particular, the Hall-plus-`k` inequality `|N_G(S)|>=|S|+k` holds exactly in the necessary nonvacuous range `1<=|S|<=n-k`. At the endpoint `|S|=n-k`, the right side is `n`, which is possible and is attained. Do not incorrectly impose `|S|+k` beyond that range.

### 1.2 Direct extension proof for arbitrary prescribed edges

Let `F` be **any** matching of size `t<=k` in the completed graph, including edges outside its cyclic interval subgraph. Delete its `t` rows and `t` columns. For any set `S` of remaining rows, `|S|<=n-t`, and

```
|N_residual(S)| >= min(n, |S|+k)-t >= |S|.
```

For the last inequality, both entries of the minimum are at least `|S|+t`: `n>=|S|+t`, and `|S|+k>=|S|+t`. The empty set is automatic. Hall's theorem yields a perfect matching of the residual graph; reinserting `F` gives the required extension.

This argument covers `t=k`, `t<k`, and `t=0` directly. It does not require an unproved assertion that adding arbitrary edges preserves extendability. The shift-zero and shift-one edges form a spanning alternating cycle because `n>=2`, hence `G` is connected. Finally `n>k` gives the usual minimum order `2n>=2k+2` in the standard definition of `k`-extendability.

### 1.3 No new internal edges

Every possible row-column edge within one old component is already present because the component is complete bipartite. Consequently every genuinely added edge is cross-component. This checks the main potential loophole explicitly: new low-red-count internal matchings cannot arise.

A `j`-step forward movement of paired positions crosses at most `j` component boundaries. Since `j<=k<m`, it cannot traverse a full cycle of all `m` components. For a cross-component added edge, the resulting forward component increment is thus an integer in `1,...,k`, interpreted modulo `m`.

### 1.4 Circulation and the strict threshold

Fix a perfect matching `M` of `G`. For a component with `b` rows and `b` columns, if `x` matching edges are internal, exactly `b-x` selected edges leave its rows and exactly `b-x` selected edges enter its columns. Hence selected cross-component edges form a balanced directed multigraph after contraction: indegree equals outdegree at every component.

If any new edge is used, this multigraph is nonempty and decomposes into directed cycles. On a directed cycle of length `ell`, sum the positive forward component increments. Their sum is a positive multiple of `m`, while each increment is at most `k`. Thus

```
k ell >= m,  ell >= ceil(m/k).
```

Every edge on this cycle is new and red, so the whole matching has at least `ceil(m/k)` red edges. This holds even if the matching also changes internal old matching choices or includes several cross-component cycles.

If `m>kT`, then `ceil(m/k)>T`; no matching of target `T` can use a new edge. Conversely, all old target matchings survive unchanged. This establishes equality of the **entire** fibers rather than the survival of a selected subsum.

## 2. Recovery and extension of the exact canonical seed

The recovered seed has the actual active label lists

```
R_active = (35,37, 0,72, 40,32, 45,27, 30,42),
C_active = (0,1, 2,3, 4,5, 6,7, 8,10).
```

In the 73-row seed, append the unused labels from `0,...,72` in increasing order to each list independently. Baseline edges `(R_i,C_i)` are blue. For each `a=0,...,4`, add both swap edges inside paired positions `2a,2a+1`:

- `(R_(2a),C_(2a+1))` is red;
- `(R_(2a+1),C_(2a))` is blue when `a<4`, and red when `a=4`.

This is a disjoint union of five complete `K_(2,2)` blocks and 63 `K_(1,1)` blocks. The five flip costs are `(1,1,1,1,2)`. All perfect matchings are the 32 choices of flips, and precisely eight have cost three: four choices of three unit-cost flips, and four choices of one unit-cost flip together with the cost-two flip.

For desired `k`, append new blue singleton edges `(r,r)` for all actual labels `r=73,...,n(k)-1`. These are new actual row offsets and column exponents, not abstract ranks substituted for old labels. The paired ordering consists of the original paired ordering followed by these singleton pairs. It has five size-two blocks and `n-10` singleton blocks, hence `m=n-5` blocks in total.

Perform the completion of Section 1. By construction,

```
n>k,
m>=3k+1>k,
ceil(m/k)>=4.
```

Thus the completed graph is `k`-extendable and its complete target-three fiber is the eight padded seed matchings.

For this family, the old edge count is `n+10`. Of the `nk` proposed positive-shift edges, exactly five forward swap edges were already present. None of the five backward swap edges is in the cyclic interval support because its shift is `n-1>k`. Therefore:

```
new red edges = nk-5,
total edges = n(k+1)+5.
```

## 3. Canonical polynomial preservation

For the completed graph define the target polynomial using actual canonical labels:

```
Phi_(G,3)(lambda) = sum over cost-three perfect permutations p:
                    sign(p) product_(r=0)^(n-1) (lambda+r)^(p(r)).
```

All new singleton factors are common across the padded old fiber. Appending fixed points with labels larger than all old labels creates no new inversions, so the sign of each padded permutation is the old sign. Hence

```
Phi_(G,3)(lambda)
 = Phi_(H_73,3)(lambda) product_(r=73)^(n-1) (lambda+r)^r
 = 0.
```

The product is a nonzero polynomial, and the fiber remains nonempty. This is exact cancellation, not vanishing caused by a missing matching, a zero common factor, or a redefinition of labels.

The independent checker reconstructs the seed without reading any previous receipt. For each of the eight permutations it uses the full canonical permutation sign, expands its ten active `(lambda+r)^(p(r))` factors with exact integer arithmetic, and verifies that all 47 coefficients of the signed active sum vanish. The fixed inactive factors are common and nonzero. The check is repeated at every audited padded size.

## 4. Independent finite verification and negative controls

Run:

```
python verify_extendable.py
python -O verify_extendable.py --output VERIFICATION_OPTIMIZED.json
```

The checker uses explicit exceptions rather than assertions, so optimized mode retains the checks.

It performs these tests:

- Actual canonical construction at `k=1,2,3,4,22,23,50,100`, including the first padded case `k=23,n=75,m=70`.
- Exact reconstruction and polynomial cancellation of all eight old target-three matchings at each size.
- Complete unrestricted target-three matching enumeration in the final graph for `k=1,2,3,4`; exact equality with the seed fiber. The `k=3` certificate has `n=73`, 297 total edges, and 20,882 backtracking states. It is independent of the theoretical exclusion in Section 1.
- 81,858 cyclic-neighborhood inequalities, exhaustively over nonempty subsets and every `1<=k<n` for `2<=n<=12`.
- 107,777 paired-position/component-step checks, exhaustively over all consecutive nonempty block decompositions for `2<=n<=10` and every `1<=k<m`.

The large cases check the exact construction and polynomial, while their complete-fiber exclusion and extendability are established by the all-parameter proof. The finite tests are not presented as a substitute for that proof. In particular, no exhaustive enumeration of all `k`-edge partial matchings at `k>=3` is claimed.

Two negative controls pin down necessary qualifications:

1. **Strict target threshold.** For `m=kT=6`, `k=2`, `T=3`, six singleton blocks and shift-two edges admit the three-red cycle `0->2->4->0` with all other rows on baseline edges. Thus replacing `m>kT` by `m>=kT` would fail in general.
2. **Completeness.** Start with 10 balanced blocks and `k=1`, but let the first two-row block be the three-edge path consisting of its two blue diagonal edges and one blue backward edge. Its missing forward edge is newly added red. The transposition then makes a new one-red perfect matching despite `m=10>kT=1`. Thus one cannot omit the no-internal-addition condition.

## 5. Scope and conclusion

The root-proposed strengthening is valid. Standard `k`-extendability, for any prescribed positive integer `k`, cannot by itself rule out cancellation of a nonempty binary-cost canonical target fiber. Indeed the exhibited family supports `k` up to `floor((n-6)/3)` for every `n>=73` using the same construction.

This conclusion addresses the graph-structural repair specifically. It neither proves nor disproves the computational complexity of Exact Matching or P versus NP, and it does not eliminate possible hypotheses that impose stronger or different restrictions than extendability alone.

Recovered local source: the five-cycle seed and two-shift construction in the earlier private proof at `brace-label-stability-20261019-1454/PROOF.md`. This audit independently verifies the precise all-`k` mathematical generalization and its finite examples; it does not rely on an external paper's definition being typo-free.
