#!/usr/bin/env python3
"""Independent finite audits for the general extendable completion lemma.
The all-k claim is proved in AUDIT.md, not inferred from these finite tests.
No input certificate, third-party module, network, or external state is used.
"""
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
AR = (35, 37, 0, 72, 40, 32, 45, 27, 30, 42)
AC = (0, 1, 2, 3, 4, 5, 6, 7, 8, 10)

def check(value, message):
    if not value:
        raise ValueError(message)

def sign(p):
    return 1 if sum(p[i] > p[j] for i in range(len(p)) for j in range(i + 1, len(p))) % 2 == 0 else -1

def convolution(a, b):
    c = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            c[i + j] += x * y
    return c

def graph(k):
    check(k >= 1, 'positive k')
    n = max(73, 3 * k + 6)
    m = n - 5
    rows = list(AR) + sorted(set(range(n)) - set(AR))
    cols = list(AC) + sorted(set(range(n)) - set(AC))
    blocks = [i // 2 if i < 10 else i - 5 for i in range(n)]
    old = {(rows[i], cols[i]): 0 for i in range(n)}
    for t in range(5):
        old[rows[2*t], cols[2*t+1]] = 1
        old[rows[2*t+1], cols[2*t]] = int(t == 4)
    new = old.copy()
    for i in range(n):
        for j in range(1, k + 1):
            new.setdefault((rows[i], cols[(i + j) % n]), 1)
    rb, cb = dict(zip(rows, blocks)), dict(zip(cols, blocks))
    added = set(new) - set(old)
    check(n > k and m > 3*k, 'size and strict target threshold')
    check(sorted(rows) == sorted(cols) == list(range(n)), 'actual canonical labels')
    check(all(rb[r] == cb[c] for r, c in old), 'old edges internal')
    check(all(new[e] == 1 and 1 <= (cb[e[1]] - rb[e[0]]) % m <= k for e in added), 'added edges cross and advance')
    check(all((rows[i], cols[(i + j) % n]) in new for i in range(n) for j in range(k + 1)), 'cyclic interval spanning graph')
    check(len(old) == n + 10 and len(added) == n*k - 5 and len(new) == n*(k+1) + 5, 'exact edge counts')
    return n, m, rows, cols, old, new

def enumerate_target(n, rows, edges, target=3):
    adj = [[] for _ in range(n)]
    for (r,c), w in sorted(edges.items()):
        adj[r].append((c,w))
    p = [-1] * n
    out = []
    states = 0
    def dfs(i, used, cost):
        nonlocal states
        states += 1
        if i == n:
            if cost == target:
                out.append(tuple(p))
            return
        r = rows[i]
        for c,w in adj[r]:
            if cost+w <= target and not (used >> c) & 1:
                p[r] = c
                dfs(i+1, used | (1 << c), cost+w)
    dfs(0,0,0)
    return sorted(out), states

def seed_fiber(n, rows, cols):
    baseline = dict(zip(rows,cols))
    out = []
    for bits in itertools.product((0,1), repeat=5):
        if sum(bits[:4]) + 2*bits[4] != 3:
            continue
        p = [baseline[r] for r in range(n)]
        for i,flip in enumerate(bits):
            if flip:
                p[rows[2*i]],p[rows[2*i+1]] = p[rows[2*i+1]],p[rows[2*i]]
        out.append(tuple(p))
    check(len(out) == 8, 'entire old target fiber has eight choices')
    total = [0] * 47
    for p in out:
        term = [1]
        for r in AR:
            e = p[r]
            factor = [math.comb(e,d) * r**(e-d) for d in range(e+1)]
            term = convolution(term,factor)
        check(len(term) == 47, 'active degree 46')
        total = [a + sign(p)*b for a,b in zip(total,term)]
    check(not any(total), 'all active polynomial coefficients vanish exactly')
    check(sum(sign(p) == 1 for p in out) == 4, 'balanced signs')
    return sorted(out), total

def expansion_tests():
    tested = 0
    for n in range(2,13):
        for bits in range(1, 1 << n):
            s = {i for i in range(n) if (bits >> i) & 1}
            nb = s.copy()
            for k in range(1,n):
                nb.update((i+k)%n for i in s)
                check(len(nb) >= min(n,len(s)+k), 'cyclic expansion endpoint')
                tested += 1
    return tested

def all_compositions(n):
    for cuts in range(1 << (n-1)):
        a, blocks = 0, []
        for i in range(n):
            blocks.append(a)
            if i < n-1 and (cuts >> i) & 1:
                a += 1
        yield blocks, a+1

def block_step_tests():
    tested = 0
    for n in range(2,11):
        for block,m in all_compositions(n):
            for k in range(1,m):
                for i in range(n):
                    for j in range(1,k+1):
                        d = (block[(i+j)%n] - block[i]) % m
                        check(d == 0 or 1 <= d <= k, 'forward block bound')
                        tested += 1
    return tested

def negative_controls():
    # Sharp strictness: m=kT=6, k=2. Three shift-two edges form a red cycle.
    n,k,t = 6,2,3
    p = list(range(n))
    for i in (0,2,4):
        p[i] = (i+k) % n
    check(sorted(p) == list(range(n)), 'boundary matching permutation')
    check(sum(i != c for i,c in enumerate(p)) == t, 'boundary has exactly target red edges')
    # Incomplete P4 component on positions 0,1: missing internal forward edge
    # adds a one-red transposition even with 10 components and k=1.
    n,m = 11,10
    old = {(i,i):0 for i in range(n)}
    old[1,0] = 0
    new = old.copy()
    for i in range(n):
        new.setdefault((i,(i+1)%n),1)
    p = list(range(n)); p[0],p[1] = 1,0
    check(m > 1 and sorted(p) == list(range(n)), 'incomplete example size')
    check(sum(new[i,c] for i,c in enumerate(p)) == 1, 'new internal one-red matching')
    check((0,1) not in old and all((i,c) in new for i,c in enumerate(p)), 'genuinely new internal edge')
    return {'strict_m_greater_than_kT_required': True, 'complete_base_component_hypothesis_essential': True}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', default='VERIFICATION.json')
    args = ap.parse_args()
    cases = []
    # k=23 is the first padded case. Full target enumeration is independent of
    # the exclusion proof for small k; larger cases check construction and seed.
    for k in (1,2,3,4,22,23,50,100):
        n,m,rows,cols,old,new = graph(k)
        expected, coefficients = seed_fiber(n,rows,cols)
        record = {'k':k, 'n':n, 'm':m, 'padded_singletons':n-73,
                  'edge_count':len(new), 'added_red_edges':len(new)-len(old),
                  'red_lower_bound_for_new_edge_matchings':(m+k-1)//k,
                  'zero_coefficients':len(coefficients), 'seed_fiber_count':len(expected)}
        if k <= 4:
            actual, states = enumerate_target(n,rows,new)
            check(actual == expected, 'complete new target fiber equals seed')
            record.update({'full_target_fiber_enumerated':True, 'backtracking_states':states})
        else:
            record['full_target_fiber_enumerated'] = False
        cases.append(record)
    result = {'status':'PASS', 'scope':'Private local audit only; no external mutations.',
              'all_k_claim_proved_in':'AUDIT.md', 'construction_cases':cases,
              'exhaustive_cyclic_expansion_checks':expansion_tests(),
              'exhaustive_component_step_checks':block_step_tests(),
              'negative_controls':negative_controls()}
    (HERE / args.output).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,sort_keys=True))

if __name__ == '__main__':
    main()
