#!/usr/bin/env python3
"""Rebuild exactly the manifest-listed archive with fixed ZIP metadata."""
import argparse, hashlib, json, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('output', type=Path)
    args = ap.parse_args()
    require(not args.output.exists(), 'Refusing to overwrite an existing archive')
    require(not args.output.resolve().is_relative_to(ROOT), 'Archive must be outside payload directory')
    entries = {}
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        checksum, name = line.split('  ', 1)
        file = ROOT/name
        require(file.resolve().is_relative_to(ROOT) and not file.is_symlink(), 'Invalid payload path')
        content = file.read_bytes()
        require(hashlib.sha256(content).hexdigest() == checksum, 'Payload hash mismatch: ' + name)
        entries[name] = content
    entries['SHA256SUMS'] = (ROOT/'SHA256SUMS').read_bytes()
    root_name = json.loads((ROOT/'REPLAY_PLAN.json').read_text())['archive_root']
    with zipfile.ZipFile(args.output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as z:
        for name in sorted(entries):
            info = zipfile.ZipInfo(root_name + '/' + name, (2026, 10, 19, 17, 4, 0))
            info.create_system = 3
            info.external_attr = (0o100644 << 16)
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, entries[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    print(hashlib.sha256(args.output.read_bytes()).hexdigest() + '  ' + args.output.name)

if __name__ == '__main__':
    main()
