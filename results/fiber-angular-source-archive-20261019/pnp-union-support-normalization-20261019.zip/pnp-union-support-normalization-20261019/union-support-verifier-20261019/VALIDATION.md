# Validation receipt

19 October 2026. The theorem is established by the symbolic proof in `PROOF.md`; these finite checks are corroboration only.

## Exhaustive core and selector checks

Both commands completed successfully with identical output:

    python check_core.py
    python -O check_core.py

The checker uses explicit `require` calls rather than assertions, so optimization does not disable the checks. It exhaustively covers every simple source support with binary colors at side sizes two and three, every valid distinguished matching D, every pair of source partial matchings with common endpoint sets, every selector mode, and every nonempty source target subfamily containing D.

Counts:

* 15,688 colored source supports with at least one perfect matching
* 35,064 distinguished-match choices
* 7,047,712 core/selector state checks
* 70,992 explicit-family checks

The same counts are saved in `core-results.json`.

## Independent actual binary-expanded graph check

The independent audit's `../union-support-verifier-audit-20261019/check_expanded.py` constructs actual binary-colored simple graphs and enumerates their perfect matchings with a generic backtracker, without relying on path or core semantics. Both its normal and optimized runs passed. The constructive worker also replayed its normal command independently; the substantive counts agree:

* 132 expanded graphs, including all 72 known-D instances across ternary 2-by-2 supports
* 22,789 actual graph perfect matchings enumerated
* 1,063 actual target matchings
* 347 source-family choices
* Maximum 341 vertices per side and 698 edges

The larger cases include dense and sparse 3-by-3 sources and source edges which need not extend to a full source perfect matching. The checker verifies matching validity, cost, distinctness, exact edge-union coverage, the exhaustive target classification, and the outside-count correspondence.

## Proof and code review

The constructive and audit workers independently derived the normalization and read each other's proof and checker in full. The parent separately reviewed the main proof's classification, padding, binary expansion, all-edge coverage, and full input-length bound. No material defect was found.

The earlier known-singleton reduction is the only proof dependency for the final reduction from arbitrary bipartite Exact Matching. Its source is `../exact-fiber-reductions-20261019/PROOF.md`. The normalization theorem itself is self-contained in `PROOF.md`.

Neither checker is an implementation of a deterministic polynomial-time solver for Exact Matching. Its exhaustive searches are confined to finite validation. The proven reduction construction, unlike those test enumerations, requires no source-fiber enumeration or oracle.
