# Union-support normalization for explicit binary perfect-matching fibers

19 October 2026. Local mathematical construction. No repository, PR, release, or remote state is changed.

## 1. Main theorem

Let **EXTRA** have input a simple bipartite graph H=(A,B,E), a binary edge coloring c, an integer t, and a nonempty explicit family F of distinct t-red perfect matchings. The question is whether another t-red perfect matching exists outside F. Let **UNION-EXTRA** be the same question with the additional promise H=union(F). Write **COMP** and **UNION-COMP** for the corresponding completeness questions.

**Normalization theorem.** There is a deterministic polynomial-time many-one reduction from EXTRA to UNION-EXTRA, and the same map reduces COMP to UNION-COMP. More precisely, if H has n vertices on either side, m edges, and f listed matchings, the reduction constructs a simple binary-colored bipartite graph G, a target K, and an explicit family F' such that

* G=union(F');
* F' consists of m+f+1 distinct valid K-red perfect matchings;
* every outside member of the source t-fiber corresponds bijectively to an outside member of the target K-fiber;
* G has O(m n^2+n^3) vertices and edges, after harmless padding to n>=2.

Equivalently, the target fiber size is the source fiber size plus m+1. The reduction does not enumerate the source fiber or test whether any additional source solution exists.

Combining this with the established known-singleton construction in `../exact-fiber-reductions-20261019/PROOF.md` yields a deterministic polynomial-time many-one reduction from arbitrary bipartite Exact Matching to UNION-EXTRA. It also reduces the complement of bipartite Exact Matching to UNION-COMP. The usual prefix-departure exact-count queries give the reverse deterministic polynomial-time Turing reduction. Thus deterministic polynomial-time union-support completeness verification is equivalent, under polynomial-time Turing reductions, to deterministic polynomial-time bipartite Exact Matching.

This is an algorithmic equivalence. It is not a claim that bipartite Exact Matching is NP-hard, that P=NP or P!=NP, or that binary-fiber synthesis is hard.

## 2. Input normalization and constants

Validate the supplied list, remove duplicates if the chosen input convention allows them, and choose one D in F. The theorem concerns well-formed inputs, so D is a known perfect matching of red count t. Consequently 0<=t<=n.

Append forced blue edges and extend all listed matchings if necessary to make n>=2. This preserves the source fiber and all outside-member questions. From now on n and m refer to this padded source graph.

Set

    B = n+1,
    C = (n+1)^2,
    K = Cn+t.

For an edge e define

    delta(e) = 0 if e is in D, and 1 otherwise,
    b(e) = c(e)+B delta(e).

There are at most four distinct values b(e), from {0,1,B,B+1}. The useful bounds are

    0 <= b(e) <= B+1 < C,
    (B+1)(n-1) = C-(n+3),
    0 < K-C-b(e) < K.

For the last inequality, the lower bound is at least C(n-1)-(B+1)>0 because n>=2; the upper bound is immediate from C+b(e)>0.

## 3. A binary path implementing a polynomial-sized integer cost

For an integer u>=0, set q=max(2,u). Replace an edge between opposite-partition terminals by an internally vertex-disjoint path of length 2q-1. Color exactly u odd-position edges red; color all other edges blue.

Every perfect matching of a larger graph containing this path has exactly one of these two states:

* Selected: it takes every odd-position edge, covers both terminals, and contributes red count u.
* Unselected: it takes every even-position edge, covers neither terminal, and contributes red count zero.

These alternatives follow by propagating the forced choices from the first internal vertex. A state covering exactly one terminal is impossible. There are q-1 new vertices on each side, and 2q-1 edges. The gadget works also for u=0 and u=1. All paths used below have polynomially bounded u; no binary-encoded exponential weight is expanded.

We first describe the construction as a weighted graph and then replace all weighted edges by these binary paths. A direct blue edge of cost zero may instead be retained when specified. The path-state correspondence is bijective and introduces no multiplicity.

## 4. The doubled core

Index A={a_1,...,a_n} and B={b_1,...,b_n}. Create backup vertices alpha_j on the left, indexed by b_j, and beta_i on the right, indexed by a_i. For every source edge e=a_i b_j create

* a forward path from a_i to b_j implementing cost C+c(e);
* a mirror path from alpha_j to beta_i implementing cost B delta(e).

Add the direct blue spokes a_i beta_i for every i and alpha_j b_j for every j.

All path interiors are disjoint, and their lengths are at least three. The core is simple and bipartite. Forward paths, mirror paths, and spokes use different endpoint blocks.

### Exact classification of core matchings

For a core perfect matching, let P be its selected forward source edges and let Q be its selected mirror source edges, with the mirror orientation suppressed. Let U be the set of a-indices met by P and V the set of b-indices met by P. Then:

1. P is a matching between U and V.
2. A spoke a_i beta_i is selected exactly when i is outside U; a spoke alpha_j b_j is selected exactly when j is outside V.
3. Q is a matching between exactly the same endpoint sets U and V.

Conversely every such pair (P,Q) uniquely determines a core perfect matching. In particular |P|=|Q|=p for some 0<=p<=n. Put

    r = sum_(e in P) c(e),
    d = |Q minus D|.

Its red count is exactly

    Cp+Bd+r,              0<=r,d<=p<=n.                 (1)

For p=0, there is a unique core matching, using every spoke and every unselected path state. Its cost is zero.

For p=1, P={e} and Q={e} for a unique source edge e. Indeed both matchings must connect the same single pair of endpoints, and H is simple. Its cost is C+b(e).

### Full target states

A core matching has red count K if and only if p=n, P is a source t-red perfect matching, and Q=D.

To prove this, if p<=n-1 then

    Cp+Bd+r <= (C+B+1)(n-1)
              = Cn-(n+3) < K.

If p=n, equation (1) equals K exactly when Bd+r=t. Since t<=n<B and d,r>=0, this forces d=0 and r=t. A full mirror matching with d=0 uses only edges of D, and hence is exactly D. The converse follows from (1).

Thus full target core matchings are already in bijection with the source target fiber, including the explicitly known lift of D. Intermediate core matchings may exist in large numbers, but no enumeration of them is used.

## 5. A selector whose every state is explicitly covered

Let

    S = {0,K} union {K-C-b(e): e in E},

with duplicate values removed. Because the singleton offsets lie strictly between 0 and K, S contains at most six and at least three distinct values.

Construct a separate bipartite multi-theta graph with terminals s on the left and z on the right. For each h in S, put an internally vertex-disjoint odd path between s and z that implements cost h by Section 3. Every branch has length at least three, so the graph is simple.

A selector perfect matching chooses exactly one branch in its selected state, and every other branch in its unselected state. Hence there is exactly one selector perfect matching of cost h for each h in S. The argument uses the two-state path property: any selected branch covers both terminals, and exactly one branch must do so.

Every edge in a branch's odd state is covered when that branch is selected, and every edge in its even state is covered when any other branch is selected. These facts will prove full edge coverage by the explicitly listed family.

Let G be the disjoint union of this selector and the doubled core, with binary coloring as already specified. Use target K.

## 6. Complete classification of the target fiber

Let h be the selected selector cost and let p,d,r describe the core.

### Selector cost K

The core must have cost zero. Since C>0 and all costs are nonnegative, this forces p=0. There is exactly one such target matching, called E_0.

### Selector cost K-C-b_0 for a present category b_0

The core must have cost C+b_0. If p=0 its cost is zero, too small. If p>=2 its cost is at least 2C>C+B+1>=C+b_0. Hence p=1.

By the classification in Section 4, the core therefore consists of the singleton pair P=Q={e}, and its cost is C+b(e). Equality holds exactly when b(e)=b_0. Each source edge e yields exactly one such target matching, called E_e: use its singleton core and the selector branch K-C-b(e).

### Selector cost zero

The core must have cost K. Section 4 shows that these target matchings are in bijection with source t-red perfect matchings M: select forward M, select mirror D, use no spokes, and select the zero selector branch. Call the resulting matching L_M.

These cases are disjoint and exhaustive. Thus the entire target fiber is

    {E_0} union {E_e: e in E} union {L_M: M in PM(H), c(M)=t}.   (2)

Because n>=2, the empty, singleton, and full core classes cannot overlap. Distinct source edges give distinct singleton matchings; distinct source perfect matchings give distinct full matchings. Therefore

    |target fiber| = 1+m+|source fiber|.                         (3)

## 7. The explicit family and full union-support promise

Output

    F' = {E_0} union {E_e: e in E} union {L_M: M in F}.

This has exactly 1+m+f distinct K-red perfect matchings, all constructible directly from the input.

Every edge of G belongs to one of these explicitly listed matchings:

* Every spoke is in E_0.
* The even-position edges of every forward and mirror path are in E_0.
* For each source edge e, the odd-position edges of both its forward path and its mirror path are in E_e.
* The selector branch of cost K is selected in E_0.
* Each selector singleton-offset branch is selected in at least one E_e, by the definition of S using only categories actually present in E.
* The selector branch of cost zero is selected in L_D, and D belongs to F.
* Each selector branch's even-position edges occur when any other branch is selected. There are at least three branches, and all branch selections have just been exhibited among F'.

There are no other edges, so G=union(F') exactly. This coverage argument does not require the source graph to be matching-covered and does not require any original edge to extend to a full source matching. The singleton pair for every source edge exists regardless.

By (2), the unlisted target matchings are exactly L_M for source target matchings M outside F. Mapping M to L_M and reading the selected forward paths to recover M are inverse polynomial-time transformations. This proves both promised many-one reductions.

## 8. Size, time, and bit bounds

The largest forward weight is C+1=O(n^2); the largest mirror weight is B=O(n); the largest selector weight is K=O(n^3). There are m forward paths, m mirror paths, 2n direct spokes, and at most six selector branches.

More explicitly, write q(u)=max(2,u). The core has

    2n + sum_(e in E) [q(C+c(e))-1 + q(B delta(e))-1]

vertices on either side. The selector has

    1 + sum_(h in S) [q(h)-1]

vertices on either side. The total is O(m n^2+n^3). Its number of edges has the same bound. The output target K has O(log(n+1)) bits, despite the unary paths implementing it.

The family is fully explicit, with (m+f+1) matchings, each containing one edge per output left vertex. In ordinary vertex-index encoding its length is

    O((m+f+1)(m n^2+n^3) log(m n^2+n^3+2)).

Constructing the graph, coloring, target, and every listed matching takes time polynomial in the full source input length, including the original f explicitly listed matchings. No source perfect-matching oracle, exhaustive permutation loop, hidden enumeration, or large-radix exponential expansion is required.

## 9. Composition with arbitrary bipartite Exact Matching

The prior known-singleton construction maps any nontrivial bipartite Exact Matching instance (J,c,k) to a binary-colored H with an explicitly known target matching D such that its target fiber consists of D plus one uniquely lifted matching for each k-red perfect matching of J. It has size O(n_0 m_0+n_0^2) and uses unary costs bounded polynomially in n_0.

Apply this normalization with F={D}. Equations (2) and (3) show that the output union-support fiber consists of m+2 explicitly listed matchings plus one additional matching for each original BEM solution. Thus arbitrary BEM reduces many-one to UNION-EXTRA with a polynomial-size, nonempty, edge-covering explicit family.

Degenerate BEM inputs may also be handled directly. A fixed complete union-support instance is one blue edge with its sole matching listed. A fixed incomplete union-support instance is three disjoint blue K2,2 blocks, target zero, and the two matchings selecting all first local choices and all second local choices: these two matchings cover every edge, while six additional target matchings exist. These fixed instances handle immediately decidable exceptional yes/no inputs without violating the union promise.

For the converse reduction, order the left vertices and build the prefix trie of the explicit family. Every outside matching first departs at a missing child. There are O(f' N'^2) candidate departure prefixes, where N' is the output side size. Fix each valid prefix, delete its endpoints, and query bipartite Exact Matching for the remaining red count. An outside matching exists exactly when at least one residual exact-count query is affirmative. This procedure is polynomial in the full explicit union-support input and does not require the union promise.

## 10. Consequences and scope limits

1. The union-of-listed-matchings promise does not remove the general bipartite Exact Matching obstacle for verifying a supplied binary coloring. It can be enforced by a deterministic polynomial-size normalization.
2. The normalization uses a polynomial-size explicit family and covers every gadget edge, including selector and unselected-path edges. It does not rely on a succinct family or trust an unverified complete enumeration.
3. General fixed-color verification under this promise has a deterministic polynomial-time algorithm if and only if bipartite Exact Matching does. The reverse direction here is a Turing reduction; no two-way many-one equivalence is claimed.
4. A single listed matching under the union promise is indeed trivial. The construction uses m+f+1 listed matchings, so it does not contradict that observation.
5. This result concerns verification of a supplied binary coloring, not existence or synthesis of some binary coloring for the family. It does not establish an NP-hardness or P-versus-NP conclusion.

Finite enumerations accompanying this proof are independent corroboration of the construction. They do not replace the exhaustive symbolic classification above.

## 11. Validation receipt

Both normal and optimized runs of `check_core.py` passed: 15,688 colored source supports, 35,064 distinguished-match choices, 7,047,712 core/selector states, and 70,992 explicit-family checks. Independent actual binary-graph enumeration also passed normal and optimized runs, covering 132 expanded graphs and 22,789 actual perfect matchings. The constructive worker replayed that independent checker and obtained the same substantive counts. See `VALIDATION.md` and the separate audit for the precise finite scope; these tests are corroboration, while Sections 2–8 prove the normalization for every well-formed input.
