#!/usr/bin/env python3
"""Exhaustive finite corroboration of the doubled-core normalization.

Enumerates source graphs, colors, partial-match pairs, and selector states.
The graph path-expansion is independently tested by the audit checker.
No dependencies, network operations, or source-fiber oracle assumptions.
"""
from collections import defaultdict
from itertools import permutations, product
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def partial_matchings(n, edges):
    adjacency = [[j for j in range(n) if (i,j) in edges] for i in range(n)]
    out=[]
    def visit(i, cols, chosen):
        if i==n:
            out.append(tuple(chosen))
            return
        visit(i+1, cols, chosen)
        for j in adjacency[i]:
            if j not in cols:
                chosen.append((i,j))
                visit(i+1, cols | {j}, chosen)
                chosen.pop()
    visit(0, set(), [])
    return out


def check_instance(n, colors, D, partials, full):
    E=set(colors)
    ds=set(D)
    t=sum(colors[e] for e in D)
    B=n+1; C=(n+1)**2; K=C*n+t
    b={e:colors[e]+B*(e not in ds) for e in E}
    S={0,K}|{K-C-b[e] for e in E}
    require(all(0<K-C-b[e]<K for e in E), 'offset range')
    require(3<=len(S)<=6, 'selector cardinality')
    groups=defaultdict(list)
    for P in partials:
        groups[(tuple(i for i,j in P),tuple(sorted(j for i,j in P)))].append(P)
    actual=set()
    state_count=0
    for ps in groups.values():
        for P,Q in product(ps,repeat=2):
            p=len(P)
            d=sum(e not in ds for e in Q)
            r=sum(colors[e] for e in P)
            cost=C*p+B*d+r
            for h in S:
                state_count+=1
                if cost+h==K:
                    actual.add((P,Q,h))
    fiber={P for P in full if sum(colors[e] for e in P)==t}
    empty=((),(),K)
    singles={((e,),(e,),K-C-b[e]) for e in E}
    lifts={(P,D,0) for P in fiber}
    expected={empty}|singles|lifts
    require(actual==expected, ('fiber classification',n,colors,D,actual^expected))
    require(len(actual)==1+len(E)+len(fiber),'count identity')
    listed={empty}|singles|{(D,D,0)}
    require(len(listed)==len(E)+2,'listed size')
    require(listed<=actual,'listed validity')
    require({h for P,Q,h in listed}==S,'selector coverage')
    require(set().union(*(set(P) for P,Q,h in listed))==E,'forward selected coverage')
    require(set().union(*(set(Q) for P,Q,h in listed))==E,'mirror selected coverage')
    require(any(not P and not Q for P,Q,h in listed),'spokes and unselected coverage')
    require(len(S)>=2,'selector unselected coverage')
    # Verify the general-F statement for every nonempty subfamily, using this D.
    others=sorted(fiber-{D})
    family_count=0
    for bits in product((0,1),repeat=len(others)):
        F={D}|{M for M,z in zip(others,bits) if z}
        FF={empty}|singles|{(P,D,0) for P in F}
        require(len(FF)==len(E)+len(F)+1,'general family size')
        require((actual-FF)=={(P,D,0) for P in fiber-F},'outside bijection')
        require((not(actual-FF))==(fiber==F),'completeness')
        family_count+=1
    return state_count,family_count


def main():
    stats={'source_colored_supports':0,'known_matchings':0,'selector_core_state_checks':0,
           'explicit_family_checks':0,'max_source_n':3}
    for n in (2,3):
        all_edges=[(i,j) for i in range(n) for j in range(n)]
        perms=[tuple(enumerate(p)) for p in permutations(range(n))]
        for trits in product((0,1,2),repeat=n*n):
            colors={e:z-1 for e,z in zip(all_edges,trits) if z}
            full=[P for P in perms if all(e in colors for e in P)]
            if not full:
                continue
            stats['source_colored_supports']+=1
            partials=partial_matchings(n,set(colors))
            for D in full:
                states,families=check_instance(n,colors,D,partials,full)
                stats['known_matchings']+=1
                stats['selector_core_state_checks']+=states
                stats['explicit_family_checks']+=families
    output=Path(__file__).with_name('core-results.json')
    output.write_text(json.dumps(stats,indent=2)+'\n')
    print(json.dumps(stats,sort_keys=True))

if __name__=='__main__':
    main()
