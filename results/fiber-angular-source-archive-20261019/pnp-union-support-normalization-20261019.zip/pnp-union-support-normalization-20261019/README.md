# Union-support normalization for explicit fixed-color fibers

Local-only, audited source package, 19 October 2026. No publication or repository action is part of this archive.

## Result and limits

Given a nonempty explicit family F of target matchings in a supplied binary-colored graph H with n vertices per side and m edges, the exact construction produces a simple binary-colored graph G and an explicit family F' of size m+|F|+1. Every edge of G belongs to F'. Outside target matchings correspond bijectively to outside source matchings. The binary path-expanded graph has O(m n^2+n^3) vertices and edges after harmless padding to n>=2.

The main proof covers all core, selector and path edges, polynomial numerical weights, all target-state cases, and the full explicit-list encoding size. It composes with the previously proved known-singleton reduction, whose unchanged proof is the sole prior dependency included here. No earlier archive is duplicated.

The resulting equivalence concerns verification of a supplied fixed coloring under the union-support promise. The forward reduction from bipartite Exact Matching is many-one; the converse is a polynomial-time Turing reduction. It does not establish two-way many-one equivalence, binary-color synthesis hardness, NP-hardness or a P-versus-NP conclusion.

Read union-support-verifier-20261019/PROOF.md and union-support-verifier-audit-20261019/AUDIT.md. The sibling exact-fiber-reductions-20261019/PROOF.md supplies the cited prior construction; its old checker suite is not duplicated or represented as newly rerun.

## Reproduce

Requirements: Python 3.10+ standard library only. No network, source repository, credentials or third-party packages are used.

    python verify_sources.py
    python -O verify_sources.py

Both commands verify package hashes, replay the exhaustive n<=3 weighted-state corroboration, and independently enumerate the actual binary path-expanded graphs. The latter test exhausts 2x2 absent/blue/red sources with every known matching, then adds deterministic dense and sparse 3x3 cases. Both validate every explicit source subfamily containing the known matching. These finite tests corroborate the universal symbolic proof; they are not asserted to exhaust all graph sizes.

Every Python validation uses explicit exceptions and remains active under -O. Integrity is checked before and after reproduction. Timing in the historical actual-graph receipt is informational and excluded from census equality. The manifest records the exact input hashes; SHA256SUMS covers every other file. ZIP entries have sorted paths, a fixed timestamp and fixed mode. Executables, caches, exploration logs, large tables and previous archive bundles are excluded.

This package is separate from the frozen proposed release batch pinned to PNP 3d05653738017c99027bf1aee3249e96a91a3cf7 and YM f3cfb6a42b83ba30544a3e43d4061739b6e084ca.
