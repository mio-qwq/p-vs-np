# Independent audit receipt: union-support normalization

Date: 19 October 2026.

Status: accepted within the scope below. No material mathematical or implementation defect found.

## Accepted universal result

A deterministic polynomial-time, outside-fiber-bijective transformation takes any nonempty explicit family F of equal-red-count perfect matchings in a simple bipartite graph H to an explicit family F' in a simple binary-colored bipartite graph G such that G is exactly the union of F'. With m source edges and f listed matchings, |F'|=m+f+1, and the new target fiber is the old target fiber plus exactly m+1 explicitly known dummies.

The construction has O(mn^2+n^3) vertices and edges after padding to n>=2. All binary path expansions, auxiliary selector states, list-generation time, and integer bit bounds are polynomial. Coverage includes every internal path edge, every selector edge, and all spokes. The mirror penalty prevents unintended full-mode completions.

Composing this result with the prior known-singleton Exact Matching reduction establishes a polynomial-time many-one reduction from bipartite Exact Matching to incompleteness under the union-support promise. A polynomial-time Turing reduction in the reverse direction follows from the prefix-departure construction. Therefore deterministic polynomial-time union-support fixed-color verification exists exactly when deterministic polynomial-time bipartite Exact Matching exists.

## Reviewed proof and executable checks

1. `../union-support-verifier-20261019/PROOF.md`: read in full; accepted.
2. `../union-support-verifier-20261019/check_core.py`: read in full; independently replayed successfully.
3. `AUDIT.md`: independent derivation, coverage audit, size/bit analysis, reduction consequence, and limitations.
4. `check_expanded.py`: independent actual-binary-graph construction and generic perfect-matching enumeration. No gadget-state shortcut is used to enumerate the actual output graph.

The actual-graph checker passes both ordinary and optimized Python, with the same substantive results: 132 expanded graphs, 22,789 actual perfect matchings, 1,063 actual target matchings, and 347 source subfamilies. This includes every 2x2 absent/blue/red source and known D (72 reductions), plus 60 dense/sparse 3x3 cases. Largest checked graph: 341 vertices per side and 698 edges.

The independently replayed structural checker passes 15,688 colored supports, 35,064 known-D cases, 7,047,712 core-selector states, and 70,992 explicit families. It covers all n=2,3 absent/blue/red source assignments and known D, with every compatible core partial-pair and selector state. Both programs use explicit checks, so Python -O does not remove them.

Saved independent run outputs:

* `expanded-results.json`
* `expanded-results-optimized.json`
* `replayed-core-results.json`

The expanded-run JSON includes wall-clock seconds, which differ between runs; all mathematical count fields match.

## Scope and limitations

The theorem is for completeness verification of a supplied binary coloring and an explicitly listed nonempty family. It is not a binary-color synthesis hardness theorem, an NP-hardness claim, a P-versus-NP separation, a deterministic solution of Exact Matching, or a two-way many-one equivalence. It does not import succinct-list hardness into explicit-list inputs. The known-singleton source reduction and the new normalization are separate, both needed for the union-support conclusion.

The finite checks corroborate the universal proof. Actual expanded-graph enumeration is exhaustive for n=2 sources and sampled at n=3; structural-state enumeration is exhaustive through n=3.

All actions were local reads, local proof/checker writes, and runs of the supplied local scripts. No remote writes, repository edits, PR operations, merges, tags, releases, or publication were performed.
