#!/usr/bin/env python3
"""Independent enumeration of the actual binary path-expanded reduction graphs.

No third-party packages. Assertions are deliberately not used, so -O repeats
every check. This corroborates, and does not replace, the universal proof.
"""
from collections import Counter
from itertools import permutations, product
import json
import random
import sys
import time


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


class Graph:
    def __init__(self):
        self.left = 0
        self.right = 0
        self.edges = []
        self.pairs = set()

    def vertex(self, side):
        if side == 0:
            v = (0, self.left)
            self.left += 1
        else:
            v = (1, self.right)
            self.right += 1
        return v

    def edge(self, x, y, red):
        if x[0] == 1:
            x, y = y, x
        require(x[0] == 0 and y[0] == 1, 'nonbipartite edge')
        pair = (x[1], y[1])
        require(pair not in self.pairs, 'parallel edge')
        require(red in (0, 1), 'nonbinary edge color')
        self.pairs.add(pair)
        e = len(self.edges)
        self.edges.append((x[1], y[1], red))
        return e

    def path(self, x, y, weight):
        require(x[0] == 0 and y[0] == 1, 'path endpoints')
        q = max(2, weight)
        vertices = [x]
        for j in range(1, 2*q-1):
            vertices.append(self.vertex(j % 2))
        vertices.append(y)
        selected = []
        unselected = []
        for j in range(1, 2*q):
            red = int(j % 2 == 1 and (j+1)//2 <= weight)
            e = self.edge(vertices[j-1], vertices[j], red)
            (selected if j % 2 else unselected).append(e)
        return (tuple(selected), tuple(unselected))


def source_matchings(n, colors):
    return [tuple((i, p[i]) for i in range(n))
            for p in permutations(range(n))
            if all((i, p[i]) in colors for i in range(n))]


def construct(n, colors, D):
    require(n >= 2, 'small source must be padded first')
    require(set(D) <= set(colors), 'source D edge missing')
    g = Graph()
    A = [g.vertex(0) for _ in range(n)]
    Bv = [g.vertex(1) for _ in range(n)]
    Bprime = [g.vertex(0) for _ in range(n)]
    Aprime = [g.vertex(1) for _ in range(n)]
    base, penalty = (n+1)**2, n+1
    t = sum(colors[e] for e in D)
    target = base*n+t
    Dset = set(D)
    forward, mirror = {}, {}
    for e, red in sorted(colors.items()):
        i, j = e
        forward[e] = g.path(A[i], Bv[j], base+red)
        mirror[e] = g.path(Bprime[j], Aprime[i], penalty*int(e not in Dset))
    spokes_a = [g.edge(A[i], Aprime[i], 0) for i in range(n)]
    spokes_b = [g.edge(Bprime[j], Bv[j], 0) for j in range(n)]
    u, v = g.vertex(0), g.vertex(1)
    category = {e: base+red+penalty*int(e not in Dset)
                for e, red in colors.items()}
    weights = sorted({0, target} | {target-a for a in category.values()})
    selector = {s: g.path(u, v, s) for s in weights}

    def matching(P, Q, selector_weight):
        P, Q = set(P), set(Q)
        used_a = {i for i, _ in P}
        used_b = {j for _, j in P}
        require(used_a == {i for i, _ in Q}, 'mismatched selected A')
        require(used_b == {j for _, j in Q}, 'mismatched selected B')
        out = []
        for e in colors:
            out.extend(forward[e][0 if e in P else 1])
            out.extend(mirror[e][0 if e in Q else 1])
        out.extend(spokes_a[i] for i in range(n) if i not in used_a)
        out.extend(spokes_b[j] for j in range(n) if j not in used_b)
        for s, path in selector.items():
            out.extend(path[0 if s == selector_weight else 1])
        return frozenset(out)

    empty = matching([], [], target)
    singletons = [matching([e], [e], target-category[e]) for e in colors]
    lift = lambda M: matching(M, D, 0)
    listed = [empty] + singletons + [lift(D)]
    require(len(set(listed)) == len(colors)+2, 'duplicate list entries')
    for M in listed:
        verify_matching(g, M, target)
    require(set().union(*listed) == set(range(len(g.edges))), 'union support fails')
    require(len(weights) <= 6, 'too many selector states')
    return g, target, set(listed), set([empty] + singletons), lift


def verify_matching(g, M, target):
    require(g.left == g.right, 'unbalanced graph')
    require(len(M) == g.left, 'matching wrong cardinality')
    left = [g.edges[e][0] for e in M]
    right = [g.edges[e][1] for e in M]
    require(len(set(left)) == g.left, 'left endpoint repeated or missing')
    require(len(set(right)) == g.right, 'right endpoint repeated or missing')
    require(sum(g.edges[e][2] for e in M) == target, 'matching wrong target')


def enumerate_actual_graph(g):
    """Generic exact matching enumeration; knows no gadget/path semantics."""
    adj = [0] * g.left
    edge_at = {}
    for e, (i, j, red) in enumerate(g.edges):
        adj[i] |= 1 << j
        edge_at[i, j] = (e, red)
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 4*g.left+100))

    def rec(rows, cols, chosen, cost):
        chosen = list(chosen)
        while rows:
            best_i, best_options, best_degree = -1, 0, g.right+1
            todo = rows
            while todo:
                bit = todo & -todo
                i = bit.bit_length()-1
                todo -= bit
                options = adj[i] & cols
                degree = options.bit_count()
                if degree == 0:
                    return
                if degree < best_degree:
                    best_i, best_options, best_degree = i, options, degree
                if degree == 1:
                    break
            rows &= ~(1 << best_i)
            if best_degree != 1:
                break
            bit = best_options & -best_options
            j = bit.bit_length()-1
            e, red = edge_at[best_i, j]
            cols &= ~bit
            chosen.append(e)
            cost += red
        else:
            yield frozenset(chosen), cost
            return
        while best_options:
            bit = best_options & -best_options
            best_options -= bit
            j = bit.bit_length()-1
            e, red = edge_at[best_i, j]
            yield from rec(rows, cols & ~bit, chosen+[e], cost+red)

    yield from rec((1 << g.left)-1, (1 << g.right)-1, [], 0)


def check_case(n, colors, D, counters):
    actual_source = source_matchings(n, colors)
    target_source = sum(colors[e] for e in D)
    source_fiber = [M for M in actual_source
                    if sum(colors[e] for e in M) == target_source]
    g, target, listed, dummy, lift = construct(n, colors, D)
    expected = dummy | {lift(M) for M in source_fiber}
    actual = set()
    total = 0
    for M, cost in enumerate_actual_graph(g):
        total += 1
        if cost == target:
            require(M not in actual, 'enumerator duplicate')
            actual.add(M)
    require(actual == expected, 'actual target fiber differs from claimed classification')
    require(len(actual) == len(colors)+1+len(source_fiber), 'count shift fails')
    require(len(actual-listed) == len(source_fiber)-1, 'singleton outside count fails')
    # Every choice of source F containing D has exactly the corresponding extras.
    others = [M for M in source_fiber if M != D]
    for flags in product((False, True), repeat=len(others)):
        F = [D]+[M for M, flag in zip(others, flags) if flag]
        listed_F = dummy | {lift(M) for M in F}
        require(len(actual-listed_F) == len(source_fiber)-len(F), 'general-list count fails')
        require(set().union(*listed_F) == set(range(len(g.edges))), 'general-list support fails')
        counters['source_lists'] += 1
    counters['expanded_graphs'] += 1
    counters['actual_matchings_enumerated'] += total
    counters['actual_target_matchings'] += len(actual)
    counters['max_side_vertices'] = max(counters['max_side_vertices'], g.left)
    counters['max_graph_edges'] = max(counters['max_graph_edges'], len(g.edges))


def main():
    start = time.time()
    counters = Counter()
    # Exhaustive: each 2x2 position is absent, blue, or red; every source D.
    n = 2
    positions = list(product(range(n), repeat=2))
    for ternary in product((-1, 0, 1), repeat=n*n):
        colors = {e: c for e, c in zip(positions, ternary) if c >= 0}
        for D in source_matchings(n, colors):
            check_case(n, colors, D, counters)
    counters['exhaustive_2x2_graphs'] = counters['expanded_graphs']
    # Dense 3x3 sources: all-blue, all-red, diagonal, checkerboard, and seeded
    # random colors, exercising every possible target value and up to 6 fibers.
    n = 3
    positions = list(product(range(n), repeat=2))
    patterns = [dict.fromkeys(positions, 0), dict.fromkeys(positions, 1),
                {e: int(e[0] == e[1]) for e in positions},
                {e: (e[0]+e[1]) % 2 for e in positions}]
    rng = random.Random(20261019)
    for _ in range(16):
        patterns.append({e: rng.randrange(2) for e in positions})
    for colors in patterns:
        Ds = source_matchings(n, colors)
        for D in (Ds[0], Ds[-1]):
            check_case(n, colors, D, counters)
    # Sparse 3x3 sources with a known diagonal and arbitrary additional edges.
    for _ in range(20):
        colors = {e: rng.randrange(2) for e in positions
                  if e[0] == e[1] or rng.randrange(2)}
        D = tuple((i, i) for i in range(n))
        check_case(n, colors, D, counters)
    output = dict(counters)
    output['seconds'] = round(time.time()-start, 3)
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
