# Independent audit: union-support does not remove the Exact Matching barrier

19 October 2026. Local mathematical audit. No repository, PR, merge, tag, release, or other remote state is changed.

## 1. Conclusion

The union-support promise admits a deterministic polynomial-time normalization from the unrestricted explicit-list completeness problem. Consequently the previously proved bipartite Exact Matching reduction can be followed by this normalization: the hardness does survive even when the supplied graph is exactly the union of a nonempty polynomial-size list of known target matchings.

This is a statement about algorithmic reductions. It is **not** a proof of NP-hardness, a complexity-class separation, or an unconditional impossibility of a deterministic polynomial-time algorithm.

The normalization below is independently derived and checked against the constructive worker's reduction. It takes a source graph with at least one explicitly known target matching. The previous singleton reduction supplies precisely that input without needing to solve the original Exact Matching instance.

## 2. Source, target, and claimed bijection

The source is a simple bipartite graph H=(A,B,E), with n vertices on each side, binary edge colors c, target t, and an explicit nonempty family F of distinct target perfect matchings. Choose D in F, and write m=|E| and f=|F|. Its target fiber is

    X_t = {M in PM(H): c(M)=t}.

If n<2, append disjoint forced blue edges until n=2 and append them to every listed matching. This preserves the target fiber bijectively and preserves t. Thus assume n>=2 throughout the construction.

We construct a simple binary-colored bipartite graph H', target K, and a known list F' such that:

1. Every member of F' is a valid target-K perfect matching.
2. The union of F' is exactly E(H').
3. There are exactly m+1 designated dummy target matchings, plus one uniquely determined lifted matching for each member of X_t.
4. F' consists of all m+1 dummies and the lifts of F. In particular |F'|=m+f+1 and

       |fiber_K(H') \ F'| = |X_t \ F|.

5. The graph, colors, target and list are generated in deterministic polynomial time without enumerating X_t or solving any Exact Matching instance.

For the singleton source F={D}, the target list has m+2 entries.

## 3. Weighted core and its exact matching states

Initially describe integer edge weights, then replace them by binary path gadgets. Put

    b=n+1,    C=(n+1)^2,    K=Cn+t.

Since D is a valid source matching, 0<=t<=n.

Take four vertex sets A, B, A', B'. Use left side A union B' and right side B union A'. For every source edge e=(a_i,b_j), add:

* a forward edge a_i b_j of weight C+c(e);
* a mirror edge b'_j a'_i of weight b times 1[e not in D].

Add weight-zero spokes a_i a'_i and b'_j b_j for every i and j.

Every core perfect matching corresponds uniquely to two source partial matchings P and Q having exactly the same selected A-vertices and exactly the same selected B-vertices. P is represented by forward edges and Q by mirror edges. Unselected vertices must use their respective spokes. Conversely any such pair determines one core perfect matching.

In particular |P|=|Q|=p. Define r=sum_(e in P)c(e) and d=|Q\D|. The core cost is exactly

    Cp+bd+r,    with 0<=d<=p, 0<=r<=p, and 0<=p<=n.

For p=0 there is one state: all spokes. For p=1, equal selected endpoint sets and source simplicity force P=Q={e} for a unique source edge e. Its cost is

    a_e=C+c(e)+b times 1[e not in D].

There are at most four distinct values a_e. They identify their pairs (c(e),1[e not in D]) uniquely because b>=3.

For p=n, P and Q are full source perfect matchings. Having core cost K is equivalent to bd+r=t. Since b=n+1>t and d,r are nonnegative, this forces d=0 and r=t. A full matching Q contained in D is exactly D. Thus full cost-K states are in bijection with source target matchings P, with the mirror state uniquely fixed to D.

The mirror penalty is essential. Leaving all mirror edges unweighted would create arbitrary mirror completions in full mode, including many extra target matchings even if the source target fiber were just {D}.

## 4. Selector and complete target classification

The selector has one state of each of the following costs, with duplicate middle costs removed:

    K;    K-a_e for each distinct present value a_e;    0.

There are at most six states. All middle costs are strictly between zero and K. Indeed for n>=2,

    max_e a_e <= C+b+1 < 2C <= Cn <= K.

The final graph is the disjoint union of the core and selector, and its target is K.

The two necessary inequalities are:

    max_e a_e <= C+b+1 < 2C,

and, whenever p<=n-1,

    Cp+bd+r <= (C+b+1)(n-1)
              = Cn-(n+3)
              < Cn <= K.

These give an exhaustive classification by selector state:

* Selector K requires core cost zero. Every p>0 contributes at least C, so p=0. This yields one empty dummy.
* Selector K-a requires core cost a. Since a>0 and a<2C, necessarily p=1. The core is the unique singleton state associated with some edge e with a_e=a. Each e yields exactly one singleton dummy. Deduplicating category selector states creates no extra multiplicity.
* Selector zero requires core cost K. The second inequality forces p=n. As proved above, these are exactly P in X_t paired with Q=D, with one lift per P.

No intermediate partial matching can contribute an unlisted target matching. No assumptions about which source edges participate in full source perfect matchings are used.

## 5. Binary, simple, polynomial-size realization

For any nonnegative integer weight w, choose q=max(2,w), and replace an edge between opposite-side old vertices by a fresh odd path of length 2q-1. Its internal vertices are new and have degree two. The path has exactly two possible local states in any ambient perfect matching:

* selected: all q odd-positioned edges, covering both old endpoints;
* unselected: all q-1 even-positioned edges, covering neither old endpoint.

Color exactly w of the odd-positioned edges red, and all other edges blue. The two states then have costs w and zero. This works also for w=0 or w=1, for which q=2. Every local choice is unique. Covering exactly one old endpoint is impossible by parity/forced alternation.

Expand all forward and mirror weighted edges in this way, keeping the zero-cost spokes as direct blue edges. All paths use disjoint internal vertices, so the graph remains simple and bipartite.

To build the selector, use fresh opposite-side terminals u,v and one such odd path for each desired selector cost. A perfect matching chooses the selected state on exactly one branch and the unselected state on every other branch. Hence its perfect matchings and costs are precisely the specified distinct selector states. Every branch has length at least three, so no parallel edge is introduced, including the zero-cost branch.

The largest forward weight is C+1=O(n^2), the largest mirror weight is b=O(n), and each selector branch has cost at most K=O(n^3). There are m forward paths, m mirror paths, 2n spokes, and at most six selector paths. Thus each side has O(mn^2+n^3) vertices and the graph has O(mn^2+n^3) edges. The target K is O(n^3) and has O(log n) bits. All weights used before expansion also have O(log n) bits and polynomial numerical magnitude.

The output list has m+f+1 matchings, each explicitly written with one edge per left-side vertex. Its total size and generation time are O((m+f+1)(mn^2+n^3)), up to ordinary encoding/logarithmic factors. No exponential-value weight is disguised as a polynomial-size path, and no existence oracle is needed to generate the list.

## 6. Union-support audit, including internal path edges

The empty dummy selects all spokes and leaves every forward and mirror path unselected. For each source edge e, its singleton dummy selects both its forward and mirror path. Therefore:

* every spoke belongs to the empty dummy;
* every odd-positioned edge of each forward/mirror path belongs to its singleton dummy;
* every even-positioned edge of each forward/mirror path belongs to the empty dummy.

For the selector:

* its cost-K branch is selected by the empty dummy;
* each middle branch K-a is selected by at least one singleton dummy, because only categories actually present in E were included;
* its cost-zero branch is selected by the lifted known matching D.

Each selector branch is unselected in another listed matching. In particular the empty dummy and the lifted D choose distinct branches, so a listed alternative is always available. Thus both the selected and unselected path edges of every branch occur in the list.

Consequently every edge of the entire expanded graph occurs in F'. The reverse inclusion is automatic since list entries are graph matchings. This proves the exact union-support promise, not merely coverage of the weighted core edges or source edges.

## 7. Complexity consequence and its limits

The previous proof at `../exact-fiber-reductions-20261019/PROOF.md` maps a bipartite Exact Matching instance deterministically in polynomial time to a simple graph with one known matching D in its target fiber, such that every additional target matching corresponds to an original solution. That reduction alone did not satisfy union support.

Following it by the construction above gives a deterministic polynomial-time many-one reduction from bipartite Exact Matching to incomplete fixed-color explicit-list verification **under the exact union-support promise**, with a nonempty polynomial-size list. Complementing the output gives the corresponding reduction from complement-Exact-Matching to completeness.

The prefix-trie oracle reduction in the previous proof applies to every explicit-list instance, including union-support inputs. It gives a deterministic polynomial-time Turing reduction in the other direction. Therefore deterministic polynomial-time union-support fixed-color completeness verification exists if and only if deterministic polynomial-time bipartite Exact Matching exists.

The forward hardness is many-one. The reverse reduction is Turing; no two-way many-one equivalence is asserted. This is fixed-color verification, not binary-color synthesis. The argument does not establish NP-hardness, defeat randomized verification, or imply a P-versus-NP separation.

## 8. Independent finite check

`check_expanded.py` constructs the actual simple binary expanded graphs and explicitly generates the proposed list. It checks all list entries, their common red count, distinctness, and exact edge-union coverage. It then enumerates all perfect matchings of the actual graph using a generic bipartite backtracker that has no knowledge of the reduction's core, selector, or path semantics.

The checker compares the actual target fiber with the exact set of empty/singleton dummies and source-fiber lifts, checks the count shift, and tests every source subfamily containing D. Its exhaustive set covers every absent/blue/red assignment on the four positions of a 2x2 source and every available known D. Additional dense and sparse 3x3 instances cover larger target fibers and all four edge categories. Normal and optimized runs use the same explicit checks; Python assertions are not relied on.

Both `python check_expanded.py` and `python -O check_expanded.py` pass with identical substantive counts:

* 132 actual expanded graphs, including 72 exhaustive 2x2 reductions and 60 additional 3x3 reductions;
* 22,789 actual perfect matchings enumerated;
* 1,063 actual target matchings checked;
* 347 source subfamilies checked;
* maximum graph size 341 vertices on each side and 698 edges.

The independent constructive proof at `../union-support-verifier-20261019/PROOF.md` and its `check_core.py` were also reviewed in full. No material defect was found. Replaying that structural checker passed 15,688 colored source supports, 35,064 known-D cases, 7,047,712 core-selector state checks, and 70,992 explicit-family checks. That checker exhaustively covers all absent/blue/red source supports on n=2 and n=3, all their known D, all compatible partial matching pairs, and all selector states. It also uses explicit exceptions rather than assertions.

These finite checks corroborate the construction; the proofs above establish its universal scope. The actual expanded-graph enumeration is exhaustive only for n=2 sources, with selected n=3 examples; the structural checker is exhaustive through n=3. Neither finite bound is presented as the universal proof.
