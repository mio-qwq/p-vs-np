#!/usr/bin/env python3
"""Reproduce the source package with explicit checks, including under Python -O.

All arithmetic checks run locally. C++ builds and temporary output are discarded.
No network, repository, credentials, or third-party Python packages are used.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integrity():
    sums = {}
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        require(name not in sums, 'duplicate checksum path')
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,
                'unsafe checksum path')
        sums[name] = digest
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    require(actual == set(sums) | {'SHA256SUMS'}, 'missing or unexpected package files')
    for name, digest in sums.items():
        require(sha256(ROOT / name) == digest, 'integrity mismatch: ' + name)
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for entry in manifest['files']:
        path = ROOT / entry['path']
        require(path.stat().st_size == entry['bytes'], 'manifest size: ' + entry['path'])
        require(sha256(path) == entry['sha256'], 'manifest hash: ' + entry['path'])
    return manifest


def run(args, cwd):
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True,
                            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    require(result.returncode == 0,
            'command failed: ' + ' '.join(map(str,args)) + '\n' + result.stdout + result.stderr)
    require(not result.stderr, 'unexpected stderr: ' + result.stderr)
    return result.stdout


def main():
    manifest = integrity()
    config = json.loads((ROOT / 'VERIFY_EXPECTATIONS.json').read_text())
    receipt = {'package': manifest['package'], 'python_optimized': bool(sys.flags.optimize),
               'integrity_before': True, 'checks': []}
    py = [sys.executable] + (['-O'] if sys.flags.optimize else [])
    for check in config['python_checks']:
        output = run(py + [str(ROOT / check['path'])], ROOT)
        if 'json_expected' in check:
            actual = json.loads(output)
            for key in check.get('ignore_output_keys', []):
                actual.pop(key, None)
            require(actual == check['json_expected'], 'Python census mismatch: ' + check['path'])
        receipt['checks'].append({'path': check['path'], 'status': 'passed',
                                  'output': output.strip()})
    for check in config['cpp_checks']:
        with tempfile.TemporaryDirectory(prefix='binary-scope-cpp-') as temp:
            temp = Path(temp)
            exe = temp / 'checker'
            run(['g++', '-O3', '-DNDEBUG', '-std=c++17', str(ROOT / check['path']),
                 '-o', str(exe)], temp)
            output = run([str(exe)], temp)
            actual = json.loads(output)
            require(actual == check['json_expected'], 'C++ census mismatch: ' + check['path'])
            for generated, reference in check.get('compare_receipts', {}).items():
                observed = (temp / generated).read_text().splitlines()
                expected = (ROOT / reference).read_text().splitlines()
                require(sorted(observed) == sorted(expected), 'survivor receipt mismatch: ' + generated)
            for generated in check.get('empty_receipts', []):
                require((temp / generated).read_bytes() == b'', 'nonempty survivor output: ' + generated)
            receipt['checks'].append({'path': check['path'], 'status': 'passed',
                                      'compile_flags': ['-O3', '-DNDEBUG', '-std=c++17'],
                                      'census': actual})
    integrity()
    receipt['integrity_after'] = True
    receipt['status'] = 'all checks passed'
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
