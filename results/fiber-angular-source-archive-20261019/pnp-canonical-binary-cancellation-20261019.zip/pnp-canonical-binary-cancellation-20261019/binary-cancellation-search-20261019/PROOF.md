# The first canonical binary cancellation: eight terms at five rows

19 October 2026. Exact local mathematical certificate. No repository, pull request, merge, tag, release, or remote file was changed.

## Results and limits

For a permutation `p` of `{0,...,n-1}`, with `p(i)` the exponent selected in row `i`, write

    f_p(L) = sgn(p) product_{i=0}^{n-1} (L+i)^{p(i)}.

There is a nonempty **0/1 relation** at `n=5`:

    sum_{p in F} f_p(L) = 0,

where

    F = {03241, 04123, 04231, 04321,
         12340, 13240, 14230, 32140}.

Each displayed five-digit string is a permutation, not an integer. Every selected permutation occurs exactly once.

The principal conclusions are:

1. Arbitrary-subset noncancellation fails at the smallest canonical dimension, `n=5`. The previously proved canonical `n=3` and `n=4` exclusions, together with the elementary `n<=2` cases, establish the dimension claim.
2. Eight is the minimum number of selected terms in any nonempty binary relation at `n=5`. This is independently certified by a small exact finite subset-sum check, without relying on numerical optimization.
3. The relation extends to every canonical dimension `n>=5` by fixing the added rows and columns. It also extends to equally spaced offsets and consecutive exponents.
4. **This is not a binary-color-fiber counterexample.** The eight selected matchings cannot be a complete fiber of any real edge-additive cost on any graph containing them. A five-term integral affine identity proves this obstruction.
5. Its 15-edge union graph has exactly 12 perfect matchings. The eight-term set above is its only nonempty zero subset. None of its 787 distinct nonempty complete binary-color fibers cancels; more strongly, no nonempty complete real-cost fiber on this particular graph cancels.

These statements do not resolve binary sparse noncancellation in general dimension and do not establish a P-versus-NP assertion. “Smallest dimension” is restricted to the canonical offsets and consecutive exponent lists specified above. Minimum cardinality eight is asserted at `n=5`, not at every higher dimension.

## 1. A short exact polynomial proof

Every term in `F` has the common nonzero factor

    C(L) = (L+1)^2 (L+2) (L+3)^2.

After factoring out `C`, the eight signed terms are:

| Permutation | Sign | `f_p/C` |
|---|---:|---|
| 03241 | + | `(L+1)(L+2)(L+3)^2(L+4)` |
| 04123 | − | `−(L+1)^2(L+4)^3` |
| 04231 | − | `−(L+1)^2(L+2)(L+3)(L+4)` |
| 04321 | + | `(L+1)^2(L+2)^2(L+4)` |
| 12340 | + | `L(L+2)^2(L+3)^2` |
| 13240 | − | `−L(L+1)(L+2)(L+3)^2` |
| 14230 | + | `L(L+1)^2(L+2)(L+3)` |
| 32140 | − | `−L^3(L+3)^2` |

The first four entries sum to

    -2 L(L+1)(L+3)(L+4),

and the last four sum to

    +2 L(L+1)(L+3)(L+4).

Both identities follow by expansion or by extracting `(L+1)(L+4)` and `L(L+3)`, respectively. Therefore the eight original polynomials sum identically to zero.

An alternative certificate separates the four even and four odd permutations. Put `g_p=product_i(L+i)^{p(i)}`, without the parity sign. Then

    g_03241 + g_04321 + g_12340 + g_14230
      = g_04123 + g_04231 + g_13240 + g_32140
      = 4(L+1)^2(L+2)^2(L+3)^2
          (L^4+8L^3+23L^2+28L+11).

This is an ordinary exact polynomial identity. Its validity does not depend on a solver status, tolerance, or approximate equality.

## 2. Minimum dimension and minimum cardinality

### 2.1 Minimum canonical dimension

At `n=1` the only term is nonzero. At `n=2` either a single nonzero term is selected or both terms are selected; the latter signed sum is `(L+1)-L=1`.

The earlier three-row classification excludes every nonempty binary subset of the six canonical terms. The earlier four-row valuation proof excludes every nonempty binary subset of the 24 canonical terms, already using only coefficients of degrees zero through four. Consequently the relation above establishes that five is the first canonical dimension admitting any nonempty binary zero subset.

The dimension conclusion uses those prior exact theorems. The standalone checker here concerns the new five-row certificate and does not re-prove the prior four-row theorem.

### 2.2 Exact minimum-cardinality certificate at five rows

Every `f_p` has degree ten and leading coefficient `sgn(p)`. Hence a zero subset must contain equally many even and odd permutations. There are 60 of each parity. A nonempty zero subset with fewer than eight elements would therefore require an equality of unsigned polynomial subset sums with `k` terms on each side for `k=1,2,3`.

The verifier enumerates these small families using integer coefficient vectors after the invertible substitution `t=L+2`. It finds:

| Terms from each parity | Subsets on each side | Distinct vectors on each side | Cross-parity equalities |
|---:|---:|---:|---:|
| 1 | 60 | 60 | 0 |
| 2 | 1,770 | 1,770 | 0 |
| 3 | 34,220 | 34,220 | 0 |

Every choice of at most three distinct terms per parity is included. Vector equality checks all eleven coefficients and uses exact integers. Thus relations of cardinality two, four, or six do not exist. Odd cardinalities are already impossible from the leading coefficient. The exhibited eight-term relation attains the lower bound.

`results.json` includes these counts and SHA-256 hashes of the deterministically ordered vector sets. The checker recomputes the sets rather than treating a stored hash as evidence of exhaustion.

## 3. A structural family in every larger canonical dimension

For `n>=5`, extend each `p in F` to a permutation `p_hat` by

    p_hat(i)=p(i)  for 0<=i<=4,
    p_hat(i)=i     for 5<=i<=n-1.

The added fixed points introduce no inversions. Consequently

    f_p_hat(L) = f_p(L) product_{i=5}^{n-1}(L+i)^i.

The latter factor is common and nonzero, so summing the eight extended terms gives zero for every `n>=5`.

More generally, take equally spaced distinct offsets `a+hi`, with `h != 0`, and consecutive nonnegative integer exponents `q,...,q+n-1`, with `q>=0`. For `z=(L+a)/h`,

    sgn(p_hat) product_i (L+a+hi)^{q+p_hat(i)}
      = [product_i(L+a+hi)^q] h^{n(n-1)/2} f_p_hat(z).

Thus the same eight selected permutations give a binary zero relation in this affine family. This does not cover arbitrary unequal offset gaps or arbitrary nonconsecutive exponents.

## 4. Why this subset is not a complete matching fiber

Let `p_M` denote the 0/1 edge-incidence vector of matching `M`. The union graph of `F` has row neighborhoods

    row 0: {0,1,3}
    row 1: {2,3,4}
    row 2: {1,2,3}
    row 3: {2,3,4}
    row 4: {0,1,3}.

It contains 15 edges and exactly these 12 perfect matchings:

    02143, 02341, 03241, 04123, 04231, 04321,
    12340, 13240, 14230, 14320, 32140, 34120.

The matching `N=02143` lies outside `F` but uses only its union edges. There is the exact incidence identity

    p_02143 = p_03241 + p_04123 - p_04321
                            + p_12340 - p_13240.       (1)

Each coordinate of this identity is an integer equality; the coefficients on the right sum to one.

Suppose any real edge-cost vector `w` assigns the same total cost `t` to every matching in `F`. Taking the dot product of (1) with `w` forces

    w dot p_02143 = t+t-t+t-t = t.

Therefore `02143` belongs to the same cost fiber. It is impossible for that complete fiber to equal `F`.

Every graph containing all matchings of `F` necessarily contains every union edge and hence also `02143`. The obstruction therefore applies to every possible containing graph, rather than only the chosen union graph. It already excludes arbitrary real edge costs, and a fortiori excludes binary red/blue costs.

The fixed-point extension in Section 3 inherits this obstruction: extend every matching in (1) by the same fixed edges. Because the affine coefficients sum to one, the added coordinates also satisfy (1). Thus those higher-dimensional eight-term subsets are not complete real-cost fibers either.

This is the precise failed inference:

    arbitrary binary cancellation subset
      does not imply
    cancellation of a complete binary edge-color fiber.

Equal cost on the listed matchings alone would be insufficient. A valid fiber certificate must also exclude every outside matching in the support graph.

## 5. Exhaustive checks on this particular union graph

Among the `2^12-1=4095` nonempty subsets of the union graph's twelve perfect matchings, exact coefficient summation finds exactly one zero subset: `F` itself.

Since `F` cannot be a complete real-cost fiber, it follows that **every nonempty complete real-cost fiber on this particular graph has nonzero signed polynomial sum**. This conclusion combines a finite exact subset enumeration with the explicit affine obstruction above; no enumeration of real costs is necessary.

As an independent binary-specific check, the verifier enumerates all `2^15=32768` binary edge colorings, forms all their nonempty complete red-count fibers, and obtains 787 distinct subsets. None has zero signed polynomial sum. These are complete fibers by construction: matchings are grouped by their actual red-edge counts, rather than filtered from a preselected list.

The determinant containing all twelve union-support matchings is

    8(L+1)^2(L+2)^2(L+3)^2 (5L^2+20L+27),

which is nonzero. Thus the cancellation subset is also not the set of all perfect matchings of its union graph.

These bounded findings do not exclude cancellation fibers in another graph. In particular, passing this one graph's exhaustive test cannot be promoted to a five-row theorem about every support and coloring.

## 6. Reproducible verification and search boundary

Run:

    python check.py
    python -O check.py

The checker uses only the Python standard library and explicit exceptions. It independently reconstructs signed polynomials with binomial coefficients, checks every one of the eleven coefficients, verifies direct integer evaluations at eleven distinct points, checks the two four-term factorizations, proves the finite minimum-cardinality claim, verifies the affine obstruction coordinatewise, and exhausts the stated union-graph subsets and colorings.

The exploratory scripts `search.py` and `search_symmetric.py` used already-installed SciPy/HiGHS only to propose binary subsets. Their floating-point solver conclusions are not used as certificates. Every reported relation was subsequently checked using exact integer coefficients, and all final claims above are independently checked by `check.py` or follow from the displayed algebraic proof.

The bounded feasibility target was: find an exact canonical five-row 0/1 relation, then determine whether its complete-fiber applicability survives on its union support. That target is complete. The search did not proceed to an unbounded enumeration of larger dimensions or of all ternary absent/blue/red edge assignments.

### Conditions for a useful next attempt

To turn arbitrary-subset cancellation into a binary-fiber counterexample, a new candidate must meet all of the following requirements:

1. An exact nonempty 0/1 polynomial identity, checked coefficientwise.
2. A specified support graph, preferably first the union graph.
3. No outside union-support matching in the affine hull of the chosen incidence vectors; otherwise every real edge-cost realization already fails.
4. A single binary edge coloring and a target red count for which the chosen set is exactly the complete fiber, with every outside matching checked.

The present eight-term candidate fails requirement 3. Continuing to search for colors for this same set cannot repair it. A new relation with different incidence geometry, or a separately proved gadget that preserves the prescribed polynomial factors, unique matching multiplicities, and complete-fiber condition, would be needed. Merely replacing weighted multiplicities by informal copies or adding the forced outside matchings would not preserve the certificate.
