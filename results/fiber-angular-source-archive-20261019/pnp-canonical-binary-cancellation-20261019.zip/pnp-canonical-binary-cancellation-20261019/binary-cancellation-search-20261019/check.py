#!/usr/bin/env python3
"""Independent standard-library, exact-integer verifier for the n=5 certificate.
Candidate-search packages and solver statuses are not imported or trusted.
All coefficients are ordered from degree zero upward. Validation uses explicit
exceptions and remains active under python -O.
"""
from itertools import combinations, permutations
from math import comb
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
F = tuple(tuple(map(int, p)) for p in (
    '03241', '04123', '04231', '04321',
    '12340', '13240', '14230', '32140'))
OUTSIDE = tuple(map(int, '02143'))
AFFINE = ((1, '03241'), (1, '04123'), (-1, '04321'),
          (1, '12340'), (-1, '13240'))

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sign(p):
    return 1 if sum(p[i] > p[j] for i in range(len(p))
                    for j in range(i + 1, len(p))) % 2 == 0 else -1

def multiply(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return tuple(out)

def power(offset, exponent):
    return tuple(comb(exponent, k) * offset ** (exponent - k)
                 for k in range(exponent + 1))

def polynomial(p, shift=0):
    out = (sign(p),)
    for i, exponent in enumerate(p):
        out = multiply(out, power(i - shift, exponent))
    return out

def add_vectors(vectors, length=11):
    out = [0] * length
    for vector in vectors:
        for k, value in enumerate(vector):
            out[k] += value
    return tuple(out)

def product_at(p, x):
    out = sign(p)
    for i, exponent in enumerate(p):
        out *= (x + i) ** exponent
    return out

def incidence(p, edges):
    return tuple(int(p[i] == j) for i, j in edges)

def key_hash(values):
    return hashlib.sha256(json.dumps(sorted(values), separators=(',', ':')).encode()).hexdigest()

def main():
    ps = tuple(permutations(range(5)))
    require(len(set(F)) == 8 and all(p in ps for p in F), 'F is not eight distinct permutations')
    vectors = {p: polynomial(p) for p in ps}
    centered = {p: polynomial(p, 2) for p in ps}
    residual = add_vectors(vectors[p] for p in F)
    require(residual == (0,) * 11, 'Exact coefficient cancellation failed')
    require(add_vectors(centered[p] for p in F) == (0,) * 11,
            'Centered coefficient cancellation failed')
    evaluations = {str(x): sum(product_at(p, x) for p in F) for x in range(-5, 6)}
    require(not any(evaluations.values()), 'Direct integer evaluation failed')

    # Short algebraic certificate: divide each term by the common factor C.
    minima = tuple(min(p[i] for p in F) for i in range(5))
    require(minima == (0, 2, 1, 2, 0), 'Unexpected common factor')
    residual_terms = {}
    for p in F:
        v = (sign(p),)
        for i in range(5):
            v = multiply(v, power(i, p[i] - minima[i]))
        residual_terms[p] = v
    half = (2,)
    for i in (0, 1, 3, 4):
        half = multiply(half, power(i, 1))
    half = half + (0,)  # Residual terms have degree five, while this has degree four.
    require(add_vectors((residual_terms[p] for p in F if p[0] == 0), 6)
            == tuple(-x for x in half), 'First four-term factor identity failed')
    require(add_vectors((residual_terms[p] for p in F if p[0] != 0), 6)
            == half, 'Second four-term factor identity failed')

    # A zero relation has equally many even and odd permutations by its
    # leading coefficient. Exclude all positive sizes below eight exactly.
    even = tuple(p for p in ps if sign(p) == 1)
    odd = tuple(p for p in ps if sign(p) == -1)
    require(len(even) == len(odd) == 60, 'Parity class counts are wrong')
    ev = tuple(centered[p] for p in even)
    ov = tuple(tuple(-x for x in centered[p]) for p in odd)
    short_checks = []
    for k in (1, 2, 3):
        positive = {add_vectors(ev[i] for i in indices)
                    for indices in combinations(range(60), k)}
        negative = {add_vectors(ov[i] for i in indices)
                    for indices in combinations(range(60), k)}
        intersections = positive.intersection(negative)
        require(not intersections, 'A smaller binary relation exists')
        short_checks.append({
            'terms_per_parity': k, 'subsets_per_parity': comb(60, k),
            'distinct_positive_vectors': len(positive),
            'distinct_negative_vectors': len(negative),
            'intersection_count': len(intersections),
            'positive_vectors_sha256': key_hash(positive),
            'negative_vectors_sha256': key_hash(negative)})

    # Check the graph determined by exactly the union of F's edges.
    edges = tuple(sorted({(i, p[i]) for p in F for i in range(5)}))
    xs = tuple(p for p in ps if all((i, p[i]) in edges for i in range(5)))
    require(len(edges) == 15 and len(xs) == 12, 'Unexpected union graph')
    require(OUTSIDE in xs and OUTSIDE not in F, 'The affine obstruction is not an outside union matching')
    incidence_sum = [0] * len(edges)
    affine_sum = 0
    for weight, name in AFFINE:
        p = tuple(map(int, name))
        require(p in F, 'Affine certificate uses a matching outside F')
        affine_sum += weight
        for e, value in enumerate(incidence(p, edges)):
            incidence_sum[e] += weight * value
    require(affine_sum == 1, 'Affine coefficients do not sum to one')
    require(tuple(incidence_sum) == incidence(OUTSIDE, edges), 'Affine incidence identity failed')

    # Every arbitrary subset of the twelve union-support matchings.
    subset_vectors = [(0,) * 11]
    for p in xs:
        v = vectors[p]
        subset_vectors.extend(tuple(a + b for a, b in zip(old, v))
                              for old in tuple(subset_vectors))
    zero_masks = [mask for mask, v in enumerate(subset_vectors)
                  if mask and not any(v)]
    fmask = sum(1 << j for j, p in enumerate(xs) if p in F)
    require(zero_masks == [fmask], 'Unexpected additional zero subset in the union graph')
    require(fmask == 1532, 'Unexpected canonical subset mask')

    # Exhaust all 2^15 binary edge colorings; obtain COMPLETE fibers.
    edge_index = {e: j for j, e in enumerate(edges)}
    matching_masks = tuple(sum(1 << edge_index[(i, p[i])] for i in range(5)) for p in xs)
    fibers = set()
    for coloring in range(1 << len(edges)):
        groups = {}
        for j, mask in enumerate(matching_masks):
            count = (coloring & mask).bit_count()
            groups[count] = groups.get(count, 0) | (1 << j)
        fibers.update(groups.values())
    require(len(fibers) == 787, 'Unexpected complete-fiber count')
    require(not any(mask in fibers for mask in zero_masks), 'A binary zero fiber was found')

    # Exact determinant of the union support (it differs from F).
    full_sum = add_vectors(vectors[p] for p in xs)
    full_factor = (8,)
    for offset in (1, 2, 3):
        full_factor = multiply(full_factor, power(offset, 2))
    full_factor = multiply(full_factor, (27, 20, 5))
    full_factor = full_factor + (0,) * (11 - len(full_factor))
    require(full_sum == full_factor, 'Union determinant factorization failed')

    result = {
        'n': 5, 'permutations': F,
        'signed_coefficient_vectors': [{'p': p, 'sign': sign(p), 'coefficients': vectors[p]} for p in F],
        'coefficient_sum': residual, 'direct_evaluation_sums': evaluations,
        'common_factor_exponents': minima,
        'minimal_cardinality': 8, 'smaller_relation_checks': short_checks,
        'union_edges': edges, 'union_perfect_matchings': xs,
        'affine_obstruction': {'outside': OUTSIDE, 'combination': AFFINE,
                               'coefficient_sum': affine_sum, 'incidence_sum': incidence_sum},
        'union_nonempty_subsets_checked': len(subset_vectors) - 1,
        'union_zero_subset_masks': zero_masks,
        'binary_colorings_checked': 1 << len(edges),
        'distinct_nonempty_complete_binary_fibers': len(fibers),
        'zero_complete_binary_fibers': 0,
        'complete_binary_fibers_sha256': key_hash(fibers),
        'union_determinant_coefficients': full_sum,
        'status': 'All exact checks passed.'}
    (ROOT / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print('PASS: eight-term binary cancellation; all 11 coefficients and 11 evaluations exact.')
    print('PASS: minimum cardinality eight at n=5; no equal parity subset sums for k=1,2,3.')
    print('PASS: 15-edge union, 12 matchings, and explicit real-cost affine obstruction.')
    print('PASS: F is the sole zero subset among 4095 nonempty union subsets.')
    print('PASS: 32768 binary colorings yield 787 distinct nonempty complete fibers; none cancel.')
    print('PASS: union support determinant has the stated nonzero factorization.')

if __name__ == '__main__':
    main()
