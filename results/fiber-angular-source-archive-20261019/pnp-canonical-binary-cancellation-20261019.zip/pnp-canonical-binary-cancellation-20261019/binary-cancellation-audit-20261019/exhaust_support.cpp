#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using I=long long;
struct Term{std::array<int,5> p; int sign; std::array<I,3> value;};
I ipow(I x,int e){I r=1;while(e--)r*=x;return r;}
int main(){
 std::vector<Term> terms;std::array<int,5> p;
 for(p[0]=0;p[0]<5;p[0]++)for(p[1]=0;p[1]<5;p[1]++)if(p[1]!=p[0])for(p[2]=0;p[2]<5;p[2]++)if(p[2]!=p[1]&&p[2]!=p[0])for(p[3]=0;p[3]<5;p[3]++)if(p[3]!=p[2]&&p[3]!=p[1]&&p[3]!=p[0])for(p[4]=0;p[4]<5;p[4]++)if(p[4]!=p[3]&&p[4]!=p[2]&&p[4]!=p[1]&&p[4]!=p[0]){
  Term t;t.p=p;int inv=0;for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)inv+=p[i]>p[j];t.sign=(inv%2)?-1:1;
  for(int e=0;e<3;e++){t.value[e]=t.sign;for(int i=0;i<5;i++)t.value[e]*=ipow(i+e+1,p[i]);}terms.push_back(t);
 }
 I total=0,feasible=0,eval1zero=0,eval2zero=0,eval3zero=0;std::ofstream survivors("support_survivors.txt");
 std::array<int,5> mask;
 for(mask[0]=1;mask[0]<32;mask[0]++)for(mask[1]=1;mask[1]<32;mask[1]++)for(mask[2]=1;mask[2]<32;mask[2]++)for(mask[3]=1;mask[3]<32;mask[3]++){
  I cof[5]={0,0,0,0,0},num[5]={0,0,0,0,0};
  for(const auto &t:terms){bool good=true;for(int i=0;i<4;i++)if(!(mask[i]&(1<<t.p[i]))){good=false;break;}if(good){cof[t.p[4]]+=t.value[0];num[t.p[4]]++;}}
  I d[32]={0},n[32]={0};
  for(int s=1;s<32;s++){
   int j=__builtin_ctz(s),rest=s&(s-1);d[s]=d[rest]+cof[j];n[s]=n[rest]+num[j];total++;
   if(!n[s])continue;feasible++;if(d[s])continue;eval1zero++;mask[4]=s;
   I vals[2]={0,0};for(const auto&t:terms){bool good=true;for(int i=0;i<5;i++)if(!(mask[i]&(1<<t.p[i]))){good=false;break;}if(good){vals[0]+=t.value[1];vals[1]+=t.value[2];}}
   if(vals[0])continue;eval2zero++;if(vals[1])continue;eval3zero++;
   for(int x:mask)survivors<<x<<' ';survivors<<'\n';
  }
 }
 std::cout<<"{\"nonempty_row_supports\":"<<total<<",\"feasible_supports\":"<<feasible<<",\"zero_at_1\":"<<eval1zero<<",\"zero_at_1_2\":"<<eval2zero<<",\"zero_at_1_2_3\":"<<eval3zero<<"}\n";
}
