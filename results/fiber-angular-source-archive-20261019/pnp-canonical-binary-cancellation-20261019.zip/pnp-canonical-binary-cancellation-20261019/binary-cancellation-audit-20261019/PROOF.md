# Independent audit of five-row binary cancellation

19 October 2026. These are local, finite canonical results. No repository, pull request, merge, tag, release, or other remote state was changed.

## 1. An exact relation that cannot be a complete cost fiber

Write a permutation as the column/exponent chosen in each row, and let

    T_p(L) = sign(p) product_{i=0}^4 (L+i)^{p(i)}.

The eight-element set

    F = {03241, 04123, 04231, 04321, 12340, 13240, 14230, 32140}

satisfies sum_{p in F} T_p(L)=0. This audit independently multiplies the linear factors in integer coefficient arithmetic and obtains eleven zero coefficients. It separately computes direct products at eleven distinct integers L=-5,...,5; since all terms have degree ten, that is an independent identity check.

This does not make F a complete color fiber. If p_M denotes the 25-coordinate edge-incidence vector of matching M, the outside matching N=02143 satisfies

    p_N = p_03241 + p_04123 - p_04321 + p_12340 - p_13240.     (1)

The coefficients on the right sum to one. Every edge of N belongs to the union of F. Thus any edge-additive cost that is constant with value t on F must assign value t to N as well. F cannot be a complete fiber for any real, rational, integer, nonnegative, or binary edge costs, in any graph containing F. This is an exact affine obstruction; it does not depend on solver output or numerical rank.

The union graph has 15 edges and precisely twelve perfect matchings. Its four additional matchings are

    02143, 02341, 14320, 34120.

Its complete determinant is

    8 (L+1)^2 (L+2)^2 (L+3)^2 (5L^2+20L+27),

which is nonzero. Hence arbitrary-subset cancellation and cancellation of the full union-support determinant also differ in this example.

The standard-library checker `check.py` verifies the coefficient identity, the separate evaluation identity, every coordinate of (1), the coefficient-sum-one condition, all union matchings, and the factored determinant. It writes the compact coefficient receipt `core_results.json`. Both `python check.py` and `python -O check.py` pass; no validation relies on Python assertions.

## 2. An exhaustive n=5 full-support determinant result

**Finite theorem.** Let B be any five-by-five matrix with entries in {0,1}. Set

    D_B(L) = det [B_ij (L+i)^j]_{i,j=0}^4.

If the support of B admits a perfect matching, then D_B(1), D_B(2), and D_B(3) are not all zero. In particular, its full determinant is not the zero polynomial.

This is a canonical five-row statement about complete support determinants, not about individual red-count coefficients, arbitrary offsets, arbitrary exponents, or higher dimensions.

### Exhaustive count

There are 2^25 = 33,554,432 supports, including supports with empty rows. Of these:

- 23,191,071 have at least one perfect matching.
- 31,312 feasible supports have D_B(1)=0.
- 62 feasible supports have D_B(1)=D_B(2)=0.
- None have D_B(1)=D_B(2)=D_B(3)=0.

The first implementation, `exhaust_support.cpp`, enumerates all 31^5 = 28,629,151 supports with nonempty rows. For each first-four-row tuple, it groups all compatible permutation terms by the column chosen in the fifth row. A 31-element subset-sum recurrence evaluates all fifth-row supports and counts their compatible matchings. Only zero evaluations at L=1 require direct evaluation at L=2 and L=3. It yields the counts above.

### Independent subset-zeta verification

The second implementation, `verify_support_zeta.cpp`, uses a different enumeration and data flow. Identify a graph with its 25-bit edge mask S. For each of the 120 permutations p, form its five-edge mask M_p and initialize

    A[M_p] = sign(p) product_i (1+i)^{p(i)},
    C[M_p] = 1,

with other entries zero. Apply the ordinary subset-zeta recurrence, once for each edge bit b:

    A[S] += A[S without b],
    C[S] += C[S without b]        whenever b belongs to S.

After all 25 stages,

    A[S] = D_S(1),
    C[S] = number of perfect matchings in S.

Every one of the 2^25 supports occurs exactly once. Therefore C[S]>0 is exactly feasibility, without a separate matching oracle. For the 31,312 feasible supports with A[S]=0, the checker sums the compatible signed permutation evaluations directly at L=2 and L=3. It independently obtains exactly the same census and explicitly fails if any expected count differs.

The two in-memory zeta arrays are discarded when the program exits. They use approximately 288 MiB in total and are not archived. All signed evaluation arithmetic uses 64-bit integers. At L=1,2,3, each of at most 120 terms has absolute value at most 7^10, so every intermediate zeta sum and evaluation has absolute value at most 120*7^10 < 2^35. No overflow is possible. The unsigned one-byte permanent counts are at most 120 at every zeta stage, so those also cannot overflow.

The small `support_62_certificate.txt` lists the 62 surviving support masks, their perfect-matching counts, and their nonzero D_B(3). It has SHA-256

    2a62309926c63dc77081fda736613c43ea48ae91f79ad47d2baf5ca61fda7ca6.

Reproduce the complete independent check with a C++17 compiler:

    g++ -O3 -std=c++17 verify_support_zeta.cpp -o verify_support_zeta
    ./verify_support_zeta

The JSON output is retained as `support_zeta_results.json`; the other implementation's receipt is `support_results.json`. The exact computation supplies the finite theorem. There is no unbounded structural claim hidden in the census.

## 3. Every binary-color fiber on the full canonical K5,5

**Finite theorem.** Color every edge of the full K5,5 graph red or blue. For any target k with a nonempty set F_k of perfect matchings using exactly k red edges, the polynomial

    Q_k(L) = sum_{p in F_k} T_p(L)

is nonzero. More specifically, Q_k(1), Q_k(2), and Q_k(3) are not all zero.

Again, this theorem is restricted to canonical offsets and exponents 0,...,4, and the full graph. It does not follow merely from Section 2: a full determinant is the sum of its fiber polynomials, so its nonvanishing alone would not prevent a zero fiber. This section separately enumerates complete fibers.

### Completeness and the small symmetry reduction

Complementing all 25 edge colors sends the red count of every five-edge perfect matching from k to 5-k. The corresponding matching subset and its polynomial are unchanged; only the target label changes. Exactly one member of each complementary coloring pair has edge (0,0) blue. Consequently enumerating all 2^24 colorings with that edge blue covers every fiber from all 2^25 binary colorings, with no assumption on the target.

The complete counts over these representatives are:

- 16,777,216 colorings.
- 89,453,821 nonempty fibers, counted with their coloring and target, not deduplicated as matching subsets.
- 50,208 such fibers vanish at L=1.
- 96 vanish at L=1 and L=2.
- None vanish at L=1, L=2, and L=3.

Counts over all colorings are twice the representative counts because complement is a fixed-point-free bijection preserving nonempty fibers.

### Two independent enumeration implementations

`exhaust_full_colors.cpp` uses a reflected binary Gray code on the 24 unfixed edge bits. Each transition changes one edge. Exactly 24 permutations contain that edge, so their red counts are updated and their precomputed signed evaluations are transferred between adjacent target bins. All six target bins maintain their exact matching counts and three signed sums. Every nonempty bin is checked after every transition, including the initial all-blue coloring.

`verify_full_colors_direct.cpp` independently enumerates the even 25-bit integers in ordinary numeric order, fixing the low bit corresponding to edge (0,0) at zero. For each coloring, it computes all 120 red counts directly as popcounts of the intersections with matching masks and sums the signed L=1 evaluations into six fresh bins. Each nonempty zero bin is then recomputed directly at L=2 and L=3. It does not use Gray state, incremental red counts, or the first program's output. It obtains the identical full census and raises an exception unless the expected counts agree.

Both implementations record the 96 fibers surviving the first two evaluation tests as (color mask, target, matching count, value at L=3). Sorting the Gray-code receipt gives a byte-for-byte match with the independent ordinary-order receipt. The retained canonical receipt is `full_color_96_direct_certificate.txt`, with SHA-256

    d55e5ca9a182aa62a2fb66885f761f1d265891cc71ab38807297d4d869e612ef.

Every product and signed sum uses 64-bit integer arithmetic. Each term has degree ten and at L=1,2,3 its absolute value is at most 7^10. Every bin contains at most 120 terms, so all sums and update intermediates are bounded in absolute value by 120*7^10 = 33,897,029,880 < 2^35 < 2^63. The elementary powers are multiplied as 64-bit integers, avoiding 32-bit intermediate overflow. Edge masks use unsigned 32-bit integers and shifts only at positions 0 through 24; matching and target counts are at most 120 and 5 respectively. Census counters are also 64-bit.

The direct verifier needs only the 120 term records and six bins, not a large coloring table. In this environment the complete direct sweep took about two seconds, and the incremental sweep about one and a half seconds. Timing is informational and not part of the mathematical certificate. Reproduce with:

    g++ -O3 -std=c++17 verify_full_colors_direct.cpp -o verify_full_colors_direct
    ./verify_full_colors_direct

A compiler targeting a CPU with POPCNT may additionally use `-mpopcnt`; it is an optional performance flag, not part of the algorithm. The output is retained as `full_color_direct_results.json`, alongside `full_color_results.json` from the Gray-code sweep.

## 4. Receipt checks and the boundary left open

`verify_receipts.py` uses only Python's standard library. It independently reconstructs every perfect matching and directly verifies each of the 62 support witnesses and each of the 96 full-graph fiber witnesses at all three evaluation points. It checks expected record counts, absence of duplicate records, stored matching counts, nonzero third values, and receipt hashes. Both ordinary and `python -O` runs pass.

The claims proved or independently verified here remain distinct:

1. Arbitrary subsets: the stated eight terms cancel exactly.
2. This particular subset: an explicit affine identity rules out realization as any complete edge-cost fiber.
3. Full determinants of arbitrary binary five-by-five supports: none cancel in the canonical setting.
4. Binary-color fibers of the full K5,5: none cancel in the canonical setting.
5. Intermediate sparse supports with arbitrary binary colorings: not exhausted by either sweep and still unresolved by this audit.

The primary search note additionally checks all binary colorings of the specific 15-edge union graph, and establishes that eight is the smallest possible size of an arbitrary binary cancellation subset among the canonical five-row terms. This audit read that checker, reran it successfully, and independently verified its core eight-term certificate. No claim is made that these finite results prove general sparse binary noncancellation or resolve P versus NP.
