"""Independently re-evaluate the two small exhaustive-sweep survivor receipts."""
import hashlib,json,math
from itertools import permutations
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def require(c,msg):
 if not c:raise RuntimeError(msg)
terms=[]
for p in permutations(range(5)):
 mask=sum(1<<(5*i+p[i]) for i in range(5))
 sign=(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
 values=[sign*math.prod((z+i)**p[i] for i in range(5)) for z in (1,2,3)]
 terms.append((mask,values))
require(len(terms)==120,'Term count')
require(120*7**10==33897029880 and 33897029880<2**35,'Integer bound')

def records(name,expected_count,digest):
 raw=(ROOT/name).read_bytes()
 require(hashlib.sha256(raw).hexdigest()==digest,name+' digest')
 rows=[list(map(int,line.split())) for line in raw.decode().splitlines()]
 require(len(rows)==expected_count,name+' count')
 return rows

support=records('support_62_certificate.txt',62,'2a62309926c63dc77081fda736613c43ea48ae91f79ad47d2baf5ca61fda7ca6')
require(len({r[0] for r in support})==62,'Duplicate support')
for mask,count,third in support:
 selected=[v for m,v in terms if mask&m==m]
 require(len(selected)==count>0,'Support matching count')
 require([sum(v[z] for v in selected) for z in range(3)]==[0,0,third] and third!=0,'Support values')

colors=records('full_color_96_direct_certificate.txt',96,'d55e5ca9a182aa62a2fb66885f761f1d265891cc71ab38807297d4d869e612ef')
require(len({tuple(r[:2]) for r in colors})==96,'Duplicate color fiber')
for color,target,count,third in colors:
 require(0<=color<1<<25 and color%2==0 and 0<=target<=5,'Color or target bounds')
 selected=[v for m,v in terms if (color&m).bit_count()==target]
 require(len(selected)==count>0,'Fiber matching count')
 require([sum(v[z] for v in selected) for z in range(3)]==[0,0,third] and third!=0,'Fiber values')
 complement=((1<<25)-1)^color
 selected_complement=[v for m,v in terms if (complement&m).bit_count()==5-target]
 require(selected_complement==selected,'Complement fiber identity')

expect_support={'feasible_supports':23191071,'zero_at_1':31312,'zero_at_1_2':62,'zero_at_1_2_3':0}
for filename in ('support_results.json','support_zeta_results.json'):
 data=json.loads((ROOT/filename).read_text())
 require(all(data.get(k)==v for k,v in expect_support.items()),filename+' census')
expect_colors={'representative_colorings':16777216,'all_colorings_via_complement':33554432,'representative_nonempty_fibers':89453821,'zero_at_1':50208,'zero_at_1_2':96,'zero_at_1_2_3':0}
for filename in ('full_color_results.json','full_color_direct_results.json'):
 data=json.loads((ROOT/filename).read_text())
 require(all(data.get(k)==v for k,v in expect_colors.items()),filename+' census')
print('PASS: all 62 support receipts and all 96 complete-fiber receipts independently verified; hashes, counts, complement identities and safe-integer bound pass.')
