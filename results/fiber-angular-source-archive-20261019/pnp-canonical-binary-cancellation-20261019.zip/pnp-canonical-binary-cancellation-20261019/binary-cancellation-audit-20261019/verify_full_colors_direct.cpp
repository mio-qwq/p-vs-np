// Independent full-color enumeration: direct popcount and permutation sums.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using I=std::int64_t;
I power(I x,int e){I r=1;while(e--)r*=x;return r;}
struct Term{std::uint32_t edges;I a,b,c;};
int main(){
 std::array<int,5> p={0,1,2,3,4};std::vector<Term> terms;
 do{int inv=0;std::uint32_t edges=0;for(int i=0;i<5;i++){edges|=1u<<(5*i+p[i]);for(int j=i+1;j<5;j++)inv+=p[i]>p[j];}I a=inv%2?-1:1,b=a,c=a;for(int i=0;i<5;i++){a*=power(i+1,p[i]);b*=power(i+2,p[i]);c*=power(i+3,p[i]);}terms.push_back({edges,a,b,c});}while(std::next_permutation(p.begin(),p.end()));
 I fibers=0,z1=0,z12=0,z123=0;std::ofstream receipt("full_color_96_direct_certificate.txt");
 // All even edge masks, exactly those with edge(0,0) blue.
 for(std::uint32_t color=0;color<(1u<<25);color+=2){
  I a[6]={0,0,0,0,0,0};int count[6]={0,0,0,0,0,0};
  for(const auto&t:terms){int k=__builtin_popcount(color&t.edges);a[k]+=t.a;count[k]++;}
  for(int k=0;k<6;k++)if(count[k]){fibers++;if(a[k])continue;z1++;I b=0,c=0;for(const auto&t:terms)if(__builtin_popcount(color&t.edges)==k){b+=t.b;c+=t.c;}if(b)continue;z12++;if(!c)z123++;receipt<<color<<' '<<k<<' '<<count[k]<<' '<<c<<'\n';}
 }
 std::cout<<"{\"representative_colorings\":16777216,\"all_colorings_via_complement\":33554432,\"representative_nonempty_fibers\":"<<fibers<<",\"zero_at_1\":"<<z1<<",\"zero_at_1_2\":"<<z12<<",\"zero_at_1_2_3\":"<<z123<<"}\n";
 if(fibers!=89453821||z1!=50208||z12!=96||z123)throw std::runtime_error("Unexpected census");
}
