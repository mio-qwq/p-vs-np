// Independent exhaustive checker: subset-zeta transform over all 25-edge graphs.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using I=std::int64_t;
I power(I a,int b){I x=1;for(int k=0;k<b;k++)x*=a;return x;}
int main(){
 const std::uint32_t N=1u<<25;
 std::vector<I> value(N,0);std::vector<unsigned char> permanent(N,0);
 struct Term {std::uint32_t mask;I e2,e3;};std::vector<Term> terms;
 std::array<int,5> p={0,1,2,3,4};
 do {
  std::uint32_t mask=0;int inversions=0;for(int i=0;i<5;i++){mask|=1u<<(5*i+p[i]);for(int j=i+1;j<5;j++)inversions+=(p[i]>p[j]);}
  I s=inversions%2?-1:1,a=s,b=s,c=s;
  for(int i=0;i<5;i++){a*=power(i+1,p[i]);b*=power(i+2,p[i]);c*=power(i+3,p[i]);}
  value[mask]=a;permanent[mask]=1;terms.push_back({mask,b,c});
 }while(std::next_permutation(p.begin(),p.end()));
 for(std::uint32_t bit=1;bit<N;bit*=2)for(std::uint32_t block=0;block<N;block+=2*bit)for(std::uint32_t j=0;j<bit;j++){
  value[block+bit+j]+=value[block+j];
  permanent[block+bit+j]+=permanent[block+j];
 }
 I feasible=0,z1=0,z12=0,z123=0;
 std::ofstream cert("support_62_certificate.txt");
 for(std::uint32_t mask=0;mask<N;mask++)if(permanent[mask]){
  feasible++;if(value[mask])continue;z1++;I b=0,c=0;
  for(const auto&t:terms)if((mask&t.mask)==t.mask){b+=t.e2;c+=t.e3;}
  if(b)continue;z12++;if(!c)z123++;cert<<mask<<' '<<static_cast<int>(permanent[mask])<<' '<<c<<'\n';
 }
 std::cout<<"{\"all_supports\":"<<N<<",\"feasible_supports\":"<<feasible<<",\"zero_at_1\":"<<z1<<",\"zero_at_1_2\":"<<z12<<",\"zero_at_1_2_3\":"<<z123<<"}\n";
 if(feasible!=23191071||z1!=31312||z12!=62||z123)throw std::runtime_error("Unexpected census");
}
