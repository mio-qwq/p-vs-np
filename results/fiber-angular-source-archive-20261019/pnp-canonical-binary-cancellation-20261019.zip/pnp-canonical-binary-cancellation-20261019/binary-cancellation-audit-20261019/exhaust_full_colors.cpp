// Exact exhaustive all full-K5,5 binary colorings, modulo global color complement.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using I=std::int64_t;
I power(I a,int b){I x=1;for(int k=0;k<b;k++)x*=a;return x;}
struct Term{std::array<I,3> values;std::array<I,11> coeff;int count=0;};
int main(){
 std::vector<Term> terms;std::array<std::vector<int>,25> containing;
 std::array<int,5> p={0,1,2,3,4};
 I sums[6][3]={};int counts[6]={120,0,0,0,0,0};
 do{
  int inversions=0;for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)inversions+=p[i]>p[j];I sign=inversions%2?-1:1;
  Term t;t.coeff.fill(0);t.coeff[0]=sign;int degree=0;
  for(int i=0;i<5;i++)for(int j=0;j<p[i];j++){for(int k=degree+1;k>=0;k--)t.coeff[k]=(k>0?t.coeff[k-1]:0)+(k<=degree?i*t.coeff[k]:0);degree++;}
  for(int z=0;z<3;z++){t.values[z]=sign;for(int i=0;i<5;i++)t.values[z]*=power(i+z+1,p[i]);sums[0][z]+=t.values[z];}
  for(int i=0;i<5;i++)containing[5*i+p[i]].push_back(terms.size());terms.push_back(t);
 }while(std::next_permutation(p.begin(),p.end()));
 if(terms.size()!=120)throw std::runtime_error("Permutation enumeration");
 for(auto &v:containing)if(v.size()!=24)throw std::runtime_error("Edge incidence");
 for(int z=0;z<3;z++)if(sums[0][z]!=288)throw std::runtime_error("Full Vandermonde");
 I fibers=0,zero1=0,zero12=0,zero123=0,zero_polynomial=0;std::uint32_t color=0;
 std::ofstream candidates("full_color_candidates.txt"),receipt("full_color_96_certificate.txt");
 const std::uint32_t N=1u<<24;
 for(std::uint32_t step=0;step<N;step++){
  if(step){int e=__builtin_ctz(step)+1;int delta=(color&(1u<<e))?-1:1;color^=1u<<e;
   for(int id:containing[e]){auto&t=terms[id];int old=t.count,nw=old+delta;t.count=nw;counts[old]--;counts[nw]++;for(int z=0;z<3;z++){sums[old][z]-=t.values[z];sums[nw][z]+=t.values[z];}}
  }
  for(int k=0;k<6;k++)if(counts[k]){
   fibers++;if(sums[k][0])continue;zero1++;if(sums[k][1])continue;zero12++;receipt<<color<<' '<<k<<' '<<counts[k]<<' '<<sums[k][2]<<'\n';if(sums[k][2])continue;zero123++;
   std::array<I,11> residual={};for(const auto&t:terms)if(t.count==k)for(int j=0;j<11;j++)residual[j]+=t.coeff[j];
   bool zero=true;for(I x:residual)zero&=x==0;if(zero)zero_polynomial++;
   candidates<<color<<' '<<k<<' '<<counts[k]<<' '<<zero;for(I x:residual)candidates<<' '<<x;candidates<<'\n';
  }
 }
 std::cout<<"{\"representative_colorings\":"<<N<<",\"all_colorings_via_complement\":"<<2*N<<",\"representative_nonempty_fibers\":"<<fibers<<",\"zero_at_1\":"<<zero1<<",\"zero_at_1_2\":"<<zero12<<",\"zero_at_1_2_3\":"<<zero123<<",\"zero_polynomial_fibers\":"<<zero_polynomial<<"}\n";
}
