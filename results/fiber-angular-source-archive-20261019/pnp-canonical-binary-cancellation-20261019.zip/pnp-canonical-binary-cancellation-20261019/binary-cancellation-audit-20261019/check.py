"""Exact standard-library verification of the eight-term relation and obstruction."""
from itertools import permutations,combinations
from pathlib import Path
import hashlib,json,math
F=[tuple(map(int,p)) for p in ['03241','04123','04231','04321','12340','13240','14230','32140']]
N=tuple(map(int,'02143'))
B=[1,1,0,-1,1,-1,0,0]

def require(c,msg):
 if not c:raise RuntimeError(msg)
def coeff(p):
 c=[1]
 for i,e in enumerate(p):
  for _ in range(e):
   d=[0]*(len(c)+1)
   for k,x in enumerate(c):d[k]+=i*x;d[k+1]+=x
   c=d
 s=(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
 return [s*x for x in c]
def incidence(p):return [int(p[i]==j) for i in range(5) for j in range(5)]
cs=[coeff(p) for p in F]
require([sum(c[k] for c in cs) for k in range(11)]==[0]*11,'Polynomial sum')
# Independent evaluations use direct products rather than coefficient convolution.
for z in range(-5,6):
 direct=sum((-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))*math.prod((z+i)**p[i] for i in range(5)) for p in F)
 require(direct==0,'Independent evaluation at '+str(z))
require(N not in F,'Outside membership')
require(sum(B)==1,'Affine coefficient sum')
require([sum(b*incidence(p)[k] for b,p in zip(B,F)) for k in range(25)]==incidence(N),'Affine incidence identity')
E=set((i,p[i]) for p in F for i in range(5))
require(all((i,N[i]) in E for i in range(5)),'Obstruction not in union support')
X=[p for p in permutations(range(5)) if all((i,p[i]) in E for i in range(5))]
require(len(E)==15 and len(X)==12,'Union counts')
extra=[p for p in X if p not in F]
require(extra==[tuple(map(int,p)) for p in ['02143','02341','14320','34120']],'Extra matchings')
full=[sum(coeff(p)[k] for p in X) for k in range(11)]
require(any(full),'Union graph determinant')
# Verify factored determinant at 11 points (degree at most ten).
for z in range(-5,6):
 require(sum(c*z**k for k,c in enumerate(full))==8*(z+1)**2*(z+2)**2*(z+3)**2*(5*z*z+20*z+27),'Factored union determinant')
result={'permutations':[''.join(map(str,p)) for p in F],'signed_coefficient_vectors':cs,'outside_matching':''.join(map(str,N)),'affine_coefficients':B,'union_edges':sorted(E),'union_matching_count':len(X),'union_determinant_coefficients':full}
Path(__file__).with_name('core_results.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: exact degree-ten zero sum, 11 independent evaluations, affine obstruction, union support and factored nonzero determinant.')
