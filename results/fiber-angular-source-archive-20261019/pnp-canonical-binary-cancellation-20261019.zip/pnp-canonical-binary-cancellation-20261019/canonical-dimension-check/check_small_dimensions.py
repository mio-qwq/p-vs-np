#!/usr/bin/env python3
"""Exact, independent finite exclusion of canonical 0/1 cancellation for n<=4.

No exploratory search solver or prior archive is imported. Checks stay active -O.
"""
from itertools import combinations, permutations
from math import comb, factorial
import json


def require(ok,message):
    if not ok:
        raise RuntimeError(message)


def unsigned_coefficients(p):
    coefficients=[1]
    for offset,exponent in enumerate(p):
        for _ in range(exponent):
            out=[0]*(len(coefficients)+1)
            for degree,value in enumerate(coefficients):
                out[degree]+=offset*value
                out[degree+1]+=value
            coefficients=out
    return tuple(coefficients)


def vector_sum(vectors,degree):
    out=[0]*(degree+1)
    for vector in vectors:
        require(len(vector)==degree+1,'coefficient vector length')
        for i,value in enumerate(vector):
            out[i]+=value
    return tuple(out)


def main():
    results=[]
    for n in range(1,5):
        degree=n*(n-1)//2
        positive=[];negative=[]
        for p in permutations(range(n)):
            vector=unsigned_coefficients(p)
            require(len(vector)==degree+1 and vector[-1]==1,'term is not monic with required degree')
            inversions=sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))
            (negative if inversions%2 else positive).append(vector)
        require(len(positive)+len(negative)==factorial(n),'permutation coverage')
        require((len(positive),len(negative))==((1,0) if n==1 else (factorial(n)//2,)*2),'parity coverage')
        checks=[]
        zero=(0,)*(degree+1)
        all_sums=[{zero},{zero}]
        if n==1:
            require(positive==[(1,)] and negative==[], 'one-row case')
            all_sums[0].add((1,))
        for k in range(1,min(len(positive),len(negative))+1):
            vectors=[];counts=[]
            for parity in (positive,negative):
                sums=set();count=0
                for indices in combinations(range(len(parity)),k):
                    sums.add(vector_sum((parity[i] for i in indices),degree))
                    count+=1
                require(count==comb(len(parity),k),'subset enumeration count')
                vectors.append(sums);counts.append(count)
            all_sums[0].update(vectors[0])
            all_sums[1].update(vectors[1])
            overlap=vectors[0]&vectors[1]
            require(not overlap,'nonempty canonical zero subset found')
            checks.append({'terms_per_parity':k,'subsets_per_parity':counts[0],
                           'distinct_even_sums':len(vectors[0]),'distinct_odd_sums':len(vectors[1]),
                           'cross_parity_equalities':len(overlap)})
        require(all_sums[0]&all_sums[1]=={zero},'global cross-parity subset intersection')
        results.append({'n':n,'permutations':factorial(n),'degree':degree,
                        'balanced_cardinality_checks':checks,'nonempty_zero_subsets':0,
                        'all_cross_parity_common_vectors':[list(zero)]})
    print(json.dumps({'max_n':4,'status':'all exact exclusions passed','results':results},indent=2,sort_keys=True))


if __name__=='__main__':main()
