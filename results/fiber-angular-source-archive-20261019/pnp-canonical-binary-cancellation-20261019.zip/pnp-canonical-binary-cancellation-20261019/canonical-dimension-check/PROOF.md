# Self-contained canonical small-dimension exclusion

19 October 2026. A small exact supplement makes the five-row archive independent of earlier archived proofs.

For each n=1,2,3,4, enumerate every permutation p of 0,...,n-1 and form the monic unsigned polynomial g_p(L)=product_i (L+i)^{p(i)} by integer convolution. Its degree is n(n-1)/2. Its signed term is sign(p)g_p(L).

Any nonempty zero subset has equally many even and odd permutations, because their leading coefficients are +1 and -1. Therefore it is enough, for every k from 1 to the smaller parity-class size, to compare every sum of k distinct even unsigned polynomials with every sum of k distinct odd unsigned polynomials. Exact coefficient equality is polynomial equality. The checker exhausts these combinations, verifies their binomial counts, and finds disjoint sum sets for every k. This includes every possible nonempty zero subset and excludes it.

At n=1 the odd class is empty, so leading coefficients already rule out a zero subset. At n=2,3,4 the parity classes have sizes 1,3,12 respectively. For n=4 the total number of nonempty subsets of each parity is just 2^12-1=4095, so this check is small. Stored sets only deduplicate repeated sums; enumeration counts verify that every distinct permutation subset was processed. Deduplication cannot lose a cross-parity equality.

The supplied results.json contains counts for every k. Both ordinary and optimized Python runs pass with identical results. The checker uses Python standard-library exact integers and explicit exceptions, not assertions. It is independent of the five-row checker and of exploratory numerical solvers.

Together with the exact eight-term n=5 certificate, this establishes five as the first canonical dimension with a nonempty 0/1 relation. It makes no claim for arbitrary unequal row offsets or nonconsecutive exponents.
