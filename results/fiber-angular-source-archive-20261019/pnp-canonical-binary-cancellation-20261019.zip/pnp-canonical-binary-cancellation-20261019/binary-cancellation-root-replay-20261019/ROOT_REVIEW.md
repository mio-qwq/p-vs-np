# Root review of binary cancellation and union-support normalization

19 October 2026. This records a further AI-assisted mathematical review, not external peer review or formal proof verification.

## Eight-term relation

I independently reconstructed all eleven integer coefficients of the eight signed permutation products using binomial multiplication, without importing either worker's checker. Their sum was zero. Factoring out (L+1)^2(L+2)(L+3)^2, the first four terms sum to -2L(L+1)(L+3)(L+4), and the last four to its positive opposite.

A separate exact incidence computation found fifteen union edges, twelve perfect matchings, affine dimension six, and all twelve matchings in the affine hull of the eight selected ones. The outside incidence identity for 02143 has coefficients 1,1,-1,1,-1, whose sum is one. Thus no complete real edge-cost fiber can equal this cancellation subset. This obstruction remains valid in every containing graph and under the fixed-point extensions. It does not refute complete binary-fiber noncancellation.

I read the complete primary proof, including the distinction between canonical minimum dimension and minimum cardinality at n=5. The finite minimum-cardinality statement relies on the supplied exact exhaustive checker; it is not inferred from a numerical solver.

## Finite support and full-color checks

I inspected the independent subset-zeta C++ support verifier and direct-popcount C++ coloring verifier before compiling them. Their complete mask ranges, complement symmetry, permutation signs, nonempty-fiber conditions, and integer types match the stated finite theorems. At evaluation points 1,2,3 every term is bounded by 7^10 and every sum by 120*7^10, well within signed 64-bit arithmetic. The one-byte permanent counts never exceed 120. Independent root replay outputs are stored alongside this review; executable binaries are reproducible and need not be archived.

These computations do not exhaust intermediate sparse graph/color pairs, arbitrary offsets, other exponent sequences, or higher dimensions.

## Union-support normalization

I read the complete normalization proof independently. With B=n+1, C=(n+1)^2 and K=Cn+t, the doubled core has cost Cp+Bd+r. For p<n its maximum is (C+B+1)(n-1)=Cn-(n+3)<K. Full target cost forces p=n, d=0 and r=t, so the mirror matching is the known D. A singleton-category target C+b is below 2C, forcing p=1 and the unique forward/mirror pair for that source edge.

The selector's empty, singleton and full modes therefore classify every target matching. The explicitly listed dummies cover every forward and mirror path in both states and every spoke; the known lift of D covers the zero selector branch. Every selector branch is selected in a listed matching and unselected in another. Hence all internal path edges, including blue ones, satisfy the union-support promise. The explicit list has m+f+1 members, and unary path sizes and list lengths remain polynomial.

The reduction concerns completeness for a supplied coloring. It establishes the stated Exact Matching relationship, not synthesis hardness, NP-hardness, or a P-versus-NP conclusion. No claim of two-way many-one equivalence or historical novelty is made.

## Completed independent replay

Both root-compiled programs completed with exit code 0.

- Support census: 33,554,432 supports; 23,191,071 feasible; 31,312 zero at 1; 62 zero at 1 and 2; none zero at 1, 2, 3.
- Full-color census: 16,777,216 complement representatives; 89,453,821 nonempty fibers; 50,208 zero at 1; 96 zero at 1 and 2; none zero at 1, 2, 3.
- Independently generated support receipt SHA-256: 2a62309926c63dc77081fda736613c43ea48ae91f79ad47d2baf5ca61fda7ca6.
- Independently generated color receipt SHA-256: d55e5ca9a182aa62a2fb66885f761f1d265891cc71ab38807297d4d869e612ef.

Both receipts agree exactly with the audited receipts.
