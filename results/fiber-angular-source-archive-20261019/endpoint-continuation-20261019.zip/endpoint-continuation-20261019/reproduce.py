#!/usr/bin/env python3
"""Replay primary and independent endpoint proofs in an isolated temporary copy."""
from pathlib import Path
from itertools import permutations
from math import isqrt
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    integrity_count = 0
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        sha, name = line.split('  ',1)
        path = ROOT/name
        require(path.resolve().is_relative_to(ROOT), 'Unsafe manifest path')
        require(path.is_file() and digest(path) == sha, 'Integrity mismatch: '+name)
        integrity_count += 1
    compiler = shutil.which('g++')
    require(compiler is not None, 'g++ with C++17 and undefined-behavior sanitizer support is required')
    prime = 2147483647
    require(all(prime % d for d in range(2,isqrt(prime)+1)), 'Modulus is not prime')
    require(5**17 < prime**2 and prime**2 < 2**62, 'Hadamard or integer-safety bound failed')
    env = dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0')
    env.pop('PYTHONOPTIMIZE',None)
    checks = []
    with tempfile.TemporaryDirectory(prefix='endpoint-checkpoint-replay-') as td:
        work = Path(td)/'payload'
        shutil.copytree(ROOT,work)
        audit = work/'audit'

        def run(label,cmd,cwd):
            result = subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True)
            require(result.returncode == 0,label+' failed:\n'+result.stdout+'\n'+result.stderr)
            require(not result.stderr,label+' wrote unexpected stderr:\n'+result.stderr)
            checks.append({'check':label,'exit_code':0,'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest()})
            return result.stdout

        primary_outputs = []
        for mode in ([],['-O']):
            label = 'optimized' if mode else 'normal'
            name = 'REPLAY_'+label+'.json'
            output = run('primary-exact-enumeration-'+label,
                         [sys.executable]+mode+['verify_endpoint_lemma.py','--output',name],work)
            require((work/name).read_bytes() == (ROOT/'ENDPOINT_CERTIFICATE.json').read_bytes(),
                    'Regenerated primary certificate differs: '+label)
            primary_outputs.append(output)
        require(primary_outputs[0] == primary_outputs[1], 'Primary mode reports differ')
        certificate = read(work/'REPLAY_normal.json')
        require(certificate['source_sha256'] == digest(work/'verify_endpoint_lemma.py'), 'Primary source digest mismatch')

        for sanitizer in (False,True):
            label = 'ubsan' if sanitizer else 'normal'
            binary = 'audit_endpoint_'+label
            flags = ['-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=all'] if sanitizer else ['-O2']
            run('compile-independent-gray-enumerator-'+label,
                [compiler]+flags+['-std=c++17','-Wall','-Wextra','-pedantic','audit_endpoint.cpp','-o',binary],audit)
            output_name = 'GRAY_'+label+'.json'
            run('independent-gray-enumeration-'+label,[str(audit/binary),output_name],audit)
            require((audit/output_name).read_bytes() == (ROOT/'audit/independent_endpoint.json').read_bytes(),
                    'Independent Gray-code certificate mismatch: '+label)

        pair_outputs = []
        for mode in ([],['-O']):
            label = 'optimized' if mode else 'normal'
            pair_outputs.append(run('independent-pair-enumeration-'+label,
                                    [sys.executable]+mode+['audit_pairs.py'],audit))
            require((audit/'PAIR_AUDIT.json').read_bytes() == (ROOT/'audit/PAIR_AUDIT.json').read_bytes(),
                    'Independent pair receipt mismatch: '+label)
        require(pair_outputs[0] == pair_outputs[1], 'Independent pair mode reports differ')

        # Fresh cross-check uses the primary final certificate, never exploratory data.
        gray = read(audit/'GRAY_normal.json')
        perm_names = [''.join(map(str,p)) for p in permutations(range(5))]
        memberships = 0
        for r in range(5):
            ps = [p for p in perm_names if int(p[0]) == r]
            item = gray[r]
            source = certificate['slices'][r]
            require(item['r'] == source['minimum_exponent'] == r,'Slice index mismatch')
            require(item['balanced'] == source['balanced_count'] and item['closed'] == source['closed_count'],
                    'Slice count mismatch')
            independent = {tuple(p for j,p in enumerate(ps) if (mask>>j)&1) for mask in item['masks']}
            primary = {tuple(sorted(x['members'])) for x in source['closed_sets']}
            require(independent == primary and len(independent) == item['closed'],
                    'Full final-certificate slice memberships disagree')
            memberships += len(independent)
        require(memberships == 571,'Wrong catalogue size')
        pair_audit = read(audit/'PAIR_AUDIT.json')
        require(pair_audit['encoding_base_B']-1 > pair_audit['encoding_coefficient_bound_H'],
                'Injective polynomial encoding bound failed')
        require(pair_audit['row_reversal_identity_verified_all_120'] is True and certificate['row_reversal_checked'] == 120,
                'Row-reversal receipt mismatch')
        primary_pairs = {tuple(x['row_support']):x for x in certificate['two_column_completions']}
        total = 0
        for item in pair_audit['pairs']:
            source = primary_pairs[(item['r'],item['s'])]
            require(item['gap_passing'] == source['gap_passing_slices'], 'Gap-pruned counts disagree')
            a = {tuple(sorted(x['members'])) for x in item['polynomial_zero_sets']}
            b = {tuple(sorted(x['members'])) for x in source['candidates']}
            require(a == b and len(a) == source['polynomial_zero_completions'], 'Pair completion memberships disagree')
            require(all(x['outsiders'] for x in item['polynomial_zero_sets']), 'Independent affine outsider missing')
            total += len(a)
        require(total == 3 and len(primary_pairs) == len(pair_audit['pairs']) == 10,'Pair exhaustion count mismatch')

    print(json.dumps({'status':'PASS','integrity_files_checked':integrity_count,'checks':checks,
        'primary_certificate_sha256':digest(ROOT/'ENDPOINT_CERTIFICATE.json'),
        'primary_normal_optimized_and_retained_certificates_byte_identical':True,
        'independent_gray_normal_ubsan_and_retained_certificates_byte_identical':True,
        'independent_pair_normal_optimized_and_retained_receipts_byte_identical':True,
        'all_571_final_primary_slice_memberships_match_independent_audit':True,
        'all_ten_pair_counts_and_three_completion_memberships_match':True,
        'modular_prime_hadamard_and_int64_bounds_verified':True,
        'comparison_inputs':'Final ENDPOINT_CERTIFICATE.json and independently regenerated Gray-code/pair receipts only',
        'new_solver_runs':0,'scope':'Necessary endpoint-row support condition for canonical n5 complete real edge-cost fibers; remaining sparse-fiber cases are unresolved.'},indent=2))

if __name__ == '__main__':
    main()
