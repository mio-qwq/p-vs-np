#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using I=std::int64_t;
constexpr I PRIME=2147483647;
using Row=std::array<I,17>;
I mod(I x){x%=PRIME;if(x<0)x+=PRIME;return x;}
I power(I a,I b){I out=1;for(;b;b>>=1,a=a*a%PRIME)if(b&1)out=out*a%PRIME;return out;}
struct Basis{
 std::array<Row,17> rows{};std::array<bool,17> used{};int rank=0;
 bool reduce(Row &v)const{for(int j=0;j<17;++j)if(v[j]&&used[j]){I t=v[j];for(int k=j;k<17;++k)v[k]=mod(v[k]-t*rows[j][k]);}for(I x:v)if(x)return false;return true;}
 void add(Row v){if(reduce(v))return;int j=0;while(!v[j])++j;I inv=power(v[j],PRIME-2);for(I &x:v)x=x*inv%PRIME;rows[j]=v;used[j]=true;++rank;}
};
int main(int argc,char **argv){
 if(argc!=2)return 2;
 std::ofstream out(argv[1]);out<<"[\n";
 for(int r=0;r<5;++r){
  std::vector<std::array<int,5>> perms;std::array<int,5> p={0,1,2,3,4};
  do{if(p[0]==r)perms.push_back(p);}while(std::next_permutation(p.begin(),p.end()));
  std::vector<int> cols;for(int c=0;c<5;++c)if(c!=r)cols.push_back(c);
  std::array<I,24> weights{};std::array<Row,24> rows{};
  for(int k=0;k<24;++k){const auto &p=perms[k];int inv=0;I v=1;for(int i=0;i<5;++i)for(int j=i+1;j<5;++j)inv+=p[i]>p[j];for(int i=1;i<5;++i)for(int e=0;e<p[i];++e)v*=i;weights[k]=(inv%2?-v:v);rows[k][0]=1;for(int i=1;i<5;++i)for(int j=0;j<4;++j)rows[k][1+(i-1)*4+j]=(p[i]==cols[j]);}
  std::uint32_t last=0;I sum=0;std::uint64_t balanced=0;std::vector<std::uint32_t> closed;
  for(std::uint32_t t=1;t<(1u<<24);++t){std::uint32_t mask=t^(t>>1),diff=last^mask;int bit=__builtin_ctz(diff);sum+=(mask&diff)?weights[bit]:-weights[bit];last=mask;if(sum)continue;++balanced;Basis basis;for(int j=0;j<24;++j)if(mask>>j&1)basis.add(rows[j]);bool yes=true;for(int j=0;j<24&&yes;++j)if(!(mask>>j&1)){Row v=rows[j];if(basis.reduce(v))yes=false;}if(yes)closed.push_back(mask);}
  std::sort(closed.begin(),closed.end());out<<"{\"r\":"<<r<<",\"balanced\":"<<balanced<<",\"closed\":"<<closed.size()<<",\"masks\":[";for(std::size_t j=0;j<closed.size();++j){if(j)out<<",";out<<closed[j];}out<<"]}"<<(r==4?"\n":",\n");std::cout<<r<<" balanced "<<balanced<<" closed "<<closed.size()<<std::endl;
 }out<<"]\n";
}
