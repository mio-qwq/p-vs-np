# Independent audit: canonical five-row endpoint fiber obstruction

19 October 2026. Independent exact local audit. No repository, remote, PR, release, or numerical MILP was changed or run.

## Verdict

**The endpoint support theorem is correct as a finite, exhaustively verified theorem:** every nonempty polynomial-cancelling complete real edge-additive-cost fiber in the canonical five-row system uses at least three distinct columns in row 0 and at least three distinct columns in row 4. The support being counted is the union of the fiber matchings. It is not a claim that every ambient graph vertex has that degree unless the graph has already been normalized to the union.

The least-exponent affine-closure lemma, the root-balance reduction, the support-gap pruning, and the row-reflection argument are sound. The counts and every one of the 571 surviving slice memberships were independently reproduced by a different enumeration and incidence representation. The three remaining two-slice zero subsets have explicit three-term affine outsider certificates, so none is a complete fiber.

This is a necessary-condition theorem at n=5 with offsets and exponents both exactly 0,1,2,3,4. It neither establishes general noncancellation nor settles the remaining sparse-fiber cases, and it has no P-versus-NP consequence by itself. The finite enumeration is part of the proof; it is not replaced by solver output, numerical tolerance, a random evaluation, external peer review, or proof-assistant formalization.

## 1. Definitions and precise statement

For a permutation p of {0,1,2,3,4}, define

    f_p(L) = sign(p) product_(i=0)^4 (L+i)^(p(i)).

Let H be any bipartite graph on these five row and five column labels. Let c_e be arbitrary real costs on its edges and t a real target. The complete fiber is

    F = {p: every (i,p(i)) belongs to H and sum_i c_(i,p(i)) = t}.

Assume F is nonempty and sum_(p in F) f_p(L) is the zero polynomial. Then

    |{p(0): p in F}| >= 3 and |{p(4): p in F}| >= 3.

No integrality or binary-color assumption is needed. Binary red-count fibers are included. Removing edges unused by F preserves the entire target fiber, so union-support normalization is legitimate but not necessary for this proof.

## 2. Why closure relative to all 24 matchings is necessary

Fix a nonempty slice F_r = {p in F: p(0)=r}. Write v_p for the full 25-coordinate 0/1 matching incidence vector. Suppose q is any permutation with q(0)=r and

    v_q = sum_(p in F_r) a_p v_p, with sum_p a_p = 1.

The coefficients may have either sign. If an edge is absent from the union of F_r, its coordinate is zero in every v_p and hence in v_q. Consequently q uses only edges of union(F_r), so q is active in H. The same identity gives

    c dot v_q = sum_p a_p (c dot v_p) = t.

Completeness therefore forces q into F_r. Thus F_r is closed under affine span relative to **all 24** permutations with the fixed first edge, not merely relative to an arbitrarily chosen residual support.

This argument deals explicitly with sparse support and the target cost. Equivalently, after deleting the fixed edge's endpoints, F_r is a complete residual 4-by-4 fiber at target t-c_(0,r).

For the independent computation, delete row 0 and column r and represent each residual matching by the 17-coordinate vector consisting of a leading 1 and all 16 incidence entries. Affine-span membership is exactly linear-span membership of these augmented rows. This representation retains the full residual incidence data and is independent of the source enumeration's reduced 10-coordinate representation.

## 3. Root balance and the derivative interference boundary

Let r=min{p(0):p in F}. Write

    f_p(L) = L^(p(0)) g_p(L),
    g_p(0) = sign(p) product_(i=1)^4 i^(p(i)).

Only F_r contributes to the coefficient of L^r. Therefore

    sum_(p in F_r) sign(p) product_(i=1)^4 i^(p(i)) = 0.

These 24 signed integer root weights are all nonzero. If s>r is the next supported exponent, the full cancellation additionally forces the polynomial sum over F_r to have zero coefficients in every degree below s. Equivalently, sum_(p in F_r) g_p is divisible by L^(s-r).

This condition stops strictly before degree s: at degree s and above, higher-exponent slices can cancel contributions from F_r. Requiring more derivatives of the isolated least slice to vanish would be unsound without another argument. The audited pair search applies exactly the valid cutoff and then solves the full polynomial completion equation, including all possible interference.

## 4. Exhaustive slice enumeration and exactness of modular ranks

`audit_endpoint.cpp` traverses every one of the 2^24-1 nonempty subsets separately for each r using a Gray-code scalar sum. It does not import the source search. Every root-balanced subset is checked for affine closure using the full 17-coordinate residual representation.

The counts for r=0,1,2,3,4 are respectively:

- Root-balanced nonempty subsets: 13,419; 1,437; 1,242; 3,609; 13,419. Total 33,126.
- Affine-closed balanced subsets: 216; 23; 24; 92; 216. Total 571.

Elimination uses the prime P=2^31-1=2,147,483,647. This is **exact for rational ranks**, for the following reason. Every augmented residual row has precisely five entries equal to 1. Every k-by-k minor, k<=17, therefore satisfies Hadamard's bound

    |det|^2 <= 5^k <= 5^17 < P^2.

Each determinant is an integer, so no nonzero minor can become zero modulo P. Conversely, a minor nonzero modulo P is nonzero as an integer. All ranks, including the rank after adjoining any candidate outsider, agree over Q and the finite field. Hence modular dependence here really does establish rational affine membership; this is not an unsupported modular heuristic. The modulus's primality and the displayed integer inequality were also checked directly.

All modular multiplications and subtractions fit signed 64-bit arithmetic: products are below P^2<2^62 and subtraction remains in the signed range. A separate undefined-behavior-sanitized compile reran the complete enumeration and produced identical JSON. Python comparisons then checked equality of all 571 closed subset memberships with the constructive worker's exact-integer computation, not merely agreement of counts.

## 5. One-column and two-column exhaustion

Every one-column cancelling fiber would be one of the 571 closed root-balanced slices. Independently constructed integer coefficient vectors show that none of these 571 sums is the zero polynomial.

For two columns r<s, every candidate least slice belongs to the list above. After the support-gap check, every possible second slice is searched by splitting its 24 permutations into two groups of 12 and using all 4096 subset sums per group. Empty second slices are excluded; duplicate subset-sum values retain all masks.

The independent implementation uses arbitrary-precision evaluation at B=9,255,938. An individual coefficient has magnitude at most 192,832, so the difference/equation being tested, containing at most 48 summands, has every coefficient bounded in absolute value by H=9,255,936. For any nonzero such integer polynomial Q, its leading nonzero term strictly dominates all lower terms at B because B-1>H. Thus Q(B)=0 if and only if Q is identically zero in this finite search. This is a deterministic injective encoding, not a probabilistic polynomial identity test. Each returned candidate is also checked again in all 11 exact coefficient coordinates.

Pair r,s; gap-passing least slices; zero polynomial completions:

    0,1: 216; 0
    0,2:   1; 0
    1,2:  23; 0
    0,3:   0; 0
    1,3:   1; 0
    2,3:  24; 0
    0,4:   0; 0
    1,4:   0; 0
    2,4:   0; 0
    3,4:  92; 3

The three candidates in the last pair have sizes 24,18,20. Independent exact Fraction elimination in all 26 augmented full-incidence coordinates finds respectively 24,24,22 outsiders in their affine closures. All are within their union supports. Full memberships and checked affine representations are in `PAIR_AUDIT.json`.

## 6. Short explicit certificates for the only three candidates

Write v_abcde for the incidence vector of permutation abcde. Candidate membership is fully recorded below so that these identities can be checked without searching another file.

### Size 18

F = {30124,30142,30214,31204,34102,40123,40132,40213,41032,41302,42013,42031,42130,42310,43021,43102,43120,43210}.

    v_31024 = v_30124 - v_40132 + v_41032.

The three right-hand members lie in F and the coefficients sum to 1; 31024 is outside F.

### Size 20

F = {31402,31420,32140,34012,34102,34120,34201,40123,40132,40213,40312,41203,41230,41320,42103,42130,43012,43021,43120,43201}.

    v_30412 = v_31402 + v_40213 - v_41203.

The three right-hand members lie in F and the coefficients sum to 1; 30412 is outside F.

### Size 24

F = {30421,31204,31402,31420,32041,32410,34021,40123,40132,40213,40231,40312,40321,41023,41032,41203,41230,41302,41320,42031,42103,42130,43021,43120}.

    v_42013 = -v_31420 + v_32410 + v_41023.

The three right-hand members lie in F and the coefficients sum to 1; 42013 is outside F.

Every identity holds in all 25 incidence coordinates. By Section 2 each displayed outsider is an active matching at the same target cost. This contradicts completeness for each candidate and finishes the row-0 proof.

## 7. Row 4 reflection

Let R(p)(i)=p(4-i), and reverse the support and cost matrix's row order. This bijection preserves completeness and target costs. Reversing five rows has sign (-1)^10=1, while the total exponent is 0+1+2+3+4=10. Hence

    f_p(-L-4) = f_(R(p))(L).

Polynomial cancellation is preserved, and the old row-4 column support becomes the new row-0 column support. The row-0 theorem therefore proves the row-4 theorem. The coefficient identity was separately verified for all 120 permutations.

## 8. Independently checked derivative corollary

After factoring L^r from each closed least-slice polynomial, the remaining polynomial has root order exactly 1 in all but four exceptional slices. For each r=0,1,3,4 there is precisely one order-2 slice; for r=2 all 24 slices have order 1. None has order 3 or higher. These orders and all exceptional memberships were independently recomputed in `audit_pairs.py` and recorded in `PAIR_AUDIT.json`.

Consequently the two smallest endpoint exponents r<s obey s-r<=2. If r=2, then s=3. A gap of exactly 2 prescribes the entire least slice. In the only cases relevant after the endpoint-support theorem, these are:

    r=0, s=2:
    {02431,03142,03241,04123,04132,04231,04321}

    r=1, s=3:
    {10234,10243,10324,10342,12304,13204,14203,14302}

In particular, endpoint support {0,3,4} is impossible. The proof uses only the derivative coefficients strictly below the second supported exponent, so it does not ignore higher-slice interference. These statements transfer to row 4 by the same row reflection.

## 9. Reproduction and scope

Run in this directory:

    g++ -O2 -std=c++17 -Wall -Wextra -pedantic audit_endpoint.cpp -o audit_endpoint
    ./audit_endpoint independent_endpoint.json
    python audit_pairs.py
    python -O audit_pairs.py

The final pair checker is self-contained: it reads only this audit's `independent_endpoint.json`. A separate comparison against the constructive worker's catalogue previously verified every one of the 571 memberships in both normal and optimized runs; the comparison is recorded in `SOURCE_COMPARISON.json`. All enforcement checks use explicit exceptions rather than assert and remain active under Python optimization. The normal and optimized receipts agree. The UBSan enumeration receipt also agrees exactly with the normal enumeration.

This confirms the claimed finite endpoint obstruction. It does not exclude fibers whose endpoint supports each have size 3,4, or5, except for the additional gap restriction just stated, nor assert noncancellation for other offsets, sizes, or polynomial families.
