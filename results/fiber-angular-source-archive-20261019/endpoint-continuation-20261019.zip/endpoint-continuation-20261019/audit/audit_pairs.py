"""Independent endpoint-pair audit; consumes only this audit's Gray-code output."""
from itertools import permutations
from collections import defaultdict, Counter
from fractions import Fraction
from math import factorial
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
P=list(permutations(range(5)))

def require(b,msg):
    if not b: raise RuntimeError(msg)

def sign(p):
    return -1 if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2 else 1

def coeff(p):
    a=[sign(p)]+[0]*10
    degree=0
    for i,e in enumerate(p):
        for _ in range(e):
            old=a[:]
            for j in range(degree+2): a[j]=i*old[j]+(old[j-1] if j else 0)
            degree+=1
    return tuple(a)
C={p:coeff(p) for p in P}
# At most 48 selected summands can occur in a two-slice relation.
H=48*max(abs(x) for a in C.values() for x in a)
B=H+2

def eval_coeff(a):
    v=0
    for x in reversed(a): v=v*B+x
    return v
V={p:eval_coeff(C[p]) for p in P}

def subset_sums(vs):
    out=[0]
    for v in vs: out.extend(x+v for x in out[:])
    return out

def incidence(p):
    return [1]+[int(p[i]==j) for i in range(5) for j in range(5)]

def closure_witnesses(F):
    m=len(F);basis=[]
    for k,p in enumerate(F):
        v=list(map(Fraction,incidence(p))); rep=[Fraction(int(j==k)) for j in range(m)]
        for pivot,b,b_rep in basis:
            t=v[pivot]
            if t:
                v=[x-t*y for x,y in zip(v,b)]
                rep=[x-t*y for x,y in zip(rep,b_rep)]
        if any(v):
            pivot=next(i for i,x in enumerate(v) if x)
            t=v[pivot];v=[x/t for x in v];rep=[x/t for x in rep]
            basis.append((pivot,v,rep));basis.sort(key=lambda x:x[0])
    outsiders=[]
    for q in P:
        if q in F:continue
        v=list(map(Fraction,incidence(q)));rep=[Fraction(0) for p in F]
        for pivot,b,b_rep in basis:
            t=v[pivot]
            if t:
                v=[x-t*y for x,y in zip(v,b)]
                rep=[x+t*y for x,y in zip(rep,b_rep)]
        if any(v):continue
        require(sum(rep)==1,'non-affine representation')
        require(all(sum(c*incidence(p)[j] for c,p in zip(rep,F))==incidence(q)[j] for j in range(26)),'bad affine witness')
        require(all(any(p[i]==q[i] for p in F) for i in range(5)),'outsider not union-supported')
        outsiders.append({'q':''.join(map(str,q)),'identity':{''.join(map(str,p)):str(c) for p,c in zip(F,rep) if c}})
    return len(basis),outsiders

D=json.loads((ROOT/'independent_endpoint.json').read_text())
PS={r:[p for p in P if p[0]==r] for r in range(5)}
S={r:[[p for j,p in enumerate(PS[r]) if mask>>j&1] for mask in D[r]['masks']] for r in range(5)}
closedsets={r:{tuple(F) for F in S[r]} for r in range(5)}

slice_orders=[]
for r in range(5):
    counts=Counter(); exceptional=[]
    for F in S[r]:
        a=[sum(C[p][j] for p in F) for j in range(11)]
        require(any(a),'zero slice in multiplicity audit')
        order=next(j for j,x in enumerate(a) if x)-r
        counts[order]+=1
        if order>1: exceptional.append({'order_after_factoring_L_power_r':order,'members':[''.join(map(str,p)) for p in F]})
    expected={1:len(S[r])} if r==2 else {1:len(S[r])-1,2:1}
    require(dict(counts)==expected,f'unexpected slice root orders r={r}')
    slice_orders.append({'r':r,'orders_after_factoring_L_power_r':dict(counts),'exceptional_slices':exceptional})

single=[]
for r in range(5):
    zero=[F for F in S[r] if not any(sum(C[p][j] for p in F) for j in range(11))]
    single.append({'r':r,'candidate_slices':len(S[r]),'zero_polynomial_slices':len(zero)})
    require(not zero,'one-column counterexample')

pairs=[]
for s in range(1,5):
    qs=PS[s]
    left=subset_sums([V[p] for p in qs[:12]])
    right=defaultdict(list)
    for mask,val in enumerate(subset_sums([V[p] for p in qs[12:]])):right[val].append(mask)
    for r in range(s):
        passing=0;matches=[]
        for F0 in S[r]:
            c0=[sum(C[p][j] for p in F0) for j in range(11)]
            if any(c0[:s]):continue
            passing+=1
            target=-eval_coeff(c0)
            for a,val in enumerate(left):
                for b in right.get(target-val,[]):
                    if not(a or b):continue
                    mask=a|(b<<12)
                    F1=[p for j,p in enumerate(qs) if mask>>j&1]
                    F=F0+F1
                    require(all(sum(C[p][j] for p in F)==0 for j in range(11)),'big integer encoding false positive')
                    rank,outsiders=closure_witnesses(F)
                    matches.append({'members':[''.join(map(str,p)) for p in F], 'size':len(F),'affine_rank_plus_one':rank,'outsiders':outsiders})
        entry={'r':r,'s':s,'gap_passing':passing,'polynomial_zero_sets':matches}
        pairs.append(entry)
        print((r,s),'gap',passing,'zero sets',len(matches),'sizes',[m['size'] for m in matches], 'outsiders',[len(m['outsiders']) for m in matches],flush=True)
        require(all(m['outsiders'] for m in matches),'complete-fiber counterexample')

reflection_ok=all(C[tuple(reversed(p))]==tuple(sum(C[p][j]*((-4)**(j-k))*(-1)**k*__import__('math').comb(j,k) for j in range(k,11)) for k in range(11)) for p in P)
require(reflection_ok,'row reversal identity fails')
result={'subset_enumeration':'all 5 * (2^24 - 1) nonempty subsets by Gray code','balanced_counts':[x['balanced'] for x in D],'closed_counts':[x['closed'] for x in D],'independent_slice_catalogue_entries':sum(len(v) for v in S.values()),'encoding_coefficient_bound_H':H,'encoding_base_B':B,'slice_root_orders':slice_orders,'one_column':single,'pairs':pairs,'row_reversal_identity_verified_all_120':reflection_ok}
(ROOT/'PAIR_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS; H =',H,'B =',B)
