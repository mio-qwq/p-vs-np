# Separate local endpoint-support recovery checkpoint

This is a third local-only archive. It does not change the earlier PNP/YM
continuation ZIPs, their index, or the frozen prior release batch.

## Result and scope

For canonical n=5 offsets and exponents 0,1,2,3,4, any nonempty cancelling
complete real edge-additive-cost fiber must use at least three distinct columns
in each endpoint row, 0 and 4. The proof also gives restrictions on the gap
between the two smallest endpoint exponents. This is a necessary condition;
it does not settle the remaining sparse-fiber cases, imply the same condition
for interior rows, or resolve P versus NP.

PROOF.md states the theorem and reduction. ROOT_REVIEW.md and audit/AUDIT.md
record the root and independent reviews. ENDPOINT_CERTIFICATE.json contains
all 571 closed scalar-balanced slices, all ten pair cases, the three polynomial
completions, and their explicit affine outsider certificates.

## Reproduction

Requires Python 3.10+ and g++ with C++17 and undefined-behavior sanitizer support.
No solver, SciPy, NumPy, network, package installation, or exploratory data is used.
From this extracted directory:

    python reproduce.py
    python -O reproduce.py

Each command first verifies SHA256SUMS, then works in an isolated temporary copy:

- Regenerate the complete primary certificate under normal and optimized Python;
  require byte-for-byte agreement with the retained final certificate.
- Compile and run the independent Gray-code enumeration normally and with UBSan;
  require both complete outputs to match the retained independent certificate.
- Replay the independent exact-integer pair enumeration and rational affine
  outsider checks under normal and optimized Python, comparing complete receipts.
- Decode and compare every one of the 571 independent slice memberships directly
  against the final ENDPOINT_CERTIFICATE.json slices, then compare all ten pair
  counts and all three completion memberships.
- Check the modular prime, Hadamard bound, signed-int64 safety bound, and the
  injective integer-polynomial encoding inequality.

Temporary binaries and generated receipts are removed on exit. None are archived.
Finite exhaustive computation is part of this proof; this is not proof-assistant
formalization or external peer review.

## Provenance and dependency notes

All nine accepted input files are unchanged byte-for-byte. The audit author had
already made audit_pairs.py self-contained before this checkpoint; no copied
research source needed modification. CHECKPOINT_MANIFEST.json records both
original and checkpoint hashes and accepted input-list provenance.

The historical audit report refers to a previous comparison receipt against
endpoint_closure.json. Those exploratory files are intentionally omitted.
reproduce.py performs a fresh, stronger portable comparison directly against
the final primary ENDPOINT_CERTIFICATE.json; the historical comparison is not
needed. No source outside this archive is required for the endpoint theorem.
The separate earlier cardinality-ten theorem mentioned in PROOF.md is contextual
and is not needed to prove the endpoint support condition.
