# Endpoint-support obstruction for canonical five-row cancellation

19 October 2026. Local exact mathematics and standard-library finite verification only. No repository, PR, merge, release, or frozen research artifact was modified. This is AI-assisted finite verification, not external peer review or proof-assistant formalization.

## New result

For a permutation p of {0,1,2,3,4}, write

    f_p(L) = sgn(p) product_(i=0)^4 (L+i)^{p(i)}.

Let G be any supported bipartite graph on these five labelled rows and columns. Let w assign arbitrary real edge costs, and let F be a nonempty **complete** cost fiber:

    F = {p in PM(G) : sum_i w_(i,p(i)) = t}.

**Finite exact theorem.** If sum_(p in F) f_p(L) is the zero polynomial, then each endpoint row uses at least three distinct columns in F:

    |{p(0): p in F}| >= 3,
    |{p(4): p in F}| >= 3.

This applies in particular to sparse binary-color fibers at targets 1 and 2. Together with the previously established cardinality obstruction, an unresolved counterexample must have at least ten matchings and at least three used edges in each endpoint row. The cardinality theorem is a separate prior result, not re-proved here.

The new statement is not asserted for interior rows. The canonical offsets prevent arbitrary row or column relabelling from being treated as a symmetry at fixed L.

## 1. Least-exponent root slice

Set r=min{p(0):p in F} and S_r={p in F:p(0)=r}. This slice is nonempty. Since every term outside S_r has a higher power of L, the coefficient of L^r in the zero polynomial gives

    sum_(p in S_r) sgn(p) product_(i=1)^4 i^{p(i)} = 0.       (1)

S_r is itself a complete cost fiber after fixing edge (0,r), deleting its row and column, and subtracting its cost from the target.

Consequently S_r is affine-closed among the 24 permutations with p(0)=r. In detail, suppose q is another such permutation and

    v_q = sum_(p in S_r) a_p v_p,    sum_p a_p = 1,

where v_p is its 25-coordinate incidence vector. If an edge is absent from union(S_r), its coordinate is zero in every v_p, so it is also zero in v_q. Thus q is supported in G. The incidence identity forces q to have cost t; completeness forces q to belong to F and hence to S_r.

This is only a necessary condition for a binary-cost fiber, which is sufficient for the exclusion below. No claim that every affine-closed set has a binary realization is used.

## 2. Exact scalar-slice classification

For each r there are 24 terms in (1), exactly 12 with positive and 12 with negative scalar weights. Enumerate all 2^12 subsets on each sign side and join equal unsigned sums, retaining every pair of masks, including duplicate values. This enumerates every root-balanced subset once.

For every nonempty balanced subset, compute the affine closure using exact integer row elimination. The affine coordinates are the leading constant 1 and a 3-by-3 submatrix of the residual 4-by-4 permutation matrix. These determine the full incidence vector because its row and column sums are one. Integer elimination with gcd reduction computes rational, and therefore real, span exactly.

The exhaustive counts are:

| Minimum exponent r | Nonempty scalar-balanced subsets | Affine-closed subsets |
|---|---:|---:|
| 0 | 13,419 | 216 |
| 1 | 1,437 | 23 |
| 2 | 1,242 | 24 |
| 3 | 3,609 | 92 |
| 4 | 13,419 | 216 |
| Total | 33,126 | 571 |

All 571 lists appear in ENDPOINT_CERTIFICATE.json. None has zero full polynomial. This already rules out a cancelling complete fiber that uses only one column in row 0.

## 3. Exhaustion when row 0 uses two columns

Suppose the two columns used are r<s. Then F is the disjoint union of S_r and a subset S_s of the 24 permutations with p(0)=s. The preceding argument requires S_r to be one of the classified affine-closed scalar-balanced subsets.

Every term of S_s is divisible by L^s. Therefore the coefficients of degrees below s in P_r=sum_(p in S_r)f_p must vanish. Discard S_r if this necessary derivative condition fails.

For each survivor, solve the exact subset-sum equation

    sum_(p in S_s) f_p = -P_r.                            (2)

Split the 24 candidate terms for S_s into two lexicographic halves of 12. Enumerate the 4,096 subsets of each half using all eleven signed integer polynomial coefficients. For every left mask, look up the complementary vector on the right and retain every matching right mask. This exhausts all 2^24 subsets without a floating-point solver. A zero polynomial is checked by coefficient equality, not by a numerical tolerance.

| Row-0 column pair | First slices surviving the derivative condition | Full polynomial-zero completions |
|---|---:|---:|
| {0,1} | 216 | 0 |
| {0,2} | 1 | 0 |
| {0,3} | 0 | 0 |
| {0,4} | 0 | 0 |
| {1,2} | 23 | 0 |
| {1,3} | 1 | 0 |
| {1,4} | 0 | 0 |
| {2,3} | 24 | 0 |
| {2,4} | 0 | 0 |
| {3,4} | 92 | 3 |

The only three completions have respectively 18, 24, and 20 members, all on the pair {3,4}. Their full membership lists and coefficient checks are in the certificate. None is a complete cost fiber, as witnessed by these elementary affine incidence identities:

    Size 18: v_31024 = v_30124 + v_41032 - v_40132.
    Size 24: v_30412 = v_30421 + v_40312 - v_40321.
    Size 20: v_30412 = v_31402 + v_40213 - v_41203.

In each line, all three right-hand matchings belong to that candidate; the left-hand matching does not. Coefficients sum to one, and the left-hand matching uses only edges of the candidate union. Hence its cost is forced to equal the common cost, contradicting completeness. The checker verifies every identity in all 25 coordinates and independently checks all three zero polynomials by direct products at eleven distinct integer values of L.

This excludes every one- or two-column endpoint support and proves the row-0 assertion.

## 4. Exact transfer to row 4

Let rho(i)=4-i. Row reversal has permutation sign (-1)^10=+1, and every product has total exponent 10. Therefore

    f_p(-4-L) = f_(p composed with rho)(L).                 (3)

Indeed, each (-4-L+i) equals -(L+4-i); ten total negative factors give sign +1, then reindex i to 4-i. The permutation signs of p and p composed with rho are equal.

Reversing the rows transports the support graph and edge costs and preserves complete fibers. Identity (3) transports polynomial cancellation and changes the original row 4 into row 0. Thus the same exclusion proves the row-4 assertion. The executable also verifies (3) in all eleven coefficients for all 120 permutations.

## 5. Additional derivative restrictions

For each affine-closed scalar-balanced S_r, factor out L^r from P_r. The classification gives the following multiplicities at L=0:

- For r=0, 1, 3, or 4, all but one closed slice have multiplicity exactly one; the exceptional slice has multiplicity exactly two.
- For r=2, all 24 closed slices have multiplicity exactly one.
- No classified nonempty closed slice has multiplicity three or more.

It follows that if s is the second-smallest column used in row 0 of a cancelling complete fiber, then s-r<=2; if r=2, then s=3. If s=r+2, the entire least-exponent slice is prescribed. The potentially relevant cases after the endpoint-degree theorem are:

    r=0, s=2:
    S_0={02431,03142,03241,04123,04132,04231,04321}.

    r=1, s=3:
    S_1={10234,10243,10324,10342,
         12304,13204,14203,14302}.

In particular, a three-column endpoint support {0,3,4} is excluded. Row reversal transfers these conditions, with the same column exponents, to endpoint row 4.

## 6. How this narrows the unresolved sparse models

After the standard exact reduction that support equals union(F), the binary support variables must satisfy

    sum_(j=0)^4 s_(0,j) >= 3,
    sum_(j=0)^4 s_(4,j) >= 3.

The scalar-slice catalogue and derivative conditions can also be used as exact disjunctive constraints or branches. They are independent of the red target and apply to arbitrary real edge costs. They strengthen the existing cardinality lower bound without claiming that the remaining sparse supports cancel or do not cancel.

No numerical MILP search was repeated. We have not exhausted three-, four-, or five-column endpoint supports, nor all intermediate sparse support/color pairs. The complete n=5 sparse binary-fiber question therefore remains unresolved.

## 7. Reproduction and audit boundary

Run in this directory:

    python verify_endpoint_lemma.py --output ENDPOINT_CERTIFICATE.json
    python -O verify_endpoint_lemma.py --output ENDPOINT_CERTIFICATE_OPTIMIZED.json
    cmp ENDPOINT_CERTIFICATE.json ENDPOINT_CERTIFICATE_OPTIMIZED.json

The source is standalone and uses only the Python standard library. It uses explicit exceptions rather than assertions for correctness checks. JSON includes its source SHA-256. The proof reduction is analytic; the finite counts and exclusions are exact executable enumeration. An independent audit in the neighboring endpoint-fiber-audit-20261019 directory confirmed all 571 memberships and all pair completions using different enumeration, scalar encoding, and affine-rank representations. See its audit report for its exact scope.

Exploratory scripts and intermediate JSONs are retained for transparency but are not the final verification entry point. The final entry point is verify_endpoint_lemma.py, and its final certificate is ENDPOINT_CERTIFICATE.json.
