# Root review — 2026-10-19

Read PROOF.md, full verification core, and independent AUDIT.md. Independently replayed verify_endpoint_lemma.py after source inspection; certificate SHA256 87f7d13f874fbd351cf819c5deba3c5b4c2365d1a45198faa08b4f696dab7367 exactly matches the primary certificate.

The least-exponent coefficient and residual slice affine-closure reduction are valid for arbitrary real edge costs even on sparse supports: a forced incidence vector cannot use a coordinate absent from every member. A second slice begins contributing at precisely its column exponent, so derivative pruning below that degree is necessary and does not overreach. Exhaustive two-slice joins retain all duplicate subsets and test exact coefficient vectors. Each of three survivors has an explicit affine outsider using only union edges. One-column cases are checked separately. The row-reversal identity f_p(-4-L)=f_(p composed reversal)(L) supplies row4 without unsupported row-permutation symmetry.

The independent audit's modular rank argument is justified by Hadamard: augmented residual rows have squared norm5, minors size<=17 satisfy absolute determinant<=sqrt(5^17)<2^31-1. Thus no nonzero integer minor can vanish modulo the prime. Its full-incidence rational outsider certificates and independently injective polynomial encoding provide separate checks.

Conclusion accepted only for canonical n5 complete fibers: at least3 used columns in each endpoint row. Interior rows, remaining endpoint sizes3/4/5, and main PvsNP remain unresolved. This new theorem is not added to the pending frozen release batch. No remote changes.
