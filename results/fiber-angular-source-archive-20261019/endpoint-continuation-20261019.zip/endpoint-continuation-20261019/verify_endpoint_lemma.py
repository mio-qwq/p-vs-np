#!/usr/bin/env python3
"""Exact local certificate for the canonical n=5 endpoint-support lemma.

Standard-library only. All mathematical tests use integers; no solver, tolerance,
or assertions. Does not read repositories or edit frozen artifacts.
"""
from collections import Counter, defaultdict
from functools import reduce
from itertools import permutations
from math import comb, gcd, prod
from pathlib import Path
import argparse
import hashlib
import json

PERMS = tuple(permutations(range(5)))
NAMES = tuple(''.join(map(str, p)) for p in PERMS)
BY_NAME = dict(zip(NAMES, PERMS))


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sign(p):
    return (-1) ** sum(p[i] > p[j] for i in range(5) for j in range(i + 1, 5))


def polynomial(p):
    a = [sign(p)]
    for i, exponent in enumerate(p):
        for _ in range(exponent):
            b = [0] * (len(a) + 1)
            for k, x in enumerate(a):
                b[k] += i * x
                b[k + 1] += x
            a = b
    require(len(a) == 11, 'Unexpected polynomial degree')
    return tuple(a)


POLYS = {name: polynomial(p) for name, p in zip(NAMES, PERMS)}


def poly_sum(names):
    return tuple(sum(POLYS[name][i] for name in names) for i in range(11))


def scalar_subsets(values):
    states = [(0, 0)]
    for i, x in enumerate(values):
        states += [(s + x, m | (1 << i)) for s, m in states]
    return states


def vector_subsets(values):
    states = [((0,) * len(values[0]), 0)]
    for i, x in enumerate(values):
        states += [(tuple(a + b for a, b in zip(s, x)), m | (1 << i))
                   for s, m in states]
    return states


def primitive(v):
    d = reduce(gcd, v)
    return [x // d for x in v] if d else v


def remainder(vector, basis):
    v = list(vector)
    for pivot, row in basis:
        if v[pivot]:
            a, c = v[pivot], row[pivot]
            v = primitive([c * x - a * y for x, y in zip(v, row)])
    return v


def affine_closure(rows, mask):
    # Each row is an augmented incidence coordinate (1, reduced incidence).
    basis = []
    for i, row in enumerate(rows):
        if (mask >> i) & 1:
            v = remainder(row, basis)
            if any(v):
                pivot = next(j for j, x in enumerate(v) if x)
                basis.append((pivot, primitive(v)))
                basis.sort()
    result = 0
    for i, row in enumerate(rows):
        if not any(remainder(row, basis)):
            result |= 1 << i
    return result, len(basis)


def incidence(name):
    p = BY_NAME[name]
    return tuple(int(p[i] == j) for i in range(5) for j in range(5))


def names_from_mask(names, mask):
    return [name for i, name in enumerate(names) if (mask >> i) & 1]


def endpoint_slices():
    results = []
    expected_balanced = [13419, 1437, 1242, 3609, 13419]
    expected_closed = [216, 23, 24, 92, 216]
    for r in range(5):
        names = [name for name in NAMES if int(name[0]) == r]
        ps = [BY_NAME[name] for name in names]
        cols = [j for j in range(5) if j != r]
        rows = [[1] + [int(p[i] == c) for i in range(1, 4) for c in cols[:3]]
                for p in ps]
        weights = [sign(p) * prod(i ** p[i] for i in range(1, 5)) for p in ps]
        for name, weight in zip(names, weights):
            require(POLYS[name][r] == weight, 'Root-weight/coefficient mismatch')
            require(not any(POLYS[name][:r]), 'Incorrect root order')
        positive = [i for i, w in enumerate(weights) if w > 0]
        negative = [i for i, w in enumerate(weights) if w < 0]
        require(len(positive) == len(negative) == 12, 'Unbalanced sign classes')
        right = defaultdict(list)
        for value, mask in scalar_subsets([-weights[i] for i in negative]):
            right[value].append(mask)
        total, closed = 0, []
        for value, pmask in scalar_subsets([weights[i] for i in positive]):
            for nmask in right.get(value, ()):
                if not (pmask or nmask):
                    continue
                mask = sum(1 << i for j, i in enumerate(positive) if (pmask >> j) & 1)
                mask += sum(1 << i for j, i in enumerate(negative) if (nmask >> j) & 1)
                total += 1
                closure, rank = affine_closure(rows, mask)
                if closure == mask:
                    members = names_from_mask(names, mask)
                    coeffs = poly_sum(members)
                    require(any(coeffs), 'A fixed-endpoint cancelling fiber was found')
                    order = next(i for i, x in enumerate(coeffs) if x)
                    closed.append({'members': members, 'augmented_rank': rank,
                                   'root_order_after_factoring': order - r})
        require(total == expected_balanced[r], 'Scalar subset count changed')
        require(len(closed) == expected_closed[r], 'Affine-closed count changed')
        expected_orders = {1: expected_closed[r] - 1, 2: 1} if r != 2 else {1: 24}
        require(dict(Counter(x['root_order_after_factoring'] for x in closed)) == expected_orders,
                'Unexpected derivative multiplicities')
        results.append({'minimum_exponent': r, 'balanced_count': total,
                        'closed_count': len(closed),
                        'closed_by_size': dict(sorted(Counter(len(x['members']) for x in closed).items())),
                        'closed_root_orders': dict(sorted(Counter(x['root_order_after_factoring'] for x in closed).items())),
                        'closed_sets': closed})
    return results


def pair_completion(slices):
    global_rows = [[1] + [int(p[i] == c) for i in range(4) for c in range(4)] for p in PERMS]
    results = []
    certificates = {
        18: {'outside': '31024', 'terms': [[1, '30124'], [1, '41032'], [-1, '40132']]},
        24: {'outside': '30412', 'terms': [[1, '30421'], [1, '40312'], [-1, '40321']]},
        20: {'outside': '30412', 'terms': [[1, '31402'], [1, '40213'], [-1, '41203']]},
    }
    for s in range(1, 5):
        names = [name for name in NAMES if int(name[0]) == s]
        left = vector_subsets([POLYS[name] for name in names[:12]])
        right = defaultdict(list)
        for value, mask in vector_subsets([POLYS[name] for name in names[12:]]):
            right[value].append(mask)
        for r in range(s):
            matches, passing = [], 0
            for source in slices[r]['closed_sets']:
                first = poly_sum(source['members'])
                if any(first[:s]):
                    continue
                passing += 1
                for value, lmask in left:
                    target = tuple(-a - b for a, b in zip(first, value))
                    for rmask in right.get(target, ()):
                        mask = lmask | (rmask << 12)
                        if not mask:
                            continue
                        members = source['members'] + names_from_mask(names, mask)
                        require(not any(poly_sum(members)), 'Nonzero purported completion')
                        fullmask = sum(1 << i for i, name in enumerate(NAMES) if name in members)
                        closure, rank = affine_closure(global_rows, fullmask)
                        require(closure != fullmask, 'A complete real cancelling fiber was found')
                        require((r, s) == (3, 4), 'Unexpected pair with a polynomial completion')
                        cert = certificates[len(members)]
                        require(cert['outside'] not in members, 'Certificate outsider is a member')
                        require(all(name in members for _, name in cert['terms']), 'Certificate source missing')
                        require(sum(c for c, _ in cert['terms']) == 1, 'Certificate is not affine')
                        require(all(sum(c * incidence(name)[j] for c, name in cert['terms'])
                                    == incidence(cert['outside'])[j] for j in range(25)),
                                'Incorrect incidence certificate')
                        support = {(i, int(name[i])) for name in members for i in range(5)}
                        require(all((i, int(cert['outside'][i])) in support for i in range(5)),
                                'Certificate outsider not supported')
                        # Independent direct-product evaluations at 11 points.
                        for L in range(1, 12):
                            require(sum(sign(BY_NAME[name]) * prod((L+i) ** BY_NAME[name][i] for i in range(5))
                                        for name in members) == 0, 'Direct evaluation disagrees')
                        matches.append({'members': members, 'size': len(members),
                                        'augmented_rank': rank, 'affine_closure_size': closure.bit_count(),
                                        'affine_certificate': cert})
            results.append({'row_support': [r, s], 'gap_passing_slices': passing,
                            'polynomial_zero_completions': len(matches), 'candidates': matches})
    require(sum(len(x['candidates']) for x in results) == 3, 'Unexpected total completions')
    require(sorted(x['size'] for y in results for x in y['candidates']) == [18, 20, 24],
            'Unexpected completion cardinalities')
    return results


def check_row_reversal():
    # f_p(-4-L) = f_{p reversed}(L): verify all exact coefficient vectors too.
    for p in PERMS:
        original = POLYS[''.join(map(str, p))]
        transformed = tuple(sum(original[k] * comb(k, j) * (-4) ** (k-j) * (-1) ** j
                                for k in range(j, 11)) for j in range(11))
        require(transformed == POLYS[''.join(map(str, reversed(p)))], 'Row-reversal identity failed')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='ENDPOINT_CERTIFICATE.json')
    args = parser.parse_args()
    slices = endpoint_slices()
    pairs = pair_completion(slices)
    check_row_reversal()
    result = {'claim': 'Every nonempty cancelling complete real edge-cost fiber in canonical n=5 uses at least three columns in each endpoint row.',
              'status': 'exact finite verification passed',
              'balanced_slice_total': sum(x['balanced_count'] for x in slices),
              'closed_slice_total': sum(x['closed_count'] for x in slices),
              'slices': slices, 'two_column_completions': pairs,
              'row_reversal_checked': 120,
              'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path(args.output).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('slices', 'two_column_completions')}, indent=2))
    print('Pair counts:', [(x['row_support'], x['gap_passing_slices'], x['polynomial_zero_completions']) for x in pairs])


if __name__ == '__main__':
    main()
