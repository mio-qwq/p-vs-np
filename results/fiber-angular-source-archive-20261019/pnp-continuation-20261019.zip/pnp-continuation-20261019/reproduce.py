#!/usr/bin/env python3
"""Replay exact checks in an isolated temporary copy. Never launch a solver."""
from pathlib import Path
from math import comb
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
AUDIT = 'sparse-fiber-one-audit-20261019'
ONE = 'sparse-fiber-one-20261019'
TWO = 'sparse-fiber-two-20261019'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def verify_integrity():
    count = 0
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = ROOT / name
        require(path.resolve().is_relative_to(ROOT), 'Unsafe manifest path')
        require(path.is_file() and sha(path) == digest, 'Integrity mismatch: '+name)
        count += 1
    return count


def main():
    integrity_count = verify_integrity()
    manifest = read(ROOT/'CHECKPOINT_MANIFEST.json')
    runs = []
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    env.pop('PYTHONOPTIMIZE', None)
    with tempfile.TemporaryDirectory(prefix='pnp-checkpoint-replay-') as td:
        work = Path(td)
        for module in (AUDIT, ONE, TWO):
            shutil.copytree(ROOT/module, work/module)
        a, one, two = (work/module for module in (AUDIT, ONE, TWO))

        def run(label, cmd, cwd):
            result = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True)
            require(result.returncode == 0, label+' failed:\n'+result.stdout+'\n'+result.stderr)
            require(not result.stderr, label+' wrote unexpected stderr:\n'+result.stderr)
            runs.append({'check':label,'exit_code':result.returncode,
                         'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest()})
            return result.stdout

        # The standalone proof checker contains only exact local arithmetic.
        spec = importlib.util.spec_from_file_location('checkpoint_exact_checker', a/'exact_checker.py')
        checker = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(checker)
        original = [checker.COEFF[p] for p in checker.PERMS]
        centered = [tuple(sum(c[r]*comb(r,d)*(-2)**(r-d) for r in range(d,11))
                          for d in range(11)) for c in original]
        for filename, coeffs in [('original_polynomials.txt',original),('centered_polynomials.txt',centered)]:
            data = ''.join(' '.join(map(str,(checker.sign(p),)+tuple(c)))+'\n'
                           for p,c in zip(checker.PERMS,coeffs))
            (a/filename).write_text(data)
            expected = manifest['omitted_regenerable_files'][AUDIT+'/'+filename]
            require(sha(a/filename) == expected, 'Regenerated polynomial table digest mismatch')
            require(8*max(abs(c) for row in coeffs for c in row) < 2**63,
                    'C++ coefficient sum would exceed int64')

        cpp = shutil.which('g++')
        require(cpp is not None, 'A C++17 compiler named g++ is required for the independent coefficient-vector enumeration')
        run('compile-local-exact-enumerator',[cpp,'-O2','-std=c++17','-Wall','-Wextra','-pedantic',
                                            'enumerate_eight.cpp','-o','enumerate_eight'],a)
        expected_eight = (a/'eight_term_relations.txt').read_bytes()
        for basis in ('centered','original'):
            out = run('eight-enumeration-'+basis,[str(a/'enumerate_eight'),basis+'_polynomials.txt',basis+'_replayed.txt'],a)
            require(json.loads(out) == read(a/'EIGHT_ENUMERATION.json'), 'C++ summary mismatch')
            require((a/(basis+'_replayed.txt')).read_bytes() == expected_eight, 'C++ relation mismatch')
        require((a/'eight_term_relations_original_basis.txt').read_bytes() == expected_eight,
                'Original and centered saved relation certificates disagree')

        for filename, label in [('exact_checker.py','small-relations-and-complete-fiber-controls'),
                                ('verify_unique_eight.py','unique-eight-and-affine-obstruction'),
                                ('audit_model.py','independent-k1-model')]:
            ordinary = run(label+'-normal',[sys.executable,filename],a)
            optimized = run(label+'-optimized',[sys.executable,'-O',filename],a)
            require(ordinary == optimized, label+' reports differ under optimization')
            receipt = {'exact_checker.py':'SELF_TEST.json','verify_unique_eight.py':'UNIQUE_EIGHT_VERIFICATION.json',
                       'audit_model.py':'MODEL_AUDIT.json'}[filename]
            require(json.loads(ordinary) == read(ROOT/AUDIT/receipt), 'Retained receipt mismatch: '+receipt)

        semantic_normal = run('independent-k2-semantics-normal',
                              [sys.executable,'audit_verify.py','--out','REPLAY_AUDIT.json'],two)
        semantic_optimized = run('independent-k2-semantics-optimized',
                                 [sys.executable,'-O','audit_verify.py','--out','REPLAY_AUDIT.json'],two)
        require(semantic_normal == semantic_optimized, 'k2 semantic outputs differ under optimization')
        require(read(two/'REPLAY_AUDIT.json') == read(ROOT/TWO/'audit_results.json'), 'k2 semantic receipt mismatch')
        model_normal = run('independent-k2-model-normal',
                           [sys.executable,'audit_model.py','model.json','--out','REPLAY_MODEL.json'],two)
        model_optimized = run('independent-k2-model-optimized',
                              [sys.executable,'-O','audit_model.py','model.json','--out','REPLAY_MODEL.json'],two)
        require(model_normal == model_optimized, 'k2 model outputs differ under optimization')
        actual = read(two/'REPLAY_MODEL.json')
        saved = read(ROOT/TWO/'audit_model_results.json')
        actual.pop('model_path', None)
        saved.pop('model_path', None)
        require(actual == saved, 'k2 model receipt mismatch')

        # Read historical terminal receipts only. No solver code is imported.
        first = read(one/'search_result.json')
        first_summary = read(one/'RUN_REPORT.json')
        second = read(two/'result.json')
        second_audit = read(two/'audit_solver_result.json')
        require(first['status'] == second['status'] == 1, 'Unexpected historical solver status')
        require(first['has_candidate'] is False and second['candidate_returned'] is False,
                'Unexpected historical candidate')
        require(first['mathematical_infeasibility_claim'] is False and first_summary['mathematical_nonexistence_conclusion'] is False,
                'Solver receipt made an unsupported theorem claim')
        require(hashlib.sha256((one/'exact_model_rows.json').read_bytes().rstrip(b'\n')).hexdigest()
                == first['model_rows_sha256'] == first_summary['exact_model_rows_sha256'], 'k1 exact-row provenance mismatch')
        require(sha(one/'model.py') == first_summary['model_source_sha256'], 'k1 original source provenance mismatch')
        require(sha(two/'model.json') == second['model_sha256'] == second_audit['model_sha256'], 'k2 model provenance mismatch')
        require(sha(two/'result.json') == second_audit['result_sha256'], 'k2 result provenance mismatch')
        require(sha(two/'search.log') == second_audit['search_log_sha256'], 'k2 log provenance mismatch')
        nodes = {}
        for k, folder, expected in [(1,one,48451),(2,two,28228)]:
            log = (folder/'search.log').read_text()
            matches = re.findall(r'^\s+Nodes\s+(\d+)\s*$',log,re.M)
            require(matches == [str(expected)], 'Unexpected terminal node count')
            require('Time limit reached' in log and not (folder/'candidate.json').exists(), 'Terminal receipt inconsistency')
            nodes[str(k)] = expected

    print(json.dumps({'status':'PASS','integrity_files_checked':integrity_count,
        'checks':runs,'normal_and_optimized_reports_identical':True,
        'both_polynomial_tables_regenerated_byte_exact':True,
        'both_cpp_coefficient_bases_agree_with_independent_python_enumeration':True,
        'unique_eight_affine_obstruction_and_lower_bound_ten_verified':True,
        'k1_k2_original_minimum_eight_model_rows_audited':True,
        'historical_timeout_receipts_and_provenance_verified':True,
        'terminal_nodes':nodes,'new_solver_runs':0,
        'source_tree_untouched_by_replay':True,
        'scope':'Exact canonical n5 finite theorem and model/receipt audit only; no sparse-fiber infeasibility or P versus NP conclusion.'},indent=2))

if __name__ == '__main__':
    main()
