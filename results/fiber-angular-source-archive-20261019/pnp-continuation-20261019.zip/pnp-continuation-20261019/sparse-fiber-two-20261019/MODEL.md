# Canonical five-row sparse binary-color fiber: target k=2

19 October 2026. Local research only. This is a model description, not a mathematical noncancellation theorem.

## Mathematical target

For a permutation p of {0,1,2,3,4}, use

    f_p(L) = sign(p) product_i (L+i)^{p(i)}.

Seek a bipartite support graph S and red-edge set W contained in S such that the nonempty complete fiber

    F = {p: every edge (i,p(i)) is in S, and exactly two of these edges are red}

satisfies sum_(p in F) f_p(L)=0. The fiber must include every supported matching of red count two, rather than an arbitrary selected subset.

## Exact model

There are 410 binary variables: 25 support bits s_e; 25 red bits w_e; and 120 each of activation bits a_p, fiber bits y_p, and disjunction bits b_p. The exact integer matrix is exported to model.json. Its 1,382 rows include all eleven polynomial coefficients. No permutation symmetry or fixed edge color is imposed.

For each edge, impose w_e<=s_e. For each permutation p, define z_p=sum_(e in p)w_e, and impose:

    a_p <= s_e for each e in p;
    a_p >= sum_(e in p)s_e - 4;
    y_p <= a_p;
    z_p + 6 y_p <= 8;
    z_p - 6 y_p >= -4;
    z_p - 6 a_p + 6 y_p + 6 b_p >= -3;
    z_p + 6 a_p - 6 y_p + 6 b_p <= 13.

The first six support rows make a_p the exact conjunction of its five support bits. If y_p=1, the two cost rows force z_p=2. If a_p=1 and y_p=0, the disjunction rows require either z_p>=3 (b_p=0) or z_p<=1 (b_p=1). If a_p=y_p=0, both choices of b_p allow every integer z_p in [0,5]. Thus, after existentially choosing b_p, these rows are exactly the predicate y_p=1 if and only if a_p=1 and z_p=2. A finite truth table checks all 24 combinations of a_p,y_p,z_p and both choices of b_p; activation checks cover all 32 support patterns.

Impose s_e<=sum_(p containing e)y_p. Along with activation, this sets S equal to the union of fiber edges. This does not lose any counterexample: delete an edge used by no member of an alleged complete target fiber. No member disappears, and removing an edge creates no new matching. Iterate until only the union remains. Original red colors on retained edges are preserved, and removed edges have w_e=0.

Impose sum_p y_p>=8, using the pre-existing exact minimum-cardinality theorem for nonempty canonical n=5 binary zero relations. The objective minimizes sum_p y_p but imposes no upper bound, so it does not exclude a larger fiber.

## Exact polynomial data

Use the invertible substitution t=L+2. Expand sign(p) product_i(t+i-2)^{p(i)} with exact integer binomial coefficients, in ascending powers of t. Each polynomial has degree ten. The largest absolute coefficient over the complete 120-by-11 matrix is 368; no row scaling or floating approximation is needed to construct the data. For each degree d=0,...,10, impose the exact integer row

    sum_p coefficient(p,d) y_p = 0.

The numerical solver necessarily receives double-precision representations of these small integers. A solver result remains only a proposal until exact checking.

## Symmetry and reduction limits

Color complementation on retained support sends z_p to 5-z_p. Hence a target-two fiber becomes target three, not target two. There is no extra fixed blue edge in this model. Targets zero and five reduce to a support determinant on the monochromatic subgraph; the earlier exact support-determinant exclusion is separate research, not established by this search. Together with complementation this explains why k=1 and k=2 are the remaining canonical targets, but this run treats only k=2.

## Reproducibility and evidentiary limits

search.py constructs the matrix, exports it, and runs installed SciPy/HiGHS with a 180-second solver time limit. It does not install software, alter repositories, or modify frozen release materials. Running it starts another numerical search, so inspect existing result.json and search.log first.

If an incumbent is returned, candidate.json records the rounded binary assignment, exact row residual checks, support, colors, all supported matchings, all complete-fiber members, and all eleven coefficient sums. A separate auditor must independently verify any claimed candidate. Floating feasibility alone is insufficient; infeasibility, timeout, and absence of an incumbent do not prove the mathematical assertion.

Useful recovery conditions are either an exact verified witness or a genuinely exhaustive, independently checkable exclusion certificate. Longer or differently parameterized numerical searches may produce candidates but do not supply such an exclusion by themselves. Any renewed search should state its time or work bound, preserve complete-fiber constraints, avoid invalid symmetry fixing, and require exact verification of every candidate.
