#!/usr/bin/env python3
"""Bounded candidate search, never a mathematical infeasibility certificate."""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from pathlib import Path
import time

import numpy as np
import scipy
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csc_array

HERE = Path(__file__).resolve().parent
N, K, M = 5, 2, 6
PERMS = list(itertools.permutations(range(N)))
S, W, A, Y, B = 0, 25, 50, 170, 290
NVARS = 410


def multiply(c, d):
    out = [0] * (len(c) + len(d) - 1)
    for i, ci in enumerate(c):
        for j, dj in enumerate(d):
            out[i + j] += ci * dj
    return out


def coefficients(p):
    """Exact signed coefficients, ascending powers of t=L+2."""
    inversions = sum(p[i] > p[j] for i in range(N) for j in range(i + 1, N))
    out = [-1 if inversions % 2 else 1]
    for i, exponent in enumerate(p):
        out = multiply(out, [math.comb(exponent, d) * (i - 2) ** (exponent - d)
                             for d in range(exponent + 1)])
    if len(out) != 11:
        raise RuntimeError("Unexpected degree")
    return out


def build_model():
    rows = []

    def add(name, terms, lower=None, upper=None):
        # Combine duplicate columns explicitly, so exported rows are canonical.
        combined = {}
        for col, value in terms:
            combined[col] = combined.get(col, 0) + value
        rows.append({"name": name, "terms": [[col, value] for col, value in sorted(combined.items()) if value],
                     "lower": lower, "upper": upper})

    edge_lists = [[5 * i + p[i] for i in range(N)] for p in PERMS]
    coeffs = [coefficients(p) for p in PERMS]

    for e in range(25):
        add(f"red_supported:{e}", [(W + e, 1), (S + e, -1)], upper=0)
    for q, edges in enumerate(edge_lists):
        for e in edges:
            add(f"activation_upper:{q}:{e}", [(A + q, 1), (S + e, -1)], upper=0)
        add(f"activation_lower:{q}", [(A + q, 1)] + [(S + e, -1) for e in edges], lower=-4)
        add(f"fiber_active:{q}", [(Y + q, 1), (A + q, -1)], upper=0)
        z = [(W + e, 1) for e in edges]
        add(f"fiber_cost_upper:{q}", z + [(Y + q, M)], upper=K + M)
        add(f"fiber_cost_lower:{q}", z + [(Y + q, -M)], lower=K - M)
        add(f"outside_positive:{q}", z + [(A + q, -M), (Y + q, M), (B + q, M)], lower=K + 1 - M)
        add(f"outside_negative:{q}", z + [(A + q, M), (Y + q, -M), (B + q, M)], upper=K - 1 + 2 * M)
    for e in range(25):
        add(f"support_is_fiber_union:{e}", [(S + e, 1)] + [(Y + q, -1) for q, edges in enumerate(edge_lists) if e in edges], upper=0)
    add("fiber_size_at_least_8", [(Y + q, 1) for q in range(120)], lower=8)
    for d in range(11):
        add(f"coefficient:{d}", [(Y + q, coeffs[q][d]) for q in range(120)], lower=0, upper=0)

    model = {"n": N, "k": K, "big_M": M, "n_variables": NVARS,
             "all_variables_binary": True, "coefficient_variable": "t=L+2",
             "coefficient_order": "ascending degree 0..10",
             "blocks": {"s": [0, 25], "w": [25, 50], "a": [50, 170], "y": [170, 290], "b": [290, 410]},
             "permutations": [list(p) for p in PERMS], "signed_coefficients": coeffs,
             "objective": "minimize fiber cardinality", "rows": rows}
    return model


def exact_candidate(model, x):
    """First exact screening; independent auditor verification is still required."""
    rounded = [int(round(float(v))) for v in x]
    result = {"maximum_distance_to_integer": max(abs(float(v) - r) for v, r in zip(x, rounded)),
              "rounded_vector": rounded, "exact_row_failures": []}
    if any(r not in (0, 1) for r in rounded):
        result["error"] = "Rounded variable outside binary range"
        return result
    for row in model["rows"]:
        value = sum(rounded[j] * a for j, a in row["terms"])
        if ((row["lower"] is not None and value < row["lower"]) or
                (row["upper"] is not None and value > row["upper"])):
            result["exact_row_failures"].append({"name": row["name"], "value": value})
    support = rounded[S:S + 25]
    red = rounded[W:W + 25]
    actual_active = [int(all(support[5 * i + p[i]] for i in range(N))) for p in PERMS]
    costs = [sum(red[5 * i + p[i]] for i in range(N)) for p in PERMS]
    actual_fiber = [int(active and cost == K) for active, cost in zip(actual_active, costs)]
    selected = rounded[Y:Y + 120]
    sums = [sum(coefficients(p)[d] * selected[q] for q, p in enumerate(PERMS)) for d in range(11)]
    union = [int(any(selected[q] and p[e // 5] == e % 5 for q, p in enumerate(PERMS))) for e in range(25)]
    result.update({"support_matrix": [support[i:i + 5] for i in range(0, 25, 5)],
                   "red_matrix": [red[i:i + 5] for i in range(0, 25, 5)],
                   "active_permutations": ["".join(map(str, p)) for p, a in zip(PERMS, actual_active) if a],
                   "fiber_permutations": ["".join(map(str, p)) for p, y in zip(PERMS, actual_fiber) if y],
                   "selected_permutations": ["".join(map(str, p)) for p, y in zip(PERMS, selected) if y],
                   "coefficient_sums": sums,
                   "activation_exact": actual_active == rounded[A:A + 120],
                   "complete_fiber_exact": actual_fiber == selected,
                   "union_support_exact": union == support})
    result["exact_valid_candidate"] = bool(not result["exact_row_failures"] and any(selected)
                                          and all(v == 0 for v in sums)
                                          and result["activation_exact"] and result["complete_fiber_exact"]
                                          and result["union_support_exact"])
    return result


def main():
    model = build_model()
    model_path = HERE / "model.json"
    model_path.write_text(json.dumps(model, indent=2) + "\n")
    print(f"Exported {len(model['rows'])} exact integer constraints and {NVARS} binary variables", flush=True)
    print(f"Max absolute polynomial coefficient: {max(abs(v) for c in model['signed_coefficients'] for v in c)}", flush=True)
    ii, jj, vv = [], [], []
    lower, upper = [], []
    for i, row in enumerate(model["rows"]):
        lower.append(-np.inf if row["lower"] is None else row["lower"])
        upper.append(np.inf if row["upper"] is None else row["upper"])
        for col, value in row["terms"]:
            ii.append(i); jj.append(col); vv.append(value)
    matrix = csc_array((np.array(vv, dtype=float), (np.array(ii, dtype=np.int32), np.array(jj, dtype=np.int32))),
                       shape=(len(model["rows"]), NVARS))
    c = np.zeros(NVARS)
    c[Y:Y + 120] = 1
    options = {"time_limit": 180.0, "mip_rel_gap": 0.0, "presolve": True, "disp": True}
    started = time.monotonic()
    result = milp(c=c, integrality=np.ones(NVARS), bounds=Bounds(np.zeros(NVARS), np.ones(NVARS)),
                  constraints=LinearConstraint(matrix, lower, upper), options=options)
    elapsed = time.monotonic() - started
    report = {"task": "canonical n=5 complete sparse binary-color cancellation fiber, target k=2",
              "scipy_version": scipy.__version__, "numpy_version": np.__version__,
              "solver_options": options, "elapsed_seconds": elapsed,
              "status": int(result.status), "message": str(result.message),
              "success": bool(result.success), "candidate_returned": result.x is not None,
              "objective": None if result.fun is None else float(result.fun),
              "mip_node_count": None if getattr(result, "mip_node_count", None) is None else int(result.mip_node_count),
              "mip_gap": None if getattr(result, "mip_gap", None) is None else float(result.mip_gap),
              "model_sha256": hashlib.sha256(model_path.read_bytes()).hexdigest(),
              "interpretation": "Floating solver search only. Infeasibility, timeout, or absence of an incumbent is not a mathematical exclusion."}
    if result.x is not None:
        candidate = exact_candidate(model, result.x)
        (HERE / "candidate.json").write_text(json.dumps(candidate, indent=2) + "\n")
        report["local_exact_candidate_screen"] = candidate.get("exact_valid_candidate", False)
    (HERE / "result.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
