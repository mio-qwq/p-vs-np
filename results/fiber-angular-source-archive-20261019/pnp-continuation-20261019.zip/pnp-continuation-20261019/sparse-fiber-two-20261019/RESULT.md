# Target-two sparse-fiber search: audited model, no witness found

19 October 2026, UTC.

## Result

The single bounded canonical n=5, target-k=2 search reached its 180-second limit without returning any incumbent or candidate. SciPy measured 180.0115 seconds. HiGHS reported 28,228 processed nodes, primal bound infinity, and dual bound 8. The dual bound merely matches the already-proved cardinality lower bound; it is not a noncancellation certificate.

**This is neither a counterexample nor a proof of nonexistence.** The sparse target-two question remains open after this run. There was no candidate to subject to witness verification, and no further numerical search was launched.

## What was established

The direct complete-fiber model was implemented with 410 binary variables and 1,382 exact integer constraints. It includes support, binary color, exact matching activation, both directions of complete-fiber membership, support equal to the fiber union, a safely proved minimum size of eight, and all eleven cancellation coefficient equations. The polynomial basis is t=L+2, with coefficient magnitudes at most 368. No edge was fixed blue or red.

An independent audit reconstructed and matched every constraint and all 1,320 coefficient entries. It independently verified the logical predicates by finite truth tables and rechecked the minimum-cardinality cut with exact evaluation-vector subset sums. Audit checks pass with normal Python and python -O. Model correctness establishes that a genuine feasible binary solution would meet the intended mathematical conditions; it does not certify the numerical solver's lack of a solution.

## Files and reproduction

- search.py: model generator and the single 180-second candidate search.
- model.json: complete exact integer export, SHA-256 c202f07b78ec86c61de994ab8f0ea9ccb74632939cf1f559c060c046d17299dd.
- result.json and search.log: actual solver termination and complete run log.
- MODEL.md: mathematical model, lossless restrictions, and scope.
- AUDIT.md: independently prepared mathematical and implementation audit.
- audit_verify.py: standard-library semantic and polynomial checker; can verify future candidate JSON without importing search code.
- audit_model.py: independent reconstruction of the entire model and minimum-size justification.
- audit_results.json and audit_model_results.json: independently obtained audit receipts.

The audit's original files remain in ../sparse-fiber-two-audit-20261019. Its original script name is verify.py; the local mirrored copy is audit_verify.py. From this directory, reproduce checks without restarting search:

    python audit_verify.py --out audit_results_recheck.json
    python -O audit_verify.py --out audit_results_recheck_optimized.json
    python audit_model.py model.json --out audit_model_results_recheck.json
    python -O audit_model.py model.json --out audit_model_results_recheck_optimized.json

Running search.py starts a new solver run. Inspect the retained result before doing so. Installed packages were SciPy 1.17.0 and NumPy 2.3.5; the run log identifies HiGHS 1.8.0.

## Recovery conditions

A useful next result would be either an exact nonempty complete-fiber witness, independently checked over all 120 matchings and all coefficients, or a genuine exact exclusion certificate covering the missing sparse/color cases. A new bounded numerical attempt may be useful for candidate discovery, but elapsed time, node counts, and floating-point infeasibility cannot settle the mathematics. Any changed search must retain complete-fiber membership and avoid imposing color-complement symmetry while holding k=2 fixed.

Only local research and verification files were written. No repository, pull request, merge, tag, release, or frozen release material was changed.
