# Exact independent audit of the canonical sparse binary-fiber model, target 2

19 October 2026. Local research and verification only. No repository, release, remote file, account, or external state was changed.

## Verdict

**The mathematical model and its exact integer export pass.** This is an audit of a search model, not a nonexistence theorem. A floating-point solver may propose a witness; its infeasibility status, timeout, or absence of an incumbent cannot establish that sparse binary-color cancellation is impossible.

The audited export is `../sparse-fiber-two-20261019/model.json`, with SHA-256

`c202f07b78ec86c61de994ab8f0ea9ccb74632939cf1f559c060c046d17299dd`.

It contains 410 binary variables, 1382 constraints, all 120 permutations, and no symmetry restriction. Every constraint was checked against the specified integer inequality. The source's conversion to SciPy uses binary bounds, integer integrality flags, and all exported rows. The objective minimizes fiber cardinality; it does not restrict which feasible witnesses exist.

## Canonical polynomial and independently checked matrix

Rows and exponent columns are labeled 0 through 4. For a permutation p,

`f_p(L) = sign(p) product_i (L+i)^{p(i)}`.

Every term has degree ten. Eleven coefficients are therefore necessary and sufficient to check an identity. The solver uses the invertible change of variable `t=L+2`, giving

`f_p(t-2) = sign(p) product_i (t+i-2)^{p(i)}`.

The coefficient matrix has 11 rows and 120 columns, in lexicographic permutation order and ascending polynomial degree. All 1320 entries agree with an independent standard-library reconstruction by repeated multiplication by linear factors, with signs computed from permutation cycle counts. The solver source instead uses binomial expansions and inversion counts. Maximum coefficient magnitude is 368. This shift is exact and does not change cancellation.

As separate checks, each column was evaluated at eleven distinct integers using direct products, and the signed sum of all 120 columns was checked to equal the Vandermonde constant 288. The known eight-term zero subset also reproduces exactly.

## Support activation and complete-fiber equivalence

For each permutation p, let `z_p` be the sum of the five red indicators. The inequalities

- `a_p <= s_e` for each of its five edges;
- `a_p >= sum_(e in p) s_e - 4`

make `a_p` exactly the indicator that all five edges are present. This conclusion uses binary variable domains. The red-supported constraints `w_e <= s_e` rule out a red but absent edge.

The cost constraints force `y_p=1` to imply `a_p=1` and `z_p=k`. For an active matching with `y_p=0`, the two outside inequalities reduce to one of:

- `b_p=0`: `1 <= z_p-k <= 5`;
- `b_p=1`: `-5 <= z_p-k <= -1`.

Thus an active matching of cost k cannot be omitted. Conversely, every supported matching of another cost has an admissible b value, and absent matchings must have y=0. Therefore the y variables encode the entire fiber, rather than an arbitrary cancellation subset.

The independent checker exhausts all 243 absent/blue/red assignments on a matching's five edges, both a and y bits, both choices of b, and every target k from 0 through 5. It also tests all advertised harmless-disjunction boundary cases. All 5832 activation/fiber cases and 144 boundary cases pass. There is no integrality-tolerance assumption in these checks.

## Big-M boundary

Since `0 <= z_p,k <= 5`, the difference lies in [-5,5]. With M=6, when `(a,y)` is `(0,0)` or `(1,1)`, the disjunctive inequalities are harmless for either b: their most restrictive lower bound is -5 and their most restrictive upper bound is 5. At k=2 the actual difference range is [-2,3], so M=6 is conservative but valid. No boundary excludes a legal matching state.

## Union-support restriction is lossless for existence

The inequalities `s_e <= sum_(p containing e) y_p`, together with y implying activation, make support exactly the union of the target-fiber matchings.

For any valid cancellation fiber F on a larger graph, delete every edge not used by F and restrict the old binary coloring to the remaining edges. Every matching in F survives with its cost unchanged. Deleting edges cannot introduce a matching. Every surviving target-cost matching was already a target-cost matching in the old graph, hence belonged to F. Thus F remains exactly the same complete fiber. The restriction loses no possible witness for the existence question.

It does not say arbitrary added edges preserve a binary fiber, nor does it identify sparse fibers with full-graph fibers.

## The minimum-cardinality cut is independently justified

The leading coefficient of each term is its permutation sign. A zero subset must contain equally many even and odd terms. To exclude cardinalities 2, 4, and 6, this audit independently compares sums of unsigned direct-product evaluation vectors at L=-5,...,5 for one, two, and three terms from each parity class.

The respective numbers of vectors on each side are 60, 1770, and 34220. Each cross-parity intersection is empty. Eleven evaluations determine a polynomial of degree at most ten, so this is an exact finite proof. Consequently `sum y >= 8` is safe. This recheck does not import the earlier minimum-cardinality checker or either solver's coefficient generator.

## Targets and scope

Complement colors only on supported edges: `w'_e=s_e-w_e`. Every active matching has five edges, so its red count becomes `5-z_p`. Thus target 2 is equivalent to target 3, and target 1 is equivalent to target 4. This is not permission to impose an arbitrary fixed edge color while retaining target 2.

Target 0 is the full perfect-matching family on the blue subgraph, and target 5 is the full family on the red subgraph. Their exclusion depends on the separately certified canonical n=5 support-determinant theorem. The present audit does not re-enumerate its 2^25 supports.

Existing full-support color results and full-determinant support results do not exhaust the intermediate sparse/color pairs. Nothing here extends to arbitrary offsets, exponents, larger dimensions, or P versus NP.

## Candidate verification and reproduction

`verify.py` uses only the Python standard library. For any candidate it enumerates all 120 permutations afresh, checks supported edges and red counts, forms the full target fiber, verifies any claimed selected set, computes its union, and checks all eleven coefficients plus eleven independently computed direct-product sums. It rejects malformed claimed fibers and empty cancellation claims. If a 410-bit vector is supplied, it also checks support/color agreement, activation, all fiber bits, disjunction bits, minimum size and the union restriction. It never imports solver code.

The accepted input may be the searcher's candidate JSON (`support_matrix`, `red_matrix`, `rounded_vector`, `fiber_permutations`, `selected_permutations`), or a simple JSON with `target`, `support_mask` and `red_mask`. A bit at index `5*i+j` is edge (i,j). Target defaults to 2 for this audit.

Run:

- `python verify.py`
- `python -O verify.py --out audit_results_optimized.json`
- `python audit_model.py ../sparse-fiber-two-20261019/model.json`
- `python -O audit_model.py ../sparse-fiber-two-20261019/model.json --out model_audit_results_optimized.json`
- `python verify.py path/to/candidate.json --out candidate_results.json`

Normal and optimized-mode audit receipts are byte-identical. All validation uses explicit exceptions rather than Python assertions. A candidate report's `valid_cancellation_witness` must be true before a mathematical witness is reported. A correct search model without such a verified candidate is only a correctly formulated attempt.

## Recovery conditions if the bounded search returns no witness

Record the actual solver termination and keep the sparse target-2 question open. Useful next evidence would be a new exact candidate, a reproducible exact infeasibility certificate for an explicitly bounded subcase, or an analytic obstruction whose assumptions cover the missing sparse/color cases. Increasing a floating-point time limit alone does not strengthen the mathematical conclusion.

## Terminal run receipt

The bounded run ended after 180.0115 seconds with SciPy status 1 and the HiGHS message “Time limit reached”; no candidate was returned and no candidate file exists. The retained log reports 28,228 nodes. Its model hash agrees with the exact audited export. `solver_result_audit.json` records the result and log hashes. There is consequently no new cancellation witness to verify. Sparse target-2 feasibility remains unresolved.
