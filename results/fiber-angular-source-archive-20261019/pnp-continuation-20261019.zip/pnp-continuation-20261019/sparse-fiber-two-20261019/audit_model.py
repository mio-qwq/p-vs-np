#!/usr/bin/env python3
"""Audit the exported k=2 MILP; never imports or executes the solver source."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
from audit_verify import PERMS, check, direct, parity_cycles, poly


def smaller_relations():
    # Eleven exact values determine a polynomial of degree at most ten.
    # Compare unsigned products across the two parity classes, independently
    # of both this audit's and the model builder's coefficient expansions.
    ev, od = [], []
    for p in PERMS:
        sign = parity_cycles(p)
        vector = tuple(sign * direct(p, x) for x in range(-5, 6))
        (ev if sign == 1 else od).append(vector)
    report = []
    for k in (1, 2, 3):
        sets = []
        for terms in (ev, od):
            sums = {tuple(sum(terms[j][d] for j in indices) for d in range(11))
                    for indices in itertools.combinations(range(60), k)}
            sets.append(sums)
        intersection = sets[0] & sets[1]
        check(not intersection, 'There is a relation with fewer than eight terms')
        report.append({'terms_per_parity': k, 'distinct_even_vectors': len(sets[0]),
                       'distinct_odd_vectors': len(sets[1]), 'intersection_count': 0})
    return report


def audit(path):
    model = json.loads(path.read_text())
    check(model['n'] == 5 and model['k'] == 2 and model['big_M'] == 6, 'wrong problem parameters')
    check(model['n_variables'] == 410 and model['all_variables_binary'] is True, 'wrong variable domain')
    check(model['blocks'] == {'s':[0,25], 'w':[25,50], 'a':[50,170], 'y':[170,290], 'b':[290,410]}, 'wrong block indexing')
    check(model['permutations'] == [list(p) for p in PERMS], 'permutation enumeration mismatch')
    check(model['coefficient_variable'] == 't=L+2' and model['coefficient_order'] == 'ascending degree 0..10', 'coefficient metadata mismatch')
    centered = [poly(p, -2) for p in PERMS]
    check(model['signed_coefficients'] == centered, 'coefficient matrix mismatch')
    rows = model['rows']
    names = [r['name'] for r in rows]
    check(len(rows) == 1382 and len(names) == len(set(names)), 'wrong row count or duplicate names')
    lookup = {r['name']:r for r in rows}
    reviewed = set()

    def row(name, terms, lo=None, hi=None):
        check(name in lookup, 'missing constraint '+name)
        expected = sorted([list(t) for t in terms if t[1]])
        r = lookup[name]
        check(r['terms'] == expected and r['lower'] == lo and r['upper'] == hi, 'wrong algebraic constraint '+name)
        check(all(type(j) is int and type(c) is int and 0 <= j < 410 for j,c in r['terms']), 'noninteger coefficient or bad variable index '+name)
        reviewed.add(name)

    for e in range(25):
        row('red_supported:'+str(e), [(e,-1),(25+e,1)], hi=0)
    for q,p in enumerate(PERMS):
        edges = [5*i+p[i] for i in range(5)]
        for e in edges:
            row(f'activation_upper:{q}:{e}', [(e,-1),(50+q,1)], hi=0)
        row('activation_lower:'+str(q), [(e,-1) for e in edges]+[(50+q,1)], lo=-4)
        row('fiber_active:'+str(q), [(50+q,-1),(170+q,1)], hi=0)
        cost = [(25+e,1) for e in edges]
        row('fiber_cost_upper:'+str(q), cost+[(170+q,6)], hi=8)
        row('fiber_cost_lower:'+str(q), cost+[(170+q,-6)], lo=-4)
        row('outside_positive:'+str(q), cost+[(50+q,-6),(170+q,6),(290+q,6)], lo=-3)
        row('outside_negative:'+str(q), cost+[(50+q,6),(170+q,-6),(290+q,6)], hi=13)
    for e in range(25):
        i,j = divmod(e,5)
        row('support_is_fiber_union:'+str(e), [(e,1)]+[(170+q,-1) for q,p in enumerate(PERMS) if p[i]==j], hi=0)
    row('fiber_size_at_least_8', [(170+q,1) for q in range(120)], lo=8)
    for d in range(11):
        row('coefficient:'+str(d), [(170+q,centered[q][d]) for q in range(120)], lo=0,hi=0)
    check(reviewed == set(names), 'an unreviewed constraint remains')
    return {'model_path': str(path), 'model_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'audited_rows': len(reviewed), 'binary_variables':410,
            'all_1320_coefficients_match_independent_linear_factor_expansion':True,
            'centered_max_abs_coefficient':max(abs(v) for c in centered for v in c),
            'minimum_cardinality_independent_evaluation_check':smaller_relations(),
            'export_passes':True,
            'limitation':'Model correctness and exact candidate validation do not turn floating-point absence, timeout, or infeasibility into a theorem.'}


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('model', type=Path)
    parser.add_argument('--out', type=Path, default=Path(__file__).with_name('model_audit_results.json'))
    args=parser.parse_args()
    result=audit(args.model)
    args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
