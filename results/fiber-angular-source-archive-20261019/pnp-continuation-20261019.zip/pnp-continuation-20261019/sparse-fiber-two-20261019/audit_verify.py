#!/usr/bin/env python3
"""Independent exact n=5 sparse binary-fiber audit. Standard library only.

Candidate JSON: target (0..5), support_mask, red_mask, optional fiber strings.
Alternatively support and red may be 5-by-5 0/1 matrices. Optional vector is
410 solver bits in s,w,a,y,b block order. No solver module is imported.
"""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
from pathlib import Path

N = 5
PERMS = tuple(itertools.permutations(range(N)))
FULL = (1 << 25) - 1


def check(condition, description):
    if not condition:
        raise ValueError(description)


def parity_cycles(p):
    seen = set()
    cycles = 0
    for start in range(N):
        if start in seen:
            continue
        cycles += 1
        j = start
        while j not in seen:
            seen.add(j)
            j = p[j]
    return -1 if (N - cycles) % 2 else 1


def pmask(p):
    return sum(1 << (N * i + p[i]) for i in range(N))


def poly(p, shift=0):
    # Repeated multiplication by linear factors, not binomial formulas.
    coeff = [parity_cycles(p)]
    for i in range(N):
        for _ in range(p[i]):
            product = [0] * (len(coeff) + 1)
            for d, c in enumerate(coeff):
                product[d] += (i + shift) * c
                product[d + 1] += c
            coeff = product
    check(len(coeff) == 11, 'Every canonical term must have degree ten')
    return coeff


def direct(p, x):
    value = parity_cycles(p)
    for i in range(N):
        value *= (x + i) ** p[i]
    return value


def evaluate(c, x):
    result = 0
    for a in reversed(c):
        result = x * result + a
    return result


def matrix_mask(obj, key):
    if key + '_mask' in obj:
        value = obj[key + '_mask']
        check(type(value) is int and 0 <= value <= FULL, key + '_mask must be a 25-bit nonnegative integer')
        return value
    matrix = obj[key]
    check(len(matrix) == N and all(len(row) == N for row in matrix), key + ' must be 5 by 5')
    check(all(type(x) is int and x in (0, 1) for row in matrix for x in row), key + ' must contain integer bits')
    return sum(matrix[i][j] << (N * i + j) for i in range(N) for j in range(N))


def semantic_verification(obj):
    obj = dict(obj)
    for old, new in (('support_matrix', 'support'), ('red_matrix', 'red'),
                     ('fiber_permutations', 'fiber'), ('rounded_vector', 'vector')):
        if old in obj and new not in obj:
            obj[new] = obj[old]
    k = obj.get('target', 2)
    check(type(k) is int and 0 <= k <= 5, 'target must be an integer from zero through five')
    s = matrix_mask(obj, 'support')
    w = matrix_mask(obj, 'red')
    check(w & ~s == 0, 'red edges must belong to support')
    terms = []
    union = 0
    total = [0] * 11
    points = list(range(-5, 6))
    values = [0] * len(points)
    fiber = []
    for index, p in enumerate(PERMS):
        mask = pmask(p)
        active = (mask & s) == mask
        z = (mask & w).bit_count()
        member = active and z == k
        term = {'index': index, 'permutation': ''.join(map(str, p)), 'edge_mask': mask,
                'supported': active, 'red_count': z, 'in_fiber': member,
                'sign': parity_cycles(p)}
        if member:
            fiber.append(term['permutation'])
            union |= mask
            c = poly(p)
            for d in range(11):
                total[d] += c[d]
            for j, x in enumerate(points):
                values[j] += direct(p, x)
        terms.append(term)
    if 'fiber' in obj:
        claimed = obj['fiber']
        check(len(claimed) == len(set(claimed)), 'claimed fiber contains duplicates')
        check(set(claimed) == set(fiber), 'claimed fiber is not the complete target fiber')
    if 'selected_permutations' in obj:
        check(len(obj['selected_permutations']) == len(set(obj['selected_permutations'])) and set(obj['selected_permutations']) == set(fiber), 'selected subset is not the complete target fiber')
    if 'vector' in obj:
        vector = obj['vector']
        check(len(vector) == 410 and all(type(v) is int and v in (0, 1) for v in vector), 'vector must contain exactly 410 integer bits')
        check(sum(vector[i] << i for i in range(25)) == s, 'vector support disagrees with candidate support')
        check(sum(vector[25+i] << i for i in range(25)) == w, 'vector red indicator disagrees with candidate colors')
        for j, term in enumerate(terms):
            check(vector[50+j] == int(term['supported']), 'wrong support-activation bit at permutation ' + term['permutation'])
            check(vector[170+j] == int(term['in_fiber']), 'wrong fiber bit at permutation ' + term['permutation'])
            check(constraints_ok(vector[50+j], vector[170+j], vector[290+j], term['red_count'], k), 'invalid cost-disjunction bit at permutation ' + term['permutation'])
        check(union == s, 'model vector violates union-support requirement')
        check(len(fiber) >= 8, 'model vector violates minimum-cardinality requirement')
    check(all(evaluate(total, x) == v for x, v in zip(points, values)), 'polynomial and independent direct-product sum disagree')
    return {'target': k, 'support_mask': s, 'red_mask': w,
            'support_edges': s.bit_count(), 'red_edges': w.bit_count(),
            'supported_matchings': sum(t['supported'] for t in terms),
            'fiber_count': len(fiber), 'fiber': fiber,
            'support_equals_fiber_union': union == s,
            'union_mask': union,
            'sum_coefficients_ascending': total,
            'evaluation_points': points, 'direct_product_sums': values,
            'nonempty': bool(fiber), 'zero_polynomial': all(c == 0 for c in total),
            'valid_cancellation_witness': bool(fiber) and all(c == 0 for c in total),
            'permutations': terms}


def constraints_ok(a, y, b, z, k, M=6):
    delta = z - k
    return (y <= a and -M*(1-y) <= delta <= M*(1-y)
            and delta >= 1-M*((1-a)+y+b)
            and delta <= -1+M*((1-a)+y+(1-b)))


def local_truth_table():
    # Each of five edges is absent, blue, or red: every possible local
    # (support,color) pattern. Test both possible a,y and both b values.
    checks = 0
    boundary = []
    for k in range(6):
        for pattern in itertools.product(range(3), repeat=5):
            ss = [int(t > 0) for t in pattern]
            ww = [int(t == 2) for t in pattern]
            truth_a = int(all(ss))
            z = sum(ww)
            for a in (0, 1):
                support_constraints = all(a <= v for v in ss) and a >= sum(ss)-4
                check(support_constraints == (a == truth_a), 'support conjunction failure')
                for y in (0, 1):
                    possible_b = [b for b in (0, 1) if constraints_ok(a, y, b, z, k)]
                    expected = y == int(a == 1 and z == k)
                    check(bool(possible_b) == expected, 'complete-fiber disjunction failure')
                    if support_constraints:
                        check((bool(possible_b)) == (y == int(truth_a and z == k)), 'combined semantic mismatch')
                    checks += 1
        # Test advertised harmlessness outside (a=1,y=0), for every z and b.
        for a, y in ((0, 0), (1, 1)):
            for z in range(6):
                for b in (0, 1):
                    lower = 1-6*((1-a)+y+b)
                    upper = -1+6*((1-a)+y+(1-b))
                    check(lower <= z-k <= upper, 'M=6 is not harmless')
                    boundary.append((a, y, b, z, k, lower, upper))
    return {'local_patterns_per_target': 243, 'targets': list(range(6)),
            'activation_fiber_tests': checks,
            'harmless_disjunction_boundary_tests': len(boundary), 'big_M': 6,
            'all_checks_passed': True}


def own_coefficient_checks():
    canonical = [poly(p) for p in PERMS]
    centered = [poly(p, -2) for p in PERMS]
    for j, p in enumerate(PERMS):
        inversion_sign = -1 if sum(p[a] > p[b] for a in range(5) for b in range(a+1, 5)) % 2 else 1
        check(parity_cycles(p) == inversion_sign, 'cycle and inversion parity disagree')
        for x in range(-5, 6):
            check(evaluate(canonical[j], x) == direct(p, x), 'canonical coefficient expansion mismatch')
            check(evaluate(centered[j], x) == direct(p, x-2), 'centered coefficient expansion mismatch')
    expected_constant = 1
    for a in range(5):
        for b in range(a+1, 5):
            expected_constant *= b-a
    totals = [sum(col[d] for col in canonical) for d in range(11)]
    check(totals == [expected_constant] + [0]*10, 'full determinant Vandermonde orientation failure')
    known_relation = {'03241','04123','04231','04321','12340','13240','14230','32140'}
    rel = [sum(canonical[j][d] for j, p in enumerate(PERMS) if ''.join(map(str,p)) in known_relation) for d in range(11)]
    check(rel == [0]*11, 'independent known eight-term cancellation regression failed')
    data = {'permutations': [''.join(map(str,p)) for p in PERMS],
            'canonical_coefficients_by_permutation': canonical,
            'centered_coefficients_by_permutation': centered}
    encoded = json.dumps(data, sort_keys=True, separators=(',', ':')).encode()
    return data, {'matching_count': 120, 'coefficient_count': 11,
                  'coefficient_generation': 'Repeated linear-factor multiplication; cycle parity',
                  'evaluation_crosscheck': '11 direct integer-product values per permutation, both shifts',
                  'centered_max_abs': max(abs(x) for col in centered for x in col),
                  'full_determinant_constant': expected_constant,
                  'known_eight_term_relation': 'zero in all 11 coefficients',
                  'coefficient_json_sha256': hashlib.sha256(encoded).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', nargs='?')
    parser.add_argument('--out', default=None)
    args = parser.parse_args()
    data, coefficient_audit = own_coefficient_checks()
    report = {'logical_audit': local_truth_table(), 'coefficient_audit': coefficient_audit}
    if args.candidate:
        report['candidate'] = semantic_verification(json.loads(Path(args.candidate).read_text()))
    else:
        # Complete graph, all blue: nonzero full determinant regression.
        blue = semantic_verification({'target': 0, 'support_mask': FULL, 'red_mask': 0})
        check(blue['sum_coefficients_ascending'] == [288]+[0]*10, 'all-blue regression failed')
        # Identity support, exactly two red edges: unique nonzero target fiber.
        identity = pmask(tuple(range(5)))
        singleton = semantic_verification({'target': 2, 'support_mask': identity, 'red_mask': (1<<0)|(1<<6)})
        check(singleton['fiber_count'] == 1 and singleton['support_equals_fiber_union'] and not singleton['zero_polynomial'], 'singleton regression failed')
        relation = ['03241','04123','04231','04321','12340','13240','14230','32140']
        relation_union = 0
        for name in relation:
            relation_union |= pmask(tuple(map(int, name)))
        try:
            semantic_verification({'target': 0, 'support_mask': relation_union, 'red_mask': 0, 'fiber': relation})
        except ValueError as error:
            check(str(error) == 'claimed fiber is not the complete target fiber', 'unexpected malformed-fiber rejection')
        else:
            raise ValueError('Verifier accepted an arbitrary cancellation subset as a complete fiber')
        empty = semantic_verification({'target': 2, 'support_mask': FULL, 'red_mask': 0})
        check(not empty['valid_cancellation_witness'] and empty['zero_polynomial'], 'empty-fiber rejection failed')
        report['regressions'] = {'all_blue': 'pass', 'singleton_target_two': 'pass',
                                 'arbitrary_subset_rejected': 'pass', 'empty_fiber_rejected':'pass'}
        Path(__file__).with_name('coefficients.json').write_text(json.dumps(data, indent=2)+'\n')
    out = Path(args.out) if args.out else Path(__file__).with_name('audit_results.json' if not args.candidate else 'candidate_results.json')
    out.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'candidate'}, indent=2))
    if args.candidate:
        c = report['candidate']
        print(json.dumps({k:v for k,v in c.items() if k != 'permutations'}, indent=2))
    print('Wrote', out)


if __name__ == '__main__':
    main()
