#!/usr/bin/env python3
"""Independent exact canonical n=5 complete binary-color-fiber checker.

No solver or model code is imported. Candidate input uses support and red keys,
5x5 matrices or row-major length25 vectors of exact JSON integers 0/1. Optional
fiber_permutations lists complete claimed selected permutations; optional y and a
are lexicographic length120 binary vectors. k must be the integer1.
"""
from itertools import permutations, combinations, product
from math import comb, prod
from pathlib import Path
import argparse
import hashlib
import json

N = 5
PERMS = tuple(permutations(range(N)))
FAMOUS_EIGHT = tuple(tuple(map(int, p)) for p in (
    '03241', '04123', '04231', '04321', '12340', '13240', '14230', '32140'))


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sign(p):
    return -1 if sum(p[i] > p[j] for i in range(N) for j in range(i + 1, N)) % 2 else 1


def polynomial(p):
    """Repeated multiplication by a linear factor, no binomial coefficient table."""
    out = [sign(p)]
    for i, exponent in enumerate(p):
        for _ in range(exponent):
            new = [0] * (len(out) + 1)
            for j, value in enumerate(out):
                new[j] += i * value
                new[j + 1] += value
            out = new
    require(len(out) == 11, 'Every permutation must have total degree10')
    return tuple(out)


COEFF = {p: polynomial(p) for p in PERMS}


def binary_vector(value, length, name):
    require(isinstance(value, list), name + ' must be a JSON list')
    if length == 25 and len(value) == 5 and all(isinstance(row, list) for row in value):
        require(all(len(row) == 5 for row in value), name + ' rows must have length5')
        value = [x for row in value for x in row]
    require(len(value) == length, name + ' has incorrect length')
    require(all(type(x) is int and x in (0, 1) for x in value), name + ' entries must be exact integer0/1')
    return tuple(value)


def sum_polynomials(family):
    return [sum(COEFF[p][j] for p in family) for j in range(11)]


def check_candidate(data, minimum_size=8):
    require(isinstance(data, dict), 'candidate must be a JSON object')
    require(type(data.get('k')) is int and data['k'] == 1, 'this checker requires exact integer k=1')
    s = binary_vector(data.get('support'), 25, 'support')
    w = binary_vector(data.get('red'), 25, 'red')
    errors = []
    if any(w[e] > s[e] for e in range(25)):
        errors.append('red edge outside support')
    rows = []
    active = []
    fiber = []
    for p in PERMS:
        edges = tuple(5 * i + p[i] for i in range(5))
        is_active = all(s[e] for e in edges)
        red_count = sum(w[e] for e in edges)
        in_fiber = is_active and red_count == 1
        if is_active:
            active.append(p)
        if in_fiber:
            fiber.append(p)
        rows.append({'permutation': list(p), 'sign': sign(p), 'active': is_active,
                     'red_count': red_count, 'in_target_fiber': in_fiber,
                     'coefficients_ascending': list(COEFF[p])})
    union = {5 * i + p[i] for p in fiber for i in range(5)}
    unused = [e for e in range(25) if s[e] and e not in union]
    if unused:
        errors.append('support differs from union(target_fiber): unused edges ' + str(unused))
    if len(fiber) < minimum_size:
        errors.append('target fiber has fewer than required ' + str(minimum_size) + ' members')
    if 'fiber_permutations' in data:
        claimed_raw = data['fiber_permutations']
        require(isinstance(claimed_raw, list), 'fiber_permutations must be a list')
        claimed = []
        for p in claimed_raw:
            require(isinstance(p, list) and len(p) == 5 and all(type(x) is int for x in p)
                    and sorted(p) == list(range(5)), 'invalid claimed permutation')
            claimed.append(tuple(p))
        if len(claimed) != len(set(claimed)):
            errors.append('duplicate claimed permutations')
        omitted = sorted(set(fiber) - set(claimed))
        spurious = sorted(set(claimed) - set(fiber))
        if omitted:
            errors.append('omitted target matchings: ' + str(omitted))
        if spurious:
            errors.append('claimed nontarget matchings: ' + str(spurious))
    for key, actual in (('a', active), ('y', fiber)):
        if key in data:
            vector = binary_vector(data[key], 120, key)
            expected = tuple(int(p in actual) for p in PERMS)
            if vector != expected:
                errors.append(key + ' indicator disagrees with exhaustive exact enumeration')
    coeff = sum_polynomials(fiber)
    if any(coeff):
        errors.append('complete target fiber polynomial is not identically zero')
    evaluations = {str(x): sum(sign(p) * prod((x + i) ** p[i] for i in range(5)) for p in fiber)
                   for x in range(11)}
    require(all(value == sum(coeff[j] * int(x) ** j for j in range(11))
                for x, value in evaluations.items()), 'independent direct evaluation disagrees with coefficients')
    return {'accepted': not errors, 'errors': errors, 'n': 5, 'k': 1,
            'support_edges': sum(s), 'red_edges': sum(w), 'active_permutations': len(active),
            'fiber_size': len(fiber), 'fiber_permutations': [list(p) for p in fiber],
            'unused_support_edges': unused, 'coefficients_ascending': coeff,
            'direct_evaluations_L_0_through_10': evaluations,
            'all_120_permutations': rows}


def exact_constraint_truth_table():
    cases = 0
    satisfying = 0
    witnesses = 0
    for k in range(6):
        for state in product(range(3), repeat=5):
            # 0=absent; 1=blue; 2=red, hence w<=s automatically.
            s = tuple(int(x > 0) for x in state)
            w = tuple(int(x == 2) for x in state)
            z = sum(w)
            expected_a = int(all(s))
            expected_y = int(expected_a and z == k)
            found_expected = False
            for a, y, b in product(range(2), repeat=3):
                cases += 1
                d = z - k
                ok = (all(a <= x for x in s)
                      and a >= sum(s) - 4 and y <= a
                      and -6 * (1 - y) <= d <= 6 * (1 - y)
                      and d >= 1 - 6 * ((1 - a) + y + b)
                      and d <= -1 + 6 * ((1 - a) + y + (1 - b)))
                if ok:
                    satisfying += 1
                    require((a, y) == (expected_a, expected_y),
                            'big-M/conjunction admits incorrect a,y')
                    found_expected = True
            require(found_expected, 'big-M/conjunction excludes correct a,y for both b choices')
            witnesses += 1
    return {'local_states_tested': cases, 'support_color_target_settings': witnesses,
            'satisfying_auxiliary_states': satisfying, 'all_correct': True,
            'M': 6, 'targets': list(range(6))}


def minimum_eight_certificate():
    even = [COEFF[p] for p in PERMS if sign(p) == 1]
    odd = [tuple(-x for x in COEFF[p]) for p in PERMS if sign(p) == -1]
    report = []
    for r in (1, 2, 3):
        left = {tuple(sum(vectors[t][j] for t in subset) for j in range(11))
                for vectors in (even,) for subset in combinations(range(60), r)}
        count_right = 0
        overlaps = 0
        for subset in combinations(range(60), r):
            vector = tuple(sum(odd[t][j] for t in subset) for j in range(11))
            count_right += 1
            overlaps += vector in left
        require(overlaps == 0, 'unexpected binary zero relation with fewer than8 terms')
        require(count_right == comb(60, r), 'incomplete small-subset enumeration')
        report.append({'terms_per_parity': r, 'subsets_per_parity': count_right,
                       'distinct_even_vectors': len(left), 'cross_parity_equalities': overlaps})
    require(sum_polynomials(FAMOUS_EIGHT) == [0] * 11, 'known exact8-term relation failed')
    return {'leading_coefficient_requires_equal_parity_counts': True,
            'no_nonempty_relation_smaller_than8': True, 'enumeration': report,
            'eight_term_attainment_verified': True}


def self_test():
    for p in PERMS:
        require(COEFF[p][-1] == sign(p), 'wrong leading coefficient')
        for x in range(-5, 6):
            require(sum(COEFF[p][j] * x ** j for j in range(11)) ==
                    sign(p) * prod((x + i) ** p[i] for i in range(5)),
                    'coefficient construction fails direct evaluation')
    constraints = exact_constraint_truth_table()
    minimality = minimum_eight_certificate()
    support = [0] * 25
    for p in FAMOUS_EIGHT:
        for i in range(5):
            support[5 * i + p[i]] = 1
    red = [support[e] if e < 5 else 0 for e in range(25)]
    negative_control = check_candidate({'support': support, 'red': red, 'k': 1,
                                       'fiber_permutations': [list(p) for p in FAMOUS_EIGHT]})
    require(not negative_control['accepted'], 'invalid arbitrary-subset control was accepted')
    require(negative_control['fiber_size'] == 12, 'negative control must expose all12 target matchings')
    require(any('omitted target matchings' in e for e in negative_control['errors']),
            'negative control omitted-target rejection missing')
    require(any(negative_control['coefficients_ascending']), '12-member fiber unexpectedly cancels')
    for malformed in (0.0, True, 2, -1):
        bad = list(support)
        bad[0] = malformed
        try:
            check_candidate({'support': bad, 'red': red, 'k': 1})
        except ValueError:
            pass
        else:
            raise ValueError('malformed support entry was accepted')
    return {'all_checks_passed': True, 'permutation_polynomials_verified': 120,
            'direct_evaluation_points_per_polynomial': 11,
            'constraint_truth_table': constraints, 'minimum_eight': minimality,
            'arbitrary_eight_not_a_fiber_negative_control': {
                key: value for key, value in negative_control.items() if key != 'all_120_permutations'}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', nargs='?', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.candidate is None:
        report = self_test()
        accepted = report['all_checks_passed']
    else:
        raw = args.candidate.read_bytes()
        report = check_candidate(json.loads(raw))
        report['candidate_sha256'] = hashlib.sha256(raw).hexdigest()
        accepted = report['accepted']
    text = json.dumps(report, indent=2) + '\n'
    if args.output:
        args.output.write_text(text)
        print(json.dumps({k: v for k, v in report.items() if k != 'all_120_permutations'}, indent=2))
    else:
        print(text, end='')
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
