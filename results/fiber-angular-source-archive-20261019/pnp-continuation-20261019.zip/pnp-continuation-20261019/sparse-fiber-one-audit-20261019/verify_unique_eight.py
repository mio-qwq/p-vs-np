#!/usr/bin/env python3
"""Independent exact eight-term enumeration by injective integer evaluation.

Uses direct products and Python arbitrary integers, not C++ coefficient sorting.
"""
from itertools import combinations
from math import comb, prod
from pathlib import Path
import json
from exact_checker import PERMS, COEFF, FAMOUS_EIGHT, sign, require, sum_polynomials

HERE=Path(__file__).resolve().parent

def main():
    centered=[tuple(sum(COEFF[p][r]*comb(r,d)*(-2)**(r-d) for r in range(d,11)) for d in range(11)) for p in PERMS]
    maximum=max(abs(x) for v in centered for x in v)
    bound=8*maximum
    base=bound+2
    # If Q(t) has coefficients bounded by bound and Q(base)=0, then Q=0:
    # the highest nonzero term dominates all lower terms because base-1>bound.
    values=[prod((base-2+i)**p[i] for i in range(5)) for p in PERMS]
    evens=[q for q,p in enumerate(PERMS) if sign(p)==1]
    odds=[q for q,p in enumerate(PERMS) if sign(p)==-1]
    first={}
    duplicates={}
    even_count=0
    for group in combinations(evens,4):
        even_count+=1
        value=sum(values[q] for q in group)
        if value in first:
            duplicates.setdefault(value,[first[value]]).append(group)
        else:
            first[value]=group
    odd_count=0
    matches=[]
    for group in combinations(odds,4):
        odd_count+=1
        value=sum(values[q] for q in group)
        if value in first:
            for left in duplicates.get(value,[first[value]]):
                match=tuple(sorted(left+group))
                require(sum_polynomials([PERMS[q] for q in match])==[0]*11, 'injective evaluation generated false identity')
                matches.append(match)
    require(even_count==odd_count==comb(60,4)==487635,'incomplete enumeration')
    require(len(matches)==1,'unique8-term claim failed')
    actual=tuple(PERMS[q] for q in matches[0])
    require(set(actual)==set(FAMOUS_EIGHT),'unique relation differs from known eight')
    cpp_relations=[tuple(sorted(map(int,line.split()))) for line in (HERE/'eight_term_relations.txt').read_text().splitlines()]
    require(cpp_relations==matches,'independent C++ and Python enumerations disagree')
    outside=tuple(map(int,'02143'))
    affine=[(1,tuple(map(int,'03241'))),(1,tuple(map(int,'04123'))),
            (-1,tuple(map(int,'04321'))),(1,tuple(map(int,'12340'))),(-1,tuple(map(int,'13240')))]
    require(outside not in FAMOUS_EIGHT,'outside matching must be outside')
    require(sum(c for c,p in affine)==1,'affine weights must sum to1')
    union={(i,p[i]) for p in FAMOUS_EIGHT for i in range(5)}
    require(all((i,outside[i]) in union for i in range(5)),'outside matching not in union')
    for i in range(5):
        for j in range(5):
            require(int(outside[i]==j)==sum(c*int(p[i]==j) for c,p in affine),'affine incidence identity failed')
    report={'verified':True,'method':'Python exact injective integer evaluation, independent of C++ coefficient-vector sorting',
            'maximum_absolute_individual_centered_coefficient':maximum,
            'maximum_absolute_eight_term_relation_coefficient':bound,'evaluation_base':base,
            'injectivity_condition_base_minus_one_exceeds_bound':base-1>bound,
            'even_four_subsets':even_count,'odd_four_subsets':odd_count,
            'distinct_even_four_sum_values':len(first),
            'eight_term_zero_subset_count':len(matches),
            'unique_zero_subset':[''.join(map(str,p)) for p in actual],
            'affine_outside_matching':'02143',
            'affine_identity':[{'coefficient':c,'permutation':''.join(map(str,p))} for c,p in affine],
            'affine_identity_verified_in_all25_coordinates':True,
            'complete_real_edge_cost_fiber_cannot_equal_unique_eight':True,
            'conclusion':'Together with independently checked exclusion below8 and parity, every nonempty cancelling complete real edge-cost fiber for canonical n5 has at least10 matchings.',
            'no_global_infeasibility_claim':True}
    (HERE/'UNIQUE_EIGHT_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
