# Independent audit and a sharper canonical five-row fiber bound

19 October 2026. Local exact computations only. No repository, pull request, merge, release, or frozen artifact was changed. This is AI-assisted mathematical verification, not external peer review or proof-assistant formalization.

## Main new result

For each permutation p of {0,1,2,3,4}, let

    f_p(L) = sgn(p) product_{i=0}^4 (L+i)^{p(i)}.

**Finite exact theorem.** There is exactly one eight-element subset F of the120 permutations for which the sum of the f_p over F is identically zero. It is

    F = {03241, 04123, 04231, 04321,
         12340, 13240, 14230, 32140}.

Consequently, every nonempty cancelling **complete real edge-additive-cost fiber** in this canonical five-row setting, on any support graph and at any target cost, has at least ten matchings. This includes binary-color fibers with targets1 and2. It does not prove that a cancelling fiber of size10 or larger exists, or that none exists. The result is restricted to canonical offsets0,1,2,3,4 and exponents0,1,2,3,4.

### Exact exhaustion of the eight-element case

Every f_p has leading coefficient sgn(p). Hence an eight-term zero subset contains four even and four odd permutations. Each parity class has60 terms, giving binomial(60,4)=487,635 four-term subsets per side. An equality of their unsigned polynomial sums is exactly an eight-term binary zero subset.

The source enumerate_eight.cpp enumerates all these subsets, sorts all eleven exact integer coefficients, and joins every equal vector, including all duplicate-vector Cartesian products. It finds one common vector and one eight-term zero subset. This was run both in the original L basis and with t=L+2; both output files contain exactly the same unique subset. The sums fit safely in signed64-bit integers. The independently computed maximum absolute centered individual coefficient is368, so a four-term centered sum has each coefficient bounded by1,472.

A separate Python program, verify_unique_eight.py, enumerates the same combinatorial families using direct products evaluated at t=2,946, rather than coefficient-vector sorting. It uses arbitrary-precision integers and exact dictionary key comparison. It again finds precisely one zero subset, with487,635 distinct even four-sum values. This is an exhaustive polynomial test, not a heuristic single evaluation: every coefficient of a difference of two four-term sums is bounded by2,944. For a nonzero integer polynomial Q with coefficients bounded in magnitude by H=2,944, its highest nonzero term at B=2,946 strictly dominates all lower terms because B-1>H. Therefore Q(B) cannot vanish. Equality at this B is equivalent to polynomial equality for the enumerated family.

Both ordinary and python -O runs passed. No assertions are used to enforce checks.

### Why the unique eight is not a fiber

Let v_p denote the25-coordinate incidence vector of matching p. Exact verification in all25 coordinates gives

    v_02143 = v_03241 + v_04123 - v_04321
                            + v_12340 - v_13240.

The right-hand coefficients sum to1. The matching02143 is outside F but uses only edges in union(F). Any support graph containing F therefore also contains02143. If every p in F has the same real edge-additive cost t, the identity forces02143 to have cost t as well. Thus F cannot be a complete fiber for any real edge costs, on any graph containing F.

### Why the lower bound is ten

The independent exact_checker.py also enumerates all equal-size unsigned subset sums with1,2,3 terms per parity. Their counts are60,1,770,34,220, with zero cross-parity matches. This excludes all nonempty binary zero subsets of size2,4,6. Odd sizes are excluded by the leading coefficient. The unique eight-element zero subset is excluded as a complete fiber by the affine identity above. Thus every nonempty cancelling complete fiber has size at least10.

## Audit of the direct k=1 sparse model

The exact proposed model is sound when all stated variables are binary. Its executable source was inspected, and all1,382 exported exact constraint rows were independently reconstructed. The solver's410 variables are all integer with bounds0 and1; the objective is constant zero, and no unsupported row/column permutation symmetry fixing is imposed.

1. The inequalities a_p<=s_e on each matching edge and a_p>=sum(s_e)-4 make a_p the exact support conjunction.
2. With w_e<=s_e, the red count z_p lies in{0,...,5}. The constraints y_p<=a_p and -6(1-y_p)<=z_p-k<=6(1-y_p) imply that a selected fiber member is active and has target cost.
3. For a_p=1,y_p=0, the two outside inequalities reduce to the disjunction z_p-k>=1 or z_p-k<=-1. Thus active target matchings cannot be omitted. When a_p=0,y_p=0 the inequalities impose no restriction beyond the existing red-count range; when y_p=1 the target equality makes either branch harmless. All11,664 local support/color/target/auxiliary assignments were tested across k=0,...,5, and a valid auxiliary state exists exactly for the intended a_p,y_p.
4. The inequalities s_e<=sum_{p containing e} y_p, together with exact activation and y_p<=a_p, make support exactly union(F). Restricting a putative witness to union(F) preserves every target matching and cannot create new ones, so this loses no counterexample.
5. The model's minimum size8 constraint is valid by the independently replayed small-subset theorem. The new result above permits strengthening it to10 in a separately identified future model. The already executed model was not changed.
6. All11 polynomial coefficient rows were checked in exact integers. The model uses t=L+2; the independent audit first constructs the original-L polynomials by repeated linear multiplication, then applies the binomial substitution L=t-2. Dividing an entire coefficient equality by its positive integer row gcd preserves the equality exactly. The verified divisors are8,4,2,1,1,1,1,1,1,1,1.
7. Color complementation within the support changes every active matching cost z to5-z and preserves the family after k is changed to5-k. Targets0 and5 are determinants on the corresponding monochromatic subgraph; their separate finite exclusion is a preexisting result, not re-proved by the present model audit.

The audited exported-row SHA-256 is

    f187a7ee154474bb7d5e459f3321672643331e33bf53f641d4fdc232a67de522

## Candidate acceptance and negative control

exact_checker.py does not import any solver or model code. It accepts exact support/red matrices, enumerates all120 permutations, reconstructs every active matching and every member of the target1 fiber, checks union(F), checks optional claimed membership indicators, and sums all eleven original-L integer coefficients. It separately checks direct products at eleven evaluation points.

The known arbitrary eight-term relation is used as an adversarial control: color every supported edge in its first row red and every other supported edge blue. All12 matchings of its15-edge union then have target cost1. A claim that the fiber consists only of the known eight is correctly rejected for omitting four target matchings. The actual12-term polynomial is nonzero, with ascending coefficients

    7776,34272,64248,67264,43288,17632,4456,640,40,0,0.

The checker also rejects floating-point, boolean, out-of-range, and negative support entries. A future numerical proposal is only a proposed exact combinatorial assignment; acceptance requires full independent enumeration and zero integer coefficients, never a tolerance.

## Bounded solver attempt and exact limits

The unchanged audited k=1 solver run ended at its180-second limit with no candidate. Its own receipt reports180.012 seconds and its log reports48,451 nodes. This supplies neither feasibility nor infeasibility evidence sufficient for a mathematical conclusion. No candidate existed for independent acceptance. The model audit and exact cardinality theorem are separate results that do not rely on a solver status.

A continuation may construct a separately hashed model with minimum fiber size10, use a different authorized exact search/certificate method, or propose a candidate for the standalone checker. Any further timeout or numerical infeasibility report remains inconclusive without an exact exhaustiveness certificate.

## Reproduction

Within this directory:

    python exact_checker.py --output SELF_TEST.json
    python -O exact_checker.py --output SELF_TEST_OPTIMIZED.json
    python audit_model.py
    g++ -O2 -std=c++17 -Wall -Wextra -pedantic enumerate_eight.cpp -o enumerate_eight
    ./enumerate_eight centered_polynomials.txt eight_term_relations.txt
    ./enumerate_eight original_polynomials.txt eight_term_relations_original_basis.txt
    python verify_unique_eight.py
    python -O verify_unique_eight.py

For a candidate in the documented matrix format:

    python exact_checker.py candidate.json --output CANDIDATE_AUDIT.json

The model audit reads the neighboring search directory. All other mathematical checkers are self-contained in this audit directory. No unknown source was executed; the new sources were written and inspected for this task.
