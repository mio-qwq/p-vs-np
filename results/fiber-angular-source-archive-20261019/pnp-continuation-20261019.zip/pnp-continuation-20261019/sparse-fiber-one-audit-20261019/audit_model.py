#!/usr/bin/env python3
"""Read-only independent exact audit of every exported model row.

Imports only the independent checker in this directory, never solver/model code.
Coefficient rows are obtained by binomial change of basis from fresh original-L
coefficient vectors, rather than using centered-offset multiplication.
"""
from collections import Counter
from functools import reduce
from hashlib import sha256
from math import comb, gcd
from pathlib import Path
import json
from exact_checker import PERMS, COEFF, require

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'sparse-fiber-one-20261019'


def main():
    raw = (SOURCE / 'exact_model_rows.json').read_bytes()
    rows = json.loads(raw)
    manifest = json.loads((SOURCE / 'model_manifest.json').read_text())
    require(sha256(raw.rstrip(b'\n')).hexdigest() == manifest['rows_sha256'], 'model row hash mismatch')
    expected = []
    def add(name, terms, lower=None, upper=None):
        expected.append([name, {str(j): v for j, v in terms.items() if v}, lower, upper])
    for edge in range(25):
        add('red_supported_' + str(edge), {25 + edge: 1, edge: -1}, upper=0)
    for index, p in enumerate(PERMS):
        edges = [5 * i + column for i, column in enumerate(p)]
        activation, membership, branch = 50 + index, 170 + index, 290 + index
        for edge in edges:
            add(f'active_upper_{index}_{edge}', {activation: 1, edge: -1}, upper=0)
        add(f'active_lower_{index}', {activation: 1, **{e: -1 for e in edges}}, lower=-4)
        add(f'fiber_active_{index}', {membership: 1, activation: -1}, upper=0)
        colors = {25 + e: 1 for e in edges}
        add(f'target_lower_{index}', {**colors, membership: -6}, lower=-5)
        add(f'target_upper_{index}', {**colors, membership: 6}, upper=7)
        add(f'outside_positive_{index}', {**colors, activation: -6, membership: 6, branch: 6}, lower=-4)
        add(f'outside_negative_{index}', {**colors, activation: 6, membership: -6, branch: 6}, upper=12)
    for edge in range(25):
        i, j = divmod(edge, 5)
        add(f'union_support_{edge}', {edge: 1, **{170 + index: -1 for index, p in enumerate(PERMS) if p[i] == j}}, upper=0)
    add('minimum_nonempty_size', {170 + index: 1 for index in range(120)}, lower=8)
    centered = {p: tuple(sum(COEFF[p][r] * comb(r, d) * (-2) ** (r - d) for r in range(d, 11))
                         for d in range(11)) for p in PERMS}
    divisors = []
    for d in range(11):
        g = reduce(gcd, (abs(centered[p][d]) for p in PERMS))
        require(g > 0, 'zero coefficient row cannot be gcd normalized')
        divisors.append(g)
        add(f'coefficient_{d}', {170 + index: centered[p][d] // g for index, p in enumerate(PERMS)}, 0, 0)
    require(rows == expected, 'exported model rows differ from independent exact reconstruction')
    require(divisors == manifest['coefficient_row_gcds'], 'coefficient gcd metadata mismatch')
    require(len(rows) == 1382 and len(rows) == manifest['rows'], 'row count mismatch')
    require(all(0 <= int(j) < 410 for _, terms, _, _ in rows for j in terms), 'invalid variable column')
    require(len({name for name, _, _, _ in rows}) == len(rows), 'duplicate constraint name')
    report = {'all_exported_rows_exactly_verified': True, 'rows': len(rows), 'variables': 410,
              'target': 1, 'coefficient_row_gcds': divisors,
              'maximum_absolute_coefficient': max(abs(x) for _, terms, _, _ in rows for x in terms.values()),
              'rows_sha256': manifest['rows_sha256'],
              'model_source_sha256': sha256((SOURCE/'model.py').read_bytes()).hexdigest(),
              'basis_change': 'Independent binomial substitution L=t-2 from original-L integer polynomials',
              'source_manually_checked': ['all410 variables integrality1', 'all410 variable bounds0..1',
                  'constant zero objective', 'complete1382-row sparse constraint matrix',
                  'no row/column symmetry fixing', 'no unproved solver infeasibility conclusion'],
              'result_scope': 'model equivalence only; no feasibility or infeasibility result'}
    (HERE/'MODEL_AUDIT.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
