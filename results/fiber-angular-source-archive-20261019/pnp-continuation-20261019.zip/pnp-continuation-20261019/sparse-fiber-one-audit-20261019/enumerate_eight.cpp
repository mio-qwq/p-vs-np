// Exact finite enumeration of all8-element binary zero subsets, split4+4 by parity.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using V = std::array<int64_t,11>;
struct Entry { V coefficients; std::array<int,4> indices; };
std::vector<Entry> sums(const std::vector<V>& polynomials, const std::vector<int>& indices) {
    if (polynomials.size()!=60 || indices.size()!=60) throw std::runtime_error("parity size");
    std::vector<Entry> result;
    result.reserve(487635);
    for (int a=0;a<57;++a) for(int b=a+1;b<58;++b)
    for(int c=b+1;c<59;++c) for(int d=c+1;d<60;++d) {
        Entry e; e.indices={indices[a],indices[b],indices[c],indices[d]};
        for (int j=0;j<11;++j) e.coefficients[j]=polynomials[a][j]+polynomials[b][j]+polynomials[c][j]+polynomials[d][j];
        result.push_back(e);
    }
    if(result.size()!=487635) throw std::runtime_error("subset count");
    std::sort(result.begin(),result.end(),[](const Entry&a,const Entry&b){
        return a.coefficients<b.coefficients || (a.coefficients==b.coefficients && a.indices<b.indices);
    });
    return result;
}
int main(int argc,char**argv) {
    if(argc!=3) throw std::runtime_error("usage: enumerate_eight input output");
    std::ifstream input(argv[1]);
    std::vector<V> positive,negative;
    std::vector<int> pi,ni;
    for(int q=0;q<120;++q){
        int parity; V v;
        if(!(input>>parity)) throw std::runtime_error("missing parity");
        for(auto &x:v) if(!(input>>x)) throw std::runtime_error("missing coefficient");
        if(parity==1){positive.push_back(v);pi.push_back(q);}
        else if(parity==-1){for(auto &x:v)x=-x; negative.push_back(v);ni.push_back(q);}
        else throw std::runtime_error("bad parity");
    }
    std::string extra;if(input>>extra)throw std::runtime_error("extra input");
    auto p=sums(positive,pi), n=sums(negative,ni);
    std::ofstream out(argv[2]);
    size_t i=0,j=0,matches=0,common_vectors=0;
    while(i<p.size() && j<n.size()) {
        if(p[i].coefficients<n[j].coefficients){++i;continue;}
        if(n[j].coefficients<p[i].coefficients){++j;continue;}
        size_t ii=i+1,jj=j+1;
        while(ii<p.size() && p[ii].coefficients==p[i].coefficients)++ii;
        while(jj<n.size() && n[jj].coefficients==n[j].coefficients)++jj;
        ++common_vectors;
        for(size_t a=i;a<ii;++a)for(size_t b=j;b<jj;++b){
            for(int x:p[a].indices)out<<x<<' ';
            for(int x:n[b].indices)out<<x<<' ';
            out<<'\n';++matches;
        }
        i=ii;j=jj;
    }
    std::cout<<"{\"subsets_per_parity\":487635,\"common_vectors\":"<<common_vectors<<",\"eight_term_zero_subsets\":"<<matches<<"}\n";
}
