# Root review — 2026-10-19

Read the full proof note and exact Python enumeration source, including the independently generated polynomial dependency. Replayed verify_unique_eight.py successfully; stdout SHA-256 7206669bac5e4c967787a9e63a8004fcbfe8e0632a1f44ebdf1ed9202e5f3ff7.

The injective evaluation is valid: for highest nonzero coefficient at degree d, its magnitude at B is at least B^d, while lower terms sum to at most H(B^d-1)/(B-1)<B^d. Here H=2944 and B=2946. The leading signed coefficient forces equal parity counts, so enumeration of all four-subsets on each parity covers every size-eight zero subset. The incidence identity has weights summing to one and its outside matching uses union edges; therefore it excludes a complete fiber on every larger support too. Together with the separately replayed size-two/four/six exclusion, this gives the lower bound ten for canonical n=5 complete real-cost fibers only.

The k=1 and k=2 floating-point solver timeouts establish no exclusion. Their original minimum-eight model snapshots are retained unchanged. New research should use a structural reduction or exact certificate rather than relabeling timeout as proof. No remote publication performed.
