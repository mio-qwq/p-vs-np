# Local canonical n5 recovery checkpoint

This is a local-only continuation snapshot, not a release or repository change.
It preserves the unique eight-term binary polynomial relation, its affine
non-fiber obstruction, and the exact lower bound of ten for a nonempty cancelling
complete real edge-additive-cost fiber with canonical offsets/exponents 0..4.
It also preserves the original stopped 180-second k=1 and k=2 numerical attempts.
Neither timeout proves infeasibility; no candidate was returned.

## One-command reproduction

Requirements: Python 3.10 or later and a C++17 compiler available as g++.
No SciPy, NumPy, network access, or software installation is needed for verification.
The exact arithmetic was replayed with Python 3.12.14 and g++ 14.2.0.

From this extracted directory:

    python reproduce.py
    python -O reproduce.py

Each command checks SHA256SUMS, copies the three modules to a fresh temporary
directory, regenerates the original/centered polynomial tables byte-for-byte,
compiles the locally authored enumerator, and replays both C++ enumerations,
the independent arbitrary-integer Python enumeration, the affine obstruction,
small-subset exclusions, complete-fiber negative controls, and both model audits.
Ordinary and optimized Python output must agree. It then verifies the retained
terminal receipts and model/log provenance without launching another solver.
The temporary files and compiled binary are removed on exit.

## Layout and dependencies

- sparse-fiber-one-audit-20261019: the new finite proof, exact checkers, certificates,
  independent review, and root review. Start with PROOF_AND_AUDIT.md.
- sparse-fiber-one-20261019: original k=1 model source, exact rows, stopped-run log,
  and receipts. The audit's model checker uses this included neighboring folder.
- sparse-fiber-two-20261019: original k=2 model, exact export, independent checkers,
  stopped-run log, and receipts. This module is self-contained.

The k1 audit has one documented portability-only edit: its original absolute
SOURCE path now resolves to the included sibling. CHECKPOINT_MANIFEST.json records
both original and checkpoint hashes and the reason. All mathematical/model logic
and both executed model snapshots are unchanged. Their size cut remains eight;
the newly proved lower bound ten is not retroactively substituted.

Two exact model exports are retained because the independent audits consume them
without importing either solver implementation. Redundant polynomial tables,
bytecode caches, compiled binaries, and duplicate mode receipts are omitted.
Original receipts and historical notes remain unedited; absolute paths in those
historical records identify their original locations. Refer to this README and
reproduce.py for portable commands, rather than historical commands using omitted
tables or old script names.

Historical references to earlier support-determinant or full-color work are not
inputs to the unique-eight/lower-bound-ten proof. Those earlier results are not
re-proved here. This checkpoint does not settle sparse-fiber feasibility, general
offsets/exponents, or P versus NP. New endpoint structural work is excluded.
