#!/usr/bin/env python3
"""Bounded numerical proposal search; no solver status is a mathematical proof."""
import argparse
from datetime import datetime, timezone
from functools import reduce
from hashlib import sha256
from itertools import permutations
from math import gcd
import json
from pathlib import Path
import time

N = 5
K = 1
M = 6
PERMS = list(permutations(range(N)))
NP = len(PERMS)
S0, W0, A0, Y0, B0 = 0, 25, 50, 170, 290
NV = 410


def multiply(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def signed_centered_coefficients(p):
    ans = [1]
    for i, exponent in enumerate(p):
        for _ in range(exponent):
            ans = multiply(ans, [i - 2, 1])
    inversions = sum(p[i] > p[j] for i in range(N) for j in range(i + 1, N))
    return [(-1 if inversions % 2 else 1) * x for x in ans]


def build_rows():
    # Each row is (name, {column: exact integer coefficient}, lower, upper).
    # None denotes the corresponding infinite bound.
    rows = []
    def add(name, terms, lower=None, upper=None):
        rows.append((name, {j: c for j, c in terms.items() if c}, lower, upper))
    for e in range(25):
        add(f'red_supported_{e}', {W0 + e: 1, S0 + e: -1}, upper=0)
    for q, p in enumerate(PERMS):
        edges = [5 * i + p[i] for i in range(5)]
        a, y, b = A0 + q, Y0 + q, B0 + q
        for e in edges:
            add(f'active_upper_{q}_{e}', {a: 1, S0 + e: -1}, upper=0)
        add(f'active_lower_{q}', {a: 1, **{S0 + e: -1 for e in edges}}, lower=-4)
        add(f'fiber_active_{q}', {y: 1, a: -1}, upper=0)
        z = {W0 + e: 1 for e in edges}
        add(f'target_lower_{q}', {**z, y: -M}, lower=K-M)
        add(f'target_upper_{q}', {**z, y: M}, upper=K+M)
        add(f'outside_positive_{q}', {**z, a: -M, y: M, b: M}, lower=K+1-M)
        add(f'outside_negative_{q}', {**z, a: M, y: -M, b: M}, upper=K-1+2*M)
    for e in range(25):
        i, j = divmod(e, 5)
        add(f'union_support_{e}', {S0+e: 1, **{Y0+q: -1 for q,p in enumerate(PERMS) if p[i] == j}}, upper=0)
    add('minimum_nonempty_size', {Y0+q: 1 for q in range(NP)}, lower=8)
    coeffs = [signed_centered_coefficients(p) for p in PERMS]
    divisors = []
    for d in range(11):
        divisor = reduce(gcd, (abs(v[d]) for v in coeffs))
        divisors.append(divisor)
        add(f'coefficient_{d}', {Y0+q: coeffs[q][d]//divisor for q in range(NP)}, lower=0, upper=0)
    return rows, coeffs, divisors


def row_violation(row, x):
    _, terms, lower, upper = row
    v = sum(c * x[j] for j, c in terms.items())
    return ((lower is not None and v < lower) or (upper is not None and v > upper))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--time-limit', type=float, default=180)
    ap.add_argument('--inspect-only', action='store_true')
    args = ap.parse_args()
    directory = Path(__file__).resolve().parent
    rows, coeffs, divisors = build_rows()
    canonical = json.dumps(rows, sort_keys=True, separators=(',', ':'))
    digest = sha256(canonical.encode()).hexdigest()
    manifest = {'n': N, 'target': K, 'big_m': M, 'variables': NV, 'rows': len(rows),
                'variable_blocks': {'support': [S0,W0], 'red': [W0,A0], 'active': [A0,Y0], 'fiber': [Y0,B0], 'disjunction': [B0,NV]},
                'coefficient_basis': 't=L+2, so row offsets are -2,-1,0,1,2',
                'coefficient_row_gcds': divisors, 'maximum_absolute_coefficient': max(abs(v) for r in rows for v in r[1].values()),
                'rows_sha256': digest, 'objective': 'constant zero feasibility',
                'minimum_fiber_size': 8, 'fixed_edge_colors': [],
                'solver_status_is_not_proof': True}
    (directory/'model_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    (directory/'exact_model_rows.json').write_text(canonical+'\n')
    print(json.dumps(manifest, indent=2), flush=True)
    if args.inspect_only:
        return
    import numpy as np
    import scipy
    from scipy.optimize import milp, Bounds, LinearConstraint
    from scipy.sparse import csc_array
    rr, cc, vv = [], [], []
    lower, upper = [], []
    for i, (_, terms, lo, hi) in enumerate(rows):
        for j, v in terms.items():
            rr.append(i); cc.append(j); vv.append(v)
        lower.append(-np.inf if lo is None else lo)
        upper.append(np.inf if hi is None else hi)
    mat = csc_array((np.array(vv, dtype=float), (np.array(rr,dtype=np.int32), np.array(cc,dtype=np.int32))), shape=(len(rows), NV))
    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.monotonic()
    result = milp(c=np.zeros(NV), integrality=np.ones(NV,dtype=np.int32), bounds=Bounds(np.zeros(NV),np.ones(NV)),
                  constraints=LinearConstraint(mat,np.array(lower),np.array(upper)),
                  options={'time_limit': args.time_limit, 'disp': True, 'presolve': True})
    output = {'started_utc': started_utc, 'elapsed_seconds': time.monotonic()-started, 'requested_solver_time_limit_seconds':args.time_limit,
              'scipy_version': scipy.__version__, 'status': int(result.status), 'message': str(result.message),
              'solver_success': bool(result.success), 'has_candidate': result.x is not None, 'model_rows_sha256': digest,
              'mathematical_infeasibility_claim': False, 'exact_witness_verified':False}
    for name in ('fun','mip_gap','mip_node_count','mip_dual_bound'):
        value = getattr(result,name,None)
        output[name] = None if value is None else float(value)
    if result.x is not None:
        raw = result.x.tolist()
        rounded = [int(round(v)) for v in raw]
        distance = max(abs(x-y) for x,y in zip(raw,rounded))
        violations = [r[0] for r in rows if row_violation(r,rounded)]
        output['maximum_rounding_distance'] = distance
        output['integer_row_violations'] = violations
        proposal = {'n':N,'target':K,'support':[[i,j] for i in range(5) for j in range(5) if rounded[S0+5*i+j]],
                    'red':[[i,j] for i in range(5) for j in range(5) if rounded[W0+5*i+j]],
                    'fiber':[''.join(map(str,p)) for q,p in enumerate(PERMS) if rounded[Y0+q]],
                    'raw_variables':raw,'rounded_variables':rounded}
        (directory/'candidate.json').write_text(json.dumps(proposal,indent=2)+'\n')
        if distance <= 1e-5 and all(v in (0,1) for v in rounded) and not violations:
            # Independent exact checker does not import this implementation.
            from verify_candidate import verify
            checked = verify(proposal)
            output['exact_witness_verified'] = checked['verified']
            (directory/'candidate_verification.json').write_text(json.dumps(checked,indent=2)+'\n')
    (directory/'search_result.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2),flush=True)

if __name__ == '__main__':
    main()
