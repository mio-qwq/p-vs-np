# Canonical five-row sparse binary-color fiber search, target one

19 October 2026. Local research only. This directory does not change any repository or frozen release materials.

## Final bounded outcome

The 180-second attempt ended with **no numerical incumbent and no exact witness**. HiGHS reported a time limit, not a completed infeasibility result. It processed 48,451 branch-and-bound nodes and 2,737,165 LP iterations; these counts do not certify exhaustive mathematical coverage. Python measured 180.012 seconds for the solver call. The bounded attempt is stopped.

The source and exact row digest match the independent audit. Files search_result.json, search.log, and RUN_REPORT.json preserve the status and provenance. There is no candidate.json because no candidate was produced. No nonexistence theorem follows from this run.

## Scope

Find a support graph S on five rows and five columns, a red-edge set R contained in S, and the **complete** target fiber

    F = {p in S_5 : every (i,p(i)) is in S and exactly one is in R}

such that F is nonempty and

    sum_{p in F} sign(p) product_i (L+i)^{p(i)} = 0.

The search is a floating-point mixed-integer feasibility attempt. A feasible assignment is only a candidate until independent exact verification. A timeout or numerical infeasibility report does not establish nonexistence.

## Exact logical model

There are 410 binary variables: 25 support indicators s, 25 red indicators w, and 120 each of a (active matching), y (target-fiber membership), and b (non-target sign choice). All variables have bounds zero and one. All 120 permutations are listed lexicographically.

For every edge, w <= s. For every permutation p:

- a <= s for each of its five edges;
- a >= sum(s on p) - 4;
- y <= a;
- with z=sum(w on p), k=1 and M=6:

      z - M y >= k-M
      z + M y <= k+M
      z - M a + M y + M b >= k+1-M
      z + M a - M y + M b <= k-1+2M.

The first two z constraints force z=k when y=1. If a=1 and y=0, the last two force z>=k+1 when b=0 and z<=k-1 when b=1. Thus an active matching has y=1 if and only if its red count is k. Inactive matchings have y=0. For other states, the inactive side of each disjunction is harmless over 0<=z<=5.

For every edge e, impose

    s_e <= sum_{p containing e} y_p.

Together with matching activation this makes S exactly the union of F. This is a completeness-preserving restriction for an existence search: deleting edges not used by any target matching cannot remove a member of F or create a new matching, so every existing counterexample has a union-support representative.

The established exact five-row minimum-cardinality theorem permits sum(y)>=8. Its independent finite subset-sum certificate is in ../binary-cancellation-search-20261019/PROOF.md and check.py. This search does not silently assume an eight-element fiber: cardinalities above eight are allowed.

All eleven coefficients of the signed polynomial sum are zero. The model expands in t=L+2, with offsets -2,-1,0,1,2, using exact integer arithmetic. Each coefficient row is divided by its integer gcd, a reversible exact operation. Maximum absolute matrix coefficient is 368. There are 1382 rows in total.

The objective is constant zero; this is a feasibility search. There is no extra fixed blue or red edge, no row/column relabeling, and no constraint selecting a particular matching. Color complementation changes k to 5-k and does not preserve this fixed k=1 model. The present run covers k=1 only.

## Reproduction and verification

    python model.py --inspect-only
    python model.py --time-limit 180 > search.log 2>&1

The first command reconstructs the exact integer rows and their SHA-256 manifest without invoking the solver. The second uses already installed SciPy/HiGHS with a 180-second solver time limit. No software installation is involved. The exact row export records names, sparse integer coefficients, and exact bounds, using null for infinity.

If a candidate appears, model.py first rounds only a vector within 1e-5 of integrality, then tests all binary bounds and every exact integer model row. verify_candidate.py separately constructs original-L-basis polynomials using binomial coefficients and enumerates all 120 permutations. It verifies red-edge containment, support equal to union(F), nonempty complete target membership with every outside matching included in the test, every one of the eleven polynomial coefficients, and direct integer evaluations at eleven points. A separate reviewer also independently audits the model and candidate when present.

The independent checker can be rerun in ordinary or optimized Python:

    python verify_candidate.py candidate.json
    python -O verify_candidate.py candidate.json

These commands are relevant only if candidate.json exists. No numerical candidate is itself an exact mathematical certificate.

## Useful recovery conditions

If no verified witness is found, a future attempt should preserve every complete-fiber and union-support constraint and all polynomial coefficients. Extending this bounded search requires a new search budget or a different, independently justified exact reduction. A reported floating-point infeasibility would need an independently checkable exact certificate or exact exhaustive proof before becoming a nonexistence theorem. A timeout provides neither.

Any new proposed witness must supply explicit support, explicit red edges, and its entire target fiber, followed by independent exact verification of all 120 matchings and all coefficients. Adding a fixed edge color, restricting to a selected arbitrary cancellation subset, or invoking unsupported row/column symmetries would change the question and is not an acceptable recovery shortcut.

## Independent model audit

The paired independent reviewer reconstructed all 1,382 exported integer rows and matched them exactly. Its polynomial route first expands in the original L basis, then uses a binomial substitution L=t-2, independently reproducing every normalized coefficient row. The review also checked the source's 410 binary variables, bounds, objective, complete sparse matrix assembly, and absence of extra symmetry fixing.

Audit receipt: ../sparse-fiber-one-audit-20261019/MODEL_AUDIT.json.

Audited row SHA-256:

    f187a7ee154474bb7d5e459f3321672643331e33bf53f641d4fdc232a67de522

The local_self_test.json file records 1,320 exact integer point checks comparing both polynomial implementations with direct products, the known eight-term arbitrary-subset identity, and rejection of a deliberately false complete-fiber proposal. These checks supplement, rather than replace, the independent audit.
