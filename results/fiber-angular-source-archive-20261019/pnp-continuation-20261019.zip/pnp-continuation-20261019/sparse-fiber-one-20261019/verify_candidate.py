#!/usr/bin/env python3
"""Independent standard-library exact verification; does not import solver code."""
import itertools
import json
import math
from pathlib import Path
import sys


def require(test, message):
    if not test:
        raise ValueError(message)


def polynomial(p):
    # Coefficients in original L basis via binomial theorem, unlike model.py.
    coefficients = [1]
    for row, power in enumerate(p):
        factor = [math.comb(power,d) * row**(power-d) for d in range(power+1)]
        new = [0] * (len(coefficients)+power)
        for degree in range(len(new)):
            new[degree] = sum(coefficients[i]*factor[degree-i] for i in range(len(coefficients)) if 0 <= degree-i < len(factor))
        coefficients = new
    sign = -1 if sum(a>b for i,a in enumerate(p) for b in p[i+1:]) % 2 else 1
    return [sign*x for x in coefficients]


def verify(data):
    require(data['n']==5 and data['target']==1,'Incorrect problem dimension or target')
    support_list = [tuple(e) for e in data['support']]
    red_list = [tuple(e) for e in data['red']]
    support, red = set(support_list), set(red_list)
    universe = set(itertools.product(range(5),repeat=2))
    require(len(support)==len(support_list) and len(red)==len(red_list),'Duplicate edges')
    require(support <= universe and red <= support,'Invalid support or unsupported red edge')
    claimed_list = [tuple(map(int,p)) for p in data['fiber']]
    claimed = set(claimed_list)
    perms = list(itertools.permutations(range(5)))
    require(len(claimed)==len(claimed_list) and claimed <= set(perms),'Invalid or duplicate fiber permutations')
    actual = set()
    active = []
    records = []
    for p in perms:
        edges = {(i,j) for i,j in enumerate(p)}
        supported = edges <= support
        cost = len(edges & red)
        member = supported and cost == 1
        if supported:
            active.append(p)
        if member:
            actual.add(p)
        records.append({'permutation':''.join(map(str,p)), 'supported':supported,'red_count':cost,'in_target_fiber':member,'claimed_member':p in claimed})
    require(actual == claimed,'Claimed subset is not exactly the complete target fiber')
    require(bool(actual),'Empty target fiber')
    require(len(actual)>=8,'Violates established n=5 minimum relation size')
    union = {(i,p[i]) for p in actual for i in range(5)}
    require(union == support,'Support is not exactly union of target fiber')
    coefficients = [sum(polynomial(p)[d] for p in actual) for d in range(11)]
    require(coefficients == [0]*11,'At least one polynomial coefficient does not cancel')
    evaluations = {}
    for point in range(-5,6):
        total = 0
        for p in actual:
            parity = sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
            total += (-1)**parity * math.prod((point+i)**p[i] for i in range(5))
        evaluations[str(point)] = total
        require(total == 0,'Direct exact evaluation does not cancel')
    return {'verified':True,'dimension':5,'target':1,'support_size':len(support),'red_edges':len(red),
            'active_matchings':len(active),'fiber_size':len(actual),'all_permutations_checked':len(records),
            'coefficient_sums_original_L_basis':coefficients,'direct_integer_evaluations':evaluations,'matching_records':records}

if __name__ == '__main__':
    path = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('candidate.json')
    print(json.dumps(verify(json.loads(path.read_text())),indent=2))
