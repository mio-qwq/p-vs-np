#!/usr/bin/env python3
"""Independent exhaustive check of the two analytic antichain lemmas.

All checks use explicit exceptions, including under python -O. The finite
census is a cross-check; the theorem is proved analytically in PROOF.md.
A saved receipt can be checked by --verify-receipt FILE. Altered receipts
must fail; --output FILE writes a deterministic, freshly computed receipt.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys

class AuditFailure(Exception):
    pass

def require(condition, message):
    if not condition:
        raise AuditFailure(message)

def is_antichain(family):
    return all((a & b) != a and (a & b) != b
               for i, a in enumerate(family) for b in family[i + 1:])

def sign_sum(family, character):
    return sum(-1 if (x & character).bit_count() % 2 else 1 for x in family)

def classify_dimension(dimension):
    size_counts = Counter()
    balanced = []
    mixed_balanced_checks = 0
    n = 1 << dimension
    for mask in range(1 << n):
        family = [x for x in range(n) if (mask >> x) & 1]
        if not is_antichain(family):
            continue
        size_counts[len(family)] += 1
        if not family:
            continue
        if dimension <= 3:
            require(len(family) <= 3,
                    'Three-coordinate antichain width lemma failed: ' + str(family))
            for character in range(n):
                if sign_sum(family, character) == 0:
                    require(len(family) == 2,
                            'Small arbitrary-character zero sum was not a pair: '
                            + str((dimension, family, character)))
                    mixed_balanced_checks += 1
        if sign_sum(family, n - 1) == 0:
            require(len(family) == 2,
                    'Four-coordinate alternating-cardinality lemma failed: '
                    + str((dimension, family)))
            balanced.append(family)
    return {
        'dimension': dimension,
        'antichains_including_empty': sum(size_counts.values()),
        'nonempty_antichains': sum(size_counts.values()) - 1,
        'counts_by_family_size': {str(k): size_counts[k] for k in sorted(size_counts)},
        'maximum_family_size': max(size_counts),
        'balanced_all_minus_count': len(balanced),
        'balanced_all_minus_families': balanced,
        'arbitrary_character_balanced_checks_for_dimension_at_most_3': mixed_balanced_checks,
    }

def compare_receipt(actual, expected):
    require(actual == expected, 'Receipt mismatch: supplied receipt differs from the independently recomputed census.')

def build_receipt():
    reports = [classify_dimension(d) for d in range(5)]
    require([x['antichains_including_empty'] for x in reports] == [2, 3, 6, 20, 168],
            'Independent antichain census does not match known small cube counts.')
    require([x['maximum_family_size'] for x in reports] == [1, 1, 2, 3, 6],
            'Unexpected maximum antichain sizes.')
    require([x['balanced_all_minus_count'] for x in reports] == [0, 0, 0, 3, 24],
            'Unexpected balanced-antichain counts.')

    # Boundary controls: removing either extension hypothesis defeats the
    # leading-coefficient argument, without implying polynomial cancellation.
    mixed_four = [x for x in range(16) if x.bit_count() == 2]
    require(is_antichain(mixed_four) and len(mixed_four) == 6
            and sign_sum(mixed_four, 1) == 0,
            'Four-coordinate mixed-character boundary control failed.')
    weights = (1, 1, 1, 1, 2)
    five = [x for x in range(32)
            if sum(weights[j] for j in range(5) if (x >> j) & 1) == 3]
    require(is_antichain(five) and len(five) == 8 and sign_sum(five, 31) == 0,
            'Five-coordinate all-minus boundary control failed.')
    require(not is_antichain([0, 1]), 'Comparable-set rejection control failed.')
    return {
        'format': 'independent-antichain-audit-v1',
        'status': 'pass',
        'method': 'All subset families in Boolean dimensions 0 through 4; exact integer operations and explicit exceptions.',
        'theorem_dependency': 'Analytic proofs are sufficient; this census and the obsolete cube-flat catalogue are not theorem premises.',
        'checked_claims': [
            'Every antichain in dimensions at most 3 has at most 3 members.',
            'A nonempty antichain in dimensions at most 4 with zero alternating-cardinality sum has exactly 2 members.',
            'In dimensions at most 3, a nonempty antichain balanced under any sign character has exactly 2 members.',
        ],
        'dimensions': reports,
        'boundary_controls': {
            'four_mixed_flips': {'family': mixed_four, 'character': 1, 'leading_sum': 0},
            'five_odd_flips': {'weights': list(weights), 'target': 3, 'family': five, 'leading_sum': 0},
            'comparable_family_rejected': [0, 1],
            'interpretation': 'The first two controls refute naive leading-coefficient extensions, not polynomial noncancellation.',
        },
    }

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--verify-receipt', type=Path)
    args = parser.parse_args()
    receipt = build_receipt()
    if args.verify_receipt is not None:
        compare_receipt(json.loads(args.verify_receipt.read_text()), receipt)
    rendered = json.dumps(receipt, indent=2, sort_keys=True) + '\n'
    if args.output is not None:
        args.output.write_text(rendered)
    print(rendered, end='')

if __name__ == '__main__':
    try:
        main()
    except (AuditFailure, OSError, ValueError) as exc:
        print('AUDIT FAILED: ' + str(exc), file=sys.stderr)
        sys.exit(1)
