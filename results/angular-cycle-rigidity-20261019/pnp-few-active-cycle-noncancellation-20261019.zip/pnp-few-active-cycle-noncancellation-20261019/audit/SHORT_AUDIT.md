# Independent audit of the final cycle-fiber theorems

**Verdict: both analytic proofs check; no mathematical correction is needed.**

Reviewed primary `PROOF.md` SHA-256:
`703bef59955b0b002d4186142db3fb1cdd8cdddaece7554a5fc844c962c71cb5`.

- **Theorem A:** At most three unequal-cost cycle choices, with arbitrary cycle lengths and flip signs.
- **Theorem B:** At most four unequal-cost cycle choices, each changing the permutation sign; equivalently each active bipartite cycle length is divisible by four.
- Both permit arbitrarily many equal-cost cycles of arbitrary lengths.

The scope requires a complete additive-cost fiber, independent alternating-cycle components and forced matching edges, pairwise distinct row offsets, and pairwise distinct nonnegative integer column exponents. The conclusion is a nonzero polynomial, not nonvanishing at every value of its variable. The stated reduction from a maximum-degree-two graph with a perfect matching is valid.

## Independent analytic review

1. Each local cycle binomial is nonzero: its two unsigned monomials have equal degrees but different multiplicities at the distinct row roots. Equal-cost cycles factor independently because the entire cost fiber is included.
2. Relabeling unequal-cost choices makes all active cost differences positive. Their fixed-cost sets are antichains. Local sign changes under relabeling contribute only an overall sign.
3. An antichain on at most three coordinates has at most three members. Odd term counts give a nonzero leading coefficient; two terms cannot cancel because either their leading signs agree or their unsigned root-multiplicity vectors differ.
4. For a four-coordinate antichain with zero alternating-cardinality sum, let `a,b,c` count members of sizes one, two and three. Then `b=a+c`. Two singletons or two triples force `b<=1`, a contradiction. A singleton and a triple must be complementary and forbid every pair. Thus exactly one singleton or triple and one pair remain. This verifies the parity lemma used by Theorem B.

**Neither a cube-flat catalogue nor any finite enumeration is a premise of either theorem.**

## Independent compact checks

`check_antichain_audit.py` enumerates every subset family in Boolean dimensions zero through four using exact integer operations and explicit exceptions, with no assertion-dependent checks. It independently verifies both analytic antichain claims.

The numbers of antichains, including the empty family, are `2,3,6,20,168`. Maximum family sizes are `1,1,2,3,6`. The numbers of nonempty all-minus balanced antichains are `0,0,0,3,24`; each is a pair.

Normal Python and `python -O` runs passed and produced identical deterministic receipts. Both executions rejected deliberately altered census counts and altered claim text through `--verify-receipt`, exiting with failure. The checker also reproduces the four-coordinate mixed-sign and five-coordinate all-minus leading-coefficient boundary examples without mislabeling them as polynomial cancellations.

Suggested reproduction:

    python check_antichain_audit.py --verify-receipt INDEPENDENT_ANTICHAIN_VERIFICATION.json
    python -O check_antichain_audit.py --verify-receipt INDEPENDENT_ANTICHAIN_VERIFICATION.json

`SHORT_AUDIT.json` records the hashes, scope and corruption-control outcomes. The larger exploratory cube-flat files are intentionally unnecessary for the portable theorem package. Historical novelty and broader P-versus-NP implications were not independently assessed here.
