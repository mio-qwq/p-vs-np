# Few cost-active cycle noncancellation

Local research checkpoint, 19 October 2026.

## Proven scope

For a complete additive-cost fiber of perfect matchings on a supported bipartite graph consisting of disjoint alternating cycles and forced edges, its signed translated-power polynomial is not identically zero if:

1. At most three cycles have unequal costs for their two local matchings, with arbitrary cycle lengths and flip parities; or
2. At most four cycles have unequal local matching costs and every active flip is odd (the cycle has an even number of rows).

Both statements permit arbitrarily many inactive cycles of arbitrary lengths, arbitrary real edge costs, distinct real row offsets, and distinct nonnegative integer column exponents. The proofs also cover maximum-degree-two support graphs with perfect matchings after unused edges are discarded. The conclusion concerns a nonzero polynomial; individual real evaluations may vanish.

The proof uses a product decomposition, distinct root multiplicities, and elementary antichain arguments. Finite checkers are supplemental tests, not substitutes for the analytic proof or exhaustive verification of unbounded parameters.

No unrestricted complete-fiber theorem, four-active mixed-parity theorem, P-versus-NP result, polynomial-time isolation algorithm, formal proof-assistant certification, or external peer review is claimed. No repository, merge, release, upload, or other publication was performed for this checkpoint.

## Contents

- `primary/PROOF.md`: Full analytic proof and boundary examples.
- `primary/verify_theorem.py`: Exact antichain census and six direct polynomial/sample graph checks.
- `primary/VERIFICATION*.json`: Identical original normal/optimized receipts, covering 132 perfect matchings across 42 complete fibers.
- `primary/MANIFEST.json`: Preserved original source pins. Its independent-review path records the original working layout; use the portable independent audit under `audit/` here.
- `audit/`: Independent scoped proof review, a compact explicit-error antichain checker, and its deterministic receipts.
- `PACKAGE_MANIFEST.json`: Size and SHA256 pins for every other payload file.
- `verify_bundle.py`: Portable integrity, normal/optimized replay, and corruption-control checks.
- `rebuild.py`: Deterministic ZIP creation with fixed metadata and no compression-library dependency.

The broad exploratory searches, cube-flat catalogues, executables, and caches have been excluded. None is a premise of these two proofs.

## Reproduce

Requires Python 3.10 or newer and only its standard library. From this directory:

    python verify_bundle.py
    python -O verify_bundle.py
    python rebuild.py ../pnp-few-active-cycle-noncancellation-20261019.zip

The verification script uses temporary directories outside this package and checks both Python execution modes. The included mutation controls must be rejected; they do not modify the preserved source files. Package hashes detect accidental corruption relative to the manifest, not a malicious simultaneous replacement of both files and manifest. Compare the archive SHA256 to the separately supplied completion receipt to pin the whole artifact.

ZIP entries have sorted names, one fixed root name, a fixed timestamp, stable permissions, no extra fields, and stored bytes. Rebuilding after clean extraction must yield an identical archive, independent of extraction-directory names.
