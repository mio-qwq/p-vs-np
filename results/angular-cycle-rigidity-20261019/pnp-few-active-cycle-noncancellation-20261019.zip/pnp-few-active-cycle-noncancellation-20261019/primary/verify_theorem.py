#!/usr/bin/env python3
"""Exact finite checks for the analytic few-cost-active-cycle theorems."""
import argparse, hashlib, itertools, json, math
from collections import defaultdict
from pathlib import Path


def need(ok, message):
    if not ok:
        raise ValueError(message)


def trim(p):
    while len(p) > 1 and not p[-1]:
        p.pop()
    return p


def add(a, b):
    c = [0] * max(len(a), len(b))
    for i, x in enumerate(a): c[i] += x
    for i, x in enumerate(b): c[i] += x
    return trim(c)


def mul(a, b):
    c = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): c[i+j] += x*y
    return trim(c)


def signed(p, s):
    return [s*x for x in p]


def powers(a, e):
    return [math.comb(e, k) * a**(e-k) for k in range(e+1)]


def monomial(assignments, offsets, exponents):
    p = [1]
    for i, j in assignments:
        p = mul(p, powers(offsets[i], exponents[j]))
    return p


def sign(p):
    return -1 if sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1, len(p))) % 2 else 1


def antichain_checks():
    out = []
    for r in range(5):
        n = 1 << r
        bad = [sum(1 << j for j in range(n) if j != i and ((i & j) == i or (i & j) == j)) for i in range(n)]
        count = 0
        max_size = 0
        balanced = defaultdict(int)
        for family in range(1 << n):
            members = [i for i in range(n) if family >> i & 1]
            if any(family & bad[i] for i in members): continue
            count += 1
            max_size = max(max_size, len(members))
            parity = sum((-1)**i.bit_count() for i in members)
            if members and not parity:
                balanced[len(members)] += 1
                if r == 4: need(len(members) == 2, 'four-coordinate parity lemma failed')
            if r <= 3: need(len(members) <= 3, 'three-coordinate antichain bound failed')
        need(count == [2, 3, 6, 20, 168][r], 'antichain census mismatch')
        out.append(dict(coordinates=r, antichains_including_empty=count, largest_size=max_size,
                        nonempty_balanced_sizes=dict(sorted(balanced.items()))))
    return out


def check_graph(lengths, deltas, forced=0, noncanonical=False):
    need(len(lengths) == len(deltas), 'bad component input')
    n = sum(lengths) + forced
    # Independent affine permutations scramble row and column labels when coprime.
    unit = next(k for k in range(2, n+2) if math.gcd(k, n) == 1)
    rows = [(unit*i+1) % n for i in range(n)]
    cols = list(reversed(range(n)))
    offsets = [i*i+i+1 for i in range(n)] if noncanonical else list(range(n))
    exponents = [3*j+(j % 2) for j in range(n)] if noncanonical else list(range(n))
    need(len(set(offsets)) == n and len(set(exponents)) == n, 'distinctness failed')
    support = [[] for _ in range(n)]
    costs = {}
    local = []
    baseline = [-1]*n
    start = 0
    for m, delta in zip(lengths, deltas):
        A = [(rows[start+k], cols[start+k]) for k in range(m)]
        B = [(rows[start+k], cols[start+(k+1) % m]) for k in range(m)]
        for edge in A+B:
            i, j = edge
            support[i].append(j)
            costs[edge] = 0
        costs[B[0]] = delta
        for i, j in A: baseline[i] = j
        local.append((A, B, (-1)**(m-1)))
        start += m
    fixed = []
    for k in range(start, n):
        edge = rows[k], cols[k]
        fixed.append(edge)
        i, j = edge
        baseline[i] = j
        support[i].append(j)
        costs[edge] = 0
    actual = defaultdict(list)
    def dfs(i, used, perm, cost):
        if i == n:
            actual[cost].append(tuple(perm))
            return
        for j in support[i]:
            if not (used >> j & 1): dfs(i+1, used | (1 << j), perm+[j], cost+costs[i,j])
    dfs(0, 0, [], 0)
    need(sum(map(len, actual.values())) == 2**len(lengths), 'supported matching count failed')
    predicted = defaultdict(list)
    for bits in itertools.product((0, 1), repeat=len(lengths)):
        p = list(baseline)
        for bit, (A, B, epsilon) in zip(bits, local):
            if bit:
                for i, j in B: p[i] = j
        cost = sum(d*b for d,b in zip(deltas, bits))
        predicted[cost].append(tuple(p))
        need(sign(p) == sign(baseline)*math.prod(ep**b for b, (_,_,ep) in zip(bits, local)), 'cycle sign formula failed')
    need({t:sorted(v) for t,v in actual.items()} == {t:sorted(v) for t,v in predicted.items()}, 'complete fiber memberships differ')
    active = [j for j,d in enumerate(deltas) if d]
    need(len(active) <= 3 or (len(active) <= 4 and all(lengths[j] % 2 == 0 for j in active)), 'instance outside theorem')
    polynomials = [(monomial(A, offsets, exponents), monomial(B, offsets, exponents), ep) for A,B,ep in local]
    common = signed(monomial(fixed, offsets, exponents), sign(baseline))
    for j,d in enumerate(deltas):
        A,B,ep = polynomials[j]
        need(A != B, 'distinct local root multiplicities failed')
        if not d:
            factor = add(A, signed(B,ep))
            need(factor != [0], 'inactive factor vanished')
            common = mul(common, factor)
    factored = defaultdict(lambda:[0])
    # Reorientation is explicitly checked in addition to the original product formula.
    for bits in itertools.product((0,1), repeat=len(active)):
        original = [b if deltas[j] > 0 else 1-b for j,b in zip(active,bits)]
        target = sum(deltas[j]*b for j,b in zip(active,original))
        base = sum(min(0,deltas[j]) for j in active)
        need(target == base + sum(abs(deltas[j])*b for j,b in zip(active,bits)), 'positive reorientation failed')
        p = [1]
        for j,b in zip(active,original):
            A,B,ep = polynomials[j]
            p = mul(p, signed(B,ep) if b else A)
        factored[target] = add(factored[target], p)
    max_degree = 0
    for target, perms in actual.items():
        direct = [0]
        for p in perms:
            direct = add(direct, signed(monomial(enumerate(p), offsets, exponents), sign(p)))
        composed = mul(common, factored[target])
        need(direct == composed, 'full coefficient product identity failed')
        need(direct != [0], 'theorem instance cancelled')
        max_degree = max(max_degree, len(direct)-1)
    return dict(cycle_row_counts=lengths, cost_differences=deltas, forced_edges=forced,
                rows=n, noncanonical=noncanonical, active_cycles=len(active),
                perfect_matchings=sum(map(len, actual.values())), complete_fibers=len(actual),
                largest_actual_degree=max_degree, all_coefficients_checked=True)


def boundary_checks():
    def fiber(ds,t):
        return [x for x in itertools.product((0,1),repeat=len(ds)) if sum(d*b for d,b in zip(ds,x)) == t]
    six = fiber([1]*4, 2)
    mixed = sum((-1)**x[0] for x in six)
    need(len(six) == 6 and mixed == 0, 'mixed character boundary wrong')
    eight = fiber([1,1,1,1,2],3)
    alt = sum((-1)**sum(x) for x in eight)
    need(len(eight) == 8 and alt == 0, 'five-coordinate boundary wrong')
    repeated_offset = add(monomial([(0,0),(1,1)],[0,0],[0,1]),
                          signed(monomial([(0,1),(1,0)],[0,0],[0,1]),-1))
    need(repeated_offset == [0], 'repeated-offset negative control failed')
    return dict(four_mixed_character_size=len(six), four_mixed_character_leading=mixed,
                five_odd_flip_size=len(eight), five_odd_flip_leading=alt,
                repeated_offset_control='cancels as expected')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='VERIFICATION.json')
    args = parser.parse_args()
    cases = [([2,3,4],[1,2,3],1,False),
             ([2,3,4,2,3],[1,-2,3,0,0],2,False),
             ([2,4,2,4],[1,2,3,4],0,False),
             ([3,2,4,2,4,3],[0,-1,2,3,4,0],0,False),
             ([3,2,2],[1,1,2],1,True),
             ([2,3],[0,0],2,False)]
    result = dict(status='PASS', source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  antichains=antichain_checks(), graph_checks=[check_graph(*c) for c in cases],
                  boundaries=boundary_checks(), arithmetic='exact standard-library integers')
    Path(args.output).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__ == '__main__': main()
