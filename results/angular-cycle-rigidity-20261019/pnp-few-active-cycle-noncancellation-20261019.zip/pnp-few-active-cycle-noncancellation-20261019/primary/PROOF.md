# Noncancellation with few cost-active alternating cycles

19 October 2026. A new structural theorem, valid in unbounded dimension. This is local mathematical work, not a P-versus-NP claim, external peer review, or proof-assistant formalization. No repository, PR, merge, release, or external service was changed. The earlier bounded exploratory searches in this directory are not premises of this theorem.

## 1. Statement

Let a_0,...,a_(n-1) be distinct real numbers and e_0,...,e_(n-1) distinct nonnegative integers. For a permutation p define

    f_p(L) = sgn(p) product_i (L+a_i)^(e_(p(i))).

The canonical model is a_i=i and e_j=j. Suppose the supported bipartite graph is a vertex-disjoint union of forced matching edges and simple alternating cycles. A cycle with m rows and m columns has exactly two local perfect matchings, denoted A and B. Call it cost-active if their two total edge costs differ. Costs may be arbitrary real numbers, with no integrality, positivity, or bound assumed.

For any real target t, let F be the entire supported additive-cost fiber.

**Theorem A.** If at most three cycles are cost-active and F is nonempty, then sum_(p in F) f_p(L) is nonzero.

**Theorem B.** The same conclusion holds if at most four cycles are cost-active and each cost-active cycle has an even number of rows (equivalently, its bipartite cycle length is divisible by four).

There may be arbitrarily many cost-inactive cycles, of arbitrary lengths, in both statements. In particular, Theorem B applies to up to four active K_(2,2) blocks. Theorem A allows both parities of local matching flips. The case of four active cycles of mixed flip parity is not asserted here.

These theorems also apply to any maximum-degree-two supported bipartite graph with a perfect matching: each path component has a unique perfect matching, and deleting edges that participate in no perfect matching leaves forced edges and cycles. The number of vertices, the individual cycle lengths, and the magnitudes of the exponents are unrestricted.

## 2. Exact product representation and inactive factors

Number the cycle components j=1,...,r. Let m_j be the number of rows on cycle j, and set

    epsilon_j = (-1)^(m_j-1).

Switching its two local matchings is an m_j-cycle on the assigned columns, so epsilon_j is exactly the change in the permutation sign.

Let A_j(L), B_j(L) be the unsigned monomial products of the translated powers for its two local matchings. Both are monic of the same degree: each uses precisely the columns of that component once. Let H(L) be the product contributed by forced edges and sigma be the sign of the all-A baseline matching. A matching is indexed uniquely by x in {0,1}^r, with

    f_x(L) = sigma H(L) product_j [A_j(L) if x_j=0,
                                  epsilon_j B_j(L) if x_j=1].

If c_0 is the baseline cost and delta_j=cost(B_j)-cost(A_j), its cost is

    c_0 + sum_j delta_j x_j.

Each A_j and B_j is nonzero, and A_j != B_j. Indeed, some row receives different columns in the two matchings; their exponents are distinct, and the distinct roots -a_i identify every row's exponent multiplicity. Therefore

    A_j(L) + epsilon_j B_j(L) != 0.

For epsilon_j=+1 its leading coefficient is 2. For epsilon_j=-1, unique factorization and A_j != B_j exclude the zero polynomial.

If delta_j=0, both local orientations occur independently with every eligible choice on the other cycles. Summing this coordinate factors out A_j+epsilon_j B_j. After factoring all such coordinates, the complete fiber polynomial is a nonzero common factor times the signed polynomial of the cost-active coordinates. This step uses the entire fiber; it is not valid for an arbitrary nonclosed selection of terms.

For every remaining negative delta_j, interchange the labels A_j and B_j. This replaces delta_j by -delta_j, changes the baseline cost and at most the overall sign, and leaves epsilon_j unchanged. We may consequently assume

    delta_j > 0 for every remaining coordinate.

The active fiber is now

    S = {x in {0,1}^s : sum_j delta_j x_j = tau},

where s is the number of cost-active cycles. It is an antichain under coordinatewise inclusion: if x<y, strict positivity gives delta dot x < delta dot y. No affine-closure catalogue or finite bound on the costs is needed.

## 3. Two elementary polynomial facts

All active matching products have the same total degree D and unsigned leading coefficient 1. Their signed leading coefficient is epsilon^x=product_j epsilon_j^(x_j).

1. An odd number of active matching terms cannot cancel: the degree-D coefficient is a sum of an odd number of elements of {+1,-1}, and is therefore nonzero.
2. Two distinct active matching terms cannot cancel. If their leading signs agree, the leading coefficient is +2 or -2. If they disagree, cancellation would require equality of the two unsigned monomial products. Distinct row roots and distinct column exponents make that equality impossible, by the root multiplicity argument in Section 2.

A singleton is covered by the first fact. Once the active polynomial is nonzero, the full polynomial is nonzero because all factored inactive and forced-edge factors are nonzero and R[L] is an integral domain.

## 4. Proof of Theorem A

Every antichain in {0,1}^s for s<=3 has at most three members. Here is a direct proof, avoiding any external combinatorial theorem.

For three coordinates, an antichain containing the empty or full set is a singleton. Otherwise its members are singletons and two-element sets. If it contains a singleton, every two-element member must avoid its index. With one singleton there is at most one such pair; with two or more singletons there are none. With no singleton there are at most the three pairs. Thus the size is at most three. The cases of fewer coordinates follow by viewing them inside the three-coordinate cube with unused coordinates fixed.

A nonempty active fiber therefore has one, two, or three members. Section 3 proves noncancellation in every case, independently of the local sign character. Factoring the inactive cycles proves Theorem A.

## 5. A four-coordinate parity lemma and Theorem B

**Lemma.** A nonempty antichain S in the subsets of a four-element set with

    sum_(X in S) (-1)^|X| = 0

has exactly two members.

If the empty or full set belongs to S, S is a singleton and is not balanced. Otherwise write a,b,c for its numbers of singletons, pairs, and triples. Balance says b=a+c.

- If a>=2, every pair must avoid the indices of at least two selected singletons. There is at most one possible pair, so b<=1<a+c.
- If c>=2, choose two distinct selected triples. They omit two different indices. A pair must avoid being contained in either triple, so it must contain both omitted indices. Again b<=1<a+c.
- If a>=1 and c>=1, a selected singleton cannot lie in a selected triple. They must therefore be complementary. Every pair either contains the singleton or is contained in the triple, so no pair belongs to the antichain. This contradicts b=a+c>0.

Consequently at most one of a,c is nonzero, and that number is at most one. Nonemptiness and b=a+c force a+c=b=1, giving exactly two members. QED.

For Theorem B, s<=3 is already covered. When s=4, every active m_j is even, so epsilon_j=-1. The degree-D coefficient of the active polynomial is exactly the alternating cardinality in the lemma. If it is nonzero, we are done. If it is zero, the fiber has exactly two members, and Section 3 again proves noncancellation. Factoring the inactive cycles finishes the proof.

## 6. What is new, and what is not proved

The preceding paired-six theorem required pair-invariant support and equal costs in each fixed reflected row pair. The present theorems impose a different sparsity hypothesis: the support components are independent cycles, but their lengths may be arbitrary, their row labels need not be reflected or adjacent, and their two local matching costs can differ. In particular, no row-pair equality of costs is assumed. The present dimension and number of inactive cycles are unbounded. The polynomial statement also allows arbitrary distinct real offsets and distinct nonnegative integer exponents.

These hypotheses do not cover general sparse supports with interacting alternating cycles, the unrestricted canonical n=6 question, or the general complete-fiber noncancellation conjecture. The theorem is not obtained by extrapolating bounded computations. It is a direct product and antichain proof. It yields no P-versus-NP separation and does not establish a general polynomial-time isolation algorithm.

Two exact limits of the leading-coefficient argument are retained in the verifier:

- With four active cycles and a mixed sign character (-1,+1,+1,+1), equal positive differences and target two give the six two-element subsets and a zero leading coefficient. This is why Theorem B's sign hypothesis is not silently removed. A zero leading coefficient is not a zero polynomial.
- With five active odd-flip cycles, differences (1,1,1,1,2) and target three give eight members: four triples avoiding the fifth coordinate and four pairs containing it. Their signed leading coefficients cancel. This is why the four-coordinate parity lemma cannot simply be extended to five. Again, no polynomial cancellation is claimed.

## 7. Verification and recovery

`verify_theorem.py` is a standalone standard-library checker. It exhaustively reconstructs every antichain on at most four coordinates and checks the two combinatorial lemmas. It independently enumerates actual perfect matchings of several cycle-support graphs, checks complete cost fibers, expands all signed polynomials, and compares them with the factored representation, including negative and zero cycle cost differences, mixed local flip parities, long cycles, noncanonical offsets and exponents, and many inactive components. It also checks the two boundary examples above and a repeated-offset negative control.

The antichain census is a finite independent check, not a premise replacing the analytic proof. Sample polynomial instances verify implementation and illustrate scope; they are not claimed to exhaust arbitrary offsets or exponents.

Run:

    python verify_theorem.py --output VERIFICATION.json
    python -O verify_theorem.py --output VERIFICATION_OPTIMIZED.json

Suspend the theorem if the cycle sign/product representation is wrong, inactive choices do not factor for an entire fiber, a supposedly active reorientation fails to make all differences positive, the antichain argument fails, or two different active matching terms have equal root-multiplicity data despite distinct offsets and exponents. Preserve the exact graph, costs, full fiber, cycle decomposition, and coefficient vectors for any disputed instance.
