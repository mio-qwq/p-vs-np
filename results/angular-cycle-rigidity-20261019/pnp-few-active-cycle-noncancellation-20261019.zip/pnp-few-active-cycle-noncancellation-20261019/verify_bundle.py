#!/usr/bin/env python3
"""Verify hashes, both execution modes, and deliberate corruption rejection."""
import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

def need(ok, message):
    if not ok:
        raise ValueError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def integrity(root):
    manifest = json.loads((root / 'PACKAGE_MANIFEST.json').read_text())
    need(manifest['format'] == 'few-active-cycle-source-checkpoint-v1', 'Unknown manifest format')
    for name, record in manifest['files'].items():
        relative = Path(name)
        need(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe manifest path')
        path = root / relative
        need(path.is_file() and not path.is_symlink(), 'Missing or nonregular payload: ' + name)
        data = path.read_bytes()
        need(len(data) == record['bytes'], 'Payload length mismatch: ' + name)
        need(digest(data) == record['sha256'], 'Payload hash mismatch: ' + name)
    original = json.loads((root / 'primary/MANIFEST.json').read_text())
    for name, record in original['essential_files'].items():
        data = (root / 'primary' / name).read_bytes()
        need(len(data) == record['bytes'] and digest(data) == record['sha256'],
             'Original source pin mismatch: ' + name)
    review = json.loads((root / 'audit/SHORT_AUDIT.json').read_text())
    for name, key in [('primary/PROOF.md', 'reviewed_primary_proof_sha256'),
                      ('audit/check_antichain_audit.py', 'independent_checker_sha256'),
                      ('audit/INDEPENDENT_ANTICHAIN_VERIFICATION.json', 'independent_receipt_sha256')]:
        need(digest((root / name).read_bytes()) == review[key],
             'Independent review pin mismatch: ' + name)
    return len(manifest['files'])

def run(script, optimized, args, cwd, rejected_with=None):
    command = [sys.executable, '-I', '-B'] + (['-O'] if optimized else [])
    completed = subprocess.run(command + [str(script)] + [str(x) for x in args],
                               cwd=cwd, text=True, capture_output=True, timeout=60)
    if rejected_with is None:
        need(completed.returncode == 0,
             'Checker failed: ' + script.name + '\n' + completed.stderr)
    else:
        need(completed.returncode != 0 and rejected_with in completed.stderr,
             'Corruption was not correctly rejected: ' + script.name + '\n' + completed.stderr)
    return completed

def replace_once(source, old, new):
    need(source.count(old) == 1, 'Mutation target not unique: ' + old)
    return source.replace(old, new, 1)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    payload_count = integrity(ROOT)
    scripts = ['primary/verify_theorem.py', 'audit/check_antichain_audit.py',
               'verify_bundle.py', 'rebuild.py']
    for script in scripts:
        tree = ast.parse((ROOT / script).read_text())
        need(not any(isinstance(node, ast.Assert) for node in ast.walk(tree)),
             'Optimization-removable assertion found: ' + script)
    primary = ROOT / 'primary/verify_theorem.py'
    audit = ROOT / 'audit/check_antichain_audit.py'
    p_reference = (ROOT / 'primary/VERIFICATION.json').read_bytes()
    a_reference = (ROOT / 'audit/INDEPENDENT_ANTICHAIN_VERIFICATION.json').read_bytes()
    need(p_reference == (ROOT / 'primary/VERIFICATION_OPTIMIZED.json').read_bytes(),
         'Primary normal and optimized references differ')
    p_receipt = json.loads(p_reference)
    need(p_receipt['status'] == 'PASS', 'Primary reference did not pass')
    need(p_receipt['source_sha256'] == digest(primary.read_bytes()), 'Primary source receipt pin failed')
    need(sum(x['perfect_matchings'] for x in p_receipt['graph_checks']) == 132,
         'Unexpected matching total')
    need(sum(x['complete_fibers'] for x in p_receipt['graph_checks']) == 42,
         'Unexpected complete fiber total')
    antichains = [x['antichains_including_empty'] for x in p_receipt['antichains']]
    need(antichains == [2, 3, 6, 20, 168], 'Unexpected primary census')
    need([x['antichains_including_empty'] for x in json.loads(a_reference)['dimensions']] == antichains,
         'Primary and independent antichain censuses disagree')

    rejected = []
    with tempfile.TemporaryDirectory(prefix='few-active-cycle-verify-') as name:
        work = Path(name)
        for optimized in (False, True):
            mode = 'optimized' if optimized else 'normal'
            p_output = work / ('primary-' + mode + '.json')
            a_output = work / ('audit-' + mode + '.json')
            run(primary, optimized, ['--output', p_output], work)
            run(audit, optimized, ['--output', a_output, '--verify-receipt',
                                  ROOT / 'audit/INDEPENDENT_ANTICHAIN_VERIFICATION.json'], work)
            need(p_output.read_bytes() == p_reference, 'Primary replay differs in ' + mode)
            need(a_output.read_bytes() == a_reference, 'Audit replay differs in ' + mode)

            primary_text = primary.read_text()
            mutations = [
                ('wrong_antichain_census', '[2, 3, 6, 20, 168][r]',
                 '[2, 3, 6, 20, 169][r]', 'antichain census mismatch'),
                ('wrong_cycle_flip_sign', 'local.append((A, B, (-1)**(m-1)))',
                 'local.append((A, B, (-1)**m))', 'cycle sign formula failed'),
                ('zero_inactive_factor', 'factor = add(A, signed(B,ep))',
                 'factor = [0]', 'inactive factor vanished'),
            ]
            for label, old, new, expected in mutations:
                path = work / (label + '.py')
                path.write_text(replace_once(primary_text, old, new))
                run(path, optimized, ['--output', work / 'unexpected.json'], work,
                    rejected_with=expected)
                rejected.append(label + ':' + mode)

            for label in ('altered_audit_count', 'altered_audit_claim'):
                receipt = copy.deepcopy(json.loads(a_reference))
                if label == 'altered_audit_count':
                    receipt['dimensions'][4]['antichains_including_empty'] += 1
                else:
                    receipt['checked_claims'][0] = 'An unsupported claim was inserted.'
                path = work / (label + '.json')
                path.write_text(json.dumps(receipt))
                run(audit, optimized, ['--verify-receipt', path], work,
                    rejected_with='Receipt mismatch')
                rejected.append(label + ':' + mode)

        corrupted = work / 'corrupted-payload'
        shutil.copytree(ROOT, corrupted)
        proof = corrupted / 'primary/PROOF.md'
        data = bytearray(proof.read_bytes())
        data[0] ^= 1
        proof.write_bytes(data)
        try:
            integrity(corrupted)
        except ValueError as error:
            need('Payload hash mismatch: primary/PROOF.md' in str(error),
                 'Unexpected payload-corruption diagnostic')
        else:
            raise ValueError('Payload corruption was accepted')
        rejected.append('same_length_payload_corruption:sha256')

    report = {
        'format': 'few-active-cycle-bundle-verification-v1',
        'status': 'PASS',
        'payload_files_hash_verified': payload_count,
        'original_source_pins_verified': 4,
        'independent_review_pins_verified': 3,
        'checker_replays': ['primary:normal', 'primary:optimized', 'audit:normal', 'audit:optimized'],
        'reference_receipts_reproduced_byte_for_byte': True,
        'optimization_removable_assertions': 0,
        'antichain_census': antichains,
        'graph_instances': 6,
        'perfect_matchings': 132,
        'complete_fibers': 42,
        'corruption_controls_rejected': rejected,
        'scope': 'Supplemental exact finite checks and artifact integrity; analytic proofs supply the unbounded theorem.',
    }
    rendered = json.dumps(report, indent=2, sort_keys=True) + '\n'
    if args.output is not None:
        args.output.write_text(rendered)
    print(rendered, end='')

if __name__ == '__main__':
    main()
