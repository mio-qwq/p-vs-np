#!/usr/bin/env python3
"""Deterministically rebuild this source ZIP using only the Python standard library."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
ARCHIVE_ROOT = 'pnp-few-active-cycle-noncancellation-20261019'

def need(ok, message):
    if not ok:
        raise ValueError(message)

def payload_paths():
    manifest = json.loads((ROOT / 'PACKAGE_MANIFEST.json').read_text())
    paths = sorted(list(manifest['files']) + ['PACKAGE_MANIFEST.json'])
    for name, record in manifest['files'].items():
        p = ROOT / name
        need(p.is_file() and not p.is_symlink(), 'Missing or nonregular payload: ' + name)
        data = p.read_bytes()
        need(len(data) == record['bytes'], 'Payload length mismatch: ' + name)
        need(hashlib.sha256(data).hexdigest() == record['sha256'], 'Payload hash mismatch: ' + name)
    return paths

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    paths = payload_paths()
    need(args.output.resolve() not in [(ROOT / p).resolve() for p in paths], 'Output would overwrite payload')
    with ZipFile(args.output, 'w', compression=ZIP_STORED, allowZip64=False) as archive:
        for name in paths:
            info = ZipInfo(ARCHIVE_ROOT + '/' + name, date_time=(2026, 10, 19, 0, 0, 0))
            info.create_system = 3
            info.compress_type = ZIP_STORED
            info.external_attr = 0o100644 << 16
            info.flag_bits = 0
            info.extra = b''
            info.comment = b''
            archive.writestr(info, (ROOT / name).read_bytes())
    data = args.output.read_bytes()
    print(json.dumps({'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}, sort_keys=True))

if __name__ == '__main__':
    main()
