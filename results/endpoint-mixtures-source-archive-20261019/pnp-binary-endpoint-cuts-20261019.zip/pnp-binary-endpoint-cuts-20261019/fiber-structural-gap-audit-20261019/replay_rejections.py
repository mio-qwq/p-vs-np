#!/usr/bin/env python3
"""Recheck every rejection from the serialized matrix, without importing enumeration."""
import gzip
import hashlib
import itertools
import json
from pathlib import Path
import sys

root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
perms=list(itertools.permutations(range(5)))
weights={1:[],2:[]}
for p in perms:
    inv=sum(a>b for i,a in enumerate(p) for b in p[i+1:])
    # Expand all linear factors, then evaluate by Horner (not direct products).
    poly=[-1 if inv%2 else 1]
    for row in range(5):
        for rep in range(p[row]):
            new=[0]*(len(poly)+1)
            for d,c in enumerate(poly):
                new[d]+=row*c; new[d+1]+=c
            poly=new
    for x in weights:
        value=0
        for a in reversed(poly): value=value*x+a
        weights[x].append(value)
seen=set(); counts={}; zero_cases=0
with gzip.open(root/'REJECTIONS.jsonl.gz','rt') as handle:
    for line in handle:
        r,k,encoded,mask_text,x,claimed=json.loads(line)
        key=(k,encoded)
        if key in seen: raise RuntimeError('Repeated assignment')
        seen.add(key)
        cells=[]; tmp=encoded
        for _ in range(25): tmp,digit=divmod(tmp,3); cells.append(digit)
        if tmp: raise RuntimeError('Invalid ternary matrix')
        rows=[cells[z:z+5] for z in range(0,25,5)]
        mask=0; value=0; first_value=0
        for n,p in enumerate(perms):
            selection=[rows[i][p[i]] for i in range(5)]
            if 0 not in selection and selection.count(2)==k:
                mask+=1<<n
                value+=weights[x][n]
                first_value+=weights[1][n]
        if mask!=int(mask_text,16): raise RuntimeError('Incomplete recorded fiber')
        if value!=claimed or value==0: raise RuntimeError('Incorrect rejection witness')
        if x not in (1,2) or (x==2 and first_value!=0): raise RuntimeError('Incorrect witness selection')
        zero_cases+= x==2
        counts[(r,k)]=counts.get((r,k),0)+1
result={'replayed_records':len(seen),'group_counts':{str(k):v for k,v in counts.items()},
        'L1_zero_L2_nonzero':zero_cases,'all_full_fibers_reconstructed':True,
        'all_rejection_values_recomputed_by_coefficient_expansion':True,
        'replay_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'ledger_sha256':hashlib.sha256((root/'REJECTIONS.jsonl.gz').read_bytes()).hexdigest()}
if len(seen)!=207360 or zero_cases!=12: raise RuntimeError('Wrong record counts')
(root/'REPLAY_CERTIFICATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
