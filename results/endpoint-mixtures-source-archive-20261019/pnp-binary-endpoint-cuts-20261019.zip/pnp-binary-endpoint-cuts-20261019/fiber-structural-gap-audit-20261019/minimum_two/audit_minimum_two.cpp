// Independent exact n=5 minimum-endpoint-two enumeration. Standard C++17.
// Designed from the mathematical decomposition, not the parent implementation.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using I=int64_t;
struct Term { array<int,5> p; array<int,5> cells; I at1,at2; string text; };
struct Counts {I bases=0,tested=0,kept=0,interiors=0,full=0,zero=0;};
void require(bool ok,const string& why){if(!ok)throw runtime_error(why);}
I power(I base,int n){I value=1;while(n--)value*=base;return value;}
int main(int argc,char**argv){
 try {
  require(argc==3,"Usage: audit_minimum_two INPUT PREFIX");
  ifstream in(argv[1]);require(bool(in),"Cannot open slice input");
  int count;in>>count;require(count==24,"Expected 24 audited slice masks");
  vector<uint32_t> slices(count);set<uint32_t> distinct;
  for(auto &mask:slices){in>>mask;require(mask>0 && mask<(1u<<24),"Invalid slice mask");distinct.insert(mask);}
  require(distinct.size()==24,"Duplicate slice membership");
  vector<Term> terms;vector<int> residual;
  array<int,5> p={0,1,2,3,4};
  do {
   int inv=0;for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)inv+=p[i]>p[j];
   Term term{p,{},inv%2?-1:1,inv%2?-1:1,""};
   for(int i=0;i<5;i++){term.cells[i]=5*i+p[i];term.at1*=power(i+1,p[i]);term.at2*=power(i+2,p[i]);term.text+=char('0'+p[i]);}
   if(p[0]==2)residual.push_back(terms.size());
   terms.push_back(term);
  }while(next_permutation(p.begin(),p.end()));
  require(terms.size()==120 && residual.size()==24,"Wrong permutation catalogue");
  I largest1=0,largest2=0,sumabs1=0,sumabs2=0;for(const auto&t:terms){I a=t.at1<0?-t.at1:t.at1,b=t.at2<0?-t.at2:t.at2;largest1=max(largest1,a);largest2=max(largest2,b);sumabs1+=a;sumabs2+=b;}
  require(largest2<1000000000LL,"Unexpected arithmetic bound");
  cerr<<"max_abs_term_at_1="<<largest1<<"; max_abs_term_at_2="<<largest2<<"; sum_bound="<<120*largest2<<"; sum_abs_at_1="<<sumabs1<<"; sum_abs_at_2="<<sumabs2<<"\n";
  ofstream stats(string(argv[2])+"_STATS.tsv"),zeros(string(argv[2])+"_ZEROS.tsv");
  require(bool(stats)&&bool(zeros),"Cannot create output");
  stats<<"slice_id\tk\tunion_edges\tbases\tresidual_extensions_tested\tresidual_extensions_kept\tinteriors\tfull_assignments\tQ1_zero\n";
  zeros<<"slice_id\tk\tpacked_matrix\tQ2\tcomplete_fiber\n";
  array<Counts,3> totals{};
  set<pair<int,I>> all_assignments;
  for(int sid=0;sid<24;sid++){
   uint32_t desired=slices[sid];array<int,25> matrix{};set<int> used;
   for(int n=0;n<24;n++)if((desired>>n)&1)for(int i=1;i<5;i++)used.insert(terms[residual[n]].cells[i]);
   vector<int> mandatory(used.begin(),used.end()),optional;
   for(int i=1;i<5;i++)for(int j=0;j<5;j++)if(j!=2&&!used.count(5*i+j))optional.push_back(5*i+j);
   require(mandatory.size()+optional.size()==16,"Incorrect residual partition");
   auto residual_fiber=[&](int target){
    uint32_t result=0;
    for(int n=0;n<24;n++){
     bool supported=true;int red=0;
     for(int i=1;i<5;i++){int v=matrix[terms[residual[n]].cells[i]];if(!v){supported=false;break;}red+=(v==2);}
     if(supported&&red==target)result|=(1u<<n);
    }
    return result;
   };
   array<Counts,3> groups{};
   for(uint32_t bits=0;bits<(1u<<mandatory.size());bits++){
    for(size_t j=0;j<mandatory.size();j++)matrix[mandatory[j]]=1+((bits>>j)&1);
    for(int z:optional)matrix[z]=0;
    int first=0;while(!((desired>>first)&1))first++;
    int target=0;for(int i=1;i<5;i++)target+=(matrix[terms[residual[first]].cells[i]]==2);
    if(target>2 || residual_fiber(target)!=desired)continue;
    vector<pair<int,int>> hypotheses;
    for(int k=1;k<=2;k++)if(k-target==0||k-target==1)hypotheses.push_back({k,k-target});
    for(auto kc:hypotheses)groups[kc.first].bases++;
    for(I ext=0;ext<power(3,optional.size());ext++){
     I code=ext;for(int z:optional){matrix[z]=code%3;code/=3;}
     for(auto kc:hypotheses)groups[kc.first].tested++;
     if(residual_fiber(target)!=desired)continue;
     for(auto kc:hypotheses){
      int k=kc.first,c=kc.second;auto &g=groups[k];g.kept++;
      matrix[0]=matrix[1]=0;matrix[2]=c+1;
      for(int deleted=0;deleted<81;deleted++){
       int tmp=deleted;for(int i=1;i<5;i++){matrix[5*i+2]=tmp%3;tmp/=3;}g.interiors++;
       for(int u=1;u<=2;u++)for(int v=1;v<=2;v++){
        matrix[3]=u;matrix[4]=v;I q1=0,q2=0;vector<int> actual;
        for(int n=0;n<120;n++){
         bool supported=true;int cost=0;
         for(int cell:terms[n].cells){int state=matrix[cell];if(!state){supported=false;break;}cost+=(state==2);}
         if(supported&&cost==k){q1+=terms[n].at1;q2+=terms[n].at2;actual.push_back(n);}
        }
        require(!actual.empty(),"Unexpected empty complete fiber");
        uint32_t actual_slice=0;
        for(int n:actual)if(terms[n].p[0]==2){auto it=find(residual.begin(),residual.end(),n);actual_slice|=1u<<distance(residual.begin(),it);}
        require(actual_slice==desired,"Full matrix changed its prescribed slice");
        I encoded=0,mult=1;for(int x:matrix){encoded+=x*mult;mult*=3;}
        require(all_assignments.insert({k,encoded}).second,"Duplicate support/color/target triple");
        g.full++;
        if(q1==0){
         g.zero++;require(q2!=0,"An assignment survived both evaluations");
         zeros<<sid<<'\t'<<k<<'\t'<<encoded<<'\t'<<q2<<'\t';bool first=true;
         for(int n:actual){if(!first)zeros<<',';first=false;zeros<<terms[n].text;}zeros<<'\n';
        }
       }
      }
     }
    }
   }
   for(int k=1;k<=2;k++){
    const auto&g=groups[k];require(g.interiors==81*g.kept&&g.full==4*g.interiors,"Extension count inconsistency");
    stats<<sid<<'\t'<<k<<'\t'<<mandatory.size()<<'\t'<<g.bases<<'\t'<<g.tested<<'\t'<<g.kept<<'\t'<<g.interiors<<'\t'<<g.full<<'\t'<<g.zero<<'\n';
    auto &a=totals[k];a.bases+=g.bases;a.tested+=g.tested;a.kept+=g.kept;a.interiors+=g.interiors;a.full+=g.full;a.zero+=g.zero;
   }
  }
  for(int k=1;k<=2;k++){
   const auto&g=totals[k];cout<<"k="<<k<<"; bases="<<g.bases<<"; residual_tested="<<g.tested<<"; residual_kept="<<g.kept<<"; interiors="<<g.interiors<<"; full="<<g.full<<"; Q1_zero="<<g.zero<<"; both_zero=0\n";
  }
  require(totals[1].tested==50523&&totals[1].kept==2713&&totals[1].full==879012&&totals[1].zero==1154,"k=1 proof counts differ");
  require(totals[2].tested==151422&&totals[2].kept==7311&&totals[2].full==2368764&&totals[2].zero==3491,"k=2 proof counts differ");
  require(all_assignments.size()==3247776,"Wrong unique assignment total");
  cout<<"distinct_support_color_target_triples="<<all_assignments.size()<<"\n";
 }catch(const exception&e){cerr<<e.what()<<'\n';return 1;}
}
