#!/usr/bin/env python3
"""Independent Python coefficient replay and optional parent-certificate comparison."""
import csv
import hashlib
import itertools
import json
from pathlib import Path
import sys

root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
parent=Path(sys.argv[2]) if len(sys.argv)>2 else None

def need(ok,why):
    if not ok: raise RuntimeError(why)

perms=list(itertools.permutations(range(5)))
texts=[''.join(map(str,p)) for p in perms]
coefficients=[]
for p in perms:
    sign=(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
    poly=[sign]
    for i in range(5):
        for _ in range(p[i]):
            new=[0]*(len(poly)+1)
            for d,c in enumerate(poly):new[d]+=i*c;new[d+1]+=c
            poly=new
    coefficients.append(poly)

def evaluate(poly,x):
    result=0
    for c in reversed(poly):result=result*x+c
    return result

all1=[evaluate(poly,1) for poly in coefficients]
all2=[evaluate(poly,2) for poly in coefficients]
bounds={'sum_abs_at_L1':sum(map(abs,all1)),'sum_abs_at_L2':sum(map(abs,all2)),
        'max_abs_at_L1':max(map(abs,all1)),'max_abs_at_L2':max(map(abs,all2))}
need(max(bounds.values())<2**63,'64-bit bound failed')
prior=json.loads((root/'INPUT_PROVENANCE.json').read_text())
residual=[s for s,p in zip(texts,perms) if p[0]==2]
masks=list(map(int,(root/'SLICE_INPUT.txt').read_text().split()))
need(masks[0]==24 and sorted(masks[1:])==prior['sorted_masks'],'Wrong input data')
selected=[{residual[n] for n in range(24) if mask>>n&1} for mask in masks[1:]]
results=[]; seen=set(); summary={1:0,2:0}; compared=set()
with (root/'NORMAL_ZEROS.tsv').open() as f:
    for record in csv.DictReader(f,delimiter='\t'):
        sid,k,encoded,q2=(int(record[v]) for v in ('slice_id','k','packed_matrix','Q2'))
        tmp=encoded;matrix=[]
        for _ in range(25):tmp,digit=divmod(tmp,3);matrix.append(digit)
        need(tmp==0,'Invalid packed matrix')
        need(matrix[0:2]==[0,0] and all(matrix[j] in (1,2) for j in (2,3,4)), 'Wrong endpoint support')
        support=sum(1<<i for i,v in enumerate(matrix) if v)
        reds=sum(1<<i for i,v in enumerate(matrix) if v==2)
        key=(k,support,reds);need(key not in seen,'Repeated exceptional assignment');seen.add(key)
        fiber=[];poly=[0]*11
        complement_fiber=[]
        complement=[3-v if v else 0 for v in matrix]
        for n,p in enumerate(perms):
            cells=[matrix[5*i+p[i]] for i in range(5)]
            if all(cells) and cells.count(2)==k:
                fiber.append(texts[n])
                poly=[a+b for a,b in zip(poly,coefficients[n])]
            inverse_cells=[complement[5*i+p[i]] for i in range(5)]
            if all(inverse_cells) and inverse_cells.count(2)==5-k:
                complement_fiber.append(texts[n])
        need(fiber==record['complete_fiber'].split(','),'Incomplete C++ survivor fiber')
        need(fiber==complement_fiber,'Color-complement transport failed')
        need({s for s in fiber if s[0]=='2'}==selected[sid],'Incorrect root slice')
        need(evaluate(poly,1)==0 and evaluate(poly,2)==q2 and q2!=0,'Incorrect polynomial rejection')
        summary[k]+=1;compared.add((k,support,reds,q2,len(fiber)))
        results.append({'slice_id':sid,'k':k,'support_mask_25':support,'red_mask_25':reds,
                        'Q_1':0,'Q_2':q2,'fiber_size':len(fiber),'fiber':fiber,'polynomial_coefficients':poly})
need(summary=={1:1154,2:3491},'Wrong survivor total')
cross={}
if parent:
    cert=json.loads(parent.read_text())
    expected={(case['k'],s['support_mask_25'],s['red_mask_25'],s['Q_2'],s['fiber_size'])
              for case in cert['cases'] if case['mode']=='minimum_two' for s in case['L1_survivors']}
    need(expected==compared,'Parent and independent survivor assignments differ')
    parent_r2=next(v for v in cert['root_catalogues'] if v['r']==2)
    parent_sets={tuple(sorted(s['members'])) for s in parent_r2['closed_sets']}
    need(parent_sets=={tuple(sorted(s)) for s in selected},'Parent and prior r=2 catalogue differ')
    # Also compare all gap exceptions from the independently replayed gap audit.
    gap=json.loads((root.parent/'AUDIT_CERTIFICATE.json').read_text())
    own_gap=set()
    for s in gap['q1_zero_cases']:
        mat=sum(s['matrix'],[])
        sm=sum(1<<i for i,v in enumerate(mat) if v)
        rm=sum(1<<i for i,v in enumerate(mat) if v==2)
        own_gap.add((s['r'],s['k'],sm,rm,s['q2'],len(s['fiber'])))
    parent_gap={(case['r'],case['k'],s['support_mask_25'],s['red_mask_25'],s['Q_2'],s['fiber_size'])
                for case in cert['cases'] if case['mode']=='gap' for s in case['L1_survivors']}
    need(own_gap==parent_gap,'Parent and independent gap survivors differ')
    cross={'parent_certificate_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),
           'all_4645_minimum_two_survivors_identical':True,'all_12_gap_survivors_identical':True,
           'all_24_r2_slice_memberships_identical':True}
supports=[]
for bits in itertools.product((0,1),repeat=5):
    if sum(bits)<3:continue
    cols=[i for i,b in enumerate(bits) if b]
    combined=bool(bits[1] and (bits[0] or bits[2]))
    previous=bool(bits[0]<=bits[1] and bits[1]<=bits[0]+bits[2] and cols!=[2,3,4])
    need(combined==previous,'Combined endpoint cuts disagree')
    if combined:supports.append(cols)
need(len(supports)==10,'Wrong combined support count')
output={'status':'passed','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'cpp_source_sha256':hashlib.sha256((root/'audit_minimum_two.cpp').read_bytes()).hexdigest(),
        'survivor_counts':summary,'integer_arithmetic_bounds':bounds,'cross_comparison':cross,
        'remaining_endpoint_supports':supports,'survivors':results}
(root/'SURVIVOR_REPLAY.json').write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='survivors'},sort_keys=True))
