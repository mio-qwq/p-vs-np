#!/usr/bin/env python3
"""Independent, exhaustive ternary-matrix audit. Python standard library only.

Designed using the proof statements, without reading the exploratory code.
No assertions are used. 0=absent, 1=blue (cost 0), 2=red (cost 1).
Every accepted matrix is evaluated against all 120 global permutations.
"""
from collections import Counter
from hashlib import sha256
from itertools import combinations, permutations, product
from math import comb, prod
from pathlib import Path
import argparse
import gzip
import json

SLICE_TEXT = {
    0: ('02431','03142','03241','04123','04132','04231','04321'),
    1: ('10234','10243','10324','10342','12304','13204','14203','14302'),
}
PERMS = tuple(permutations(range(5)))
INDEX = {p: n for n, p in enumerate(PERMS)}
EDGES = tuple(tuple(5*i+p[i] for i in range(5)) for p in PERMS)

def ensure(condition, message):
    if not condition:
        raise RuntimeError(message)

def parity(p):
    return (-1)**sum(p[i] > p[j] for i in range(5) for j in range(i+1,5))

def cycle_parity(p):
    seen=set(); cycles=0
    for i in range(5):
        if i not in seen:
            cycles += 1
            while i not in seen:
                seen.add(i); i=p[i]
    return (-1)**(5-cycles)

def term_at(p, x):
    return parity(p)*prod((x+i)**p[i] for i in range(5))

def coefficients(p):
    out=[parity(p)]
    for row, exponent in enumerate(p):
        for _ in range(exponent):
            nxt=[0]*(len(out)+1)
            for d,c in enumerate(out):
                nxt[d] += row*c
                nxt[d+1] += c
            out=nxt
    return out

def coeff_eval(cs,x):
    out=0
    for c in reversed(cs):
        out=out*x+c
    return out

COEFFS=tuple(coefficients(p) for p in PERMS)
VAL1=tuple(term_at(p,1) for p in PERMS)
VAL2=tuple(term_at(p,2) for p in PERMS)

def slice_mask(matrix, r, t):
    result=0
    for n,p in enumerate(PERMS):
        if p[0]!=r:
            continue
        a,b,c,d=(matrix[5*i+p[i]] for i in range(1,5))
        if a and b and c and d and a+b+c+d==t+4:
            result |= 1<<n
    return result

def full_fiber(matrix,k):
    result=0; q1=0
    for n,(i0,i1,i2,i3,i4) in enumerate(EDGES):
        a,b,c,d,e=(matrix[i0],matrix[i1],matrix[i2],matrix[i3],matrix[i4])
        if a and b and c and d and e and a+b+c+d+e==k+5:
            result |= 1<<n
            q1 += VAL1[n]
    return result,q1

def members(mask):
    return [n for n in range(120) if (mask>>n)&1]

def pack(matrix):
    return sum(v*3**i for i,v in enumerate(matrix))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output-dir',default='.')
    args=ap.parse_args(); out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    # Check the polynomial convention by two independent constructions.
    for p,cs in zip(PERMS,COEFFS):
        ensure(parity(p)==cycle_parity(p),'Permutation parity disagreement')
        for x in range(-5,6):
            ensure(coeff_eval(cs,x)==term_at(p,x),'Polynomial evaluation disagreement')
        reversed_coeff=COEFFS[INDEX[tuple(reversed(p))]]
        substituted=[sum(cs[d]*comb(d,h)*(-4)**(d-h)*(-1)**h
                         for d in range(h,11)) for h in range(11)]
        ensure(substituted==reversed_coeff,'Row reversal failed coefficient identity')
    cut_rows=[]
    for bits in product((0,1),repeat=5):
        if sum(bits)<3:
            continue
        used=[j for j in range(5) if bits[j]]
        cuts=bits[0]<=bits[1] and bits[1]<=bits[0]+bits[2]
        consecutive=used[1]==used[0]+1
        ensure(cuts==consecutive,'Support cuts not equivalent')
        cut_rows.append({'support':used,'passes':cuts})
    data={'encoding':'25 row-major ternary digits: 0 absent, 1 blue, 2 red; packed=sum(cell[i]*3**i)',
          'source_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
          'scope':'Conditional on the prior exact real-cost slice theorem; independent new binary gap exhaustion.',
          'polynomial_checks':{'permutations':120,'test_points':list(range(-5,6)),
                               'row_reversal_all_coefficients':True},
          'support_cuts':cut_rows,'slices':{},'groups':[], 'q1_zero_cases':[]}
    ledger_path=out/'REJECTIONS.jsonl.gz'
    total=0; unique=set()
    with ledger_path.open('wb') as raw, gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as ledger:
        for r in (0,1):
            selected={tuple(map(int,s)) for s in SLICE_TEXT[r]}
            wanted=sum(1<<INDEX[p] for p in selected)
            mandatory=tuple(sorted({5*i+p[i] for p in selected for i in range(1,5)}))
            missing_grid=tuple(5*i+j for i in range(1,5) for j in range(5)
                               if j!=r and 5*i+j not in mandatory)
            missing_interior=tuple(cell for cell in range(5,25) if cell not in mandatory)
            ensure(len(mandatory)==13 and len(missing_grid)==3 and len(missing_interior)==7,
                   'Wrong residual-union decomposition')
            row_patterns=[]
            for row in product((0,1,2),repeat=5):
                used=[j for j in range(5) if row[j]]
                if len(used)>=3 and used[:2]==[r,r+2]:
                    row_patterns.append(row)
            ensure(len(row_patterns)==(32 if r==0 else 8),'Wrong row pattern count')
            first_polynomial=[sum(COEFFS[INDEX[p]][d] for p in selected) for d in range(11)]
            ensure(next(d for d,c in enumerate(first_polynomial) if c)==r+2,
                   'Prescribed slice has wrong root multiplicity')
            bases={t:[] for t in range(3)}
            for binary in product((1,2),repeat=13):
                matrix=[0]*25
                for cell,value in zip(mandatory,binary): matrix[cell]=value
                for t in range(3):
                    if slice_mask(matrix,r,t)==wanted:
                        bases[t].append(binary)
            data['slices'][str(r)]={'selected':list(SLICE_TEXT[r]),
                'mandatory_edges':[[z//5,z%5] for z in mandatory],
                'missing_grid_edges':[[z//5,z%5] for z in missing_grid],
                'base_counts':{str(t):len(v) for t,v in bases.items()},
                'polynomial_coefficients':first_polynomial}
            for k in (1,2):
                count=Counter(); slice_extensions=set()
                for c in (0,1):
                    t=k-c
                    rows=[row for row in row_patterns if row[r]==c+1]
                    for binary in bases[t]:
                        count['base_colorings']+=1
                        matrix=[0]*25
                        for cell,value in zip(mandatory,binary): matrix[cell]=value
                        # Directly enumerate the seven remaining interior cells together.
                        # This does not use the exploratory program's extension staging.
                        for extras in product((0,1,2),repeat=7):
                            count['interior_candidates']+=1
                            for cell,value in zip(missing_interior,extras): matrix[cell]=value
                            if slice_mask(matrix,r,t)!=wanted:
                                continue
                            count['interiors_retained']+=1
                            residual_signature=(t,binary,tuple(matrix[z] for z in missing_grid))
                            slice_extensions.add(residual_signature)
                            for row in rows:
                                matrix[:5]=row
                                fiber,q1=full_fiber(matrix,k)
                                ensure((fiber&wanted)==wanted,'Global fiber lost prescribed slice')
                                ensure(sum(1<<n for n in members(fiber) if PERMS[n][0]==r)==wanted,
                                       'Global fiber has wrong least-exponent slice')
                                encoded=pack(matrix)
                                key=(k,encoded)
                                ensure(key not in unique,'Duplicate full support/color/target assignment')
                                unique.add(key)
                                chosen=members(fiber)
                                witness_x=1; witness=q1
                                if not q1:
                                    count['q1_zero']+=1
                                    q2=sum(VAL2[n] for n in chosen)
                                    ensure(q2!=0,'Potential polynomial-zero assignment: inspect!')
                                    witness_x=2; witness=q2
                                    cs=[sum(COEFFS[n][d] for n in chosen) for d in range(11)]
                                    ensure(coeff_eval(cs,1)==0 and coeff_eval(cs,2)==q2,'Exceptional polynomial mismatch')
                                    data['q1_zero_cases'].append({'r':r,'k':k,'packed_matrix':encoded,
                                        'matrix':[matrix[5*i:5*i+5] for i in range(5)],
                                        'fiber':[''.join(map(str,PERMS[n])) for n in chosen],
                                        'polynomial_coefficients':cs,'q2':q2})
                                count['full_assignments']+=1; total+=1
                                record=[r,k,encoded,format(fiber,'x'),witness_x,witness]
                                ledger.write((json.dumps(record,separators=(',',':'))+'\n').encode())
                count['residual_extensions_tested']=27*count['base_colorings']
                count['residual_extensions_retained']=len(slice_extensions)
                ensure(count['interiors_retained']==81*len(slice_extensions),'Interior extension accounting failed')
                count['q1_zero']=count['q1_zero']
                count['both_zero']=0
                data['groups'].append({'r':r,'k':k,**dict(sorted(count.items()))})
                print(json.dumps(data['groups'][-1]),flush=True)
    data['totals']={'full_assignments':total,'q1_zero':len(data['q1_zero_cases']),
                    'both_zero':0,'distinct_support_color_target_triples':len(unique)}
    data['ledger_sha256']=sha256(ledger_path.read_bytes()).hexdigest()
    data['ledger_schema']=['r','k','packed_matrix','fiber_bitmask_hex_lexicographic_permutations','witness_L','witness_Q_value']
    expected=[(0,1,22032,2),(0,2,76464,10),(1,1,32400,0),(1,2,76464,0)]
    for group,(r,k,n,z) in zip(data['groups'],expected):
        ensure((group['r'],group['k'],group['full_assignments'],group['q1_zero'])==(r,k,n,z),
               'Observed group count differs from proposed proof')
    ensure(total==207360 and len(data['q1_zero_cases'])==12,'Overall count mismatch')
    (out/'AUDIT_CERTIFICATE.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps(data['totals']),flush=True)

if __name__=='__main__': main()
