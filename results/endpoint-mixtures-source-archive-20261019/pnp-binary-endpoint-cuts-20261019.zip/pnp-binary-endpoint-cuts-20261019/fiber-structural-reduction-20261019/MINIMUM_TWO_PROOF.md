# Excluding endpoint minimum two in canonical binary fibers

19 October 2026. Separate local exact extension; independent enumeration, sanitizer run, and coefficient-based survivor replay have passed. No repository or earlier artifact was modified.

## Statement and consequence

In the setting of PROOF.md, with binary target k=1 or 2, a nonempty polynomial-cancelling complete fiber cannot have smallest used column 2 in either endpoint row. The previous endpoint-degree theorem would force that used-column set to be exactly {2,3,4}.

Together with the independently audited gap-two exclusion in PROOF.md, this forces column 1 to occur at both endpoint rows. More precisely, each endpoint uses at least three columns, includes column 1, and includes at least one of columns 0 and 2. Color complementation transfers these conclusions to targets 3 and 4.

## Input classification

The prior endpoint certificate, independently audited in ../endpoint-fiber-audit-20261019/, classifies exactly 24 nonempty affine-closed root-balanced subsets among the 24 permutations with p(0)=2. Its enumeration initially finds 1,242 nonempty scalar-balanced subsets. The scalar equation is

    sum_(p in S) sign(p) product_(i=1)^4 i^(p(i)) = 0.

If F is a complete fiber and r=2 is its least row-0 exponent, the coefficient of L^2 forces this scalar equality on S={p in F:p(0)=2}. Fixing the edge (0,2) leaves a complete residual fiber, so S is affine-closed. Hence S belongs to those 24 classified families. The standalone final checker regenerates this catalogue directly by exact subset sums and integer affine elimination; it does not trust an imported list. Its 24 memberships exactly match the earlier independently audited catalogue.

## Exhaustive extension

For each such S, form its union U in the four rows 1,...,4 and four columns 0,1,3,4. Enumerate every binary coloring R of U. For c=w(0,2) in {0,1}, let t=k-c. Retain a coloring only when the complete target-t fiber on U is exactly S, including exclusion of every other supported residual permutation.

Enumerate each of the 16-|U| residual-grid edges not in U independently as absent, blue, or red. Again retain only assignments whose full residual target-t fiber is precisely S. Next enumerate all 3^4 choices for the four interior edges in column 2. Finally row-0 columns 0,1 are absent, edge (0,2) has color c, and edges (0,3),(0,4) are independently blue or red, giving four choices.

Every candidate global support/coloring with endpoint minimum 2 appears. As before, support may first be reduced to union(F), making the unused row-0 columns absent. Interior unused edges are nevertheless allowed in the enumeration; that safely enlarges the family. A full assignment determines its unique root slice and all its enumerated choices. No arbitrary relabelling or numerical relaxation is used.

## Exact outcome

For every full assignment, the actual complete target-k fiber polynomial Q is tested at L=1 and then, if necessary, L=2. No assignment passes both tests. A nonzero integer value is a sufficient rejection certificate; the proof never treats two zero values as polynomial identity.

    k=1:
      50,523 residual extensions tested; 2,713 retained;
      219,753 interior assignments; 879,012 full assignments;
      1,154 have Q(1)=0; all have Q(2)!=0.

    k=2:
      151,422 residual extensions tested; 7,311 retained;
      592,191 interior assignments; 2,368,764 full assignments;
      3,491 have Q(1)=0; all have Q(2)!=0.

Total: 3,247,776 full assignments and 4,645 first-evaluation survivors, all rejected at the second evaluation. These counts are reproduced by the standalone primary verifier and an independently written C++ enumerator. Normal and undefined-behavior-sanitizer C++ outputs are byte-identical. An independent Python checker reconstructs each of the 4,645 first-evaluation survivors, expands all polynomial coefficients, and verifies its nonzero second evaluation. Every survivor assignment, value, and fiber size exactly matches the primary certificate. The exact sum of all 120 absolute term values at L=2 is 142,672,320, safely below the signed-64-bit limit used by the independent enumerator.

The row-reversal identity and color-complement proof are exactly those in PROOF.md. The target reduction is t=k-c, not k-r. Endpoint r=2 is an exponent constraint, not a red-count contribution.

## Combined audited exact cuts

For endpoint i in {0,4}, support=union(F), and binary targets k in {1,2,3,4}:

    sum_j s(i,j) >= 3,
    s(i,1) = 1,
    s(i,0)+s(i,2) >= 1.

Exactly 10 of the 16 degree-at-least-three endpoint supports survive. The previously excluded {0,3,4}, four new gap-two supports, and the new {2,3,4} account for all six exclusions. The remaining supports are

    {0,1,2}, {0,1,3}, {0,1,4}, {1,2,3}, {1,2,4},
    {0,1,2,3}, {0,1,2,4}, {0,1,3,4}, {1,2,3,4},
    {0,1,2,3,4}.

No statement is made that any surviving support admits cancellation. The global sparse binary-fiber question remains unresolved. No new numerical solver run is authorized or initiated by this structural result.

## Independent audit and reproduction

The independent report is ../fiber-structural-gap-audit-20261019/minimum_two/AUDIT.md, with frozen ACCEPTED_FILES.json, C++ enumeration source, normal and sanitizer statistics, and a separate Python survivor checker. The primary verify_reductions.py runs in ordinary and python -O modes with byte-identical certificates; the root reviewer also reran all cases with a byte-identical ROOT_REPLAY.json. This is AI-assisted finite verification, not external peer review or proof-assistant formalization.
