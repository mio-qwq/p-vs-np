# Exact canonical binary-fiber endpoint reductions

Local restricted-model research, 19 October 2026.

## Result

For canonical five-row signed polynomials f_p(L)=sign(p) product_i(L+i)^(p(i)), any nonempty cancelling complete binary edge-cost fiber at target k in {1,2,3,4} must, in each endpoint row 0 and 4:

- use at least three columns (the prior endpoint theorem);
- use column 1;
- use at least one of columns 0 and 2.

The new work excludes gap-two minima and the remaining endpoint-minimum-two case. Exactly 10 of the 16 degree-at-least-three endpoint support patterns remain. This is not a proof that a cancelling fiber exists or that none exists, and it is not a P-versus-NP result.

Both reductions are independently audited and accepted. The primary standalone verifier passed in ordinary and python -O modes, and the root reviewer replayed all cases; all three certificates are byte-identical. The independent gap audit reconstructed every complete fiber and coefficient-based rejection witness. The independent minimum-two audit used separately written C++ enumeration, an undefined-behavior sanitizer, and Python coefficient replay of every first-evaluation survivor. All exceptional assignments and values match the primary certificate. This is AI-assisted finite verification, not external peer review or proof-assistant formalization.

## Authoritative files

- PROOF.md: gap-two theorem, complete branch decomposition, row reversal, color complement, and exact support cuts.
- MINIMUM_TWO_PROOF.md: separate minimum-two extension and combined forced-column conclusion.
- verify_reductions.py: self-contained standard-library exhaustive verifier. It regenerates all root-slice catalogues used here from exact scalar subset sums and integer affine elimination. It imports no earlier research source and uses no solver.
- REDUCTION_CERTIFICATE.json: regenerated catalogues, binary slice-coloring lists, complete branch counts, every first-evaluation survivor and its nonzero second evaluation, symmetry tests, and source SHA-256.
- REDUCTION_CERTIFICATE_OPTIMIZED.json and ROOT_REPLAY.json: verified byte-identical independent executions of the primary source.
- ACCEPTED_MANIFEST.json and INDEPENDENT_COMPLETION.json: frozen acceptance and input/output hashes.
- ../fiber-structural-gap-audit-20261019/AUDIT.md and its minimum_two/AUDIT.md: independently written audit reports and sources.

Files named explore_* and EXPLORATORY_* are retained exploratory work. They are not the authoritative verification entry point.

## Reproduce

    python verify_reductions.py --output REDUCTION_CERTIFICATE.json
    python -O verify_reductions.py --output REDUCTION_CERTIFICATE_OPTIMIZED.json
    cmp REDUCTION_CERTIFICATE.json REDUCTION_CERTIFICATE_OPTIMIZED.json

Expected exact totals across both reductions:

- 3,455,136 complete support/color/target assignments
- 4,657 assignments whose complete fiber polynomial vanishes at L=1
- zero assignments vanishing at both L=1 and L=2

Two nonzero evaluations are not being used as an identity test: each rejected assignment has at least one explicitly nonzero integer evaluation, which proves its polynomial nonzero. Every first-evaluation survivor is separately checked by direct all-120-permutation enumeration and full coefficient summation.

The root catalogues regenerated are r=0: 13,419 balanced / 216 closed; r=1: 1,437 / 23; r=2: 1,242 / 24. The previously established endpoint-degree-at-least-three theorem is an explicit analytic dependency, not re-proved here.

## Next-step conditions

No further numerical solver run was performed or is authorized by this result. Any future search may use these independently audited cuts but must preserve completeness, support=union(F), exact polynomial coefficients, and fixed canonical labels, and obtain any required authorization for a new numerical run. The remaining finite cases have endpoint minimum 0 or 1 and consecutive first two used columns. The general sparse binary-fiber question remains unresolved. No outside-target constraint may be dropped, and no unsupported permutation symmetry or fixed color may be imposed. A numerical timeout or approximate infeasibility does not establish nonexistence.

All work is in a new local directory. No earlier research artifact, repository, PR, merge, or release was modified.
