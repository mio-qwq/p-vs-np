# Binary endpoint-gap reduction in canonical dimension five

19 October 2026. New local exact structural research. No repository, PR, release, or previous research artifact was modified. This is a restricted-model finite theorem, not a P-versus-NP claim. Independent gap review and complete rejection-ledger replay have passed; see ../fiber-structural-gap-audit-20261019/AUDIT.md.

## Statement

Let p range over permutations of {0,1,2,3,4}, and set

    f_p(L) = sign(p) product_i (L+i)^(p(i)).

Let G be any supported bipartite graph on these labelled rows and columns, let w:E(G)->{0,1}, and let k be 1 or 2. Let

    F = {p in PM(G): sum_i w(i,p(i))=k}.

If F is nonempty and sum_(p in F) f_p is identically zero, then the smallest and second-smallest columns used by each endpoint row, 0 and 4, differ by exactly one.

Together with the prior endpoint-degree theorem, this excludes the additional endpoint supports {0,2,3}, {0,2,4}, {0,2,3,4}, and {1,3,4}. The already excluded {0,3,4} remains excluded. The theorem also transfers to k=3,4 by complementing colors within the support. It does not by itself settle existence or nonexistence of a cancelling complete fiber.

## Prior exact input and reduction

We use the previously established real-cost endpoint theorem in ../sparse-fiber-structural-next-20261019/PROOF.md, with certificate ENDPOINT_CERTIFICATE.json:

1. Each endpoint uses at least three columns.
2. If r<s are its two smallest used columns, then s-r<=2.
3. If s=r+2, its least-exponent row-0 slice must be one of these two fixed families:

    r=0, s=2:
    S0={02431,03142,03241,04123,04132,04231,04321}.

    r=1, s=3:
    S1={10234,10243,10324,10342,12304,13204,14203,14302}.

These are the only gap-two possibilities with at least three endpoint columns. We do not assume any arbitrary row/column relabelling symmetry.

The support may first be replaced by union(F), preserving F exactly: removing edges used by no member of F loses no fiber member and creates none. Consequently the row-0 edges for unused endpoint columns may be treated as absent. Other enumerated edges are allowed to be unused, which merely enlarges the tested family and cannot invalidate an exclusion.

## Complete finite case decomposition

Fix r in {0,1} and its prescribed slice S=S_r. Let U be the union of the four-edge residual matchings obtained from S by deleting row 0 and column r. Both U have exactly 13 edges in a 4-by-4 residual grid. Let c in {0,1} be the color of edge (0,r). Every residual member of S must have target

    t = k-c,

so t is k or k-1. In particular k=1 needs residual targets 0 and 1; k=2 needs residual targets 1 and 2. There is no exponent-dependent subtraction from the cost target: r is a column exponent, whereas c is the pinned binary edge cost.

Enumerate all 2^13 binary colorings of U, retaining those for which the complete target-t fiber among all 24 residual permutations on U is exactly S. Thus equal cost of the selected members alone is insufficient. The exact retained counts are:

    r=0: t=0 -> 0; t=1 -> 7; t=2 -> 18.
    r=1: t=0 -> 1; t=1 -> 10; t=2 -> 18.

For each retained coloring:

A. Each of the three residual-grid edges outside U independently has state absent, blue, or red. Enumerate all 3^3=27 choices and retain only those for which the complete residual target-t fiber is still exactly S. No unspecified residual support edge remains.

B. The four edges in rows 1,...,4 and deleted column r independently have state absent, blue, or red. Enumerate all 3^4=81 choices. Together with A, this supplies every interior 4-by-5 support/color matrix exactly once for the fixed U coloring.

C. Supply row 0. Its column r edge has the fixed color c=k-t, every column less than r is absent, and column r+1 is absent by the hypothesized gap. Column r+2 must be present, and the row must use at least three edges.

For r=0, edge 2 has two colors, and edges 3,4 each have three states, with the pair not both absent: 2*(9-1)=16 choices. For r=1, edges 3,4 must both be present and have independent colors: 4 choices. These row choices include every support allowed by the hypothesized gap. They may include superfluous edges; this is safe for exclusion.

Every global assignment considered by the theorem appears in exactly one of these branches, determined by its unique r, pinned edge color c, U coloring, three missing-grid states, four column-r states, and remaining row-0 states. Different r or k groups are separate hypotheses. Across target groups, colorings or supports may recur, but the triple (support, coloring, target) is what is counted; no uniqueness across different k is claimed.

## Exact rejection and counts

For each full assignment, enumerate all 120 permutations using the actual support and binary red count. Define Q(L) as the sum of f_p over the complete cost-k fiber. A nonzero Q(1) excludes polynomial cancellation. For Q(1)=0, a nonzero Q(2) also excludes it. Both evaluations use signed integer products, with no floating-point tolerance. Zero at only these two points would not prove polynomial cancellation; however no tested assignment passes both.

    r=0, k=1: 189 residual extensions tested; 17 retained;
      1,377 interiors; 22,032 full assignments; 2 with Q(1)=0; 0 with Q(1)=Q(2)=0.
    r=0, k=2: 675 tested; 59 retained;
      4,779 interiors; 76,464 full assignments; 10 with Q(1)=0; 0 with both evaluations zero.
    r=1, k=1: 297 tested; 100 retained;
      8,100 interiors; 32,400 full assignments; 0 with Q(1)=0.
    r=1, k=2: 756 tested; 236 retained;
      19,116 interiors; 76,464 full assignments; 0 with Q(1)=0.

The total is 207,360 full assignments. These counts were independently reconstructed using a different 25-cell ternary representation and enumeration order. A separate coefficient-based checker reconstructed all 207,360 complete fibers and verified every nonzero rejection witness. The standalone final verify_reductions.py also regenerates the root catalogues used here and reproduces these counts. The theorem rests on the complete decomposition and exact exclusion, not the count alone.

## Row reversal and color complement

Let rho(i)=4-i and q=p composed with rho. Because sign(rho)=(-1)^10=+1 and sum_i p(i)=10,

    f_p(-4-L)=f_q(L).

Reversing rows transports any supported colored graph and preserves the red count, completeness, and nonemptiness of its fiber. Polynomial zero is preserved by substituting -4-L. The original row-4 used-column set becomes the new row-0 used-column set. Thus the row-0 exclusion proves the row-4 exclusion with the same column labels.

Complementing colors only on supported edges changes the count of each perfect matching from k to 5-k. It preserves the matching family and its polynomial. Hence the k=1,2 exclusions also apply to k=4,3. No assertion about k=0,5 is needed here.

## Exact model cuts

For either endpoint i and support variables already constrained to equal union(F), the new necessary conditions can be written

    s(i,0) <= s(i,1),
    s(i,1) <= s(i,0)+s(i,2).

Under the prior degree-at-least-three condition, these are equivalent to consecutiveness of the first two used columns. There are 16 endpoint support subsets of size at least three; 11 satisfy these cuts, and the five rejected supports are precisely {0,3,4} plus the four new patterns listed above. These are target-specific justified cuts; they do not authorize another numerical search and no such search was started.

## Recovery and limits

The canonical sparse binary-fiber question remains open after this reduction. A future exact or separately authorized search must retain complete-fiber constraints, support=union(F), all polynomial coefficients, and canonical labels. Numerical timeout or an unverified infeasibility claim is not a theorem. A candidate must include support, colors, and the full actual fiber and pass an independent all-120-permutation integer check. Independent review has reconstructed the finite cases from the definitions rather than merely rerunning the primary implementation. See the neighboring independent audit report for the precise scope.
