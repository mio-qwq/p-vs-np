"""Cross-check existing exact certificates without importing any implementation."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
primary=HERE/'REDUCTION_CERTIFICATE.json'
prior=HERE.parent/'sparse-fiber-structural-next-20261019/ENDPOINT_CERTIFICATE.json'
audit=HERE.parent/'fiber-structural-gap-audit-20261019/AUDIT_CERTIFICATE.json'
x=json.loads(primary.read_text());y=json.loads(prior.read_text());z=json.loads(audit.read_text())
counts={}
for a in x['root_catalogues']:
 b=y['slices'][a['r']]
 if {tuple(s['members']) for s in a['closed_sets']}!={tuple(s['members']) for s in b['closed_sets']}:
  raise RuntimeError('Root catalogues disagree')
 counts[str(a['r'])]=len(a['closed_sets'])
ours={(c['r'],c['k'],s['support_mask_25'],s['red_mask_25'],s['Q_2'],s['fiber_size']) for c in x['cases'] if c['mode']=='gap' for s in c['L1_survivors']}
theirs=set()
for s in z['q1_zero_cases']:
 flat=sum(s['matrix'],[])
 S=sum(1<<i for i,c in enumerate(flat) if c)
 R=sum(1<<i for i,c in enumerate(flat) if c==2)
 theirs.add((s['r'],s['k'],S,R,s['q2'],len(s['fiber'])))
if ours!=theirs or len(ours)!=12:
 raise RuntimeError('Independent gap survivors disagree')
result={'status':'cross-check passed','regenerated_root_memberships_match_prior':counts,
 'gap_survivor_assignments_values_sizes_match_independent_audit':12,
 'input_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (primary,prior,audit)},
 'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(HERE/'CROSS_CHECK.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
