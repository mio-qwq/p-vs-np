#!/usr/bin/env python3
"""Self-contained exact finite checks of two canonical n=5 binary-fiber reductions.
Uses only Python's standard library. Relies analytically on the previously proved
endpoint degree >=3 theorem; regenerates every root slice used here.
"""
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

PERMS = list(itertools.permutations(range(5)))
NAMES = [''.join(map(str,p)) for p in PERMS]
SIGNS = [(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5)) for p in PERMS]
INNER_MASKS = [sum(1<<((i-1)*5+p[i]) for i in range(1,5)) for p in PERMS]
FULL_MASKS = [sum(1<<(5*i+p[i]) for i in range(5)) for p in PERMS]

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def value(index, x):
    v=SIGNS[index]
    for i,e in enumerate(PERMS[index]):
        v *= (x+i)**e
    return v

VALUES = [[value(i,x) for i in range(120)] for x in (1,2)]

def coefficients(index):
    a=[SIGNS[index]]
    for i,e in enumerate(PERMS[index]):
        for _ in range(e):
            b=[0]*(len(a)+1)
            for j,c in enumerate(a):
                b[j]+=i*c
                b[j+1]+=c
            a=b
    return a

POLYS=[coefficients(i) for i in range(120)]

def normalize(v):
    d=0
    for x in v:
        d=math.gcd(d,abs(x))
    if d:
        v=[x//d for x in v]
        if next(x for x in v if x)<0:
            v=[-x for x in v]
    return v

def reduce_row(v,basis):
    v=list(v)
    for pivot,b in basis:
        if v[pivot]:
            a=v[pivot]
            v=normalize([b[pivot]*x-a*y for x,y in zip(v,b)])
    return v

def affine_basis(rows):
    basis=[]
    for row in rows:
        v=reduce_row(row,basis)
        if any(v):
            p=next(i for i,x in enumerate(v) if x)
            basis.append((p,normalize(v)))
            basis.sort()
    return basis

def half_sums(indices,weights):
    entries=[(0,0)]
    for i in indices:
        entries += [(s+abs(weights[i]),m|(1<<i)) for s,m in entries]
    result={}
    for s,m in entries:
        result.setdefault(s,[]).append(m)
    return result

def root_catalogue(r):
    ids=[i for i,p in enumerate(PERMS) if p[0]==r]
    cols=[c for c in range(5) if c!=r]
    weights=[]
    vectors=[]
    for i in ids:
        p=PERMS[i]
        w=SIGNS[i]
        for j in range(1,5):
            w*=j**p[j]
        weights.append(w)
        vectors.append([1]+[int(p[row]==col) for row in range(1,4) for col in cols[:3]])
    positives=[i for i,w in enumerate(weights) if w>0]
    negatives=[i for i,w in enumerate(weights) if w<0]
    require(len(positives)==len(negatives)==12,'Unexpected root parity sizes')
    pos=half_sums(positives,weights)
    neg=half_sums(negatives,weights)
    balanced=0
    closed=[]
    for total,pmasks in pos.items():
        for a in pmasks:
            for b in neg.get(total,[]):
                mask=a|b
                if not mask:
                    continue
                balanced+=1
                local=[i for i in range(24) if mask>>i&1]
                basis=affine_basis([vectors[i] for i in local])
                if any(not any(reduce_row(vectors[i],basis)) for i in range(24) if not(mask>>i&1)):
                    continue
                members=[ids[i] for i in local]
                poly=[sum(POLYS[i][d] for i in members) for d in range(11)]
                require(any(poly),'Unexpected polynomial-zero root slice')
                order=next(d for d,v in enumerate(poly) if v)-r
                require(order>=1,'Root balance failed')
                closed.append({'indices':members,'members':[NAMES[i] for i in members],
                               'augmented_rank':len(basis),'root_order_after_factoring':order})
    closed.sort(key=lambda s:s['members'])
    expected={0:(13419,216),1:(1437,23),2:(1242,24)}
    require((balanced,len(closed))==expected[r],f'Root catalogue count mismatch at r={r}')
    return {'r':r,'balanced_count':balanced,'closed_count':len(closed),'closed_sets':closed}

def ternary_states(bits):
    states=[(0,0)]
    for bit in bits:
        states=states+[(s|bit,r) for s,r in states]+[(s|bit,r|bit) for s,r in states]
    require(len(states)==3**len(bits),'Ternary state count failed')
    require(len(set(states))==len(states),'Duplicate ternary states')
    return states

def prepare_slice(s,r):
    members=set(s['indices'])
    U=0
    for i in members:
        U|=INNER_MASKS[i]
    residual_ids=[i for i,p in enumerate(PERMS) if p[0]==r]
    active_ids=[i for i in residual_ids if INNER_MASKS[i]&U==INNER_MASKS[i]]
    inside=[INNER_MASKS[i] for i in sorted(members)]
    outside=[INNER_MASKS[i] for i in active_ids if i not in members]
    colors={0:[],1:[],2:[]}
    R=U
    tested=0
    while True:
        tested+=1
        t=(R&inside[0]).bit_count()
        if t<=2 and all((R&m).bit_count()==t for m in inside[1:]) and all((R&m).bit_count()!=t for m in outside):
            colors[t].append(R)
        if R==0:
            break
        R=(R-1)&U
    require(tested==2**U.bit_count(),'Union color enumeration incomplete')
    residual_grid=sum(1<<(5*i+j) for i in range(4) for j in range(5) if j!=r)
    absent_bits=[1<<e for e in range(20) if (residual_grid^U)>>e&1]
    return U,colors,ternary_states(absent_bits),members,residual_ids

def row_choices(r,c,mode):
    choices=[]
    for tail in itertools.product((-1,0,1),repeat=4-r):
        row=[-1]*5
        row[r]=c
        for j,x in zip(range(r+1,5),tail):
            row[j]=x
        if sum(x>=0 for x in row)<3:
            continue
        if mode=='gap' and (row[r+1]!=-1 or row[r+2]<0):
            continue
        choices.append(row)
    expected=16 if mode=='gap' and r==0 else 4
    require(len(choices)==expected,'Row choice count failed')
    return choices

def direct_fiber(inner_s,inner_r,row,k):
    S=inner_s<<5
    R=inner_r<<5
    for j,c in enumerate(row):
        if c>=0:
            S|=1<<j
            if c:
                R|=1<<j
    ids=[i for i,m in enumerate(FULL_MASKS) if m&S==m and (m&R).bit_count()==k]
    return S,R,ids

def run_case(slices,r,k,mode):
    stat={key:0 for key in ('root_slices','union_colorings_tested','valid_union_colorings',
          'residual_extensions_tested','residual_extensions_kept','interior_configurations',
          'full_configurations','passed_L1','passed_L2')}
    survivors=[]
    slice_records=[]
    columns=ternary_states([1<<(5*i+r) for i in range(4)])
    for s in slices:
        stat['root_slices']+=1
        U,colors,extensions,members,residual_ids=prepare_slice(s,r)
        stat['union_colorings_tested']+=2**U.bit_count()
        slice_records.append({'members':s['members'],'union_mask_interior':U,
                              'valid_red_masks_by_target':{str(t):sorted(ws) for t,ws in colors.items()}})
        for t in (k-1,k):
            rows=row_choices(r,k-t,mode)
            for W in colors[t]:
                stat['valid_union_colorings']+=1
                for extra_s,extra_r in extensions:
                    stat['residual_extensions_tested']+=1
                    base_s=U|extra_s
                    base_r=W|extra_r
                    actual={i for i in residual_ids if INNER_MASKS[i]&base_s==INNER_MASKS[i] and (INNER_MASKS[i]&base_r).bit_count()==t}
                    if actual!=members:
                        continue
                    stat['residual_extensions_kept']+=1
                    for col_s,col_r in columns:
                        stat['interior_configurations']+=1
                        inner_s=base_s|col_s
                        inner_r=base_r|col_r
                        sums=[[[0]*(k+1) for _ in range(5)] for _ in range(2)]
                        for i,m in enumerate(INNER_MASKS):
                            if m&inner_s!=m:
                                continue
                            h=(m&inner_r).bit_count()
                            if h<=k:
                                j=PERMS[i][0]
                                sums[0][j][h]+=VALUES[0][i]
                                sums[1][j][h]+=VALUES[1][i]
                        for row in rows:
                            stat['full_configurations']+=1
                            q1=sum(sums[0][j][k-c] for j,c in enumerate(row) if c>=0)
                            if q1:
                                continue
                            stat['passed_L1']+=1
                            q2=sum(sums[1][j][k-c] for j,c in enumerate(row) if c>=0)
                            S,R,ids=direct_fiber(inner_s,inner_r,row,k)
                            require(ids,'Empty first-evaluation survivor')
                            require(sum(value(i,1) for i in ids)==0,'Direct first evaluation disagrees')
                            require(sum(value(i,2) for i in ids)==q2,'Direct second evaluation disagrees')
                            poly=[sum(POLYS[i][d] for i in ids) for d in range(11)]
                            require(sum(a*2**d for d,a in enumerate(poly))==q2,'Coefficient check disagrees')
                            survivors.append({'support_mask_25':S,'red_mask_25':R,'Q_1':0,'Q_2':q2,'fiber_size':len(ids)})
                            if not q2:
                                stat['passed_L2']+=1
    expected={('gap',0,1):(189,17,1377,22032,2),('gap',0,2):(675,59,4779,76464,10),
              ('gap',1,1):(297,100,8100,32400,0),('gap',1,2):(756,236,19116,76464,0),
              ('minimum_two',2,1):(50523,2713,219753,879012,1154),
              ('minimum_two',2,2):(151422,7311,592191,2368764,3491)}
    keys=('residual_extensions_tested','residual_extensions_kept','interior_configurations','full_configurations','passed_L1')
    require(tuple(stat[x] for x in keys)==expected[(mode,r,k)],'Case counts disagree')
    require(stat['passed_L2']==0,'Unexcluded case; no theorem can be reported')
    return {'mode':mode,'r':r,'k':k,'counts':stat,'slice_colorings':slice_records,'L1_survivors':survivors}

def symmetry_and_cuts():
    index={p:i for i,p in enumerate(PERMS)}
    for i,p in enumerate(PERMS):
        j=index[tuple(reversed(p))]
        for x in range(11):
            require(value(i,-4-x)==value(j,x),'Row reversal identity failed')
        m=FULL_MASKS[i]
        for red in range(32):
            R=sum(1<<(5*row+p[row]) for row in range(5) if red>>row&1)
            require((m&R).bit_count()+(m&(m^R)).bit_count()==5,'Color complement failed')
    subsets=[tuple(j for j in range(5) if mask>>j&1) for mask in range(32) if mask.bit_count()>=3]
    gap_allowed=[]
    combined=[]
    for S in subsets:
        b=[int(j in S) for j in range(5)]
        gap=(b[0]<=b[1] and b[1]<=b[0]+b[2])
        require(gap==(S[1]==S[0]+1),'Gap support cuts are not equivalent')
        if gap:
            gap_allowed.append(list(S))
        allowed=(b[1]==1 and b[0]+b[2]>=1)
        require(allowed==(gap and S!=(2,3,4)),'Combined cuts are not equivalent')
        if allowed:
            combined.append(list(S))
    require(len(gap_allowed)==11 and len(combined)==10,'Support count mismatch')
    return {'row_reversal_polynomials':120,'evaluation_points_each':11,
            'color_complement_matching_color_tests':120*32,
            'degree_at_least_three_supports':16,'gap_allowed':gap_allowed,'combined_allowed':combined}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('all','gap','minimum_two'),default='all')
    parser.add_argument('--output',default='REDUCTION_CERTIFICATE.json')
    args=parser.parse_args()
    catalogues={r:root_catalogue(r) for r in range(3)}
    cases=[]
    if args.mode in ('all','gap'):
        for r in (0,1):
            exceptional=[s for s in catalogues[r]['closed_sets'] if s['root_order_after_factoring']>=2]
            require(len(exceptional)==1 and exceptional[0]['root_order_after_factoring']==2,'Gap slice uniqueness failed')
            for k in (1,2):
                cases.append(run_case(exceptional,r,k,'gap'))
    if args.mode in ('all','minimum_two'):
        require(all(s['root_order_after_factoring']==1 for s in catalogues[2]['closed_sets']),'Unexpected r=2 root order')
        for k in (1,2):
            cases.append(run_case(catalogues[2]['closed_sets'],2,k,'minimum_two'))
    result={'status':'all requested exact checks passed','scope':'canonical n=5 binary targets k=1,2; extends to k=4,3 by complement',
            'prior_input':'Analytic endpoint degree >=3 theorem; used root catalogues are independently regenerated here.',
            'mode':args.mode,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'root_catalogues':list(catalogues.values()),'cases':cases,'symmetry_and_support_cuts':symmetry_and_cuts(),
            'totals':{'full_configurations':sum(c['counts']['full_configurations'] for c in cases),
                      'L1_survivors':sum(c['counts']['passed_L1'] for c in cases),
                      'L2_survivors':sum(c['counts']['passed_L2'] for c in cases)}}
    Path(args.output).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'totals':result['totals'],'output':args.output},sort_keys=True))

if __name__=='__main__':
    main()
