#!/usr/bin/env python3
"""Replay accepted finite proofs in a disposable copy; preserve source packages."""
from pathlib import Path
from zipfile import ZipFile
import argparse,csv,hashlib,json,os,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
PRIMARY='fiber-structural-reduction-20261019'
GAP='fiber-structural-gap-audit-20261019'
def require(ok,why):
 if not ok:raise RuntimeError(why)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def integrity():
 count=0
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);path=ROOT/name
  require(path.resolve().is_relative_to(ROOT),'Unsafe manifest path')
  require(path.is_file() and sha(path)==digest,'Integrity mismatch: '+name);count+=1
 return count

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--integrity-only',action='store_true');parser.add_argument('--replay-prior',action='store_true');args=parser.parse_args()
 count=integrity()
 if args.integrity_only:print(json.dumps({'status':'PASS','integrity_files':count},sort_keys=True));return
 compiler=shutil.which('g++');require(compiler is not None,'g++ with C++17 and UBSan support required')
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0');env.pop('PYTHONOPTIMIZE',None)
 checks=[]
 with tempfile.TemporaryDirectory(prefix='pnp-endpoint-replay-') as td:
  work=Path(td)/'work';shutil.copytree(ROOT,work);primary=work/PRIMARY;gap=work/GAP;minimum=gap/'minimum_two'
  def run(label,cmd,cwd=work):
   result=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True)
   require(result.returncode==0,label+' failed:\n'+result.stdout+'\n'+result.stderr)
   checks.append(label);return result
  def same(path,expected):require(sha(path)==expected,'Regenerated file hash mismatch: '+path.name)
  def python(script,*args,optimized=False):return [sys.executable,*(['-O'] if optimized else []),str(script),*map(str,args)]
  expected=sha(ROOT/PRIMARY/'REDUCTION_CERTIFICATE.json')
  for optimized in (False,True):
   label='optimized' if optimized else 'normal';out=primary/('REPLAY_'+label+'.json')
   run('primary-'+label,python(primary/'verify_reductions.py','--output',out,optimized=optimized));same(out,expected)
  certificate=read(primary/'REDUCTION_CERTIFICATE.json')
  require(certificate['totals']=={'full_configurations':3455136,'L1_survivors':4657,'L2_survivors':0},'Unexpected primary totals')
  # Pinned prior theorem and full input catalogues are included, not resolved from a mutable branch.
  dep=work/'dependencies/endpoint-continuation-20261019.zip';same(dep,'d7241176deef0780da07144bb54947eb0fe776557164766bed8ddd152bc6ddf2')
  with ZipFile(dep) as z:
   require(all((work/x.filename).resolve().is_relative_to(work) for x in z.infolist()),'Unsafe dependency path');z.extractall(work)
  prior=work/'endpoint-continuation-20261019'
  frozen=read(primary/'ACCEPTED_MANIFEST.json')['analytic_prior_dependency']
  same(prior/'PROOF.md',frozen['proof_sha256']);same(prior/'audit/AUDIT.md',frozen['audit_sha256'])
  old=read(prior/'ENDPOINT_CERTIFICATE.json')
  for catalogue in certificate['root_catalogues']:
   r=catalogue['r'];require({tuple(s['members']) for s in catalogue['closed_sets']}=={tuple(s['members']) for s in old['slices'][r]['closed_sets']},'Prior root catalogue membership differs')
  checks.append('prior-exact-proof-audit-and-263-used-root-slices-pinned-and-matched')
  if args.replay_prior:run('full-prior-endpoint-proof-replay',python(prior/'reproduce.py'))
  for optimized in (False,True):
   label='optimized' if optimized else 'normal'
   run('independent-gap-enumeration-'+label,python(gap/'audit_binary_gap.py','--output-dir',gap,optimized=optimized))
   same(gap/'AUDIT_CERTIFICATE.json',sha(ROOT/GAP/'AUDIT_CERTIFICATE.json'))
   run('gap-all-assignment-coefficient-replay-'+label,python(gap/'replay_rejections.py',gap,optimized=optimized))
   same(gap/'REPLAY_CERTIFICATE.json',sha(ROOT/GAP/'REPLAY_CERTIFICATE.json'))
  hashes=read(minimum/'ACCEPTED_FILES.json')['files_sha256']
  for sanitizer in (False,True):
   label='ubsan' if sanitizer else 'normal';binary=minimum/('replay_'+label)
   flags=['-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=all'] if sanitizer else ['-O2']
   run('compile-independent-minimum-two-'+label,[compiler,*flags,'-std=c++17','-Wall','-Wextra','-pedantic',str(minimum/'audit_minimum_two.cpp'),'-o',str(binary)])
   run('independent-minimum-two-'+label,[str(binary),str(minimum/'SLICE_INPUT.txt'),str(minimum/'NORMAL')])
   same(minimum/'NORMAL_STATS.tsv',hashes['NORMAL_STATS.tsv']);same(minimum/'NORMAL_ZEROS.tsv',hashes['NORMAL_ZEROS.tsv'])
  for optimized in (False,True):
   label='optimized' if optimized else 'normal'
   run('minimum-two-full-fiber-coefficient-replay-'+label,python(minimum/'replay_survivors.py',minimum,primary/'REDUCTION_CERTIFICATE.json',optimized=optimized))
   same(minimum/'SURVIVOR_REPLAY.json',hashes['SURVIVOR_REPLAY.json'])
  # Deliberately corrupt one exact rejection value. This must fail before any completion claim.
  zeros=minimum/'NORMAL_ZEROS.tsv';lines=zeros.read_text().splitlines();fields=lines[1].split('\t');fields[3]=str(int(fields[3])+1);lines[1]='\t'.join(fields);zeros.write_text('\n'.join(lines)+'\n')
  for optimized in (False,True):
   result=subprocess.run(python(minimum/'replay_survivors.py',minimum,primary/'REDUCTION_CERTIFICATE.json',optimized=optimized),capture_output=True,text=True,env=env)
   require(result.returncode!=0 and 'Incorrect polynomial rejection' in result.stderr,'Corrupt coefficient witness not rejected as intended')
  checks.append('corrupt-minimum-two-witness-rejected-normal-and-optimized')
  badinput=minimum/'BAD_SLICE_INPUT.txt';badinput.write_text((minimum/'SLICE_INPUT.txt').read_text().replace('24\n','23\n',1))
  result=subprocess.run([str(minimum/'replay_normal'),str(badinput),str(minimum/'BAD')],capture_output=True,text=True,env=env)
  require(result.returncode!=0 and 'Expected 24 audited slice masks' in result.stderr,'Corrupt slice count not rejected')
  checks.append('corrupt-prior-slice-count-rejected')
 print(json.dumps({'status':'PASS','integrity_files':count,'python':sys.version.split()[0],'checks':checks,'primary_normal_optimized_and_root_certificates_sha256':expected,'totals':certificate['totals'],'all_4657_exceptional_fibers_independently_reconstructed':True,'all_207360_gap_assignments_independently_replayed':True,'r2_normal_ubsan_generated_outputs_byte_identical':True,'prior_dependency':'Exact archived theorem/proof/audit and all 263 used root slices verified. Prior full enumeration is optional via --replay-prior; it is not silently claimed as newly rerun.','prior_full_enumeration_rerun':args.replay_prior,'numerical_solver_runs':0,'claim_boundary':'Restricted canonical n=5 necessary conditions; remaining sparse-fiber question unresolved; no P-versus-NP conclusion.'},indent=2,sort_keys=True))
if __name__=='__main__':main()
