# Exact canonical binary endpoint cuts

Local source checkpoint, 19 October 2026. Both new reductions have completed independent audit. No repository write, PR, merge, release, or publication was performed.

## Accepted scope

For nonempty cancelling complete canonical n=5 binary-cost fibers at targets 1,2,3,4, both endpoint rows must use at least three columns, include column 1, and include at least one of columns 0 and 2. Exactly 10 endpoint support patterns remain. The prior endpoint-degree theorem is an explicit dependency, included in its exact archived source ZIP. This does not settle existence among the remaining fibers or P versus NP.

## Reproduce

Requires Python 3.10+ (standard library only) and g++ with C++17 and undefined-behavior sanitizer support. All generated data and binary executables stay in disposable temporary directories.

    python reproduce.py
    python -O reproduce.py
    python -O reproduce.py --integrity-only

Each full invocation:

- regenerates the primary catalogue and 3,455,136 exact assignments under normal and optimized Python, requiring the accepted certificate bytes;
- regenerates and coefficient-replays all 207,360 independent gap assignments in both modes;
- compiles and reruns the independent 3,247,776-case minimum-two enumeration normally and under UBSan;
- independently reconstructs every minimum-two exceptional complete fiber and all polynomial coefficients in normal and optimized Python;
- checks every expected output hash and all 4,657 primary/independent exceptional assignments;
- rejects a deliberately corrupted coefficient witness in both modes and a corrupted input slice count;
- verifies the exact prior archive, its analytic proof/audit hashes, and all 263 used prior root-slice memberships.

The prior theorem's full independent enumeration is included but not rerun by default. To rerun that dependency as well:

    python reproduce.py --replay-prior

No numerical solver is used. A nonzero exact evaluation certifies noncancellation; no zero-polynomial conclusion is drawn from only two zeros.

## Files and size policy

Read fiber-structural-reduction-20261019/PROOF.md, MINIMUM_TWO_PROOF.md, and INDEPENDENT_COMPLETION.json, together with both AUDIT.md files. One 917,756-byte primary certificate is retained. Its ordinary, optimized, and root outputs are identical. The 1.6 MB compressed gap ledger, 350 KB minimum-two survivor list, and 2.4 MB expanded coefficient output are omitted because the supplied independent checkers deterministically regenerate them and their exact SHA-256 values are retained. Exploratory outputs, caches, and executable binaries are omitted.

Original absolute source references are historical provenance, not runtime dependencies. PROVENANCE.json maps the retained copies. The original cross_check_certificates.py is preserved for source completeness; reproduce.py performs its checks portably with the included prior archive. Frozen acceptance manifests enumerate some intentionally omitted files; this is documented in PROVENANCE.json, not evidence of a failed current payload manifest. SHA256SUMS covers every payload file except itself; the external archive hash protects that manifest.

## Recovery and open work

Verify the external ZIP SHA-256, extract into a fresh directory, and replay. Never modify a reference certificate to conceal a mismatch. The remaining cases have endpoint minimum 0 or 1 with consecutive first two used columns. Full sparse binary-fiber existence remains unresolved. Further numerical searches and remote changes are outside this checkpoint.
