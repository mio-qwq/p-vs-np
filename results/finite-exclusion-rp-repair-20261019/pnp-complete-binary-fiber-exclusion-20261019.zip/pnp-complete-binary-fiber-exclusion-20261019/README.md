# Complete canonical five-row binary-fiber exclusion

Local source checkpoint, 19 October 2026. Independent audits accepted the restricted finite theorem. No repository, PR, merge, release or publication is performed by this package.

## Result and limits

For the fixed signed polynomials f_p(L)=sgn(p) product_(i=0)^4 (L+i)^(p(i)), no nonempty complete fiber of any supported binary edge-cost matrix cancels identically. All 29,238,600 reduced extensions at targets 1 and 2 were exhausted; all 20,575 Q(1)=0 survivors have nonzero Q(2). Exact recoloring and complementation cover targets 0 through 5. This does not settle general n, arbitrary costs or P versus NP. Independent implementations are AI-assisted verification, not external peer review or formal proof.

## Reproduction

Requirements: Python 3.10+ (standard library) and g++ supporting C++17; --ubsan requires undefined-behavior sanitizer support. No network, solver or Python package installation is needed.

    python reproduce.py
    python -O reproduce.py --ubsan
    python -O reproduce.py --integrity-only

Each full invocation uses a fresh disposable directory and:

- Regenerates the primary root catalogues, binary options, 7,162 cores, and all 29,238,600 extensions, checking the exact accepted output bytes.
- Reconstructs every first-evaluation survivor using complete explicit cell-state fibers and all eleven integer polynomial coefficients.
- Independently regenerates roots by Gray-code subset enumeration and full 26-coordinate exact elimination, then independently joins root colorings and regenerates every core/domain; all exact objects must agree.
- Reconstructs all 52,094 single-edge exclusion witnesses. Independently replays every extension both on primary cores and on independently regenerated cores. Compares full survivor multisets, not just counts.
- Independently reconstructs polynomial coefficients by Newton finite differences and cycle parity, and checks exact symmetry/recoloring transfers.
- Rejects corrupt Q(2), full-fiber membership, and edge-domain witnesses in both normal and optimized Python.
- Checks the included pinned endpoint-cut archive and nested prior endpoint proof, audit and catalogue.

The --ubsan invocation additionally repeats primary C++ cores/extensions with UBSan and uses UBSan for both independent C++ implementations. The prior source archives include complete earlier reproduction entry points. To replay those expensive earlier enumerations too, add --replay-prior. Without that flag their full finite enumeration is not claimed as newly rerun.

## Reading and provenance

Read remaining-fiber-obstruction-20261019/PROOF.md and ACCEPTED_MANIFEST.json, joint-fiber-exhaustion-audit-20261019/AUDIT.md, and remaining-fiber-construction-20261019/joint_extension_audit/AUDIT.md. Dependencies contain the exact published source ZIP pinned to commit b3c5a3f79083ea32f8a624b1b8fb83e8d35c5ce8; its nested archive includes the original endpoint-degree theorem.

All retained research sources are byte-for-byte copies. Runtime path adapters operate only on disposable copies. EXPECTED_OUTPUTS.json records omitted deterministic outputs; PROVENANCE.json records exact source mappings and the canonical coefficient digest rule. Historical manifests enumerate some deliberately omitted regenerable files. SHA256SUMS covers every current payload file except itself; the external archive SHA-256 protects that manifest. The full pipeline writes only into temporary directories and reports JSON to stdout.

## Recovery

Verify the external archive digest, extract afresh, then run reproduction. A missing case, changed domain, arithmetic mismatch or actual polynomial-zero complete fiber suspends the result. Preserve the entire support, binary coloring, target, all 120 matching decisions and coefficients. Two zero evaluations alone would not prove an identity; none occurs here. Never change accepted reference data to hide a mismatch.

## Deterministic source archive

From a verified clean extraction:

    python build_archive.py ../pnp-complete-binary-fiber-exclusion-20261019-rebuilt.zip

The builder refuses an existing destination and writes outside the source payload. It fixes entry timestamps to 1980-01-01, regular-file mode 0644, sorted names, and DEFLATE level 9. Byte-identical compressed output requires the same zlib implementation.
