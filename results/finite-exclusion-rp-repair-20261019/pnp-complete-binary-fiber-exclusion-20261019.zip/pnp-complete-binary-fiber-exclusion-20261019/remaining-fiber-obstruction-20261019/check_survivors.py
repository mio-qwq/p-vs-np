#!/usr/bin/env python3
"""Independent-form polynomial reconstruction of every Q(1)=0 survivor.
Uses explicit cell matrices and binomial expansions, not primary bit arithmetic
or repeated linear-factor multiplication for the polynomial coefficients.
"""
import argparse,hashlib,itertools,json,math
from pathlib import Path
PERMS=list(itertools.permutations(range(5)))
def require(c,m):
 if not c:raise RuntimeError(m)
def convolution(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return c
POLYS=[]
for p in PERMS:
 parity=sum(p[i]>p[j]for i in range(5)for j in range(i+1,5))%2
 coeff=[(-1)**parity]
 for i,e in enumerate(p):coeff=convolution(coeff,[math.comb(e,j)*i**(e-j) for j in range(e+1)])
 require(len(coeff)==11,'Wrong degree bound')
 POLYS.append(coeff)
def run(directory):
 directory=Path(directory);records=[]
 for k in (1,2):
  checked=0;sizes={};evaluation_signs={}
  path=directory/f'EVALUATION_SURVIVORS_{k}.txt'
  for line in path.read_text().splitlines():
   core,S,R,q2,n,*supplied=map(int,line.split())
   require(R&S==R,'Red edges outside support')
   matrix=[[None if not(S>>(5*i+j)&1)else (R>>(5*i+j)&1)for j in range(5)]for i in range(5)]
   actual=[]
   for z,p in enumerate(PERMS):
    colors=[matrix[i][p[i]]for i in range(5)]
    if all(c is not None for c in colors)and sum(colors)==k:actual.append(z)
   require(actual==supplied and len(actual)==n,'Actual complete fiber disagrees')
   coeff=[sum(POLYS[z][d]for z in actual)for d in range(11)]
   require(sum(coeff)==0,'Q(1) nonzero')
   actual2=sum(c*2**d for d,c in enumerate(coeff))
   require(actual2==q2 and q2!=0,'Q(2) disagreement or zero')
   require(any(coeff),'Identically zero polynomial')
   for row in (0,4):
    used={PERMS[z][row]for z in actual}
    require(len(used)>=3 and 1 in used and bool({0,2}&used),'Endpoint cut disagreement')
   checked+=1;sizes[n]=sizes.get(n,0)+1;evaluation_signs[str((q2>0)-(q2<0))]=evaluation_signs.get(str((q2>0)-(q2<0)),0)+1
  expected=json.loads((directory/f'EXTENSION_STATS_{k}.json').read_text())
  require(checked==expected['Q1_zero'],'Survivor count disagreement')
  records.append(dict(target=k,checked=checked,fiber_sizes=sizes,Q2_signs=evaluation_signs,
                      survivor_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 result=dict(status='All supplied evaluation survivors independently reconstructed with full integer coefficients',records=records,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
 (directory/'SURVIVOR_COEFFICIENT_CHECK.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps(result,sort_keys=True,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);a=p.parse_args();run(a.directory)
