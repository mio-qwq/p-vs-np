#!/usr/bin/env python3
"""Self-contained exact catalogue and complete joint-endpoint binary-fiber check.
Catalogue primitives adapted from the accepted 19 October endpoint reduction.
Uses only Python's standard library. Relies analytically on the previously proved
endpoint degree >=3 theorem; regenerates every root slice used here.
"""
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

PERMS = list(itertools.permutations(range(5)))
NAMES = [''.join(map(str,p)) for p in PERMS]
SIGNS = [(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5)) for p in PERMS]
INNER_MASKS = [sum(1<<((i-1)*5+p[i]) for i in range(1,5)) for p in PERMS]
FULL_MASKS = [sum(1<<(5*i+p[i]) for i in range(5)) for p in PERMS]

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def value(index, x):
    v=SIGNS[index]
    for i,e in enumerate(PERMS[index]):
        v *= (x+i)**e
    return v

VALUES = [[value(i,x) for i in range(120)] for x in (1,2)]

def coefficients(index):
    a=[SIGNS[index]]
    for i,e in enumerate(PERMS[index]):
        for _ in range(e):
            b=[0]*(len(a)+1)
            for j,c in enumerate(a):
                b[j]+=i*c
                b[j+1]+=c
            a=b
    return a

POLYS=[coefficients(i) for i in range(120)]

def normalize(v):
    d=0
    for x in v:
        d=math.gcd(d,abs(x))
    if d:
        v=[x//d for x in v]
        if next(x for x in v if x)<0:
            v=[-x for x in v]
    return v

def reduce_row(v,basis):
    v=list(v)
    for pivot,b in basis:
        if v[pivot]:
            a=v[pivot]
            v=normalize([b[pivot]*x-a*y for x,y in zip(v,b)])
    return v

def affine_basis(rows):
    basis=[]
    for row in rows:
        v=reduce_row(row,basis)
        if any(v):
            p=next(i for i,x in enumerate(v) if x)
            basis.append((p,normalize(v)))
            basis.sort()
    return basis

def half_sums(indices,weights):
    entries=[(0,0)]
    for i in indices:
        entries += [(s+abs(weights[i]),m|(1<<i)) for s,m in entries]
    result={}
    for s,m in entries:
        result.setdefault(s,[]).append(m)
    return result

def root_catalogue(r):
    ids=[i for i,p in enumerate(PERMS) if p[0]==r]
    cols=[c for c in range(5) if c!=r]
    weights=[]
    vectors=[]
    for i in ids:
        p=PERMS[i]
        w=SIGNS[i]
        for j in range(1,5):
            w*=j**p[j]
        weights.append(w)
        vectors.append([1]+[int(p[row]==col) for row in range(1,4) for col in cols[:3]])
    positives=[i for i,w in enumerate(weights) if w>0]
    negatives=[i for i,w in enumerate(weights) if w<0]
    require(len(positives)==len(negatives)==12,'Unexpected root parity sizes')
    pos=half_sums(positives,weights)
    neg=half_sums(negatives,weights)
    balanced=0
    closed=[]
    for total,pmasks in pos.items():
        for a in pmasks:
            for b in neg.get(total,[]):
                mask=a|b
                if not mask:
                    continue
                balanced+=1
                local=[i for i in range(24) if mask>>i&1]
                basis=affine_basis([vectors[i] for i in local])
                if any(not any(reduce_row(vectors[i],basis)) for i in range(24) if not(mask>>i&1)):
                    continue
                members=[ids[i] for i in local]
                poly=[sum(POLYS[i][d] for i in members) for d in range(11)]
                require(any(poly),'Unexpected polynomial-zero root slice')
                order=next(d for d,v in enumerate(poly) if v)-r
                require(order>=1,'Root balance failed')
                closed.append({'indices':members,'members':[NAMES[i] for i in members],
                               'augmented_rank':len(basis),'root_order_after_factoring':order})
    closed.sort(key=lambda s:s['members'])
    expected={0:(13419,216),1:(1437,23),2:(1242,24)}
    require((balanced,len(closed))==expected[r],f'Root catalogue count mismatch at r={r}')
    return {'r':r,'balanced_count':balanced,'closed_count':len(closed),'closed_sets':closed}

def ternary_states(bits):
    states=[(0,0)]
    for bit in bits:
        states=states+[(s|bit,r) for s,r in states]+[(s|bit,r|bit) for s,r in states]
    require(len(states)==3**len(bits),'Ternary state count failed')
    require(len(set(states))==len(states),'Duplicate ternary states')
    return states

def prepare_slice(s,r):
    members=set(s['indices'])
    U=0
    for i in members:
        U|=INNER_MASKS[i]
    residual_ids=[i for i,p in enumerate(PERMS) if p[0]==r]
    active_ids=[i for i in residual_ids if INNER_MASKS[i]&U==INNER_MASKS[i]]
    inside=[INNER_MASKS[i] for i in sorted(members)]
    outside=[INNER_MASKS[i] for i in active_ids if i not in members]
    colors={0:[],1:[],2:[]}
    R=U
    tested=0
    while True:
        tested+=1
        t=(R&inside[0]).bit_count()
        if t<=2 and all((R&m).bit_count()==t for m in inside[1:]) and all((R&m).bit_count()!=t for m in outside):
            colors[t].append(R)
        if R==0:
            break
        R=(R-1)&U
    require(tested==2**U.bit_count(),'Union color enumeration incomplete')
    residual_grid=sum(1<<(5*i+j) for i in range(4) for j in range(5) if j!=r)
    absent_bits=[1<<e for e in range(20) if (residual_grid^U)>>e&1]
    return U,colors,ternary_states(absent_bits),members,residual_ids


def run(output):
    import subprocess
    output=Path(output)
    output.mkdir(parents=True, exist_ok=True)
    here=Path(__file__).resolve().parent
    catalogues=[root_catalogue(r) for r in (0,1)]
    (output/'ROOT_CATALOGUES.json').write_text(json.dumps(catalogues,sort_keys=True,indent=2)+'\n')
    slices=[]
    for cat in catalogues:
        r=cat['r']
        for s in cat['closed_sets']:
            U,colors,extensions,members,residual_ids=prepare_slice(s,r)
            slices.append(dict(r=r,members=s['members'],indices=s['indices'],U=U,
                               colors={str(t):sorted(z) for t,z in colors.items()}))
    (output/'BINARY_ROOT_SLICES.json').write_text(json.dumps(slices,sort_keys=True,indent=2)+'\n')
    commands=[]
    for source in ('regenerate_cores','exhaust_extensions'):
        command=['g++','-O3','-std=c++17',str(here/(source+'.cpp')),'-o',str(output/source)]
        subprocess.run(command,check=True)
        commands.append(command)
    summaries=[]
    for k in (1,2):
        valid=[s for s in slices if any(s['colors'][str(t)] for t in (k-1,k))]
        core_input=output/f'CORE_INPUT_{k}.txt'
        with core_input.open('w') as f:
            print(k,len(valid),file=f)
            for s in valid:
                options=[(32*s['U']+(1<<s['r']),32*R+((k-t)<<s['r']))
                         for t in (k-1,k) for R in s['colors'][str(t)]]
                print(s['r'],len(s['indices']),len(options),*s['indices'],
                      *(x for o in options for x in o),file=f)
        extension_input=output/f'EXTENSION_INPUT_{k}.txt'
        core_stats=output/f'CORE_STATS_{k}.json'
        subprocess.run([str(output/'regenerate_cores'),str(core_input),str(extension_input),str(core_stats)],check=True)
        extension_stats=output/f'EXTENSION_STATS_{k}.json'
        subprocess.run([str(output/'exhaust_extensions'),str(extension_input),str(extension_stats),
                        str(output/f'EVALUATION_SURVIVORS_{k}.txt'),str(output/f'CANDIDATES_{k}.txt')],check=True)
        c=json.loads(core_stats.read_text());e=json.loads(extension_stats.read_text())
        require(c['extensions']==e['full_assignments'],'Extension count disagreement')
        require(e['Q1_Q2_zero']==0 and e['polynomial_zero']==0,'Unexpected survivor: inspect candidates')
        summaries.append(dict(target=k,core=c,extension=e))
    source_hashes={name:hashlib.sha256((here/name).read_bytes()).hexdigest()
                   for name in ('verify_complete.py','regenerate_cores.cpp','exhaust_extensions.cpp')}
    summary=dict(status='primary exact finite exclusion; independent acceptance tracked separately',
                 scope='canonical n=5 sparse binary complete fibers, targets 1,2; 3,4 by color complement',
                 catalogue_counts=[(c['r'],c['balanced_count'],c['closed_count']) for c in catalogues],
                 summaries=summaries,source_sha256=source_hashes)
    (output/'COMPLETE_RESULT.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
    print(json.dumps(summary,sort_keys=True,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    run(args.output)
