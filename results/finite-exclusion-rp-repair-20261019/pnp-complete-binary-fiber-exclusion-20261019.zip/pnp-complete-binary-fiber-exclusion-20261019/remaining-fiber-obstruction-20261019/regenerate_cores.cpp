#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <vector>
using namespace std;using U=uint32_t;struct Opt{U s,r;};struct Slice{int minimum;array<bool,120>member{};vector<Opt>opts;};struct Core{U s,r;int a,b;vector<pair<int,vector<int>>>dom;};
U reverse_rows(U a){U b=0;for(int i=0;i<5;++i)b|=((a>>(5*i))&31)<<(5*(4-i));return b;}
int main(int argc,char**argv){if(argc!=4)throw runtime_error("input output stats");ifstream in(argv[1]);int k,n;in>>k>>n;vector<Slice>ss(n);for(auto&s:ss){int sz,no;in>>s.minimum>>sz>>no;while(sz--){int i;in>>i;s.member[i]=true;}while(no--){Opt o;in>>o.s>>o.r;s.opts.push_back(o);}}
vector<array<int,5>>p;array<int,5>x{0,1,2,3,4};do{p.push_back(x);}while(next_permutation(x.begin(),x.end()));array<U,120>mask{};array<int,120>rev{};for(int i=0;i<120;++i){for(int j=0;j<5;++j)mask[i]|=1u<<(5*j+p[i][j]);x=p[i];reverse(x.begin(),x.end());rev[i]=find(p.begin(),p.end(),x)-p.begin();}
long long pairs=0,compatible=0,colorpairs=0,consistent=0,rootgood=0,extensions=0;vector<Core>cores;
for(int a=0;a<n;++a)for(int b=0;b<n;++b){++pairs;auto&A=ss[a];auto&B=ss[b];vector<int>bad;bool good=true;for(int i=0;i<120;++i){bool forbidden=p[i][0]<A.minimum||p[i][4]<B.minimum||(p[i][0]==A.minimum&&!A.member[i])||(p[i][4]==B.minimum&&!B.member[rev[i]]);if(forbidden){bad.push_back(i);if(A.member[i]||B.member[rev[i]])good=false;}}if(!good)continue;++compatible;
for(auto o:A.opts)for(auto u:B.opts){++colorpairs;u.s=reverse_rows(u.s);u.r=reverse_rows(u.r);if((o.r^u.r)&o.s&u.s)continue;++consistent;U S=o.s|u.s,R=o.r|u.r;bool badroot=false;for(int i:bad)if((mask[i]&S)==mask[i]&&__builtin_popcount(mask[i]&R)==k){badroot=true;break;}if(badroot)continue;++rootgood;Core c{S,R,a,b,{}};long long ways=1;for(int e=0;e<25;++e){if(S&(1u<<e))continue;int row=e/5,col=e%5;if((row==0&&col<A.minimum)||(row==4&&col<B.minimum))continue;vector<int>ds{-1};for(int color:{0,1}){U NS=S|(1u<<e),NR=R|(color?(1u<<e):0);bool ok=true;for(int i:bad)if((mask[i]&NS)==mask[i]&&__builtin_popcount(mask[i]&NR)==k){ok=false;break;}if(ok)ds.push_back(color);}if(ds.size()>1){c.dom.push_back({e,ds});ways*=ds.size();}}extensions+=ways;cores.push_back(c);}}
sort(cores.begin(),cores.end(),[](const Core&a,const Core&b){if(a.s!=b.s)return a.s<b.s;return a.r<b.r;});for(int i=1;i<(int)cores.size();++i)if(cores[i].s==cores[i-1].s&&cores[i].r==cores[i-1].r)throw runtime_error("duplicate core");
ofstream out(argv[2]);out<<k<<' '<<cores.size()<<'\n';for(auto&c:cores){out<<c.s<<' '<<c.r<<' '<<ss[c.a].minimum<<' '<<ss[c.b].minimum<<' '<<c.dom.size();for(auto [e,ds]:c.dom){out<<' '<<e<<' '<<ds.size();for(int d:ds)out<<' '<<d;}out<<'\n';}
ofstream st(argv[3]);st<<"{\"target\":"<<k<<",\"individual_slices\":"<<n<<",\"slice_pairs\":"<<pairs<<",\"membership_compatible\":"<<compatible<<",\"color_pairs\":"<<colorpairs<<",\"consistent_colors\":"<<consistent<<",\"root_consistent_cores\":"<<rootgood<<",\"cores\":"<<cores.size()<<",\"extensions\":"<<extensions<<"}\n";cerr<<k<<" cores="<<cores.size()<<" extensions="<<extensions<<'\n';}
