#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;using LL=long long;
struct Perm{array<int,5>p;uint32_t m;LL v1,v2;array<LL,11> poly;};
vector<Perm> pp;int k;long long checked=0,root_passed=0,endpoint_passed=0,first_passed=0,second_passed=0,zero_count=0;ofstream surv,candidates;
LL power(LL a,int e){LL z=1;while(e--)z*=a;return z;}
void visit(uint32_t S,uint32_t R,const vector<int>&bad,int core){++checked;for(int i:bad){auto&p=pp[i];if((p.m&S)==p.m&&__builtin_popcount(p.m&R)==k)return;}++root_passed;
 LL q1=0,q2=0;uint32_t used=0;vector<int>F;for(int i=0;i<120;++i){auto&p=pp[i];if((p.m&S)==p.m&&__builtin_popcount(p.m&R)==k){q1+=p.v1;q2+=p.v2;used|=p.m;F.push_back(i);}}
 if(F.empty())throw runtime_error("Empty core extension");
 for(int row:{0,4}){int usedrow=(used>>(5*row))&31;if(__builtin_popcount((unsigned)usedrow)<3||!(usedrow&2)||!(usedrow&5))return;}++endpoint_passed;
 if(q1)return;++first_passed;surv<<core<<' '<<S<<' '<<R<<' '<<q2<<' '<<F.size();for(int i:F)surv<<' '<<i;surv<<'\n';if(q2)return;++second_passed;
 array<LL,11>poly{};for(int i:F)for(int d=0;d<=10;++d)poly[d]+=pp[i].poly[d];bool zero=true;for(LL c:poly)if(c)zero=false;if(zero)++zero_count;
 candidates<<core<<' '<<S<<' '<<R<<' '<<zero<<' '<<F.size();for(LL c:poly)candidates<<' '<<c;for(int i:F)candidates<<' '<<i;candidates<<'\n';
}
void rec(int pos,uint32_t S,uint32_t R,const vector<pair<int,vector<int>>>&dom,const vector<int>&bad,int core){if(pos==(int)dom.size()){visit(S,R,bad,core);return;}auto[e,ds]=dom[pos];for(int c:ds){uint32_t b=1u<<e;rec(pos+1,S|(c>=0?b:0),R|(c==1?b:0),dom,bad,core);}}
int main(int argc,char**argv){if(argc!=5)throw runtime_error("Need input stats survivors candidates");ifstream in(argv[1]);int n;in>>k>>n;surv.open(argv[3]);candidates.open(argv[4]);array<int,5>a{0,1,2,3,4};do{Perm p{};p.p=a;int inv=0;for(int i=0;i<5;++i)for(int j=i+1;j<5;++j)inv+=a[i]>a[j];int sign=(inv%2?-1:1);p.v1=p.v2=sign;p.poly[0]=sign;int deg=0;for(int i=0;i<5;++i){p.m|=1u<<(5*i+a[i]);p.v1*=power(i+1,a[i]);p.v2*=power(i+2,a[i]);for(int h=0;h<a[i];++h){array<LL,11>q{};for(int d=0;d<=deg;++d){q[d]+=i*p.poly[d];q[d+1]+=p.poly[d];}p.poly=q;++deg;}}pp.push_back(p);}while(next_permutation(a.begin(),a.end()));
 for(int c=0;c<n;++c){uint32_t U,R;int r0,r4,m;in>>U>>R>>r0>>r4>>m;vector<pair<int,vector<int>>>domains;while(m--){int e,z;in>>e>>z;vector<int>ds(z);for(int&d:ds)in>>d;domains.push_back({e,ds});}vector<int>bad;for(int i=0;i<120;++i){auto&p=pp[i];bool in_core=(p.m&U)==p.m&&__builtin_popcount(p.m&R)==k;if((p.p[0]==r0||p.p[4]==r4)&&!in_core)bad.push_back(i);}rec(0,U,R,domains,bad,c);if(c%1000==0)cerr<<"core "<<c<<"/"<<n<<" checked "<<checked<<" first "<<first_passed<<" second "<<second_passed<<'\n';}
 if(!in)throw runtime_error("Input parse failure");ofstream st(argv[2]);st<<"{\"target\":"<<k<<",\"cores\":"<<n<<",\"full_assignments\":"<<checked<<",\"root_consistent\":"<<root_passed<<",\"endpoint_consistent\":"<<endpoint_passed<<",\"Q1_zero\":"<<first_passed<<",\"Q1_Q2_zero\":"<<second_passed<<",\"polynomial_zero\":"<<zero_count<<"}\n";cerr<<"DONE "<<checked<<' '<<root_passed<<' '<<endpoint_passed<<' '<<first_passed<<' '<<second_passed<<' '<<zero_count<<'\n';}
