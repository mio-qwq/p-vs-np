# Canonical n=5 binary-fiber exclusion: accepted finite research artifact

Status: accepted after independently regenerated roots, cores and domains; a separate complete extension implementation; exact coefficient replay; sanitizer runs; and root reproduction. This is AI-assisted finite verification, not external peer review or formal verification.

Read `PROOF.md` for the coverage argument and limits. The finite check covers targets 1 and 2; color complementation and recoloring cover all binary targets 0–5. This is only the fixed canonical five-row determinant-isolation model.

## Reproduce

    python verify_complete.py --output NEW_DIRECTORY
    python check_survivors.py --directory NEW_DIRECTORY

Requirements: Python 3 and a C++17 compiler named `g++`. No third-party Python packages, network, MILP or numerical solver are used. The new directory must be writable. The source and previous research artifacts are not changed by reproduction.

Core files:

- `verify_complete.py`: standalone regeneration of exact root catalogues and binary options; runs the complete verification pipeline.
- `regenerate_cores.cpp`: direct joint-root colored core and single-edge domain enumeration, without affine-pair pruning.
- `exhaust_extensions.cpp`: complete extension enumeration and actual 120-permutation fiber checks.
- `check_survivors.py`: separate-form exact coefficient replay of every first-evaluation survivor.
- `STANDALONE_REPLAY/COMPLETE_RESULT.json`: primary exact result and source digests.
- `STANDALONE_REPLAY/ROOT_CATALOGUES.json`, `CORE_INPUT_*.txt`, `EXTENSION_INPUT_*.txt`: full finite case inputs.
- `STANDALONE_REPLAY/EVALUATION_SURVIVORS_*.txt`: every Q(1)=0 survivor and complete actual fiber.
- `STANDALONE_REPLAY/SURVIVOR_COEFFICIENT_CHECK.json`: coefficient replay receipt.

Earlier files named `explore_joint.py`, `joint_closure.cpp`, `join_binary_cores.py`, and `BINARY_CORES_*.json` preserve the discovery route. They are not needed by the final standalone entry point. The exploratory affine-pair filter and the simpler direct construction gave identical core/domain sets.

No remote repositories, PRs, merges or releases were changed. The independent reviews are complete. Frozen evidence and precise scope are recorded in `ACCEPTED_MANIFEST.json`.
