#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
A=P.parent/'joint-fiber-exhaustion-audit-20261019'
E=P.parent/'remaining-fiber-construction-20261019'/'joint_extension_audit'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def receipt(p):return {'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
audit=json.loads((A/'AUDIT_MANIFEST.json').read_text())
for rec in audit['files']:
 if digest(Path(rec['path']))!=rec['sha256']:raise RuntimeError('Independent manifest digest mismatch: '+rec['path'])
if '0' not in audit['scope'] or '5' not in audit['scope']:raise RuntimeError('Independent scope not updated')
files=['PROOF.md','README.md','verify_complete.py','regenerate_cores.cpp','exhaust_extensions.cpp','check_survivors.py','freeze_acceptance.py','REPLAY_CROSSCHECK.json']
files += ['STANDALONE_REPLAY/'+name for name in ['COMPLETE_RESULT.json','ROOT_CATALOGUES.json','BINARY_ROOT_SLICES.json','SURVIVOR_COEFFICIENT_CHECK.json']]
files += ['STANDALONE_REPLAY/'+f'{prefix}_{k}.{ext}'for k in(1,2)for prefix,ext in [('CORE_INPUT','txt'),('CORE_STATS','json'),('EXTENSION_INPUT','txt'),('EXTENSION_STATS','json'),('EVALUATION_SURVIVORS','txt'),('CANDIDATES','txt')]]
result=dict(status='accepted exact finite theorem',date_utc='2026-10-19',scope='canonical n=5, arbitrary bipartite support, binary edge costs, nonempty complete fibers at all targets 0 through 5',limitations='Does not cover general n, arbitrary real costs, other offsets, or P versus NP; AI-assisted independent implementation checks, not external peer review or proof-assistant formalization',enumerated_targets=[1,2],analytic_target_reductions={'3,4':'supported-edge color complement','0':'normalize to union(F), recolor every row0 edge red, reduce to target1','5':'color complement followed by target0 reduction'},core_counts={'1':1066,'2':6096},full_assignments=29238600,first_evaluation_survivors=20575,double_evaluation_survivors=0,primary_files_sha256={n:digest(P/n)for n in files},independent_audits=[receipt(A/'AUDIT.md'),receipt(A/'AUDIT_MANIFEST.json'),receipt(E/'AUDIT.md'),receipt(E/'REPLAY_COMPARISON.json')],accepted_prior_dependency=[receipt(P.parent/'fiber-structural-reduction-20261019'/n)for n in('ACCEPTED_MANIFEST.json','PROOF.md','MINIMUM_TWO_PROOF.md')],root_replay=receipt(P/'ROOT_REPLAY'/'COMPLETE_RESULT.json'),normal_optimized_root_outputs_byte_identical=True,sanitizer_replay_passed=True,prior_artifacts_modified=False,repository_pr_release_changed=False,recovery='Suspend the complete-exclusion claim for any missing catalogue member, core/domain discrepancy, omitted assignment, arithmetic failure, or actual polynomial-zero complete fiber. Preserve full support, binary colors, target, all120 matching decisions and polynomial coefficients.')
(P/'ACCEPTED_MANIFEST.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
(P/'SHA256SUMS.txt').write_text(''.join(f'{digest(P/n)}  {n}\n'for n in files+['ACCEPTED_MANIFEST.json']))
print(json.dumps({'accepted_manifest_sha256':digest(P/'ACCEPTED_MANIFEST.json'),'proof_sha256':digest(P/'PROOF.md'),'readme_sha256':digest(P/'README.md')},indent=2))
