# Joint-endpoint exclusion of canonical five-row binary cancelling fibers

19 October 2026. Accepted exact finite result after independent root/core regeneration, a separately implemented complete extension replay, coefficient reconstruction, sanitizer runs, and root replay. This is independent AI-assisted verification, not external peer review or proof-assistant formalization. This is a theorem about a fixed, finite determinant-isolation model. It is not a claim about arbitrary dimension, arbitrary real edge costs, or P versus NP. No earlier artifact or remote repository was modified.

## Statement

Let G be any bipartite graph on labelled rows and columns {0,1,2,3,4}, and let w:E(G)→{0,1}. For a permutation p write

    f_p(L) = sgn(p) ∏_(i=0)^4 (L+i)^(p(i)).

For an integer k define the complete fiber

    F_k = {p in PM(G): ∑_i w(i,p(i))=k}.

**Finite exact theorem.** If F_k is nonempty, its polynomial ∑_(p in F_k) f_p(L) is not identically zero.

The exhaustive calculation directly covers k=1,2, using the previously accepted endpoint reductions. Color complementation covers k=3,4. A short recoloring argument below covers k=0,5. Other integer targets have empty fibers.

The finite calculation checked 29,238,600 support/color assignments, covering every possible hypothetical counterexample after exact reductions. All assignments either violate necessary endpoint conditions or have a nonzero integer evaluation at L=1 or L=2. There were no double-evaluation survivors, so no inference of polynomial identity from two zero values is used.

## 1. Accepted prior input and support normalization

For a nonempty cancelling complete binary fiber at target 1 or 2, the accepted endpoint theorem and reductions imply, for i=0,4:

    |{p(i):p in F_k}| >= 3,
    1 belongs to {p(i):p in F_k},
    {0,2} intersects {p(i):p in F_k}.

In particular each endpoint's smallest used column is 0 or 1. The prior proofs and acceptance manifest are in `../fiber-structural-reduction-20261019/`, with the underlying exact root-slice theorem in `../sparse-fiber-structural-next-20261019/PROOF.md`.

Replace G by union(F_k). Every member of F_k remains supported, and removing edges creates no new matching. Thus the complete fiber remains exactly F_k. Consequently every unused endpoint column may be treated as absent. Intermediate calculations may still allow extra unused edges; this enlarges the family and is safe for an exclusion.

## 2. Exact least-root slice classification

Put r=min{p(0):p in F_k} and S={p in F_k:p(0)=r}. The coefficient of L^r gives

    ∑_(p in S) sgn(p) ∏_(i=1)^4 i^(p(i)) = 0.

S is a complete residual cost fiber after fixing (0,r). It is therefore affine-closed among the 24 permutations with p(0)=r: any permutation incidence vector in the affine span of S has the same cost, and its zero coordinates force it to lie in union(S), so completeness includes it in S.

The standalone verifier regenerates every nonempty scalar-balanced subset using exact positive/negative subset-sum joins, then tests affine closure using integer elimination. It finds:

| r | Scalar-balanced subsets | Affine-closed subsets |
|---|---:|---:|
| 0 | 13,419 | 216 |
| 1 | 1,437 | 23 |

These catalogues are regenerated from the definitions, not read from prior membership lists. Only the analytic endpoint reductions are external dependencies.

For each S let U_S be the union of its four-edge residual matchings after deleting row 0 and column r. Enumerate all 2^|U_S| binary colorings R of this union. For c=w(0,r) in {0,1}, the residual target is t=k−c. Retain a coloring only when the complete target-t fiber among all 24 residual permutations supported by U_S is exactly S, including exclusion of all unselected residual permutations. Then restore the fixed edge (0,r) with color c.

Every actual candidate produces one retained option: its color restriction to U_S has this property. Extra residual edges outside U_S are not assumed absent in the eventual graph; they are supplied in the extension stage.

At k=1, 159 distinct root slices have some retained coloring; at k=2, 174 do. The total numbers of retained root/color options are respectively 880 and 3,049.

## 3. Transport to the second endpoint

Let rho(i)=4−i. The reversal has even sign, and every term has total exponent 10. Hence

    f_p(−4−L) = f_(p composed with rho)(L).

Reversal transports support, colors, complete fibers and their red target without changing the column labels. The row-4 least-root slice is therefore the reversal of one of the row-0 options just enumerated. No arbitrary column relabelling or row symmetry is used.

## 4. Direct joint core construction

Choose an ordered pair of endpoint slices and a retained colored option for each, reversing the second option's rows. Their union is a colored core, with support U and red-edge set R.

Reject the choice if:

1. A member of either slice violates the other endpoint's specified minimum or specified least-root slice membership.
2. An overlapping edge has different colors in the two options.
3. The actual complete target-k fiber on the core contains a forbidden least-root matching.

The third condition checks every permutation, using its actual support and binary cost. Thus affine-closure outsiders are excluded automatically; **the final verifier does not rely on an affine-pair pruning catalogue**.

The exact direct counts are:

| Quantity | k=1 | k=2 |
|---|---:|---:|
| Ordered root-slice pairs | 25,281 | 30,276 |
| Membership-compatible pairs | 21,444 | 25,678 |
| Colored pairs tested | 649,091 | 7,960,693 |
| Overlap-color-consistent pairs | 42,375 | 214,887 |
| Valid colored cores | 1,066 | 6,096 |

Each valid core determines its least-root slices by its own complete fiber. The generator explicitly checks that no support/red-mask core is duplicated.

## 5. Monotone single-edge domain pruning

For every edge outside U, start with the three choices absent, blue, red. Edges below either endpoint minimum are forced absent by support normalization. For every remaining edge e and color b, temporarily add just that colored edge to the core.

If this creates a forbidden least-root matching at target k, forbid the color b for e in every extension. This is sound because adding further edges cannot remove an already supported matching or change the colors of its edges. Thus that same forbidden matching would still occur in any such extension.

Each unpruned edge independently has domain {absent,blue}, {absent,red}, or {absent,blue,red}. Edges whose only allowed choice is absent need no variable. There are at most 12 variable edges in any core.

Every normalized hypothetical counterexample contains one of the valid cores and uses only these allowed edge states. Therefore independently enumerating every remaining domain gives a complete finite cover; there is no edge-count bound, numerical budget, sampled branch, or size cutoff.

The products of domain sizes sum to 6,810,246 assignments at k=1 and 22,428,354 at k=2. The catalogue includes some graphs with extra unused edges and some assignments that produce additional forbidden root matchings through combinations of edges. Those are harmless enlargements and are checked exactly in the final stage.

## 6. Full-fiber exact rejection

For each assignment, form the actual complete target-k fiber by enumerating all 120 permutations, checking that every one of its five edges is supported and exactly k are red.

First reject if either least-root slice differs from the prescribed slice. Then compute the used endpoint columns from the **actual fiber**, and reject violations of the accepted endpoint conditions. All fibers reaching this stage are nonempty because the original core slices remain present.

For the remaining fibers compute the integer values Q(1) and Q(2). A nonzero value proves the polynomial is nonzero. If both values were zero, the implementation would expand and record all eleven coefficients; this branch was never reached.

| Quantity | k=1 | k=2 |
|---|---:|---:|
| All complete assignments | 6,810,246 | 22,428,354 |
| Preserve prescribed root slices | 2,006,841 | 5,053,461 |
| Also satisfy accepted endpoint cuts | 217,810 | 974,805 |
| Q(1)=0 | 5,272 | 15,303 |
| Q(1)=Q(2)=0 | 0 | 0 |

No hypothetical cancelling fiber survives. This proves the exclusion for k=1,2, conditional on the accepted prior endpoint theorems and verification of the stated finite enumeration.

All arithmetic used for decisions is exact. The sums of absolute values of all 120 terms at L=1 and L=2 are respectively 8,527,540 and 142,672,320, far below signed 64-bit range. Masks occupy only 25 bits. Catalogue elimination uses arbitrary-precision Python integers.

## 7. All binary targets

Complement every supported edge color. Each perfect matching uses five edges, so target k becomes 5−k with the same fiber and same polynomial. This proves k=3,4 from k=2,1.

For k=0, normalize support to union(F_0). Every remaining edge is blue, since every used edge belongs to a zero-red matching. Consequently F_0 is the set of all perfect matchings of this normalized support. Recolor every supported edge in row 0 red, leaving all other edges blue. Every matching now has exactly one red edge. Thus the same F_0 is a complete target-1 fiber, already excluded. Complementation handles k=5. This extension adds no enumeration or new structural assumption.

## 8. Reproduction, evidence and recovery

Run:

    python verify_complete.py --output NEW_OUTPUT_DIRECTORY
    python check_survivors.py --directory NEW_OUTPUT_DIRECTORY

`verify_complete.py` regenerates both root catalogues and all binary options, compiles the two C++ programs, directly constructs all cores and edge domains, and exhausts every extension. `check_survivors.py` reconstructs all 20,575 first-evaluation survivors using explicit cell matrices and binomial expansions rather than the primary bit-mask matching test and repeated-factor polynomial construction. Every recorded fiber and nonzero Q(2) agrees.

`STANDALONE_REPLAY/COMPLETE_RESULT.json` records the primary result. An optimized-Python replay and a C++ undefined-behavior-sanitizer replay are recorded separately. Primary replay is not independent review. The completed independent root/core/coefficient audit is `../joint-fiber-exhaustion-audit-20261019/`. The independently implemented full extension and pruning audit is `../remaining-fiber-construction-20261019/joint_extension_audit/`. Both passed. See `ACCEPTED_MANIFEST.json` for frozen receipts and dependencies.

Recovery conditions: if an independent checker finds a missing root slice, a core/domain disagreement, an unrepresented assignment, an arithmetic error, or an actual double-evaluation survivor, suspend the complete-exclusion claim. Preserve the exact support mask, red mask, target, both endpoint slices, full 120-permutation fiber membership, all polynomial coefficients and the disputed reduction branch. A survivor at two evaluations alone is not a counterexample; the full polynomial must vanish. A polynomial-zero subset alone is also not enough: it must be the entire actual cost fiber. The bounded result does not authorize a merge or research release, and it does not settle any unrestricted complexity-theoretic problem.
