// Independently reconstruct roots and binary cores using full 26-coordinate
// incidence vectors, Gray-code subset enumeration, and direct binary joins.
// Does not import any primary catalogue, pair filter, or core list.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using Vec=array<int64_t,26>;
struct Perm {array<int,5> p; uint32_t mask; int64_t weight; Vec v;};
vector<Perm> perms;
void check(bool ok,const string& why){if(!ok)throw runtime_error(why);}
Vec primitive(Vec a){int64_t g=0;for(auto x:a)g=gcd(g,x);if(!g)return a;for(auto &x:a)x/=g;for(auto x:a)if(x){if(x<0)for(auto&y:a)y=-y;break;}return a;}
Vec eliminate(Vec a,const vector<Vec>& basis){for(const auto& b:basis){int j=0;while(j<26&&!b[j])++j;check(j<26,"Zero basis row");if(!a[j])continue;int64_t h=a[j],d=b[j];for(int c=0;c<26;c++){__int128 z=(__int128)d*a[c]-(__int128)h*b[c];check(z>=INT64_MIN&&z<=INT64_MAX,"Exact elimination overflow");a[c]=(int64_t)z;}a=primitive(a);}return a;}
bool zero(const Vec&a){for(auto x:a)if(x)return false;return true;}
int pivot(const Vec&a){for(int c=0;c<26;c++)if(a[c])return c;return 26;}
vector<Vec> basis_of(const vector<int>& ids){vector<Vec> basis;for(int id:ids){auto a=eliminate(perms[id].v,basis);if(!zero(a)){basis.push_back(primitive(a));sort(basis.begin(),basis.end(),[](const Vec&a,const Vec&b){return pivot(a)<pivot(b);});}}return basis;}
struct Root {int r;vector<int> ids;uint32_t support;int rank;};
struct Option {int root;uint32_t support,red;};
uint32_t reverse_rows(uint32_t m){uint32_t n=0;for(int row=0;row<5;row++)n|=((m>>(5*row))&31)<<(5*(4-row));return n;}
string name(int id){string n;for(int x:perms[id].p)n+=char('0'+x);return n;}
int main(int argc,char**argv){check(argc==2,"Output directory required");string path=argv[1];array<int,5>p{0,1,2,3,4};do{Perm a{};a.p=p;int inv=0;for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)inv+=p[i]>p[j];a.weight=inv%2?-1:1;a.v[0]=1;for(int i=0;i<5;i++){a.mask|=1u<<(5*i+p[i]);a.v[1+5*i+p[i]]=1;if(i)for(int e=0;e<p[i];e++)a.weight*=i;}perms.push_back(a);}while(next_permutation(p.begin(),p.end()));
 vector<int> rev(120);for(int i=0;i<120;i++){auto q=perms[i].p;reverse(q.begin(),q.end());for(int j=0;j<120;j++)if(q==perms[j].p)rev[i]=j;}
 vector<Root> roots;ofstream rs(path+"/independent_roots.tsv");
 for(int r:{0,1}){vector<int> ids;for(int i=0;i<120;i++)if(perms[i].p[0]==r)ids.push_back(i);int balanced=0,closed=0;int64_t sum=0;uint32_t old=0;for(uint32_t n=1;n<(1u<<24);n++){uint32_t gray=n^(n>>1),delta=gray^old;int bit=__builtin_ctz(delta);sum+=(gray&delta)?perms[ids[bit]].weight:-perms[ids[bit]].weight;old=gray;if(sum)continue;balanced++;vector<int> selected;for(int j=0;j<24;j++)if(gray&(1u<<j))selected.push_back(ids[j]);auto basis=basis_of(selected);bool is_closed=true;for(int j=0;j<24;j++)if(!(gray&(1u<<j))&&zero(eliminate(perms[ids[j]].v,basis))){is_closed=false;break;}if(!is_closed)continue;closed++;uint32_t support=0;for(int i:selected)support|=perms[i].mask;roots.push_back({r,selected,support,(int)basis.size()});rs<<r<<' '<<basis.size()<<' '<<support<<' '<<selected.size();for(int id:selected)rs<<' '<<name(id);rs<<'\n';}cerr<<"ROOT "<<r<<" balanced "<<balanced<<" closed "<<closed<<'\n';}
 // Sort independently regenerated roots by the member strings, matching only
 // the mathematical families, not any imported index or order.
 sort(roots.begin(),roots.end(),[](const Root&a,const Root&b){return pair(a.r,a.ids)<pair(b.r,b.ids);});
 for(int k:{1,2}){vector<Option> options;ofstream os(path+"/independent_options_"+to_string(k)+".tsv");for(int ri=0;ri<(int)roots.size();ri++){auto&s=roots[ri];uint32_t inner=s.support&~31u;uint32_t red=inner;do{for(int cost:{0,1}){uint32_t full_red=red|(cost?1u<<s.r:0);bool good=true;for(int i=0;i<120;i++)if(perms[i].p[0]==s.r){bool inside=binary_search(s.ids.begin(),s.ids.end(),i);bool actual=(perms[i].mask&s.support)==perms[i].mask&&__builtin_popcount(perms[i].mask&full_red)==k;if(inside!=actual){good=false;break;}}if(good){options.push_back({ri,s.support,full_red});os<<s.r<<' '<<s.support<<' '<<full_red<<' '<<s.ids.size();for(int id:s.ids)os<<' '<<name(id);os<<'\n';}}if(!red)break;red=(red-1)&inner;}while(true);}cerr<<"OPTIONS "<<k<<' '<<options.size()<<'\n';
 long long shared_ok=0,min_ok=0,root_ok=0,mass=0;set<pair<uint32_t,uint32_t>> keys;map<int,int> hist;ofstream cs(path+"/independent_cores_"+to_string(k)+".tsv");ofstream input(path+"/independent_extension_input_"+to_string(k)+".txt");vector<string> inputrows;
 for(const auto&a:options)for(const auto&bb:options){const auto&s=roots[a.root];const auto&t=roots[bb.root];uint32_t B=reverse_rows(bb.support),W=reverse_rows(bb.red);if((a.red^W)&a.support&B)continue;shared_ok++;uint32_t U=a.support|B,R=a.red|W;uint32_t forbidden=((1u<<s.r)-1)|(((1u<<t.r)-1)<<20);if(U&forbidden)continue;min_ok++;array<bool,120> wanted0{},wanted4{};for(int id:s.ids)wanted0[id]=true;for(int id:t.ids)wanted4[rev[id]]=true;bool good=true;vector<int> bad;for(int i=0;i<120;i++){bool actual=(perms[i].mask&U)==perms[i].mask&&__builtin_popcount(perms[i].mask&R)==k;if(perms[i].p[0]==s.r&&actual!=wanted0[i])good=false;if(perms[i].p[4]==t.r&&actual!=wanted4[i])good=false;if((perms[i].p[0]==s.r&&!wanted0[i])||(perms[i].p[4]==t.r&&!wanted4[i]))bad.push_back(i);}if(!good)continue;root_ok++;check(keys.insert({U,R}).second,"Duplicate independent support/color core");
 vector<pair<int,vector<int>>>domains;long long extensions=1;for(int e=0;e<25;e++){uint32_t bit=1u<<e;if((U|forbidden)&bit)continue;vector<int>d{-1};for(int c:{0,1}){uint32_t V=U|bit,Z=R|(c?bit:0);bool admissible=true;for(int id:bad)if((perms[id].mask&V)==perms[id].mask&&__builtin_popcount(perms[id].mask&Z)==k){admissible=false;break;}if(admissible)d.push_back(c);}if(d.size()>1){extensions*=d.size();domains.push_back({e,d});}}mass+=extensions;hist[static_cast<int>(domains.size())]++;cs<<U<<' '<<R<<' '<<s.r<<' '<<t.r<<' '<<extensions<<' '<<domains.size();for(auto&[e,d]:domains){cs<<' '<<e<<' '<<d.size();for(int c:d)cs<<' '<<c;}cs<<'\n';string line=to_string(U)+" "+to_string(R)+" "+to_string(s.r)+" "+to_string(t.r)+" "+to_string(domains.size());for(auto&[e,d]:domains){line+=" "+to_string(e)+" "+to_string(d.size());for(int c:d)line+=" "+to_string(c);}inputrows.push_back(line);
 }input<<k<<' '<<inputrows.size()<<'\n';for(const string&line:inputrows)input<<line<<'\n';cerr<<"JOIN "<<k<<" all_pairs "<<options.size()*options.size()<<" shared_colors "<<shared_ok<<" minima "<<min_ok<<" cores "<<root_ok<<" mass "<<mass<<'\n';for(auto[d,n]:hist)cerr<<"DOMAIN "<<k<<' '<<d<<' '<<n<<'\n';}
}
