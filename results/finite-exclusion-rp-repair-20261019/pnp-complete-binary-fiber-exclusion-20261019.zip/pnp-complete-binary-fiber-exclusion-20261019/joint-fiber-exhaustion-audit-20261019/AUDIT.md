# Independent audit of the canonical n=5 binary-fiber exhaustion

19 October 2026. Local read-only review of prior research inputs, with new independent calculations in this directory. No repository, PR, merge, release, or prior accepted artifact was changed.

## Verdict and exact scope

PASS, conditional on the already accepted endpoint-support reductions in `../fiber-structural-reduction-20261019`.

For the fixed canonical signed polynomials

    f_p(L) = sgn(p) product_(i=0)^4 (L+i)^(p(i)),

there is no nonempty complete fiber of a supported binary edge-cost matrix, at any binary target k in {0,1,2,3,4,5}, whose sum is the zero polynomial. Here p ranges over all 120 permutations of the fixed column labels {0,1,2,3,4}. The audit supports this finite restricted-model conclusion. It makes no assertion about general n, arbitrary costs, different offsets, or P versus NP. Targets 0 and 5 are covered by the separate analytic recoloring argument below, not by new enumeration.

This is independent AI-assisted finite verification, not external peer review or proof-assistant formalization.

## Independence of root and core coverage

`regenerate_roots_and_cores.cpp` imports no primary catalogue, root list, affine-pair filter, or core file. It performs the following independent reconstruction:

1. Generate all 120 permutations, actual 25-edge incidence masks, signed endpoint scalar weights, and full augmented 26-coordinate incidence vectors.
2. At each possible endpoint minimum r in {0,1}, visit every nonempty subset of its 24 permutations in Gray-code order, maintaining the exact signed scalar sum. This is different from the primary positive/negative subset-sum join.
3. For every balanced subset, compute affine closure using all 25 incidence coordinates plus the leading constant coordinate. Integer elimination with gcd normalization is exact and includes explicit overflow checks. This is independent of the primary reduced-coordinate implementation.
4. For each retained root family, enumerate every binary coloring of its residual union and both pinned root-edge costs. Keep it precisely when direct matching enumeration gives the complete prescribed root family at global target k.
5. Join every pair of rooted colorings. Reflect the second root by row reversal, require agreement on common edge colors, exclude edges below either endpoint minimum, and test both root families by direct complete-fiber enumeration. No affine-pair pruning is used.
6. Independently regenerate every missing-edge domain from the actual support and costs.

Counts:

| Quantity | k=1 | k=2 |
|---|---:|---:|
| Rooted binary options | 880 | 3,049 |
| All ordered option pairs | 774,400 | 9,296,401 |
| Compatible shared colors | 49,751 | 245,420 |
| Also compatible with both endpoint minima | 49,135 | 243,425 |
| Complete-root-consistent cores | 1,066 | 6,096 |
| Ternary assignments after single-edge pruning | 6,810,246 | 22,428,354 |

The independent root enumeration gives 13,419 balanced / 216 affine-closed families at r=0, and 1,437 / 23 at r=1. `compare_and_check.py` verifies exact equality of all 239 memberships and augmented ranks against the accepted endpoint catalogue, exact equality of all 880/3,049 colored root options, and exact equality of every core's support, colors, endpoint minima, edge domains, and extension count against the primary objects. Matching only the aggregate counts would not have been sufficient.

The original primary affine-pair pruning therefore is not a dependency of this audit or of the final exclusion.

## Why the case reduction cannot omit a real cancelling fiber

Assume a nonempty cancelling complete fiber F at target 1 or 2. Replace its support by union(F), keeping the existing costs on those edges. This preserves F: no member is lost, and deleting edges cannot create a matching. By the accepted endpoint reductions, each endpoint uses at least three columns, includes column 1 and at least one of 0 and 2, and has minimum 0 or 1.

For row 0, let r be its smallest used exponent and S its nonempty minimum slice. The coefficient of L^r forces the signed scalar sum of S to be zero. S is affine-closed among the 24 root permutations: an affine combination equal to another incidence vector uses no edge absent from union(S), has the same cost, and therefore belongs to the complete fiber. Full augmented incidence coordinates are sufficient for this argument. Consequently S occurs in the independently generated catalogue.

Restrict the actual colors to the union of S. Removing other edges preserves exactly S in the root slice. Its binary coloring and the pinned root-edge color therefore occur in the independent options. Row reversal gives the corresponding option for row 4. Their colors agree on overlap, their union contains no edge below either endpoint minimum, and adding the two unions cannot introduce a wrong root matching. Thus the actual matrix has one of the generated cores.

For each missing edge, absence is always allowed. A blue or red state is removed only if adding that one edge to the fixed core already creates a target-k matching in a forbidden root position. Any extension preserving these fixed edge colors retains that matching; adding later edges cannot remove it or change its cost. Such a state cannot occur in the original F. Edges below the endpoint minima are absent in union(F). These are all edge exclusions. Edges whose only admissible state is absence need not appear as variables.

All other edge states are enumerated independently, including superfluous edges unused by the final fiber. Allowing unused edges enlarges the family and is safe for exclusion. Later combinations of individually safe edges can create wrong root matchings; they are checked and rejected at each complete assignment. The endpoint-degree/column restrictions are applied to the actual union of the resulting fiber, not merely to the raw support graph.

## Independent extension replay and exact arithmetic

The separate reviewer in `../remaining-fiber-construction-20261019/joint_extension_audit` independently implemented the complete extension replay using 25 explicit cell states and incrementally maintained missing-edge/red-count arrays for all 120 matchings. It traverses domains in a different order and derives signs from cycle counts. It also reran the replay on the independently regenerated inputs from this directory, under undefined-behavior sanitization. Its primary-input and independent-input survivor multisets agree.

Exact final counts:

| Quantity | k=1 | k=2 |
|---|---:|---:|
| Complete assignments | 6,810,246 | 22,428,354 |
| Both root slices preserved | 2,006,841 | 5,053,461 |
| Endpoint restrictions satisfied | 217,810 | 974,805 |
| Q(1)=0 | 5,272 | 15,303 |
| Q(1)=Q(2)=0 | 0 | 0 |

`compare_and_check.py` adds an independent coefficient-level audit of every one of the 20,575 first-evaluation survivors. It reconstructs the actual fiber by reading the explicit 25 cell states and testing all 120 permutations. Signs come from cycle count rather than inversion count. Every signed polynomial is reconstructed by Newton finite differences from eleven exact integer products, giving all eleven integer coefficients. Those polynomials are checked at additional positive and negative integer points. Every recorded fiber membership, Q(1)=0, and nonzero Q(2) is verified; the smallest absolute nonzero Q(2) values are 35,280 and 12,960. Full coefficients and matching lists are saved in `coefficient_witnesses_1.json` and `coefficient_witnesses_2.json`.

The rejection is sound because a nonzero evaluation proves a polynomial nonzero. Zero at two points would not prove an identity; there were no such survivors. With degree 10, each individual absolute evaluation at 1 or 2 is at most 6^10. Summing at most 120 terms remains below 7.3 billion, safely inside signed 64-bit range. Coefficient absolute sums are bounded by 120*5^10. Exact arithmetic is used throughout, with no numerical tolerance or solver infeasibility claim.

## Symmetry and target coverage

The identity f_p(-4-L)=f_(p reversed)(L) follows from even row-reversal parity and total exponent 10. The audit checks it for all 120 polynomials at eleven exact points, sufficient for degree at most ten. Row reversal preserves support, binary costs, completeness, and nonemptiness, and does not relabel columns.

Complementing costs on supported edges maps target k to 5-k without changing the fiber membership or its polynomial. The audit checks all 32 binary cost patterns on a five-edge matching. Thus the exclusions at 1 and 2 transfer to 4 and 3.

For target 0, normalize support to union(F). Every remaining edge lies in a zero-cost matching; because all costs are nonnegative binary values, every remaining edge is blue. Therefore F is all perfect matchings of this normalized graph. Recolor all supported row-0 edges red and leave all other edges blue. Every perfect matching has exactly one row-0 edge, so every perfect matching now has cost 1. The identical nonempty matching family F is thus a complete target-1 fiber, with the identical polynomial. The target-1 exclusion proves the target-0 exclusion. Complementing colors reduces target 5 to target 0. Integer targets outside 0 through 5 have no matching. This analytic extension requires no additional endpoint assumption or enumeration.

No other permutation symmetry or arbitrary fixed edge color is assumed.

## Reproduction and numerical safety

Build and execute:

    g++ -std=c++17 -O2 -Wall -Wextra -Wconversion regenerate_roots_and_cores.cpp -o regenerate_roots_and_cores
    ./regenerate_roots_and_cores . > regenerate.log 2>&1
    python compare_and_check.py

For the sanitizer replay:

    mkdir -p ubsan
    g++ -std=c++17 -O1 -g -Wall -Wextra -Wconversion -fsanitize=undefined -fno-sanitize-recover=undefined regenerate_roots_and_cores.cpp -o regenerate_roots_and_cores_ubsan
    ./regenerate_roots_and_cores_ubsan ubsan > ubsan/regenerate.log 2>&1

The sanitizer replay completed without a diagnostic. All eight generated root, option, core, extension-input, and log files are byte-identical to the optimized reconstruction. `COMPARISON_AND_COEFFICIENT_AUDIT.json` gives the exact object-comparison and coefficient-replay results. `AUDIT_MANIFEST.json` records sources, outputs, dependency hashes, and the separate extension replay evidence.

The accepted endpoint-degree and endpoint-column theorems are explicit dependencies; they are not re-proved here. Everything after those cuts has independently reconstructed coverage and independent full-extension verification.
