#!/usr/bin/env python3
"""Independent object comparisons and exact rejection-witness replay.
No primary code imported. Polynomials recovered from eleven integer values
with Newton differences; parity computed from cycle count, not inversions.
"""
from pathlib import Path
from fractions import Fraction
from itertools import permutations
from math import factorial, prod
import hashlib, json
HERE=Path(__file__).resolve().parent
PRIMARY=Path('/workspace/shared/remaining-fiber-obstruction-20261019')
ACCEPTED=Path('/workspace/shared/sparse-fiber-structural-next-20261019/ENDPOINT_CERTIFICATE.json')
P=list(permutations(range(5)))
NAMES=[''.join(map(str,p)) for p in P]
INDEX={n:i for i,n in enumerate(NAMES)}
def require(ok, why):
    if not ok: raise RuntimeError(why)
def cycle_sign(p):
    unseen=set(range(5)); cycles=0
    while unseen:
        cycles+=1; j=min(unseen)
        while j in unseen:
            unseen.remove(j); j=p[j]
    return (-1)**(5-cycles)
def polynomial(p):
    sign=cycle_sign(p)
    values=[sign*prod((x+i)**p[i] for i in range(5)) for x in range(11)]
    leading=[]; differences=values
    while differences:
        leading.append(differences[0]); differences=[b-a for a,b in zip(differences,differences[1:])]
    result=[Fraction(0) for _ in range(11)]; falling=[1]
    for order,delta in enumerate(leading):
        for degree,c in enumerate(falling): result[degree]+=Fraction(delta*c,factorial(order))
        grown=[0]*(len(falling)+1)
        for degree,c in enumerate(falling): grown[degree]-=order*c; grown[degree+1]+=c
        falling=grown
    require(all(c.denominator==1 for c in result),'Non-integral reconstructed coefficients')
    result=[int(c) for c in result]
    for x in (-7,-4,-1,0,1,2,5,11,17):
        require(sum(c*x**j for j,c in enumerate(result))==sign*prod((x+i)**p[i] for i in range(5)),'Newton polynomial reconstruction failed')
    return result
POLY=[polynomial(p) for p in P]
report={'root_method':'All 2^24 subsets via Gray code; exact full 26-coordinate affine closure',
        'join_method':'All binary root/color pairs, direct complete fibers, no affine pair pruning',
        'coefficient_method':'Cycle parity and Newton differences from 11 exact integer products', 'targets':{}}
roots={}
for line in (HERE/'independent_roots.tsv').read_text().splitlines():
    r,rank,support,count,*names=line.split(); require(len(names)==int(count),'Root record length')
    roots[(int(r),tuple(names))]=(int(rank),int(support))
accepted=json.loads(ACCEPTED.read_text())
oldroots={}
for group in accepted['slices']:
    r=group['minimum_exponent']
    if r not in (0,1): continue
    for s in group['closed_sets']: oldroots[(r,tuple(s['members']))]=s['augmented_rank']
require(roots.keys()==oldroots.keys(),'Accepted root membership mismatch')
require(all(value[0]==oldroots[key] for key,value in roots.items()),'Accepted root rank mismatch')
report['root_memberships_and_ranks_match']=len(roots)
primary_roots=json.loads((PRIMARY/'BINARY_ROOT_SLICES.json').read_text())
for k in (1,2):
    options=set()
    for line in (HERE/f'independent_options_{k}.tsv').read_text().splitlines():
        r,u,w,count,*names=line.split();require(len(names)==int(count),'Option record length')
        options.add((int(r),int(u),int(w),tuple(names)))
    reference=set()
    for s in primary_roots:
        for t in (k-1,k):
            for red in s['colors'][str(t)]:
                reference.add((s['r'],(s['U']<<5)|(1<<s['r']),(red<<5)|((k-t)<<s['r']),tuple(s['members'])))
    require(options==reference,'Binary root option mismatch')
    cores={}
    for line in (HERE/f'independent_cores_{k}.tsv').read_text().splitlines():
        nums=list(map(int,line.split()));u,w,r0,r4,total,nd=nums[:6];at=6; domains=[]
        for _ in range(nd):
            edge,size=nums[at:at+2];at+=2;ds=tuple(nums[at:at+size]);at+=size;domains.append((edge,ds))
        require(at==len(nums),'Core record trailing data')
        require((u,w) not in cores,'Duplicate core key')
        cores[(u,w)]=(r0,r4,total,tuple(domains))
    reference={}
    for c in json.loads((PRIMARY/f'BINARY_CORES_{k}.json').read_text()):
        reference[(c['U'],c['R'])]=(c['r0'],c['r4'],c['extensions'],tuple((e,tuple(d)) for e,d in c['domains']))
    require(cores==reference,'Core or domain exact-set mismatch')
    witnesses=[]; q2_min=None; sizes={}; unique=set()
    for line in (PRIMARY/f'EVALUATION_SURVIVORS_{k}.txt').read_text().splitlines():
        core,u,w,q2,size,*claimed=map(int,line.split())
        require(w&~u==0,'Red edge outside support')
        matrix=[[(-1 if not (u>>(5*i+j))&1 else (w>>(5*i+j))&1) for j in range(5)] for i in range(5)]
        actual=[]
        for index,p in enumerate(P):
            costs=[matrix[i][p[i]] for i in range(5)]
            if -1 not in costs and sum(costs)==k:actual.append(index)
        require(actual==claimed and size==len(actual) and actual,'Incorrect complete survivor fiber')
        coeff=[sum(POLY[index][degree] for index in actual) for degree in range(11)]
        require(sum(coeff)==0,'First evaluation nonzero')
        derived_q2=sum(c*(2**degree) for degree,c in enumerate(coeff))
        require(derived_q2==q2 and q2!=0,'Second evaluation witness failure')
        for row in (0,4):
            used={P[index][row] for index in actual}
            require(len(used)>=3 and 1 in used and bool(used&{0,2}),'Endpoint filter violation')
        q2_min=min(abs(q2),q2_min or abs(q2));sizes[size]=sizes.get(size,0)+1;unique.add((u,w))
        witnesses.append({'support':u,'red':w,'fiber':actual,'coefficients':coeff,'Q2':q2})
    output=HERE/f'coefficient_witnesses_{k}.json'
    output.write_text(json.dumps(witnesses,separators=(',',':'))+'\n')
    report['targets'][str(k)]={'root_options':len(options),'cores':len(cores),'full_extensions':sum(c[2] for c in cores.values()),'root_options_exact_match':True,'core_domains_exact_match':True,'Q1_survivors_checked':len(witnesses),'distinct_Q1_support_color_pairs':len(unique),'minimum_abs_Q2':q2_min,'fiber_size_histogram':sizes,'witness_sha256':hashlib.sha256(output.read_bytes()).hexdigest()}
# Check both transfer identities independently from coefficients and explicit costs.
for p,a in zip(P,POLY):
    rev=P.index(tuple(reversed(p)))
    for x in range(11):require(sum(c*((-4-x)**j) for j,c in enumerate(a))==sum(c*(x**j) for j,c in enumerate(POLY[rev])),'Row reversal transfer failure')
    for red in range(32):require(sum((red>>i)&1 for i in range(5))+sum(1-((red>>i)&1) for i in range(5))==5,'Complement transfer failure')
report['all_120_polynomials_reconstructed_and_cross_checked']=True
report['row_reversal_checked_at_11_points']=True
report['color_complement_checked_all_matching_colorings']=True
for p in P:
    require(sum(1 for row,col in enumerate(p) if row==0)==1,'Pinned-row recoloring failure')
report['zero_five_target_extension']='Analytic: normalize target0 to an allblue support, recolor supported row0 edges red to preserve the identical complete fiber at target1; target5 by complement. Each of120 permutations has exactly one row0 edge.'
(HERE/'COMPARISON_AND_COEFFICIENT_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
