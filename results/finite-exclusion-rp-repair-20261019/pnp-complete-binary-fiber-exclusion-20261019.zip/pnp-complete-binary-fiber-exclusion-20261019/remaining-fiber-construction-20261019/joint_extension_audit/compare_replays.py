import collections,itertools,json,math
from pathlib import Path
D=Path(__file__).resolve().parent;S=Path('/workspace/shared/remaining-fiber-obstruction-20261019')
def need(x,m):
 if not x:raise RuntimeError(m)
P=list(itertools.permutations(range(5)))
def coefficients(p):
 sign=(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5));c=[sign]
 for i,e in enumerate(p):
  new=[0]*(len(c)+e)
  for j,x in enumerate(c):
   for d in range(e+1):new[j+d]+=x*math.comb(e,d)*i**(e-d)
  c=new
 return c
C={p:coefficients(p) for p in P}
for p,c in C.items():
 transformed=[sum(c[d]*math.comb(d,j)*(-4)**(d-j)*(-1)**j for d in range(j,11)) for j in range(11)]
 need(transformed==C[p[::-1]],'row reversal polynomial identity')
for bits in itertools.product((0,1),repeat=5):need(sum(1-b for b in bits)==5-sum(bits),'binary complement')
results=[]
for k in (1,2):
 primary=json.loads((S/f'EXTENSION_STATS_{k}.json').read_text())
 a=json.loads((D/f'INDEPENDENT_STATS_{k}.json').read_text())
 b=json.loads((D/f'REGENERATED_STATS_{k}.json').read_text())
 for key,value in a.items():need(primary[key]==value==b[key],f'stat mismatch {key}')
 s0=(S/f'EVALUATION_SURVIVORS_{k}.txt').read_text().splitlines()
 s1=(D/f'INDEPENDENT_SURVIVORS_{k}.txt').read_text().splitlines()
 s2=(D/f'REGENERATED_SURVIVORS_{k}.txt').read_text().splitlines()
 need(sorted(s0)==sorted(s1),'same-core full survivor list')
 need(collections.Counter(tuple(map(int,s.split()[1:])) for s in s0)==collections.Counter(tuple(map(int,s.split()[1:])) for s in s2),'regenerated full survivor list ignoring reordered core IDs')
 need(len(s0)==a['Q1_zero'],'survivor count');need(a['Q1_Q2_zero']==0,'second evaluation exclusions')
 results.append({'target':k,'all_stats_match':True,'same_core_survivor_lines_match':True,'regenerated_survivor_multiset_matches':True,'first_evaluation_survivors':len(s0),'second_evaluation_survivors':0})
out={'row_reversal_coefficient_checks':120,'binary_complement_cost_pattern_checks':32,'target_checks':results}
(D/'REPLAY_COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
