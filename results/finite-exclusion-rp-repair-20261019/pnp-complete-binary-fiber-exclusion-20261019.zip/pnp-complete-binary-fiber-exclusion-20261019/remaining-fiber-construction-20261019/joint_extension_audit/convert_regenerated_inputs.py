import itertools,json
from pathlib import Path
D=Path(__file__).resolve().parent;S=Path('/workspace/shared/joint-fiber-exhaustion-audit-20261019')
P=list(itertools.permutations(range(5)));M=[sum(1<<(5*r+p[r]) for r in range(5)) for p in P]
for k in (1,2):
 vals=iter(map(int,(S/f'independent_extension_input_{k}.txt').read_text().split()));target=next(vals);n=next(vals)
 if target!=k:raise RuntimeError('target')
 with (D/f'REGENERATED_INPUT_{k}.txt').open('w') as f:
  f.write(f'{k} {n}\n')
  for core in range(n):
   U,R,r0,r4,m=[next(vals) for _ in range(5)];domains=[]
   for _ in range(m):
    e,z=next(vals),next(vals);domains.append((e,[next(vals) for _ in range(z)]))
   colors=[-1 if not(U>>e)&1 else (R>>e)&1 for e in range(25)]
   F=[i for i,x in enumerate(M) if x&U==x and (x&R).bit_count()==k]
   f.write(f'{core} {r0} {r4}\n'+' '.join(map(str,colors))+'\n')
   for row,r in [(0,r0),(4,r4)]:
    ids=[i for i in F if P[i][row]==r];f.write(str(len(ids))+' '+' '.join(map(str,ids))+'\n')
   f.write(str(m)+'\n')
   for e,ds in reversed(domains):f.write(f'{e} {len(ds)} '+' '.join(map(str,reversed(ds)))+'\n')
 try:next(vals);raise RuntimeError('extra input')
 except StopIteration:pass
 print(k,n,flush=True)
