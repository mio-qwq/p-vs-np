# Independent extension replay and pruning audit

19 October 2026. Local exact audit of the remaining canonical five-row binary-fiber exhaustion. No remote changes. This is AI-assisted independent implementation, not external peer review or formal verification.

## Outcome

All 29,238,600 extension assignments reproduce exactly in an independently implemented incremental-state enumerator. Every first-evaluation survivor agrees with the primary program's full support, coloring, complete fiber membership and nonzero second evaluation. A second run on independently regenerated core inputs, compiled with undefined-behavior sanitization, gives the same results and the same survivor multiset. No sanitizer failure occurred.

- Target 1: 1,066 cores; 6,810,246 assignments; 2,006,841 root-consistent; 217,810 endpoint-consistent; 5,272 with Q(1)=0; none with Q(1)=Q(2)=0.
- Target 2: 6,096 cores; 22,428,354 assignments; 5,053,461 root-consistent; 974,805 endpoint-consistent; 15,303 with Q(1)=0; none with Q(1)=Q(2)=0.

This audit supplies the extension/pruning part of the finite proof. Independent root/core coverage is supplied by `../../joint-fiber-exhaustion-audit-20261019/`, which regenerated all scalar-balanced affine-closed root slices, all binary root colorings, and all consistent paired cores without using the primary affine-pair filter. That auditor reports exact canonical equality of all core/domain objects. The present sanitized replay uses its newly generated inputs, rather than merely importing the primary cores.

## Pruning audit

`prepare_and_audit_domains.py` reconstructs the core as 25 explicit cell states: absent, blue, or red. It recomputes each complete target fiber by checking all five actual entries of each of the 120 permutations, and confirms the prescribed row-0 and row-4 root slices exactly.

For each unsupported edge not forbidden by an endpoint minimum, it separately tries blue and red. A color is excluded only if the core plus that edge already supports an unwanted target-cost matching in one of the prescribed root slices. The audit records a concrete permutation witness for every excluded edge/color pair. It reproduces every domain exactly, with 7,809 exclusions for target 1 and 44,285 for target 2, 52,094 in total. Edges with no permitted present color are permanently absent.

This pruning is logically necessary. In every future extension the witness's five existing edges remain present with the same colors, so its cost stays at the target. Adding other edges cannot repair the extra root member. Conversely, every color without such a witness remains available; absence is always included. The rule can miss obstructions involving two or more added edges, but cannot remove an actual completion. Those later obstructions are checked at the full leaves.

Endpoint edges below a prescribed minimum are absent after the valid normalization support=union(F). Removing unused support edges preserves every member of F, creates no matching, and leaves every target matching in the reduced graph inside F. Thus this normalization does not discard any putative cancelling fiber. Interior edges need not equal union(F) in the enumeration; allowing extra unused edges safely enlarges the tested family.

## Independent enumeration method

The primary enumerator tests support/color bitmasks afresh. `independent_extensions.cpp` instead maintains, for every permutation, a count of missing edges and its current red count. When an optional edge is added or removed during mixed-domain recursion, only the 24 permutations containing that edge are updated. A complete fiber member is exactly a permutation with missing count zero and red count k. Every leaf checks both root slices by explicit membership equality, then calculates used endpoint columns and exact integer Q(1), Q(2).

Permutations are generated recursively by available columns. Signs are computed from cycle counts, independently of the primary inversion-count method. Polynomial values are computed by direct products. Domain order and state order are reversed relative to the primary program. Core-reordered survivor outputs are compared as exact multisets, including every support/color pair, all complete fiber indices and the nonzero Q(2), not just aggregate counts.

`convert_regenerated_inputs.py` converts the other auditor's independently created bitmask inputs to explicit 25-cell inputs. It derives prescribed root membership directly from the actual core support and cost. The sanitized C++ replay then enumerates all assignments again. The independently regenerated core order differs, so survivor comparison ignores only the core identifier while preserving multiplicities and every mathematical datum.

## Symmetry and target checks

`compare_replays.py` independently expands all 120 original-L polynomials by binomial convolution and checks every coefficient of

    f_p(-4-L) = f_reverse(p)(L).

This validates use of the same root catalogue at row 4. The identity also follows because row reversal has even permutation sign and total degree ten is even.

Color complementation acts only on supported edges. Every perfect matching has five edges, so its new cost is 5 minus its old cost. The checker verifies all 32 possible five-edge color patterns. The complete target-k fiber is unchanged as a matching family when the target becomes 5-k; hence the k=1,2 exclusions transfer to k=4,3. This audit makes no additional assertion about targets 0 or 5.

The accepted endpoint theorem is a dependency: a cancelling target-1-through-4 complete fiber must use at least three endpoint columns, must include column 1, and must include column 0 or 2. Consequently both endpoint minima are 0 or 1. The enumeration does not assume arbitrary relabeling symmetry.

## Scope and recovery

No counterexample or pruning gap was found. Exact nonzero evaluations are sufficient rejection certificates; two zero evaluations would not by themselves establish a polynomial identity, but no leaf passes both. The coefficient-based survivor audit by the other reviewer gives an additional independent check of all 20,575 first-evaluation survivors.

These checks establish the extension layer only together with the independent core-coverage result and the accepted endpoint restrictions. No solver status, timeout, approximate zero, or general P-versus-NP implication enters the proof.

## Files and reproduction

- `DOMAIN_AUDIT_1.json`, `DOMAIN_AUDIT_2.json`: every single-edge pruning witness.
- `INDEPENDENT_STATS_*.json`, `INDEPENDENT_SURVIVORS_*.txt`: first independent replay on the primary cores.
- `REGENERATED_STATS_*.json`, `REGENERATED_SURVIVORS_*.txt`: sanitized replay on independently regenerated cores.
- `REPLAY_COMPARISON.json`: exact aggregate and full survivor comparison, plus symmetry checks.
- `PER_CORE_*.txt`, `REGENERATED_PER_CORE_*.txt`: per-core stage counts.

From this directory, with the two neighboring research directories present:

    python prepare_and_audit_domains.py
    g++ -O2 -std=c++17 -Wall -Wextra -Wno-misleading-indentation independent_extensions.cpp -o independent_extensions
    ./independent_extensions INDEPENDENT_INPUT_1.txt INDEPENDENT_STATS_1.json INDEPENDENT_SURVIVORS_1.txt PER_CORE_1.txt
    ./independent_extensions INDEPENDENT_INPUT_2.txt INDEPENDENT_STATS_2.json INDEPENDENT_SURVIVORS_2.txt PER_CORE_2.txt
    python convert_regenerated_inputs.py
    g++ -O2 -g -std=c++17 -Wall -Wextra -Wno-misleading-indentation -fsanitize=undefined -fno-sanitize-recover=undefined independent_extensions.cpp -o independent_extensions_ubsan
    ./independent_extensions_ubsan REGENERATED_INPUT_1.txt REGENERATED_STATS_1.json REGENERATED_SURVIVORS_1.txt REGENERATED_PER_CORE_1.txt
    ./independent_extensions_ubsan REGENERATED_INPUT_2.txt REGENERATED_STATS_2.json REGENERATED_SURVIVORS_2.txt REGENERATED_PER_CORE_2.txt
    python compare_replays.py

Python checks use explicit exceptions and pass with `python -O`. Compiled executables are reproducible build artifacts rather than trust anchors.
