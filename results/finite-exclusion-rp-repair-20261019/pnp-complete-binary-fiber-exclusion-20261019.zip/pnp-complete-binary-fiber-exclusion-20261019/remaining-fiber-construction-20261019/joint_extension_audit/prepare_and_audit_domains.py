import itertools,json,math
from pathlib import Path
D=Path(__file__).resolve().parent
S=Path('/workspace/shared/remaining-fiber-obstruction-20261019')
P=list(itertools.permutations(range(5)))
E=[[5*r+p[r] for r in range(5)] for p in P]
def need(x,m):
 if not x:raise RuntimeError(m)
def fiber(c,k):return [i for i,e in enumerate(E) if all(c[j]>=0 for j in e) and sum(c[j] for j in e)==k]
for k in (1,2):
 cores=json.loads((S/f'BINARY_CORES_{k}.json').read_text());ledger=[];exp=0;pruned=0
 with (D/f'INDEPENDENT_INPUT_{k}.txt').open('w') as f:
  f.write(f'{k} {len(cores)}\n')
  for idx,c in enumerate(cores):
   need(c['R']&~c['U']==0,'red outside support')
   state=[-1 if not(c['U']>>e)&1 else int((c['R']>>e)&1) for e in range(25)]
   F=fiber(state,k);A=set(c['S0']);B=set(c['S4'])
   need(F==c['base_fiber'],'base fiber')
   need({i for i in F if P[i][0]==c['r0']}==A,'row0 slice')
   need({i for i in F if P[i][4]==c['r4']}==B,'row4 slice')
   need(c['r0'] in (0,1) and c['r4'] in (0,1),'endpoint minima')
   forbidden=[i for i,p in enumerate(P) if (p[0]==c['r0'] and i not in A) or (p[4]==c['r4'] and i not in B)]
   domains=[];witnesses=[]
   for e in range(25):
    row,col=divmod(e,5)
    if (row==0 and col<c['r0']) or (row==4 and col<c['r4']):
     need(state[e]==-1,'forbidden endpoint edge present');continue
    if state[e]>=0:continue
    ds=[-1]
    for color in (0,1):
     state[e]=color
     witness=next((i for i in forbidden if all(state[j]>=0 for j in E[i]) and sum(state[j] for j in E[i])==k),None)
     if witness is None:ds.append(color)
     else:witnesses.append([e,color,witness]);pruned+=1
     state[e]=-1
    if len(ds)>1:domains.append([e,ds])
   need(domains==c['domains'],f'domain mismatch target{k} core{idx}')
   extensions=math.prod(len(ds) for _,ds in domains);need(extensions==c['extensions'],'extension count');exp+=extensions
   f.write(f'{idx} {c["r0"]} {c["r4"]}\n')
   f.write(' '.join(map(str,state))+'\n')
   for fam in (c['S0'],c['S4']):f.write(str(len(fam))+' '+' '.join(map(str,fam))+'\n')
   f.write(str(len(domains))+'\n')
   for e,ds in reversed(domains):f.write(f'{e} {len(ds)} '+' '.join(map(str,reversed(ds)))+'\n')
   ledger.append({'core':idx,'pruned_edge_color_witnesses':witnesses,'extensions':extensions})
 result={'target':k,'cores':len(cores),'extension_assignments':exp,'pruned_edge_colors':pruned,'all_domains_match':True,'ledger':ledger}
 (D/f'DOMAIN_AUDIT_{k}.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({x:result[x] for x in result if x!='ledger'}),flush=True)
