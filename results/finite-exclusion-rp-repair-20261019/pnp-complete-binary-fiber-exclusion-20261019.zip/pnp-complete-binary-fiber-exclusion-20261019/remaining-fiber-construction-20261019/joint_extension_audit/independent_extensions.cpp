// Independent incremental complete-fiber replay. No support-bitmask matching tests.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;
struct Term{array<int,5> p;array<int,5> edges;long long q1,q2;};
vector<Term> terms;array<vector<int>,25> incident;array<int,120> missing,red;array<int,25> colors;array<bool,120> expected0,expected4;
int target,root0,root4,core;long long checked=0,rootok=0,endpointok=0,first=0,second=0;ofstream survivors,percore;
struct Domain{int edge;vector<int>states;};vector<Domain> domains;
long long power(int a,int b){long long x=1;for(int j=0;j<b;++j)x*=a;return x;}
void enumerate_perms(array<int,5>&p,int row,int used){
 if(row<5){for(int c=0;c<5;++c)if(!(used&(1<<c))){p[row]=c;enumerate_perms(p,row+1,used|(1<<c));}return;}
 // Sign from the number of cycles, independently of inversion-count generation.
 array<bool,5>seen{};int cycles=0;for(int i=0;i<5;++i)if(!seen[i]){++cycles;int j=i;do{seen[j]=true;j=p[j];}while(j!=i);}
 Term t{};t.p=p;t.q1=t.q2=((5-cycles)%2?-1:1);
 for(int r=0;r<5;++r){t.edges[r]=5*r+p[r];t.q1*=power(r+1,p[r]);t.q2*=power(r+2,p[r]);}terms.push_back(t);
}
void leaf(){
 ++checked;array<bool,120>active{};int used0=0,used4=0;long long q1=0,q2=0;vector<int>F;
 for(int i=0;i<120;++i){active[i]=missing[i]==0&&red[i]==target;
 if(terms[i].p[0]==root0 && active[i]!=expected0[i])return;
 if(terms[i].p[4]==root4 && active[i]!=expected4[i])return;
 }
 ++rootok;
 for(int i=0;i<120;++i)if(active[i]){used0|=1<<terms[i].p[0];used4|=1<<terms[i].p[4];q1+=terms[i].q1;q2+=terms[i].q2;F.push_back(i);}
 for(int used:{used0,used4}){int count=0;for(int j=0;j<5;++j)count+=(used>>j)&1;if(count<3 || !(used&2) || !(used&5))return;}
 ++endpointok;if(q1!=0)return;++first;
 uint32_t support=0,reds=0;for(int e=0;e<25;++e){if(colors[e]>=0)support|=uint32_t(1)<<e;if(colors[e]==1)reds|=uint32_t(1)<<e;}
 survivors<<core<<' '<<support<<' '<<reds<<' '<<q2<<' '<<F.size();for(int i:F)survivors<<' '<<i;survivors<<'\n';if(q2==0)++second;
}
void walk(int d){
 if(d==(int)domains.size()){leaf();return;}
 int edge=domains[d].edge;
 for(int state:domains[d].states){
  colors[edge]=state;
  if(state>=0)for(int i:incident[edge]){--missing[i];red[i]+=state;}
  walk(d+1);
  if(state>=0)for(int i:incident[edge]){++missing[i];red[i]-=state;}
 }
 colors[edge]=-1;
}
int main(int argc,char**argv){
 if(argc!=5)throw runtime_error("input stats survivors percore");ifstream input(argv[1]);int n;input>>target>>n;survivors.open(argv[3]);percore.open(argv[4]);array<int,5>p{};enumerate_perms(p,0,0);
 if(terms.size()!=120)throw runtime_error("permutation count");for(int i=0;i<120;++i)for(int e:terms[i].edges)incident[e].push_back(i);
 for(int c=0;c<n;++c){input>>core>>root0>>root4;if(core!=c)throw runtime_error("core order");for(int&e:colors)input>>e;
  expected0.fill(false);expected4.fill(false);for(auto*expected:{&expected0,&expected4}){int z;input>>z;while(z--){int i;input>>i;(*expected)[i]=true;}}
  int z;input>>z;domains.clear();while(z--){Domain d;int m;input>>d.edge>>m;d.states.resize(m);for(int&s:d.states)input>>s;domains.push_back(d);}
  for(int i=0;i<120;++i){missing[i]=red[i]=0;for(int e:terms[i].edges){missing[i]+=colors[e]<0;if(colors[e]>=0)red[i]+=colors[e];}}
  long long bchecked=checked,broot=rootok,bendpoint=endpointok,bfirst=first,bsecond=second;walk(0);
  percore<<core<<' '<<(checked-bchecked)<<' '<<(rootok-broot)<<' '<<(endpointok-bendpoint)<<' '<<(first-bfirst)<<' '<<(second-bsecond)<<'\n';
 }
 if(!input)throw runtime_error("input failure");string extra;if(input>>extra)throw runtime_error("extra input");
 ofstream out(argv[2]);out<<"{\"target\":"<<target<<",\"cores\":"<<n<<",\"full_assignments\":"<<checked<<",\"root_consistent\":"<<rootok<<",\"endpoint_consistent\":"<<endpointok<<",\"Q1_zero\":"<<first<<",\"Q1_Q2_zero\":"<<second<<"}\n";
 cerr<<"Done target "<<target<<": "<<checked<<" assignments, "<<first<<" first survivors, "<<second<<" second survivors.\n";
}
