#!/usr/bin/env python3
"""Portable full replay, with all writes confined to a disposable directory."""
from pathlib import Path
from zipfile import ZipFile
import argparse,hashlib,itertools,json,math,os,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
P='remaining-fiber-obstruction-20261019'; A='joint-fiber-exhaustion-audit-20261019'; E='remaining-fiber-construction-20261019/joint_extension_audit'
def require(ok,why):
 if not ok:raise RuntimeError(why)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
def verify_tree(root):
 count=0;listed=set()
 for line in (root/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);p=root/name
  require(p.resolve().is_relative_to(root.resolve()),'Unsafe manifest path')
  require(p.is_file() and sha(p)==digest,'Integrity mismatch: '+name);count+=1;listed.add(name)
 require(listed=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS'},'Payload file-set mismatch')
 return count
def unzip(path,where):
 with ZipFile(path) as z:
  require(all((where/x.filename).resolve().is_relative_to(where.resolve()) for x in z.infolist()),'Unsafe ZIP path')
  z.extractall(where)
def canonical_witness(p):
 a=read(p);a.sort(key=lambda z:(z['support'],z['red'],z['fiber'],z['Q2']))
 return hashlib.sha256((json.dumps(a,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--integrity-only',action='store_true');parser.add_argument('--ubsan',action='store_true');parser.add_argument('--replay-prior',action='store_true');args=parser.parse_args()
 count=verify_tree(ROOT)
 if args.integrity_only:print(json.dumps({'status':'PASS','integrity_files':count},sort_keys=True));return
 compiler=shutil.which('g++');require(compiler is not None,'g++ with C++17 required')
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0');env.pop('PYTHONOPTIMIZE',None)
 expected=read(ROOT/'EXPECTED_OUTPUTS.json');pin=read(ROOT/'PROVENANCE.json')['dependency'];checks=[]
 optimized=bool(sys.flags.optimize)
 def py(script,*args,mode=None):return [sys.executable,*(['-O'] if (optimized if mode is None else mode) else []),str(script),*map(str,args)]
 with tempfile.TemporaryDirectory(prefix='pnp-complete-replay-') as td:
  work=Path(td);sources=work/'sources';shutil.copytree(ROOT,sources)
  primary=work/'primary';primary.mkdir();audit=work/'audit';audit.mkdir();extensions=work/'extensions';extensions.mkdir()
  def run(label,cmd,cwd=work):
   result=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True)
   require(result.returncode==0,label+' failed:\n'+result.stdout+'\n'+result.stderr)
   checks.append(label);return result
  def rejected(label,cmd,needle):
   result=subprocess.run(cmd,cwd=work,env=env,capture_output=True,text=True)
   require(result.returncode!=0 and needle in result.stderr,label+' did not fail at required check:\n'+result.stdout+'\n'+result.stderr)
   checks.append(label)
  def same(p,digest):require(sha(p)==digest,'Regenerated hash mismatch: '+p.name)
  def adapt(source,dest,changes):
   text=source.read_text()
   for old,new in changes:
    require(old in text,'Runtime path adapter no longer matches: '+source.name);text=text.replace(old,new)
   dest.write_text(text)
  # Exact self-contained dependency chain, including original endpoint-degree theorem.
  dep=sources/pin['file'];same(dep,pin['sha256']);unzip(dep,work)
  previous=work/'pnp-binary-endpoint-cuts-20261019';verify_tree(previous)
  nested=previous/'dependencies/endpoint-continuation-20261019.zip';same(nested,pin['nested_prior_endpoint_sha256']);unzip(nested,work)
  endpoint=work/'endpoint-continuation-20261019';verify_tree(endpoint)
  acceptance=read(sources/P/'ACCEPTED_MANIFEST.json')
  for item in acceptance['accepted_prior_dependency']:
   same(previous/'fiber-structural-reduction-20261019'/Path(item['path']).name,item['sha256'])
  for item in read(sources/A/'AUDIT_MANIFEST.json')['dependencies']:
   if item['path'].endswith('ENDPOINT_CERTIFICATE.json'):same(endpoint/'ENDPOINT_CERTIFICATE.json',item['sha256'])
  checks.append('exact-pinned-endpoint-cut-and-original-theorem-dependency-chain')
  if args.replay_prior:run('full-earlier-endpoint-cuts-and-prior-enumeration',py(previous/'reproduce.py','--replay-prior'))
  # Regenerate the whole primary pipeline from unchanged copies of the four sources.
  run('primary-complete-enumeration',py(sources/P/'verify_complete.py','--output',primary))
  run('primary-all-survivor-full-coefficient-check',py(sources/P/'check_survivors.py','--directory',primary))
  for name,digest in expected['primary_sha256'].items():same(primary/name,digest)
  checks.append('primary-all-accepted-output-bytes-match')
  # Convert final text core format to the historical audit JSON structure.
  perms=list(itertools.permutations(range(5)));masks=[sum(1<<(5*i+p[i]) for i in range(5)) for p in perms]
  for k in (1,2):
   vals=iter(map(int,(primary/f'EXTENSION_INPUT_{k}.txt').read_text().split()));target,n=next(vals),next(vals);require(target==k,'Core target mismatch');cores=[]
   for _ in range(n):
    u,r,r0,r4,nd=[next(vals) for _ in range(5)];domains=[]
    for __ in range(nd):
     edge,size=next(vals),next(vals);domains.append([edge,[next(vals) for ___ in range(size)]])
    members=[i for i,m in enumerate(masks) if m&u==m and (m&r).bit_count()==k]
    cores.append({'U':u,'R':r,'r0':r0,'r4':r4,'domains':domains,'extensions':math.prod(len(ds) for e,ds in domains),'base_fiber':members,'S0':[i for i in members if perms[i][0]==r0],'S4':[i for i in members if perms[i][4]==r4]})
   require(next(vals,None) is None,'Trailing core data');dump(primary/f'BINARY_CORES_{k}.json',cores)
  # Independent root/core coverage, using a different full-subset and affine basis algorithm.
  flags=['-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=undefined'] if args.ubsan else ['-O2']
  run('compile-independent-root-core',[compiler,'-std=c++17',*flags,str(sources/A/'regenerate_roots_and_cores.cpp'),'-o',str(audit/'regenerate')])
  generated=run('independent-root-core-regeneration',[str(audit/'regenerate'),str(audit)])
  (audit/'regenerate.log').write_text(generated.stdout+generated.stderr)
  for name,digest in expected['independent_regenerated_sha256'].items():same(audit/name,digest)
  changes=[("Path('/workspace/shared/remaining-fiber-obstruction-20261019')",'Path('+repr(str(primary))+')'),("Path('/workspace/shared/sparse-fiber-structural-next-20261019/ENDPOINT_CERTIFICATE.json')",'Path('+repr(str(endpoint/'ENDPOINT_CERTIFICATE.json'))+')')]
  adapt(sources/A/'compare_and_check.py',audit/'compare_and_check.py',changes)
  run('independent-exact-objects-and-newton-coefficients',py(audit/'compare_and_check.py'))
  report=read(audit/'COMPARISON_AND_COEFFICIENT_AUDIT.json');old=read(sources/A/'COMPARISON_AND_COEFFICIENT_AUDIT.json')
  for result in (report,old):
   for k in ('1','2'):result['targets'][k].pop('witness_sha256')
  require(report==old,'Independent audit semantic report mismatch')
  for k in (1,2):require(canonical_witness(audit/f'coefficient_witnesses_{k}.json')==expected['independent_coefficient_canonical_sha256'][str(k)],'Canonical full coefficient witness mismatch')
  checks.append('independent-canonical-full-witness-digests-match')
  # Domain witnesses and fully independent extension enumeration on BOTH core sources.
  primary_literal="Path('/workspace/shared/remaining-fiber-obstruction-20261019')"
  independent_literal="Path('/workspace/shared/joint-fiber-exhaustion-audit-20261019')"
  for name in ('prepare_and_audit_domains.py','compare_replays.py'):
   adapt(sources/E/name,extensions/name,[(primary_literal,'Path('+repr(str(primary))+')')])
  adapt(sources/E/'convert_regenerated_inputs.py',extensions/'convert_regenerated_inputs.py',[(independent_literal,'Path('+repr(str(audit))+')')])
  run('all-single-edge-pruning-witnesses',py(extensions/'prepare_and_audit_domains.py'))
  for k in (1,2):
   domain=read(extensions/f'DOMAIN_AUDIT_{k}.json');require(domain['pruned_edge_colors']==expected['pruned_edge_colors'][str(k)],'Pruning witness count mismatch')
  run('compile-independent-extension-enumerator',[compiler,'-std=c++17',*flags,str(sources/E/'independent_extensions.cpp'),'-o',str(extensions/'enumerate')])
  run('independent-core-input-conversion',py(extensions/'convert_regenerated_inputs.py'))
  for prefix in ('INDEPENDENT','REGENERATED'):
   for k in (1,2):run(f'{prefix.lower()}-complete-extension-replay-{k}',[str(extensions/'enumerate'),str(extensions/f'{prefix}_INPUT_{k}.txt'),str(extensions/f'{prefix}_STATS_{k}.json'),str(extensions/f'{prefix}_SURVIVORS_{k}.txt'),str(extensions/f'{prefix}_PER_CORE_{k}.txt')])
  run('all-full-survivor-multisets-and-symmetries',py(extensions/'compare_replays.py'))
  same(extensions/'REPLAY_COMPARISON.json',sha(sources/E/'REPLAY_COMPARISON.json'))
  if args.ubsan:
   for name in ('regenerate_cores','exhaust_extensions'):run('compile-primary-'+name+'-ubsan',[compiler,'-std=c++17',*flags,str(sources/P/(name+'.cpp')),'-o',str(work/(name+'-ubsan'))])
   for k in (1,2):
    out=work/f'SANITIZED_INPUT_{k}.txt';stats=work/f'SANITIZED_CORE_STATS_{k}.json'
    run(f'primary-core-ubsan-{k}',[str(work/'regenerate_cores-ubsan'),str(primary/f'CORE_INPUT_{k}.txt'),str(out),str(stats)])
    same(out,expected['primary_sha256'][f'EXTENSION_INPUT_{k}.txt']);same(stats,expected['primary_sha256'][f'CORE_STATS_{k}.json'])
    st=work/f'SANITIZED_STATS_{k}.json';survivors=work/f'SANITIZED_SURVIVORS_{k}.txt';candidates=work/f'SANITIZED_CANDIDATES_{k}.txt'
    run(f'primary-extensions-ubsan-{k}',[str(work/'exhaust_extensions-ubsan'),str(out),str(st),str(survivors),str(candidates)])
    for path,name in ((st,f'EXTENSION_STATS_{k}.json'),(survivors,f'EVALUATION_SURVIVORS_{k}.txt'),(candidates,f'CANDIDATES_{k}.txt')):same(path,expected['primary_sha256'][name])
  # Negative controls never touch reference data, only generated temporary outputs.
  victim=primary/'EVALUATION_SURVIVORS_1.txt';original=victim.read_text();lines=original.splitlines();fields=lines[0].split();fields[3]=str(int(fields[3])+1);lines[0]=' '.join(fields);victim.write_text('\n'.join(lines)+'\n')
  for mode in (False,True):
   label='optimized' if mode else 'normal'
   rejected('corrupt-Q2-primary-rejected-'+label,py(sources/P/'check_survivors.py','--directory',primary,mode=mode),'Q(2) disagreement or zero')
   rejected('corrupt-Q2-independent-rejected-'+label,py(audit/'compare_and_check.py',mode=mode),'Second evaluation witness failure')
  victim.write_text(original);lines=original.splitlines();fields=lines[0].split();fields[5]=str((int(fields[5])+1)%120);lines[0]=' '.join(fields);victim.write_text('\n'.join(lines)+'\n')
  for mode in (False,True):rejected('corrupt-fiber-membership-rejected-'+str(mode),py(sources/P/'check_survivors.py','--directory',primary,mode=mode),'Actual complete fiber disagrees')
  victim.write_text(original)
  corefile=primary/'BINARY_CORES_1.json';original=corefile.read_text();cores=json.loads(original);require(cores[0]['domains'],'No domain to corrupt');cores[0]['domains'][0][1].append(99);dump(corefile,cores)
  for mode in (False,True):rejected('corrupt-edge-domain-rejected-'+str(mode),py(extensions/'prepare_and_audit_domains.py',mode=mode),'domain mismatch')
  corefile.write_text(original)
  totals=[read(primary/f'EXTENSION_STATS_{k}.json') for k in (1,2)]
 print(json.dumps({'status':'PASS','integrity_files':count,'python':sys.version.split()[0],'optimized_python':optimized,'ubsan':args.ubsan,'checks':checks,'totals':totals,'independent_coefficient_canonical_sha256':expected['independent_coefficient_canonical_sha256'],'all_52094_pruning_witnesses_reconstructed':True,'prior_dependency_integrity':'Exact pinned source ZIP, nested original endpoint archive, proof/audit/certificate bytes verified','prior_full_enumeration_rerun':args.replay_prior,'numerical_solver_runs':0,'claim_boundary':'Only fixed canonical n=5 nonempty complete supported binary-cost fibers, all targets 0 through 5; no unrestricted complexity claim.'},indent=2,sort_keys=True))
if __name__=='__main__':main()
