#!/usr/bin/env python3
"""Deterministically rebuild this source-only ZIP; never writes a repository."""
from pathlib import Path
import importlib.util, json, stat, sys, zipfile
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('bundle_integrity', ROOT / 'integrity.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
manifest = m.validate(ROOT)
if len(sys.argv) != 2:
    raise SystemExit('usage: python rebuild_archive.py OUTPUT.zip')
output = Path(sys.argv[1]).resolve()
m.require(ROOT != output and ROOT not in output.parents, 'output must be outside the extracted package')
names = sorted([v['path'] for v in manifest['files']] + ['MANIFEST.json', 'SHA256SUMS'])
with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in names:
        item = zipfile.ZipInfo(manifest['package_name'] + '/' + name, (2026, 10, 19, 0, 0, 0))
        item.create_system = 3
        item.external_attr = (stat.S_IFREG | 0o644) << 16
        item.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(item, (ROOT / name).read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
raw = output.read_bytes()
print(json.dumps({'archive': output.name, 'bytes': len(raw), 'sha256': m.sha(raw)}, indent=2, sort_keys=True))
