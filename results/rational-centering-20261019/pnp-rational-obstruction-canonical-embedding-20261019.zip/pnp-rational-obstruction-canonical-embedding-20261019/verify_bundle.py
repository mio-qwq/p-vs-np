#!/usr/bin/env python3
"""Exact offline replay, normal/optimized equivalence and negative controls.
All child scripts are copied to temporary directories; frozen files are untouched.
"""
from pathlib import Path
import importlib.util, json, os, shutil, subprocess, sys, tempfile
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('bundle_integrity', ROOT / 'integrity.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
manifest = m.validate(ROOT)
config = json.loads((ROOT / 'REPLAY_CONFIG.json').read_text())
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
records = []
negative = []

def run(script, optimized=False, arguments=(), output=None, replacement=None):
    with tempfile.TemporaryDirectory(prefix='source-check-') as tmp:
        base = Path(tmp)
        target = base / Path(script).name
        text = (ROOT / script).read_text()
        if replacement is not None:
            old, new = replacement
            m.require(text.count(old) == 1, 'mutation anchor count: ' + script)
            text = text.replace(old, new)
        target.write_text(text)
        command = [sys.executable, '-I', '-B'] + (['-O'] if optimized else []) + [str(target), *arguments]
        cp = subprocess.run(command, cwd=base, env=env, capture_output=True, timeout=600)
        data = (base / output).read_bytes() if output and (base / output).is_file() else cp.stdout
        return cp, data

for task in config['positive']:
    expected = (ROOT / task['expected']).read_bytes()
    modes = []
    for optimized in (False, True):
        cp, raw = run(task['script'], optimized, task.get('arguments', []), task.get('output'))
        m.require(cp.returncode == 0 and not cp.stderr, task['name'] + ' failed: ' + cp.stderr.decode())
        m.require(raw == expected, task['name'] + ' frozen exact certificate differs')
        modes.append(raw)
    m.require(modes[0] == modes[1], task['name'] + ' normal/-O mismatch')
    records.append({'name': task['name'], 'normal': 'PASS', 'optimized': 'PASS', 'byte_identical': True,
                    'certificate': task['expected'], 'certificate_sha256': m.sha(expected)})

for task in config['negative']:
    for optimized in (False, True):
        cp, raw = run(task['script'], optimized, task.get('arguments', []), replacement=task.get('replacement'))
        last = cp.stderr.decode().strip().splitlines()[-1] if cp.stderr else ''
        m.require(cp.returncode != 0 and task['error_contains'] in last,
                  'negative control not rejected as expected: ' + task['name'] + '\n' + cp.stderr.decode())
        negative.append({'name': task['name'], 'optimized': optimized, 'exit_code': cp.returncode, 'rejected': True,
                         'last_stderr_line': last})

integrity_negative = []
for name, mode in [('alter source byte', 'alter'), ('remove source file', 'remove'), ('add unlisted source', 'extra')]:
    with tempfile.TemporaryDirectory(prefix='inventory-control-') as tmp:
        copy = Path(tmp) / 'bundle'
        shutil.copytree(ROOT, copy)
        victim = copy / config['positive'][0]['script']
        if mode == 'alter':
            victim.write_bytes(victim.read_bytes() + b'\n# deliberate integrity corruption\n')
        elif mode == 'remove':
            victim.unlink()
        else:
            (copy / 'unexpected.txt').write_text('deliberate extra source')
        try:
            m.validate(copy)
        except RuntimeError as exc:
            integrity_negative.append({'name':name, 'rejected':True, 'reason':str(exc)})
        else:
            raise RuntimeError('inventory negative control accepted: ' + name)

# Check independent reconstruction agrees with the author certificate, not only
# with its own frozen output. No source certificate is passed into audit.py.
if config['kind'] == 'pnp':
    author = json.loads((ROOT / 'primary/CERTIFICATE.json').read_text())
    audit = json.loads((ROOT / 'audit/CHECKS.json').read_text())
    m.require(author['F51_coefficients_high_to_low'] == audit['Qbranch']['F51_coefficients'], 'F51 independent coefficient mismatch')
    m.require(author['F69_coefficients_high_to_low'] == audit['Nbranch']['F69_coefficients'], 'F69 independent coefficient mismatch')
    m.require(len(author['negative_controls']) == 5 and all(x['rejected'] for x in author['negative_controls']), 'author internal negative controls')
    scientific_summary = {'author_explicit_checks':len(author['checks']), 'author_internal_negative_controls_per_mode':5,
                          'independent_sylvester_points':audit['independent_sylvester']['number_of_points'],
                          'independent_sylvester_degree_bound':audit['independent_sylvester']['degree_bound'],
                          'independent_polynomial_coefficient_lists_agree':True}
else:
    author = json.loads((ROOT / 'primary/CHECKS.json').read_text())
    prior = json.loads((ROOT / 'dependency/PRIOR_CHECKS.json').read_text())
    scientific_summary = {'author_explicit_checks':author['checks_executed'], 'prior_explicit_checks':prior['checks_executed'],
                          'new_audit_scope':'Author RESULT.md Sections 1–5 only; later routine comparison corollaries are not independently audited by that report.'}
report = {'status':'PASS', 'kind':config['kind'], 'file_integrity':'PASS', 'positive_replays':records,
          'negative_controls':negative, 'inventory_negative_controls':integrity_negative, 'scientific_summary':scientific_summary,
          'limits':'Exact algebra, finite enumeration, rejection and byte-integrity checks. Not a proof-assistant formalization, external peer review, or general P-vs-NP/Yang–Mills solution.'}
raw = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
reference = ROOT / 'EXPECTED_REPLAY.json'
if reference.exists():
    m.require(raw == reference.read_bytes(), 'bundle replay differs from frozen expected report')
sys.stdout.buffer.write(raw)
