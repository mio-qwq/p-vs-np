# Independent audit: rational-to-canonical padding

Verdict: **PASS for existence across unbounded dimensions.** This is a general embedding lemma, independent of the reflected-family rational obstruction. It does not establish whether a counterexample exists and does not claim a polynomial-size reduction.

## Precise setup

Let a supported bipartite graph have m rows with pairwise distinct rational offsets b_i and m columns with pairwise distinct nonnegative integer exponents e_j. Give its allowed edges finite additive costs c_ij. For a fixed target T, take the **entire** perfect-matching cost fiber, and its signed polynomial

    P_T(t)=sum_{pi: allowed, cost(pi)=T} sign(pi) product_i(t+b_i)^{e_pi(i)}.

For a nontrivial counterexample require the fiber to be nonempty. A selected zero subsum is not sufficient: this lemma preserves the whole cost fiber, not an arbitrarily selected group of matchings.

## Integer normalization and dimension

Choose a positive integer s clearing the denominators of every b_i-b_min. Then

    c_i=s(b_i-b_min)

are distinct nonnegative integers. Set

    N=1+max(max_i c_i, max_j e_j).

This version does not need to increase s until the offset span exceeds the largest exponent. Since there are m distinct nonnegative c_i, N is at least m. Let the canonical row offsets and column exponents both be 0,...,N-1. The old rows embed by i -> c_i and old columns by j -> e_j.

Every old matching polynomial transforms by the same total exponent D=sum_j e_j:

    product_i(t+c_i)^{e_pi(i)}
       =s^D product_i(t/s-b_min+b_i)^{e_pi(i)}.

Thus the transformed old fiber polynomial is s^D P_T(t/s-b_min), up to the fixed row/column ordering sign.

## Forced padding and full fiber preservation

There are N-m missing row offsets and N-m missing column exponents. Choose any bijection f between them and permit only the corresponding forced edge for each new row.

To express this sparse construction as a full finite cost matrix, choose L so every allowed old cost c_ij+L is nonnegative. Each old matching uses exactly m old edges, so the new target is

    T'=T+mL.

Give forced edges cost zero and every other edge, including every missing old edge and every old/new cross edge, a finite cost K strictly larger than max(T',0). All edge costs are now nonnegative. A matching containing a forbidden edge has cost at least K>T', so it cannot enter the target fiber. Every target matching therefore uses all forced edges and restricts to exactly one old target matching. Conversely every old target matching extends uniquely.

If the original costs are integral, L and K may be integral. If they are rational, they may be rational and then a common positive denominator scaling makes all costs and the target integral. For arbitrary real costs the same finite construction works over real costs, without implying an integer-cost representation.

## Polynomial and sign

Let

    F(t)=product_{new rows r}(t+r)^{f(r)}.

This is a nonzero polynomial. For the embedded permutation, the sign is epsilon*sign(pi), where epsilon is fixed by the row embedding, column embedding, and forced bijection. It is independent of pi: comparing two extended permutations cancels the fixed bijection and leaves the sign of the corresponding permutation on the old columns.

Consequently the entire canonical target fiber polynomial is exactly

    P_canonical(t)=epsilon F(t) s^D P_T(t/s-b_min).

A source identity P_T=0 therefore becomes a canonical identity. Nonempty source fibers stay nonempty. The construction also preserves the exact number of fiber matchings.

## Indexing conventions

The above uses indices 0,...,N-1 for both canonical offsets and exponents. If the required convention is offsets a_i=i for i=1,...,N and exponents e_j=j for j=1,...,N, replace every normalized old offset by c_i+1 and every old exponent by e_j+1; then fill the missing values of 1,...,N. The common exponent shift introduces the same factor product_i(t+c_i+1) in every old matching term, so zero is preserved. If only the offsets or only the exponents are one-based, use the corresponding shift alone.

## Consequence and limits

A canonical full-fiber counterexample is itself a rational-offset example. Hence existence of a rational-offset counterexample and existence of a canonical-offset/canonical-exponent counterexample are equivalent **when arbitrary enlargement of dimension is allowed and the same finite additive-cost domain is retained**.

The scale, integer span, largest exponent, and padded N can be enormous compared with bit-length input size. No efficient or polynomial-size reduction follows. Restrictions such as fixed dimension, bounded cost alphabet, or an externally prescribed graph family are not automatically preserved. Distinct offsets, distinct nonnegative integer exponents, and complete fibers are essential to the stated construction.

The companion finite test enumerates every permutation in a deliberately unsorted three-row rational example with negative rational source costs, then every permutation of its four-row canonical extension. It checks the exact full-fiber bijection, a nontrivial global sign, the full polynomial scaling identity, and the one-based convention. It does not purport to produce a zero example.
