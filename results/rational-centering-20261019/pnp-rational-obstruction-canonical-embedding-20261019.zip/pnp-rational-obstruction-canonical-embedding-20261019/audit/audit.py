import sympy as S, json, hashlib, time, sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
u,t,a,k,d,q,p,z,v=S.symbols('u t a k d q p z v')
def ck(x,name):
 if not x: raise RuntimeError(name)
 print('PASS',name,flush=True)
N=3*u**3+(4*k+2+4*a-a*a-d)*u**2+(k*k+2*k-d*(2*k-a*a))*u-d*k*k
Q=3*u**3+(2*k+4*a-2*d)*u**2+(2*k-2*d*(k+1+2*a)+1)*u-2*d*k
R2=(t*t+a*t+k)/(t-1)**2
R3=(t*t-a*t+k)/(t+1)**2
R4=t*t/(t*t-d)
ck(S.cancel((R2*R3+R2*R4+R3*R4)/(R2+R3+R4)-N.subs(u,t*t)/Q.subs(u,t*t))==0,'raw ratio identity')
# Directly derive the Q-triple coefficient constraints, with d nonzero.
k_q=3*q**3/(2*d); a_q=(-9*q-2*k_q+2*d)/4
rem=S.Poly(S.factor((Q-3*(u-q)**3).subs({k:k_q,a:a_q})),u)
ck(rem.degree()==1 and rem.TC()==0,'Q triple leaves only linear coefficient')
curve=3*(q-d)**3+d*(d-1)**2
ck(S.factor(rem.nth(1)-curve/d)==0,'Q triple curve equation')
h=1-9*z**3; dq=1/h; qq=(1-3*z*z)/h;kz=k_q.subs({q:qq,d:dq});az=a_q.subs({q:qq,d:dq})
ck(S.factor(curve.subs({q:qq,d:dq}))==0,'Q triple parametrization curve')
ck(S.factor(Q.subs({a:az,k:kz,d:dq})-3*(u-qq)**3)==0,'Q triple parametrization identity')
Nclear=S.Poly(S.cancel(16*h**5*N.subs({a:az,k:kz,d:dq})),u).as_expr()
def cubic_discriminant(f):
 aa,bb,cc,dd=S.Poly(f,u).all_coeffs()
 return S.expand(bb*bb*cc*cc-4*aa*cc**3-4*bb**3*dd-27*aa*aa*dd*dd+18*aa*bb*cc*dd)
discN=cubic_discriminant(Nclear)
ck(S.expand(discN-S.discriminant(Nclear,u))==0,'explicit cubic discriminant agrees for Nclear')
factorsN=S.factor_list(discN,z)
print('N factors',[(S.degree(f,z),m) for f,m in factorsN[1]],flush=True)
F51=[S.Poly(f,z) for f,m in factorsN[1] if S.degree(f,z)==51][0]
ck(S.degree(F51,z)==51,'F51 degree')
ck(S.expand(discN-(3*z-1)**3*(9*z**3-1)**2*F51.as_expr())==0,'complete F51 discriminant factor identity')
ck(int(F51.LC())%13 !=0,'F51 leading coefficient nonzero mod 13')
val51=[int(F51.eval(j))%13 for j in range(13)]
ck(all(val51),'F51 no roots mod 13')
ck(S.factor(Nclear.subs(z,S.Rational(1,3))) !=0,'exceptional Nclear nonzero')
q_exception={a:S.factor(az.subs(z,S.Rational(1,3))),k:S.factor(kz.subs(z,S.Rational(1,3))),d:S.factor(dq.subs(z,S.Rational(1,3)))}
ck(q_exception=={a:-2,k:1,d:S.Rational(3,2)},'Q branch rational exception collapse')
# N-triple branch, derive linear a equation by reducing C constraint with B constraint.
dv=3*v**3*k
Av=9*v**6-27*v**4-6*v**3+9*v**2-1
av=(Av*k-2-6*v**3)/(12*v**3)
P=S.cancel(144*v**6*(a*a-4*a-2-(4+9*v-3*v**3)*k).subs(a,av))
ck(S.denom(P)==1,'P denominator cleared exactly')
Ceq=S.Poly(N,u).nth(1).subs(d,dv)-9*v*v*k*k
Ceqred=S.rem(Ceq,S.Poly(a*a-4*a-2-(4+9*v-3*v**3)*k,a),a)
ck(S.factor(Ceqred-12*v**3*k*(a-av))==0,'N branch linear a derivation')
Nv=N.subs({a:av,d:dv})
# N-3(u-vk)^3 is zero modulo P after clearing denominators.
for j in range(4):
 num=S.fraction(S.cancel(S.Poly(Nv-3*(u-v*k)**3,u).nth(j)))[0]
 ck(S.rem(num,P,k)==0,'N triple reconstruction coefficient '+str(j))
Qv=S.cancel(Q.subs({a:av,d:dv}))
D=S.cancel(9*v**6*cubic_discriminant(Qv))
ck(S.denom(D)==1,'D denominator cleared exactly')
print('P degree k,v',S.degree(P,k),S.degree(P,v),'D degree',S.degree(D,k),S.degree(D,v),flush=True)
R=S.resultant(P,D,k)
facR=S.factor_list(R,v)
print('R factors',[(S.degree(f,v),m) for f,m in facR[1]],flush=True)
F69=[S.Poly(f,v) for f,m in facR[1] if S.degree(f,v)==69][0]
R_expected=314928*v**12*(v-1)**3*F69.as_expr()
ck(S.factor(R-R_expected)==0,'exact resultant identity')
# Independently verify the polynomial identity through a hand-coded integer
# Sylvester determinant at 121 points, exceeding the degree bound 120.
def idet(m):
 mat=[list(row) for row in m]; n=len(mat); prev=1; sign=1
 for j in range(n-1):
  if not mat[j][j]:
   swap=next((i for i in range(j+1,n) if mat[i][j]),None)
   if swap is None:return 0
   mat[j],mat[swap]=mat[swap],mat[j];sign=-sign
  piv=mat[j][j]
  for i in range(j+1,n):
   for ell in range(j+1,n):
    val=mat[i][ell]*piv-mat[i][j]*mat[j][ell]
    if val%prev:raise RuntimeError('nonexact Bareiss division')
    mat[i][ell]=val//prev
   mat[i][j]=0
  prev=piv
 return sign*mat[-1][-1]
pc=[S.Poly(x,v) for x in S.Poly(P,k).all_coeffs()]
dc=[S.Poly(x,v) for x in S.Poly(D,k).all_coeffs()]
degree_bound=6*max(x.degree() for x in pc)+2*max(x.degree() for x in dc)
ck(degree_bound==120 and S.degree(R_expected,v)<=120,'Sylvester determinant polynomial degree bound')
for value in range(-60,61):
 pp=[int(x.eval(value)) for x in pc];dd=[int(x.eval(value)) for x in dc]
 mat=[]
 for j in range(6):mat.append([0]*j+pp+[0]*(5-j))
 for j in range(2):mat.append([0]*j+dd+[0]*(1-j))
 if idet(mat)!=int(R_expected.subs(v,value)):
  raise RuntimeError('independent Sylvester interpolation mismatch at '+str(value))
ck(True,'121 exact integer Sylvester determinants certify entire resultant identity')
val69=[int(F69.eval(j))%5 for j in range(5)]
ck(int(F69.LC())%5 !=0 and all(val69),'F69 no roots mod 5')
g1=S.gcd(P.subs(v,1),D.subs(v,1))
ck(S.factor(g1-4*(k-1))==0,'v1 gcd exactly 4(k-1)')
ck(S.factor(av.subs({v:1,k:1}))==-2 and dv.subs({v:1,k:1})==3,'N branch rational exception collapse')
# Explicit common source collapse for all d at a=-2,k=1.
ck(S.cancel(R2.subs({a:-2,k:1}))==1 and S.cancel(R3.subs({a:-2,k:1}))==1,'both rational exceptions inactive r2 r3')
# Own-pole cancellation is automatically lost reduced degree.
ck(S.rem(N.subs(a,-k-1),u-1,u)==0 and S.rem(Q.subs(a,-k-1),u-1,u)==0,'own-pole cancellation yields common u-1')
# Enumerate all degree <=3 partitions to certify multiplicity reduction.
def partitions(n,low=1):
 if n==0:yield ()
 for j in range(low,n+1):
  for tail in partitions(n-j,j):yield (j,)+tail
allowed=[]
for n in (1,2,3):
 for ps in partitions(n):
  for ns in partitions(n):
   g=S.igcd(*ps,*ns);m=2*(len(ps)+len(ns));bound=(2*n)//int(g)>=m-1
   if bound:allowed.append([n,list(ps),list(ns)])
ck(allowed==[[3,[1,2],[3]],[3,[3],[1,2]]],'all partition candidates enumerated')
# Every nonconstant reduced r1 has exactly one triple and a double/simple cubic.
record={'all_checks_passed':True,'independent_sylvester':{'degree_bound':degree_bound,'evaluation_points':[-60,60],'number_of_points':121,'method':'custom integer Bareiss determinant; exact division checks'},'discriminants':'explicit cubic formula','sympy':S.__version__,'allowed_partitions':allowed,'Qbranch':{'N_discriminant_constant':str(factorsN[0]),'N_discriminant_factors':[[str(f),int(m)] for f,m in factorsN[1]],'F51_coefficients':[int(c) for c in F51.all_coeffs()],'mod13_values':val51,'mod13_leading':int(F51.LC())%13,'exception':{str(x):str(y) for x,y in q_exception.items()}},'Nbranch':{'A':str(Av),'P':str(S.expand(P)),'D':str(S.expand(D)),'resultant_constant':str(facR[0]),'resultant_factors':[[str(f),int(m)] for f,m in facR[1]],'F69_coefficients':[int(c) for c in F69.all_coeffs()],'mod5_values':val69,'mod5_leading':int(F69.LC())%5,'v1_gcd':str(g1)}}
(OUT/(sys.argv[1] if len(sys.argv)>1 else 'CHECKS.json')).write_text(json.dumps(record,indent=2)+'\n')
print('AUDIT PASS',flush=True)
