from itertools import permutations
from fractions import Fraction
from pathlib import Path
import json
import sympy as S
OUT=Path(__file__).resolve().parent
t=S.symbols('t')
b=[S.Integer(1),-S.Rational(1,2),S.Rational(1,2)]
e=[2,0,3];m=3;scale=2;bmin=min(b);c=[int(scale*(x-bmin)) for x in b]
allowed={(i,i) for i in range(m)}|{(i,(i+1)%m) for i in range(m)}
oldcost={ij: (-S.Rational(3,2) if ij[0]==0 else S.Integer(0)) for ij in allowed}
T=-S.Rational(3,2); L=S.Rational(3,2);Tp=T+m*L;K=max(Tp,0)+1
N=1+max(max(c),max(e))
def sign(p):return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
def require(cond,label):
 if not cond:raise RuntimeError(label)
 checks.append(label)
checks=[]
oldfiber=[p for p in permutations(range(m)) if all((i,p[i]) in allowed for i in range(m)) and sum(oldcost[i,p[i]] for i in range(m))==T]
P=sum(sign(p)*S.prod((t+b[i])**e[p[i]] for i in range(m)) for p in oldfiber)
require(len(oldfiber)==2,'source complete fiber has two matchings')
results=[]
for shift in [0,1]:
 rows=[x+shift for x in c];cols=[x+shift for x in e]
 universe=list(range(shift,N+shift));missing_rows=sorted(set(universe)-set(rows));missing_cols=sorted(set(universe)-set(cols));forced=dict(zip(missing_rows,missing_cols))
 C={(i,j):K for i in universe for j in universe}
 for i,j in allowed:C[rows[i],cols[j]]=oldcost[i,j]+L
 for i,j in forced.items():C[i,j]=0
 fiber=[p for p in permutations(universe) if sum(C[i,p[index]] for index,i in enumerate(universe))==Tp]
 extended=[];ratios=[]
 for p in oldfiber:
  lookup={rows[i]:cols[p[i]] for i in range(m)}|forced
  ep=tuple(lookup[i] for i in universe);extended.append(ep);ratios.append(sign(ep)*sign(p))
 require(set(fiber)==set(extended),'full-fiber bijection shift '+str(shift))
 require(len(set(ratios))==1 and ratios[0]==-1,'constant nontrivial sign shift '+str(shift))
 PC=sum(sign(p)*S.prod((t+i)**p[index] for index,i in enumerate(universe)) for p in fiber)
 F=S.prod((t+i)**j for i,j in forced.items())
 extra=S.prod((t+rows[i])**shift for i in range(m))
 expected=ratios[0]*F*extra*scale**sum(e)*P.subs(t,(t+shift)/scale-bmin)
 require(S.expand(PC-expected)==0,'exact canonical polynomial identity shift '+str(shift))
 results.append({'index_shift':shift,'source_row_indices':rows,'source_column_indices':cols,'forced_edges':list(forced.items()),'fiber':[list(x) for x in fiber],'sign_ratio':ratios[0],'canonical_polynomial':str(S.expand(PC))})
record={'status':'verified','checks':checks,'source_offsets':[str(x) for x in b],'source_exponents':e,'source_target':str(T),'shifted_target':str(Tp),'forbidden_cost':str(K),'N':N,'source_polynomial':str(S.expand(P)),'cases':results,'scope':'exact general embedding identity tested; not a zero counterexample'}
(OUT/'PADDING_CHECKS.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'verified','checks':checks},indent=2))
