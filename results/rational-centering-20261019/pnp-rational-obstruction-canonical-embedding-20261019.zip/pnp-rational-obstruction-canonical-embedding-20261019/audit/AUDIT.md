# Independent audit: reflected-family rational obstruction

19 October 2026. Verdict: **PASS within the stated family.** No repository, external service, PR, merge, or release was changed.

I independently reconstructed the cubic ratio, the single-cycle multiplicity reduction, both coefficient eliminations, both finite-field rational-root exclusions, and every possible denominator exception. I then reviewed `PROOF.md` and `verify_obstruction.py` in the separate source folder `/workspace/shared/rational-offset-obstruction-20261019-1406/`.

The source theorem is valid as written. In fact its algebra proves the stronger statement below. This is a scoped exact computer-assisted obstruction, not a result about general four-cycle rational offsets or P versus NP.

## 1. Independently verified statement

Let a,k,d be rational numbers with dk nonzero. Set

    N(u)=3u^3+(4k+2+4a-a^2-d)u^2
          +(k^2+2k-d(2k-a^2))u-dk^2,
    Q(u)=3u^3+(2k+4a-2d)u^2
          +(2k-2d(k+1+2a)+1)u-2dk.

Then the reduced rational function N(t^2)/Q(t^2) cannot be the ratio of the two matchings of one genuine nontrivial alternating cycle with distinct real row roots and distinct integer column exponents.

This stronger statement does not require the three source ratios themselves to have real or disjoint supports. Their genuine, disjoint source-cycle requirements imply dk nonzero, so it applies to the claimed reflected family. If d=0, r4=1 is inactive. If k=0 and d is nonzero, r2,r3,r4 all have the row root 0, contradicting disjoint source supports. Thus these omitted parameter axes do not leave a gap in the actual source theorem.

## 2. Cancellation and multiplicity audit

For a genuine cycle, its signed nonzero divisor multiplicities delta_i are the successive differences of its distinct integer exponents. If M is total positive variation and g is the gcd of absolute multiplicities, all exponents are congruent modulo g, so

    M >= exponent span >= g(m-1).

This argument needs distinct row roots (no cancellation between different cycle rows), distinct exponents (no zero difference), and a genuine nontrivial cycle. All are explicitly required.

The reduced even rational function has equal numerator/denominator degree h in u. Both raw constants are nonzero. Every remaining root must therefore be a positive real u-value; each supplies two distinct t-roots of the same multiplicity. If s is the total number of distinct reduced u-roots, m=2s and M=2h. Polynomial cancellation can be over real or complex roots: in either case it lowers h, so it cannot evade the argument.

All partitions of h=1,2,3 were enumerated independently. The bound 2h/g >= 2s-1 retains exactly

    h=3: numerator multiplicities (3), denominator multiplicities (2,1),
    h=3: numerator multiplicities (2,1), denominator multiplicities (3).

The constant case h=0 is inactive. Hence cancellation, including nonreal common factors, is impossible in a genuine first cycle. There is exactly one triple cubic and one double/simple cubic, with six first-cycle row roots. In particular the source proof has not assumed its desired repeated-root pattern.

As an extra explicit check, the own-pole source cancellation stratum a=-k-1 gives a common factor u-1 in N and Q. It is already eliminated by the degree argument, irrespective of how source-cycle sign conventions are interpreted on that stratum.

## 3. Q-cube branch and exhaustive parametrization

From Q=3(u-q)^3, coefficient comparison gives

    k=3q^3/(2d),
    a=(-9q-2k+2d)/4,
    3(q-d)^3+d(d-1)^2=0.

The remaining coefficient is exactly u times the last expression divided by d. Since d is nonzero, no solution was lost.

If w=d-q is zero, the last equation forces d=q=1, which the source parametrization covers at z=0. Otherwise define z=(d-1)/(3w). The equation gives w=3dz^2 and d-1=9dz^3. Consequently

    d(1-9z^3)=1,
    d=1/(1-9z^3),
    q=(1-3z^2)/(1-9z^3).

In particular its denominator is nonzero. This proves the parametrization is exhaustive; substituting a parametrization without this converse would not suffice.

Using the explicit cubic-discriminant formula rather than relying only on a symbolic discriminant call, I verified

    disc_u(16(1-9z^3)^5 N)
      =(3z-1)^3(9z^3-1)^2 F51(z).

The factor F51 has degree 51. Its leading coefficient is 7 modulo 13, and its evaluation residues at 0 through 12 are

    2,3,2,12,8,2,12,10,11,3,7,3,12.

For a rational root m/n in lowest terms, either 13 divides n, contradicted by the nonzero leading coefficient in the homogenized equation, or n is invertible and reduction produces a forbidden finite root. Thus F51 has no rational root; no irreducibility assumption is required.

The only allowable rational zero of the discriminant is z=1/3. It gives (a,k,d)=(-2,1,3/2), for which

    N=3(u-1)^2(u-1/2), Q=3(u-1)^3,
    r1=(u-1/2)/(u-1), r2=r3=1.

The reduced degree is one, so it is excluded even by the stronger theorem without source admissibility. The denominator-zero factor 9z^3-1 cannot be used: the exhaustive derivation proved 1-9z^3 nonzero.

## 4. N-cube branch, denominators, and resultant

From N=3(u-p)^3, p is rational and nonzero. Also k is nonzero. Set v=p/k, so v is rational and nonzero. Direct coefficient elimination gives

    d=3v^3 k,
    A(v)=9v^6-27v^4-6v^3+9v^2-1,
    a=(A(v)k-2-6v^3)/(12v^3).

There are no additional excluded denominators. I independently reduced the C coefficient equation by the B coefficient equation and obtained exactly 12v^3 k(a-a(v,k)). Conversely, reconstructing all four coefficients of N-3(u-vk)^3 gives zero modulo the remaining equation P.

With the above substitution, define

    P=144v^6[a^2-4a-2-(4+9v-3v^3)k],
    D=9v^6 disc_u(Q).

Both are integer polynomials, of k-degrees two and six. Since v is nonzero, clearing those denominators neither discards solutions nor turns a necessary repeated-root condition into something weaker. The independently reproduced exact identity is

    Res_k(P,D)=314928 v^12(v-1)^3 F69(v).

I additionally certify this identity using a separate implementation of the 8-by-8 Sylvester determinant. Its degree in v is bounded by 6*12+2*24=120. A hand-coded integer Bareiss determinant, with an explicit exact-division check at every step, agrees with the displayed right side at all 121 distinct integers from -60 through 60. This proves the entire polynomial identity by the degree bound, rather than merely spot-checking it or accepting a symbolic resultant call.

F69 has leading coefficient 3 modulo 5 and the nonzero evaluation residues

    4,1,3,1,3.

The same rational-root argument excludes all rational roots of F69. Since v is nonzero, any rational solution must have v=1. At v=1, direct polynomial gcd over Q gives 4(k-1), hence k=1. This check also handles possible leading-coefficient degeneration in the elimination inputs. A common finite k-root always makes the Sylvester determinant vanish, even when a leading coefficient vanishes; the resultant is used only as a necessary condition.

Then a=-2,d=3 and

    N=3(u-1)^3, Q=3(u-1)^2(u-2),
    r1=(u-1)/(u-2), r2=r3=1.

Again the reduced degree is one, so it cannot realize the first cycle. Both branches are exhausted.

## 5. Rational offsets and affine normalization

For the actual admissible source family, rational row roots force a,k rational through the quadratic roots and d rational through the r4 poles. The coefficient obstruction therefore excludes all-rational roots, including integer and consecutive-integer roots.

The source support contains the three distinct anchors -1,0,1. If s=lambda*t+mu takes every row root to a rational number, its value at 0 gives rational mu and its value at 1 then gives rational lambda. Since lambda is nonzero, every original root would be rational as well. The affine corollary is therefore sound.

This does not rule out asymmetric source families, different source multiplicities, interacting cycles, or arbitrary four-cycle constructions. Those limits in the source proof are important and accurate.

## 6. Reproduction and certificate boundaries

Run:

    python audit.py
    python -O audit.py CHECKS_OPTIMIZED.json

The verifier uses explicit RuntimeError checks and retains them in optimized Python. It reconstructs all polynomials locally, records the full coefficient lists, and does not read the source certificate as input. The source certificate is only compared afterward.

Computer algebra and the exact integer computations are trusted execution components. The proof is not formalized in a proof assistant and is not external peer review. The strengthened theorem in Section 1 is independently justified here; adopting it in a repository would still be a separate publication step.
