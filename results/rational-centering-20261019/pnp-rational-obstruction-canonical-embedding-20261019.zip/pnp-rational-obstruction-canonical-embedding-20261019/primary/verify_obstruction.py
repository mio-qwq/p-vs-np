#!/usr/bin/env python3
"""Exact verifier for the rational reflected-family obstruction.
No numerical premises; explicit checks survive python -O.
"""
from pathlib import Path
import json, sys, platform
import sympy as S

OUT = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('CERTIFICATE.json')
checks=[]
def require(condition, label):
    if not condition:
        raise RuntimeError('FAILED: '+label)
    checks.append(label)
def zero(expr,label): require(S.cancel(expr)==0,label)
def same_poly(lhs,rhs,label): zero(S.expand(lhs-rhs),label)
def ZZpoly(expr,*symbols):
    num,den=S.cancel(expr).as_numer_denom()
    require(den==1,'integer polynomial denominator: '+str(symbols))
    return S.Poly(num,*symbols,domain=S.ZZ)
def rational_root_free(poly, prime):
    require(S.isprime(prime),'prime modulus '+str(prime))
    lc=int(poly.LC())%prime
    vals=[int(poly.eval(i))%prime for i in range(prime)]
    require(lc!=0,'nonzero projective leading coefficient mod '+str(prime))
    require(all(vals),'no finite root mod '+str(prime))
    return {'prime':prime,'leading_coefficient_residue':lc,'values_at_0_through_p_minus_1':vals}

t,u,a,k,d,q,z,p,v=S.symbols('t u a k d q z p v')
r2=(t*t+a*t+k)/(t-1)**2
r3=(t*t-a*t+k)/(t+1)**2
r4=t*t/(t*t-d)
common=(t-1)**2*(t+1)**2*(t*t-d)
B=4*k+2+4*a-a*a-d
C=k*k+2*k-d*(2*k-a*a)
E=-d*k*k
N=3*u**3+B*u*u+C*u+E
Q=3*u**3+(2*k+4*a-2*d)*u*u+(2*k-2*d*(k+1+2*a)+1)*u-2*d*k
zero((r2+r3+r4)*common-Q.subs(u,t*t),'independent denominator cubic expansion')
zero((r2*r3+r2*r4+r3*r4)*common-N.subs(u,t*t),'independent numerator cubic expansion')

# Exhaust all multiplicity partitions for h<=3. Reduced numerator and denominator
# have disjoint roots, and every u-root gives two t-root divisor points.
def partitions(n, lower=1):
    if n==0:
        yield ()
    for first in range(lower,n+1):
        for rest in partitions(n-first,first):
            yield (first,)+rest
from math import gcd
from functools import reduce
possibilities=[]
for h in (1,2,3):
    for plus in partitions(h):
        for minus in partitions(h):
            g=reduce(gcd,plus+minus)
            points=2*(len(plus)+len(minus))
            passed=2*h//g>=points-1
            possibilities.append({'h':h,'plus':plus,'minus':minus,'g':g,'m':points,'passes_bound':passed})
passed=[(r['h'],r['plus'],r['minus']) for r in possibilities if r['passes_bound']]
require(set(passed)=={(3,(3,),(1,2)),(3,(1,2),(3,))},'only cube/double-simple branches pass cycle bound')
# Both surviving divisor patterns really can realize one six-row cycle.
steps=[1,1,2,2,-3,-3]; exponents=[0,1,2,4,6,3]
require([exponents[(i+1)%6]-exponents[i] for i in range(6)]==steps,'surviving six-row divisor is realizable')
require(len(set(exponents))==6,'six distinct cycle exponents')

# Q-cube coefficient equations and exhaustive rational parametrization.
kq=3*q**3/(2*d); aq=(-9*q-2*kq+2*d)/4
residual=3*(q-d)**3+d*(d-1)**2
Qsub=S.cancel(Q.subs({k:kq,a:aq}, simultaneous=True))
zero(S.expand(Qsub-3*(u-q)**3)-u*residual/d,'exhaustive Q-cube residual equation')
# Singular point of the rational parametrization is explicitly covered at z=0.
require(S.factor(residual.subs(q,d))==d*(d-1)**2,'d=q exceptional case')
h0=1-9*z**3
dz=1/h0; qz=(1-3*z*z)/h0; kz=3*qz**3/(2*dz); az=(-9*qz-2*kz+2*dz)/4
zero(residual.subs({d:dz,q:qz}),'Q-cube parametrization lies on cubic relation')
zero(((d-1)/(3*(d-q))).subs({d:dz,q:qz})-z,'rational inverse parameter identity')
zero(Q.subs({d:dz,k:kz,a:az}, simultaneous=True)-3*(u-qz)**3,'Q cube after parameterization')
Nz=S.cancel(N.subs({d:dz,k:kz,a:az}, simultaneous=True))
Nclear=ZZpoly(16*h0**5*Nz,u,z).as_expr()
disc=S.discriminant(Nclear,u)
F51=ZZpoly(S.cancel(disc/((3*z-1)**3*(9*z**3-1)**2)),z)
require(F51.degree()==51,'degree-51 obstruction polynomial')
require(F51.LC()==2024476440885924144048,'degree-51 leading coefficient')
same_poly(disc,(3*z-1)**3*(9*z**3-1)**2*F51.as_expr(),'exact Q-branch discriminant identity')
mod13=rational_root_free(F51,13)
qdeg={a:S.Integer(-2),k:S.Integer(1),d:S.Rational(3,2)}
require([S.cancel(expr.subs(z,S.Rational(1,3))) for expr in (az,kz,dz,qz)]==[-2,1,S.Rational(3,2),1],'sole rational Q-branch parameter degeneration')
zero(r2.subs(qdeg)-1,'Q branch source r2 collapses')
zero(r3.subs(qdeg)-1,'Q branch source r3 collapses')
same_poly(N.subs(qdeg),3*(u-1)**2*(u-S.Rational(1,2)),'Q branch numerator degeneration')

# N-cube branch, independently derive its remaining equation and resultant.
Av=9*v**6-27*v**4-6*v**3+9*v*v-1
dv=3*v**3*k
av=(Av*k-2-6*v**3)/(12*v**3)
pv=v*k
subv={a:av,d:dv}
zero(E.subs(subv)+3*pv**3,'N-cube constant equation')
zero((C+d*B).subs(subv)-(9*pv**2-9*dv*pv),'N-cube eliminated coefficient equation')
P=ZZpoly(144*v**6*(av*av-4*av-2-(4+9*v-3*v**3)*k),k,v).as_expr()
zero((B.subs(subv)+9*pv)+P/(144*v**6),'N-cube remaining coefficient equation')
Qv=S.cancel(Q.subs(subv))
Dv=ZZpoly(9*v**6*S.discriminant(Qv,u),k,v).as_expr()
require(S.degree(P,k)==2 and S.degree(Dv,k)==6,'resultant input degrees')
resultant=S.resultant(P,Dv,k)
F69=ZZpoly(S.cancel(resultant/(314928*v**12*(v-1)**3)),v)
require(F69.degree()==69,'degree-69 obstruction polynomial')
require(F69.LC()==15910197221763,'degree-69 leading coefficient')
same_poly(resultant,314928*v**12*(v-1)**3*F69.as_expr(),'exact N-branch resultant identity')
mod5=rational_root_free(F69,5)
require(mod5['values_at_0_through_p_minus_1']==[4,1,3,1,3],'displayed mod-5 certificate')
same_poly(P.subs(v,1),32*(k-1)*(8*k-5),'v=1 residual equation')
gcd1=S.Poly(S.gcd(P.subs(v,1),Dv.subs(v,1)),k).monic()
require(gcd1.as_expr()==k-1,'v=1 common-root elimination')
ndeg={a:S.Integer(-2),k:S.Integer(1),d:S.Integer(3)}
require(S.cancel(av.subs({v:1,k:1}))==-2,'N branch a degeneration')
zero(r2.subs(ndeg)-1,'N branch source r2 collapses')
zero(r3.subs(ndeg)-1,'N branch source r3 collapses')
same_poly(N.subs(ndeg),3*(u-1)**3,'N branch numerator degeneration')
same_poly(Q.subs(ndeg),3*(u-2)*(u-1)**2,'N branch denominator degeneration')

# Mutation/negative-control checks use independent rejection predicates.
negative=[]
def rejected(label,predicate):
    require(not predicate,'negative control: '+label)
    negative.append({'mutation':label,'rejected':True})
rejected('alter resultant constant',S.expand(resultant-314929*v**12*(v-1)**3*F69.as_expr())==0)
bad51=S.Poly(F51.as_expr()*(z-2),z)
rejected('introduce rational root 2 into F51',all(int(bad51.eval(i))%13 for i in range(13)))
bad69=S.Poly(F69.as_expr()-F69.eval(0),v)
rejected('introduce rational root 0 into F69',all(int(bad69.eval(i))%5 for i in range(5)))
rejected('accept h=2 square/square cycle ignoring gcd',4//2>=4-1)
rejected('accept collapsed source cycle as nonconstant',S.cancel(r2.subs(qdeg))!=1)

certificate={
 'status':'verified', 'theorem_scope':'reflected quadratic source family only; not general rational-offset or canonical-offset noncancellation',
 'python':platform.python_version(),'sympy':S.__version__,
 'checks':checks,'cycle_bound_cases':possibilities,
 'F51_coefficients_high_to_low':[int(x) for x in F51.all_coeffs()],
 'F51_rational_root_exclusion':mod13,
 'F69_coefficients_high_to_low':[int(x) for x in F69.all_coeffs()],
 'F69_rational_root_exclusion':mod5,
 'resultant_constant':314928,
 'rational_branch_degenerations':{'Q_cube':{'z':'1/3','a':'-2','k':'1','d':'3/2'},'N_cube':{'v':'1','a':'-2','k':'1','d':'3'}},
 'negative_controls':negative,
}
OUT.write_text(json.dumps(certificate,indent=2)+'\n')
print(json.dumps({'status':'verified','checks':len(checks),'output':str(OUT),'mod13':mod13,'mod5':mod5,'negative_controls':len(negative)},indent=2))
