# Tested dead ends and exact recovery conditions

## Closed within the reflected family

1. **Rationally approximate the existing algebraic parameter.** Exact Q-cube closure and a repeated numerator force a rational parameter to z=1/3. At that point both source quadratics equal their denominators. Small numerical residuals elsewhere are not exact identities. Recovery requires changing the source family or another stated hypothesis.

2. **Move to the unexamined numerator-cube branch.** The exact resultant has only the rational candidate v=1 after excluding v=0. Its common-root condition forces k=1,a=-2,d=3 and collapses the source cycles. Recovery again requires a different source family, not merely the dual cube branch.

3. **Use generic fully split numerator and denominator cubics.** Twelve divisor points of positive total multiplicity six violate the cycle span bound. Even eight divisor points violate it. Recovery would need different degree/multiplicity structure, or a different construction that is actually one cycle.

4. **Cancel shared factors to obtain a smaller ratio.** Reduced u-degree one violates the span bound directly. Degree two forces two squared linear factors; their divisor-multiplicity gcd is two, so the sharpened bound still excludes a genuine cycle. Degree zero is inactive. These are exact exhaustion checks, not bounded root searches.

5. **Use larger exponents in the first cycle.** Adding a common constant to its exponents does not change the ratio. The divisor multiplicities already determine total positive variation and their gcd, so increasing a baseline cannot evade the necessary bound.

6. **Clear the real example's irrationality by translation or scaling.** The actual source rows include -1,0,1. An affine transformation making every row rational would have rational scale and shift, forcing the original rows rational. The theorem excludes this across the entire admissible reflected family.

## Branch not used as a premise

An exploratory idea was to use the curve y²=1-9z³ arising if d is a rational square. No rank claim or rational-point classification for that elliptic curve was established or used. The finite-field polynomial certificates above completely replace this possible detour and are stronger for the stated family.

## What can legitimately reopen the search

- Break the reflected source relation r3(t)=r2(-t).
- Change the source divisor patterns or source polynomial degrees.
- Use other cycle configurations or interacting alternating cycles.
- Find an exact error in the cubic identities, necessary cycle bound, exhaustive parametrization, resultant, or finite-field tables.

Do not promote a numerical candidate. A recoverable candidate must preserve exact rational coefficients/row roots, actual cycle exponent sequences, full supported graph, actual complete cost fiber, and exact polynomial coefficients. A rational-offset counterexample in another family would already embed in the canonical model by CANONICAL_EMBEDDING.md; forced-edge padding alone cannot manufacture rationality from the current algebraic example.
