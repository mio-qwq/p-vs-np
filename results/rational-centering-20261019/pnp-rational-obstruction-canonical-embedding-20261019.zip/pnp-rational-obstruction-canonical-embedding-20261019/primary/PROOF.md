# Rational-offset obstruction for the reflected quadratic four-cycle family

19 October 2026. This is a new, scoped nonexistence theorem. All work was local; no repository, PR, merge, release, or external service was changed. It does not settle arbitrary rational-offset four-cycle configurations or the canonical offsets a_i=i.

## 1. Result and exact scope

Consider the three-parameter reflected family

    r2(t) = (t²+a t+k)/(t−1)²,
    r3(t) = (t²−a t+k)/(t+1)²,
    r4(t) = t²/(t²−d).

Require these to be genuine three-row matching-flip ratios on pairwise disjoint real row-root supports: each displayed zero/pole is present with its displayed nonzero multiplicity, the two zeros of each quadratic are real and distinct, d>0, and no root is shared between cycles. These requirements imply d k != 0. Define

    r1 = (r2 r3+r2 r4+r3 r4)/(r2+r3+r4).

The denominator is not identically zero, since all three source ratios tend to 1 at infinity. The complete six-term cost-two fiber with local signs (−1,+1,+1,+1) vanishes exactly when this relation holds.

**Theorem.** If r1 is also the ratio of the two matchings on one genuine alternating cycle with distinct real row roots and distinct integer column exponents, then the three coefficients a,k,d cannot all be rational.

**Corollary.** No instance in this reflected family can have all rational row offsets. In particular, it has no all-integer or consecutive-integer row-offset realization. Nor can an affine change of variable turn an admissible real instance in this family into such an instance.

The theorem allows arbitrarily large initially proposed first-cycle size and exponents. The proof itself forces that first cycle to have exactly six rows. It does not assume the repeated-numerator pattern used in the previously constructed example.

## 2. The exact cubic pair

Put u=t². A common-denominator calculation yields

    r1(t)=N(u)/Q(u),

where

    N(u)=3u³+B u²+C u+E,
    B=4k+2+4a−a²−d,
    C=k²+2k−d(2k−a²),
    E=−dk²,

and

    Q(u)=3u³+(2k+4a−2d)u²
          +[2k−2d(k+1+2a)+1]u−2dk.

In particular, N(0) and Q(0) are nonzero and the quotient tends to 1 at infinity.

## 3. Why there are only two branches, even allowing cancellations

For a genuine m-row cycle, write its nonzero exponent differences as delta_i. Their sum is zero. Let M be their total positive sum and g=gcd(|delta_i|). The cycle's distinct column exponents are all congruent modulo g, so their span is at least g(m−1). The total positive variation is at least that span. Therefore

    M/g >= m−1.                                      (1)

The absence of zero differences follows from distinct column exponents and a genuine nontrivial cycle.

Cancel the polynomial gcd of N and Q in R[u], and let h be the common degree of the reduced numerator and denominator; 0<=h<=3. Degree zero gives r1=1, which cannot be a genuine cycle on distinct row roots and exponents.

For h>=1, all roots of both reduced polynomials must be positive real u-values: every zero/pole of a matching ratio is real in t, and u=0 is excluded by N(0)Q(0)!=0. Each distinct u-value gives the two distinct real row roots ±sqrt(u), with equal multiplicity. If there are s distinct u-values across numerator and denominator, then

    m=2s,   M=2h,   2h/g >= 2s−1.                   (2)

There is at least one u-value on each side, so s>=2.

- h=1: (2) fails already with g=1 and s=2.
- h=2: (2) forces s=2. Each polynomial must then be a square of one linear factor, so g=2; (2) fails again.
- h=3: (2) forces s<=3. If s=2, both sides are cubes, g=3, and (2) fails. Thus s=3. One cubic has one distinct root and hence is a cube; the other has exactly two distinct roots and hence a double and a simple root.

Consequently h=3, so **no cancellation occurred**; r1 has exactly six row roots, and there are precisely two possibilities:

    Q=3(u−q)³, with discriminant(N)=0;               (Q-cube)
    N=3(u−p)³, with discriminant(Q)=0.               (N-cube)

This establishes the completeness of the subsequent algebraic split. It also explains why trying generic split cubics, or cancelling a common factor to lower their degrees, cannot recover a genuine first cycle.

## 4. Q-cube branch: exhaustive parametrization and exclusion

Assume a,k,d are rational. A cube Q has rational q. Comparing its three coefficients gives

    k=3q³/(2d),
    a=(−9q−2k+2d)/4,
    3(q−d)³+d(d−1)²=0.                              (3)

If d=q, (3) and d!=0 give d=q=1, represented below by z=0. Otherwise define the rational number

    z=(d−1)/(3(d−q)).

Equation (3) gives z²=(d−q)/(3d) and z³=(d−1)/(9d). Thus every rational Q-cube solution with d!=0 belongs to

    h0=1−9z³,
    d=1/h0,
    q=(1−3z²)/h0,
    k=3q³/(2d),
    a=(−9q−2k+2d)/4.                               (4)

The denominator h0 is nonzero. This is an exhaustive derivation, not an assumption that an arbitrary triple-root solution lies on the earlier one-parameter family.

Let Nhat=16 h0^5 N, which is an integer polynomial in u,z. Exact arithmetic gives

    disc_u(Nhat)=(3z−1)³(9z³−1)² F51(z),            (5)

where F51 is an integer polynomial of degree 51. Its leading coefficient is

    2024476440885924144048.

The full coefficient list is in CERTIFICATE.json and is regenerated from the compact definition (5).

F51 has no rational root. A particularly small certificate avoids any irreducibility assumption: its leading coefficient is 7 modulo 13 and F51 has no root in F13. The verifier records all thirteen nonzero evaluation residues. If z=m/n in lowest terms were a rational root, reduction of the homogenized polynomial modulo 13 would contradict either the nonzero leading coefficient (13|n) or this root table (13 does not divide n).

Since a repeated root of N forces (5) to vanish, and h0!=0, the only rational possibility is z=1/3. Substitution gives

    a=−2, k=1, d=3/2, q=1,
    N=3(u−1)²(u−1/2).

But r2=r3=1, because their numerators equal their denominators. The source cycles collapse, violating admissibility. Hence there is no admissible rational-coefficient Q-cube solution.

## 5. N-cube branch: a separate exact elimination

This branch was not needed for the old real example and must not be omitted from the exclusion theorem.

Suppose N=3(u−p)³. Then p is rational, p!=0, and dk²=3p³. Put v=p/k; thus v is rational and nonzero. Comparing coefficients, including the combination C+dB, gives

    d=3v³ k,
    A(v)=9v^6−27v^4−6v³+9v²−1,
    a=[A(v)k−2−6v³]/(12v³).                        (6)

The remaining coefficient equation is P(v,k)=0, where

    P=144v^6 [a²−4a−2−(4+9v−3v³)k].               (7)

After (6), this expression is an integer polynomial, quadratic in k. Define

    D(v,k)=9v^6 disc_u(Q),                          (8)

again substituting (6). This is an integer polynomial of degree six in k. Repeated roots of Q require D=0.

The exact resultant is

    Res_k(P,D)=314928 v^12(v−1)³ F69(v).            (9)

Here F69 is an integer polynomial of degree 69 with leading coefficient

    15910197221763.

The coefficient list is in CERTIFICATE.json; the verifier regenerates both sides of (9). This is a necessary-condition elimination only; no sufficiency of a resultant root is assumed.

F69 has no rational root. Its leading coefficient is 3 modulo 5, and its values at 0,1,2,3,4 modulo 5 are respectively

    4, 1, 3, 1, 3.

The same homogenized rational-root argument used above proves the assertion. Since v!=0, (9) forces v=1. At v=1,

    P(1,k)=32(k−1)(8k−5),
    gcd_k(P(1,k),D(1,k))=k−1

up to a nonzero rational constant. Thus k=1. Equation (6) then yields

    a=−2, d=3, p=1,
    N=3(u−1)³,
    Q=3(u−2)(u−1)².

Again r2=r3=1, violating the genuine source-cycle requirements. This excludes the N-cube branch and proves the theorem.

## 6. Rational offsets and affine changes

If every row root in the displayed normalized family is rational, the two roots of t²+a t+k make a and k rational, and the poles of r4 make d rational. The theorem excludes this.

For an affine change s=lambda t+mu, lambda!=0, the source support contains the distinct anchors −1,0,1. If all transformed row roots were rational, mu and lambda would both be rational. Inverting the affine map would make every original row root rational, which is impossible by the preceding argument. This includes translations making offsets positive and common-denominator scalings attempting to make them integral.

The existing exact real counterexample is admissible in this family, so irrationality is structurally necessary within this family. The obstruction does not merely say that the particular degree-51 parameter chosen earlier is irrational.

## 7. Boundaries and recovery conditions

The following remain open here:

- Arbitrary rational or integer row offsets for other mixed four-cycle constructions.
- The original consecutive row offsets a_i=i.
- Asymmetric quadratic sources, higher-degree source ratios, other divisor multiplicity patterns on the source cycles, or interacting cycle supports.

Promising changes must leave at least one hypothesis used above. Merely changing z within the Q-cube family, moving to the N-cube branch, choosing larger first-cycle exponents, using common-factor cancellation, or making an affine row-coordinate change cannot succeed under these hypotheses.

A numerical rational search or near-cancellation cannot refute this theorem. A potential counterexample must supply exact rational a,k,d, full real disjoint source supports, a genuine distinct-exponent first cycle, and the exact six-term identity. Retain it and suspend the theorem if it violates the exact verified cubic formulas, the span/gcd bound, the exhaustive Q-cube parametrization, either discriminant/resultant identity, or either finite-field rational-root certificate.

The proof is computer-assisted exact algebra, not proof-assistant formalization or external peer review.
