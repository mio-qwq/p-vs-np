#!/usr/bin/env python3
from pathlib import Path
from itertools import permutations
from math import lcm
import json, sys
import sympy as S

t=S.symbols('t')
def require(ok,label):
    if not ok: raise RuntimeError('FAILED: '+label)
def sign(p):return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
def verify(b,es,cost,target):
    n=len(b);lo=min(b);scale=lcm(*(int(x.q) for x in b))
    cs=[int(scale*(x-lo)) for x in b];M=max(max(cs),max(es));N=M+1
    require(set(cs)<=set(range(N)) and max(es)<=M,'canonical containment')
    B=max(0,-min(min(row) for row in cost));tau=target+n*B;K=tau+1
    require(tau>=0,'nonempty target nonnegative after shift')
    new=[[K]*N for _ in range(N)]
    for i in range(n):
        for j in range(n):new[cs[i]][es[j]]=cost[i][j]+B
    forced=dict(zip(sorted(set(range(N))-set(cs)),sorted(set(range(N))-set(es))))
    for row,col in forced.items():new[row][col]=0
    old=[p for p in permutations(range(n)) if sum(cost[i][p[i]] for i in range(n))==target]
    require(bool(old),'original fiber nonempty')
    # This enumerates the full cost fiber, safely pruning because all costs >=0.
    fiber=[]
    def visit(i,used,p,running):
        if i==N:
            if running==tau:fiber.append(tuple(p))
            return
        for col in range(N):
            price=new[i][col]
            if col not in used and running+price<=tau:
                visit(i+1,used|{col},p+[col],running+price)
    visit(0,set(),[],0)
    def extend(p):
        out=[None]*N
        for row,col in forced.items():out[row]=col
        for i in range(n):out[cs[i]]=es[p[i]]
        return tuple(out)
    require(set(fiber)=={extend(p) for p in old},'exact complete fiber retained')
    sigmas={sign(extend(p))*sign(p) for p in old};require(len(sigmas)==1,'constant embedding sign')
    sigma=sigmas.pop();D=sum(es)
    F=sum(sign(p)*S.prod((t+b[i])**es[p[i]] for i in range(n)) for p in old)
    G=sum(sign(p)*S.prod((t+i)**p[i] for i in range(N)) for p in fiber)
    H=S.prod((t+row)**col for row,col in forced.items())
    require(S.expand(G-sigma*H*scale**D*F.subs(t,t/scale-lo))==0,'exact canonical embedding polynomial identity')
    require(sorted(es+list(forced.values()))==list(range(N)),'exact consecutive exponent set')
    G1=sum(sign(p)*S.prod((t+i+1)**(p[i]+1) for i in range(N)) for p in fiber)
    require(S.expand(G1-S.prod(t+i+1 for i in range(N))*G.subs(t,t+1))==0,'one-based canonical conversion')
    return {'n':n,'N':N,'scale':scale,'original_offsets':list(map(str,b)),'original_exponents':es,'old_target':target,'new_target':tau,'forbidden_cost':K,'fiber_size':len(fiber),'embedding_sign':sigma,'forced_count':len(forced)}
b=list(map(S.Rational,['-1/2','0','1']))
cost=[[0,1,2],[1,0,1],[2,1,0]]
results=[verify(b,[0,1,2],cost,2),verify(b,[5,0,9],[[x-2 for x in row] for row in cost],-4)]
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('EMBEDDING_CHECK.json')
output.write_text(json.dumps({'status':'verified','examples':results},indent=2)+'\n')
print(json.dumps({'status':'verified','output':str(output),'examples':results},indent=2))
