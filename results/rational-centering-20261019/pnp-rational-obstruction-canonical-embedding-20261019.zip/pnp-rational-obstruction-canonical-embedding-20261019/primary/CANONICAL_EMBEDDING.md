# Rational offsets can be embedded in the canonical model

19 October 2026. This is an existence-preserving padding lemma, not a counterexample or a polynomial-time reduction claim.

## Statement

Suppose a nonempty complete additive-cost fiber satisfies an exact zero identity

    F_b(t)=sum_(pi in fiber) sgn(pi) product_i (t+b_i)^(e_pi(i))=0,

where the b_i are distinct rational offsets and the e_j are distinct nonnegative integers. Then a larger instance has offsets exactly 0,1,...,N−1, exponents exactly 0,1,...,N−1, and a nonempty complete fiber whose signed polynomial is also zero.

If the original allowed support consists of disjoint cycles and forced edges, the new allowed support has exactly the same cycles, with additional forced edges. The optional dense finite-cost completion below also has high-cost edges outside this allowed support, but none can enter the target fiber. If the original edge costs and target are integers, the new costs and target can also be nonnegative integers.

Consequently, in unbounded dimension, the existence of a rational-offset counterexample is equivalent to the existence of a fully canonical counterexample. The reverse implication is immediate. This does not settle whether either exists.

## Proof

A one-row instance has only one term and cannot be zero, so take at least two original rows. Put b_min=min_i b_i. Choose a positive integer s clearing the finite rational denominators, so that

    c_i=s(b_i−b_min) are all nonnegative integers.

Set M=max(max_i c_i, max_j e_j) and N=M+1. The c_i are distinct elements of {0,...,M}, and the original exponents also form a subset of this set. Let D=sum_j e_j. For every matching,

    product_i (t+c_i)^(e_pi(i))
      =s^D product_i (t/s−b_min+b_i)^(e_pi(i)).

The scalar s^D and affine substitution are common to every term. Therefore the original fiber polynomial, after the row transformation, is

    F_c(t)=s^D F_b(t/s−b_min)=0.

Add one new row for every missing offset in {0,...,M}. There are exactly N−n such rows and exactly N−n missing exponents. Choose any fixed bijection between them, and give each new row its one allowed, forced edge to that exponent's column. This completes both sets to the canonical sets.

The new fiber's matching terms acquire the same nonzero forced-edge polynomial H(t). Their signs acquire a single constant sign sigma independent of pi: compare with the extension of one fixed original matching; changing pi permutes only the original columns and has the same sign as the original permutation change. Thus the new fiber polynomial is

    sigma H(t) s^D F_b(t/s−b_min)=0.

To realize this as a full finite cost matrix, first add a common constant B to every original allowed-edge cost so that all become nonnegative. This changes every original matching cost by nB, hence changes the target from tau to tau'=tau+nB and leaves the complete fiber unchanged. Its nonemptiness implies tau'>=0. Give all forced edges cost 0 and all other, forbidden edges a cost K>tau'. A target-tau' permutation cannot use a forbidden edge, since all costs are nonnegative. Therefore the complete new fiber consists exactly of the old fiber extended by the forced edges. When old costs are integers, choose integral B and K; tau' is then an integer as well.

If the canonical convention is one-based, convert the completed instance by adding 1 to every offset and every exponent. Its polynomial becomes the zero-based polynomial evaluated at t+1, multiplied by the fixed nonzero factor product_(i=0)^(N−1)(t+i+1). Thus the same existence equivalence holds for either indexing convention.

## Interpretation and limitations

This closes a tempting distinction between arbitrary rational rows and consecutive integer rows: in an unbounded existence question, a rational counterexample would already imply a consecutive-row counterexample after padding. The required dimension can be very large because rational denominators and offset spans can be large. No polynomial bound in the original bit length is asserted.

This lemma does not apply to the algebraic irrational real example. The reflected-family obstruction in PROOF.md explains why that family cannot supply the rational premise.

The verifier verify_embedding.py checks both ordinary and negative original costs, exact affine/product/sign identities, globally consecutive exponents, retained complete-fiber enumeration, and a case in which the original exponents extend beyond the integer-normalized offset span. These finite examples check the implementation; the general proof above does not depend on a bounded search.
