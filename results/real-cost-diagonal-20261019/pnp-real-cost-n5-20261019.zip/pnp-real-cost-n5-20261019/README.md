# Canonical five-row real-cost noncancellation

This frozen, local source package contains a finite exact result:

For every bipartite support graph on five labelled rows and columns, every
nonempty complete fiber of an arbitrary real additive edge cost has nonzero
polynomial sum `sum_p sign(p) product_i (L+i)^p(i)`.

The offsets and exponents are exactly `0,1,2,3,4`. Completeness of the fiber is
essential. This is not an arbitrary-dimension statement or a P-versus-NP
separation. The work is AI-assisted, independently implemented finite mathematics;
it is neither external peer review nor proof-assistant formalization.

## Read first

- `real-cost-fiber-next-20261019/PROOF.md`: self-contained accepted proof.
- `affine-fiber-next-20261019/AUDIT.md`: separately implemented complete audit.
- `real-cost-fiber-next-20261019/ACCEPTED_MANIFEST.json`: original allowlist.
- `PROVENANCE.json`: original source locations, exact bytes, and digests.
- `SHA256SUMS`: complete frozen-payload integrity manifest.

The independent audit's incidental reference to its earlier local `PROOF.md`
concerns an optional explicit integer-realization bound. That older exploratory
note is intentionally omitted. The packaged primary proof proves the needed
real-fiber/affine-closure equivalence directly; no omitted file is needed to
reproduce or understand the accepted exclusion.

## Reproduce from scratch

Requirements: Python 3.10 or later, the Python standard library, and `g++` with
C++17 and the 128-bit integer extension. No downloaded packages, numerical
solver, saved catalogue, remote repository, or network access are needed.

Run from the extracted package directory, using a new output directory outside
the package each time:

    python -B reproduce.py --output ../pnp-clean-replay
    python -B -O reproduce.py --optimized --output ../pnp-optimized-replay
    python -B reproduce.py --sanitize --output ../pnp-sanitized-replay

Each command verifies every packaged file, regenerates both catalogues, compiles
both distinct traversals, runs both uncapped searches, compares all 571 root
memberships and 1,949 core memberships/ranks, and checks the aggregate results.
Each implementation visits 177,379 states and finds zero cancelling fibers.
The primary interleaves scalar interval and gcd tests; the independent checker
does all intervals first. Their separate rejection counters differ while their
total rejection count is 172,808 in each implementation.

The two implementations can also be run directly with their original
`verify_complete.py` and `verify_independent.py` entry points. Their original
basenames and sibling layout are preserved. The independent wrapper's optional
`--reverse` experiment is outside this accepted package and must not be used;
the accepted full traversal uses the default ascending canonical order.

## Negative controls

    python -B test_package.py --output ../pnp-package-controls.json
    python -B -O test_package.py --output ../pnp-package-controls-optimized.json
    python -B real-cost-fiber-next-20261019/negative_controls.py --output ../pnp-math-controls.json
    python -B -O real-cost-fiber-next-20261019/negative_controls.py --output ../pnp-math-controls-optimized.json

The package controls test missing/tampered/extra payload files, an incomplete or
miscounted traversal, a reported zero candidate, corrupted witnesses, and bad
per-core totals. They inject corrupted output fixtures at the subprocess boundary
to test explicit validation guards, rather than run additional traversals. The
mathematical controls test coefficient/projection corruption, invalid moduli,
a known cancelling eight-term subset that fails complete-fiber closure, and the
full 120-term determinant with constant value 288. All tests use explicit
exceptions and remain active under Python optimization.

## Evidence and reproducible archive

Accepted evidence includes deterministic root/core lists, per-core totals, all
48 evaluation-zero survivors with nonzero coefficient vectors, complete term
and projection vectors, and final replay receipts. All source and proof files
are copied byte-for-byte. Exploration, capped searches, unfinished reverse
traversal, binaries, caches, and large regenerable logs are excluded.

`receipts/pnp-clean-source-replays.json` records fresh packaging-side primary
normal/optimized/sanitized and independent normal replays. The retained accepted
receipts also include an independent UBSan replay. Archive-extraction replay
and packaging-negative-control receipts are distributed beside the ZIP.

    python -B build_archive.py ../pnp-real-cost-n5-20261019-rebuilt.zip

The builder verifies the payload, sorts entries, and fixes timestamps and file
permissions. Rebuilding with the same Python/zlib toolchain yields identical
archive bytes. It refuses to overwrite an existing output.

No remote repository, pull request, merge, or release was changed by packaging.
Any research merge or release requires the user's separate batch approval.
