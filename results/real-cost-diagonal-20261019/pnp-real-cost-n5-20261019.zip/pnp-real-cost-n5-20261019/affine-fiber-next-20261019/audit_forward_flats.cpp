#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <stdexcept>
#include <vector>
using namespace std;
using Mask=__uint128_t;
using Vec=array<int,17>;
using Checks=array<long long,59>;
constexpr int MOD=1000003;
Mask one(int i){return Mask(1)<<i;}
int inverse(int value){long long a=value,b=MOD,x=1,y=0;while(b){long long q=a/b;long long c=a-q*b;a=b;b=c;c=x-q*y;x=y;y=c;}if(a!=1)throw runtime_error("not invertible");return int((x%MOD+MOD)%MOD);}
struct Space{
 array<Vec,17>rows{};int dimension=0;
 Vec reduce(Vec v)const{for(int k=16;k>=0;--k)if(v[k]&&rows[k][k]){long long f=v[k];for(int j=0;j<=k;++j)v[j]=int((v[j]-f*rows[k][j]%MOD+MOD)%MOD);}return v;}
 void insert(Vec v){v=reduce(v);int k=16;while(k>=0&&!v[k])--k;if(k<0)return;long long inv=inverse(v[k]);for(int j=0;j<=k;++j)rows[k][j]=int(v[j]*inv%MOD);++dimension;}
 bool contains(Vec v)const{v=reduce(v);return all_of(v.begin(),v.end(),[](int x){return !x;});}
};
array<array<int,5>,120>perms;
array<Vec,120>vectors;
array<Checks,120>values;
array<int,120>reversed;
struct Seed{int minimum,dimension;Mask members=0;};
vector<Seed>seeds;
uint64_t pairs=0,compatible=0,cores=0,visited=0,blocks_seen=0,bad_blocks=0,early_blocks=0,interval_pruned=0,gcd_pruned=0,zero=0,terminal=0;
map<int,uint64_t>ranks;
ofstream witnesses;
int binom(int n,int k){int z=1;for(int j=1;j<=k;++j)z=z*(n-j+1)/j;return z;}
long long power(long long x,int n){long long z=1;while(n--)z*=x;return z;}
array<long long,11>coefficients(const array<int,5>&p,int origin){array<long long,11>a{};int inv=0;for(int i=0;i<5;++i)for(int j=i+1;j<5;++j)inv+=p[i]>p[j];a[0]=inv%2?-1:1;int deg=0;for(int i=0;i<5;++i){array<long long,11>b{};for(int j=0;j<=deg;++j)for(int k=0;k<=p[i];++k)b[j+k]+=a[j]*binom(p[i],k)*power(origin+i,p[i]-k);a=b;deg+=p[i];}return a;}
Checks sum(Mask m){Checks a{};for(int i=0;i<120;++i)if(m&one(i))for(int k=0;k<59;++k)a[k]+=values[i][k];return a;}
void enumerate(const Space&space,Mask members,Mask forbidden,int previous,const Checks&total){
 ++visited;++ranks[space.dimension];bool iszero=true;for(int k=0;k<11;++k)if(total[k])iszero=false;if(iszero){++zero;witnesses<<"zero "<<space.dimension;for(int i=0;i<120;++i)if(members&one(i))witnesses<<' '<<i;witnesses<<'\n';witnesses.flush();}
 map<Vec,Mask>directions;
 for(int i=119;i>=0;--i)if(!(members&one(i))){Vec r=space.reduce(vectors[i]);int k=16;while(k>=0&&!r[k])--k;if(k<0)throw runtime_error("unclosed node");long long inv=inverse(r[k]);for(int j=0;j<=k;++j)r[j]=int(r[j]*inv%MOD);directions[r]|=one(i);}
 struct Option{int maximum;Mask block;Checks value;};vector<Option>options;Checks lo{},hi{},div{};
 for(auto &kv:directions){++blocks_seen;Mask block=kv.second;if(block&forbidden){++bad_blocks;continue;}int maximum=0;while(!(block&one(maximum)))++maximum;if(maximum<=previous){++early_blocks;continue;}Checks b=sum(block);options.push_back({maximum,block,b});for(int k=0;k<59;++k){lo[k]+=min(0LL,b[k]);hi[k]+=max(0LL,b[k]);div[k]=gcd(div[k],b[k]);}}
 for(int k=0;k<59;++k)if(-total[k]<lo[k]||-total[k]>hi[k]){++interval_pruned;return;}
 for(int k=0;k<59;++k)if(div[k]&&total[k]%div[k]){++gcd_pruned;return;}
 if(options.empty()){++terminal;return;}
 sort(options.begin(),options.end(),[](const Option&a,const Option&b){return a.maximum<b.maximum;});
 for(const auto&o:options){Space next=space;next.insert(vectors[o.maximum]);if(next.dimension!=space.dimension+1)throw runtime_error("rank did not increase");Checks t=total;for(int k=0;k<59;++k)t[k]+=o.value[k];enumerate(next,members|o.block,forbidden,o.maximum,t);}
}
int main(int argc,char**argv){if(argc!=3)return 1;array<int,5>p{0,1,2,3,4};int count=0;do{perms[count++]=p;}while(next_permutation(p.begin(),p.end()));long long maxabs=0;for(int i=0;i<120;++i){vectors[i][0]=1;for(int r=1;r<5;++r)for(int c=1;c<5;++c)vectors[i][1+4*(r-1)+c-1]=perms[i][r]==c;p=perms[i];reverse(p.begin(),p.end());reversed[i]=int(find(perms.begin(),perms.end(),p)-perms.begin());int k=0;for(int root=-4;root<=0;++root){auto a=coefficients(perms[i],root);for(auto x:a)values[i][k++]=x;}for(int x:{-6,-5,1,2}){int inv=0;for(int r=0;r<5;++r)for(int c=r+1;c<5;++c)inv+=perms[i][r]>perms[i][c];long long v=inv%2?-1:1;for(int r=0;r<5;++r)v*=power(x+r,perms[i][r]);values[i][k++]=v;}}
 for(int k=0;k<59;++k){long long bound=0;for(int i=0;i<120;++i)bound+=abs(values[i][k]);maxabs=max(maxabs,bound);}
 ifstream in(argv[1]);int n;in>>n;if(n!=571)throw runtime_error("not all571 seeds");for(int a=0;a<n;++a){Seed s;int size;in>>s.minimum>>s.dimension>>size;for(int j=0;j<size;++j){int i;in>>i;s.members|=one(i);}seeds.push_back(s);}
 witnesses.open(string(argv[2])+"_candidates.txt");ofstream coreout(string(argv[2])+"_cores.txt");
 for(int a=0;a<n;++a){for(int b=0;b<n;++b){++pairs;const auto&s=seeds[a];const auto&t=seeds[b];Mask other=0;for(int i=0;i<120;++i)if(t.members&one(i))other|=one(reversed[i]);Mask start=s.members|other,forbidden=0;for(int i=0;i<120;++i)if(perms[i][0]<s.minimum||perms[i][4]<t.minimum||(perms[i][0]==s.minimum&&!(s.members&one(i)))||(perms[i][4]==t.minimum&&!(other&one(i))))forbidden|=one(i);if(start&forbidden)continue;++compatible;Space sp;for(int i=119;i>=0;--i)if(start&one(i))sp.insert(vectors[i]);Mask closed=0;for(int i=0;i<120;++i)if(sp.contains(vectors[i]))closed|=one(i);if(closed&forbidden)continue;++cores;coreout<<a<<' '<<b<<' '<<sp.dimension;for(int i=0;i<120;++i)if(closed&one(i))coreout<<' '<<i;coreout<<'\n';enumerate(sp,closed,forbidden,-1,sum(closed));}if(a%50==0)cerr<<"slice "<<a<<" cores "<<cores<<" nodes "<<visited<<'\n';}
 ofstream out(string(argv[2])+"_stats.json");out<<"{\"all_pairs\":"<<pairs<<",\"membership_compatible\":"<<compatible<<",\"cores\":"<<cores<<",\"nodes\":"<<visited<<",\"quotient_blocks\":"<<blocks_seen<<",\"forbidden_blocks\":"<<bad_blocks<<",\"canonical_blocks\":"<<early_blocks<<",\"interval_pruned\":"<<interval_pruned<<",\"gcd_pruned\":"<<gcd_pruned<<",\"zero_candidates\":"<<zero<<",\"terminal\":"<<terminal<<",\"maximum_absolute_projection_sum\":"<<maxabs<<",\"modulus\":"<<MOD<<",\"polynomial_span_pruning_used\":false,\"search_cap\":null,\"node_ranks\":{";bool first=true;for(auto [r,c]:ranks){if(!first)out<<',';first=false;out<<'\"'<<r<<"\":"<<c;}out<<"}}\n";
}
