#include <array>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <stdexcept>
using namespace std;
constexpr long long M=1000000007;
using Row=array<long long,17>;
long long power(long long b,long long e){long long a=1;for(;e;e>>=1,b=b*b%M)if(e&1)a=a*b%M;return a;}
struct Basis{array<Row,17>b{};int rank=0;};
// Separate membership elimination preserves the pivot coefficient before mutation.
bool inside(Row a,const Basis&bs){for(int k=0;k<17;++k)if(a[k]){if(!bs.b[k][k])return false;auto x=a[k];for(int j=k;j<17;++j)a[j]=(a[j]-x*bs.b[k][j]%M+M)%M;}return true;}
void add(Row a,Basis&bs){for(int k=0;k<17;++k)if(a[k]){if(bs.b[k][k]){auto x=a[k];for(int j=k;j<17;++j)a[j]=(a[j]-x*bs.b[k][j]%M+M)%M;}else{auto inv=power(a[k],M-2);for(int j=k;j<17;++j)bs.b[k][j]=a[j]*inv%M;++bs.rank;return;}}}
int main(int argc,char**argv){if(argc!=2)return 1;vector<array<int,5>>pp;array<int,5>p{0,1,2,3,4};do{pp.push_back(p);}while(next_permutation(p.begin(),p.end()));vector<Row>v(120);vector<long long>w(120);for(int i=0;i<120;++i){v[i][0]=1;for(int r=1;r<5;++r)for(int c=1;c<5;++c)v[i][1+4*(r-1)+(c-1)]=pp[i][r]==c;int inv=0;for(int r=0;r<5;++r)for(int c=r+1;c<5;++c)inv+=pp[i][r]>pp[i][c];w[i]=inv%2?-1:1;for(int r=1;r<5;++r)for(int k=0;k<pp[i][r];++k)w[i]*=r;}
 vector<array<int,3>>info;vector<vector<int>>sets;
 for(int r=0;r<5;++r){vector<int>ids;for(int i=0;i<120;++i)if(pp[i][0]==r)ids.push_back(i);unsigned prev=0;long long total=0,balanced=0,closed=0;for(unsigned step=1;step<(1u<<24);++step){unsigned g=step^(step>>1),diff=g^prev;int k=__builtin_ctz(diff);total+=(g&diff)?w[ids[k]]:-w[ids[k]];prev=g;if(total)continue;++balanced;Basis bs;vector<int>s;for(int j=0;j<24;++j)if(g&(1u<<j)){add(v[ids[j]],bs);s.push_back(ids[j]);}bool good=true;for(int j=0;j<24&&good;++j)if(!(g&(1u<<j))&&inside(v[ids[j]],bs))good=false;if(good){++closed;info.push_back({r,bs.rank,(int)s.size()});sets.push_back(s);}}
 cerr<<r<<' '<<balanced<<' '<<closed<<'\n';}
 vector<int>order(sets.size());for(int i=0;i<(int)order.size();++i)order[i]=i;sort(order.begin(),order.end(),[&](int a,int b){if(info[a][0]!=info[b][0])return info[a][0]<info[b][0];return sets[a]<sets[b];});ofstream out(argv[1]);out<<sets.size()<<'\n';for(int i:order){out<<info[i][0]<<' '<<info[i][1]<<' '<<info[i][2];for(int x:sets[i])out<<' '<<x;out<<'\n';}if(sets.size()!=571)throw runtime_error("Catalogue size disagreement");}
