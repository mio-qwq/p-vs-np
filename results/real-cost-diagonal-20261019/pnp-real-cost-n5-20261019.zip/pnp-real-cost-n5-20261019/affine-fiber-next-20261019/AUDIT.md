# Independent all-real-cost five-row verification

19 October 2026. Independent AI-assisted implementation and mathematical audit. This is not external peer review or proof-assistant formalization. No remote repository or publication action was taken.

## Result

The complete independent finite check passed: every nonempty complete additive-cost fiber, for arbitrary real costs and arbitrary bipartite support on five labelled rows and columns, has a nonzero canonical polynomial

    sum_(p in F) sign(p) product_i (L+i)^(p(i)).

This result is confined to the canonical n=5 model. It makes no unrestricted dimension or complexity-theoretic claim.

The primary companion search is in `../real-cost-fiber-next-20261019/`. This audit does not merely rerun its code. The independent implementation agrees with its complete result and all 1,949 exact core memberships.

## Complete coverage

Every complete real-cost fiber is globally affine-closed. Any affine incidence outsider uses only edges in the selected union and has the same cost, so completeness would include it. Conversely, every affine-closed subset can be realized as an integer-cost fiber on K5,5; `PROOF.md` gives an explicit construction and bound.

For a hypothetical cancelling fiber, let r be the least used row-0 column. Its nonempty r-slice has zero coefficient of L^r, giving the exact scalar equation

    sum_(p in S_r) sign(p) product_(i=1)^4 i^(p(i)) = 0.

The slice is affine-closed among its 24 possible permutations. No restriction to r<=2 is made. Row reversal gives the same root-slice condition at row 4 because

    f_p(-4-L) = f_(reverse rows of p)(L).

The reversal sign and total exponent are both even. Hence the two least-root slices appear among the full 571-slice catalogue. Their joint closure lies in the hypothetical fiber, and none of its members can violate either prescribed minimum or slice membership. Pairing all571 slices therefore supplies a complete set of1949 possible closed cores, without prior binary, endpoint-degree, or cardinality theorems.

For any closed node C, the nonzero incidence residues modulo span(C) split into projective direction blocks. Adding one permutation closes to exactly C plus its entire block. Every larger flat is a union of such blocks. Blocks containing forbidden least-root members can never enter a permitted extension.

Ascending canonical traversal chooses only blocks whose minimum index exceeds the previous chosen minimum. Every target flat is reached exactly once by repeatedly choosing its least element not yet present. Skipping that element would make it impossible to acquire later, proving uniqueness as well as coverage. At a node, the earlier-index blocks may also be excluded from the scalar relaxation because the canonical descendants cannot acquire them.

Every visited nonempty flat is tested for the zero polynomial before descendant pruning. There is no size, parity, endpoint-degree, cost-range, support-size, timeout, or node-count gate.

## Independent implementation differences

1. Root catalogue: Gray-code enumeration of every one of the2^24-1 nonempty subsets for each of five minima, rather than a positive/negative subset-sum join.
2. Incidence representation: constant plus the lower-right4-by-4 incidence submatrix, rather than the upper-left submatrix.
3. Full-search arithmetic: prime1,000,003, Euclidean modular inverses, and descending-pivot elimination; the primary uses a different prime and elimination implementation.
4. Polynomial construction: direct binomial-factor convolution separately at each original root L=-4,-3,-2,-1,0, rather than translating one centered coefficient vector.
5. Evaluations: direct signed products at L=-6,-5,1,2.
6. Zero test: all11 coefficients at L=-4, without a preliminary cardinality or evaluation gate.
7. Descendant pruning: interval and gcd tests only. The independent full verification uses no polynomial-span or multi-prime rank pruning.
8. All1949 core membership lists were also compared with a separate exact-integer elimination replay.

The optional descending-index traversal was stopped after the complete ascending audit and its sanitizer replay had passed. It is an incomplete supplementary experiment and is not counted as evidence of complete exclusion.

## Exact arithmetic and sound projections

Every augmented incidence row has at most five ones. Any square minor of at most17 rows therefore has absolute value at most5^(17/2), which is strictly less than1,000,003. Both1,000,003 and the root generator's1,000,000,007 are prime. Thus their incidence ranks, closures, and projective-block decisions equal the rational/real decisions exactly. This is not a probabilistic modular-rank argument.

At a node, every extension must add whole allowed blocks. For each of59 integer linear functionals of the polynomial, its required value is therefore a subset sum of the corresponding block values:

- 55 Taylor coefficients: all11 coefficients at each original root L=-4,-3,-2,-1,0
- Four evaluations: L=-6,-5,1,2

Any such subset sum lies between the sum of negative block values and the sum of positive values. It is divisible by the gcd of all block values. Failure of either condition safely excludes every descendant. Passing asserts nothing about realizability.

The independent implementation computes the maximum, over these59 functionals, of the sum of absolute values across all120 individual terms. It is142,672,320. Every block, core, interval endpoint, and actual fiber sum is bounded by this number. Modular products use signed64-bit integers with values below the square of their modulus, also safely within range.

## Complete independent counts

Root minima0,1,2,3,4 respectively have:

- Scalar-balanced nonempty subsets:13,419;1,437;1,242;3,609;13,419
- Affine-closed balanced subsets:216;23;24;92;216

All571 independently generated memberships equal both the primary standalone regenerated catalogue and the accepted earlier catalogue.

Full independent traversal:

- Ordered root-slice pairs:326,041
- Membership-compatible pairs:49,274
- Affine-compatible closed cores:1,949
- Visited closed nodes:177,379
- Projective blocks considered:11,340,790
- Blocks rejected for forbidden members:4,690,101
- Blocks excluded by canonical ordering:3,525,766
- Nodes rejected by interval tests:170,741
- Further nodes rejected by gcd tests:2,067
- Expanded nodes:4,571
- Cancelling polynomial candidates:0
- Search cap:none

The different attribution between interval and gcd rejections in the primary implementation is expected: this audit tries every interval before trying any gcd, while the primary interleaves the checks. The total rejected node count172,808 and the complete node memberships/counts agree.

Core rank distribution:5:10;6:112;7:268;8:408;9:540;10:382;11:178;12:47;13:4.

Visited-node rank distribution:5:10;6:614;7:6,412;8:21,701;9:42,853;10:51,485;11:37,158;12:14,317;13:2,611;14:218.

## Reproduction

Run:

    python verify_independent.py --output NEW_DIRECTORY

For a separate undefined-behavior-sanitizer build:

    python verify_independent.py --output NEW_SANITIZED_DIRECTORY --sanitize

The script compiles only the independent local sources, regenerates all571 roots from scratch, and performs the uncapped traversal. It imports no primary source, accepted catalogue, solver, or previous result file. `INDEPENDENT_RESULT.json` records the completed direct audit, and `INDEPENDENT_UBSAN_RESULT.json` records a successful fresh standalone regeneration and undefined-behavior-sanitizer replay; `CATALOGUE_AUDIT.json` records the catalogue equality checks; `ALL_INTEGER_CORE_STATS.json` and `ALL_INTEGER_CORES.txt` record the independent integer core replay.

## Recovery conditions

Suspend acceptance if any checker finds a missed scalar-balanced closed slice, a wrong core closure, an invalid projective block, an unsound canonical or scalar rejection, modular rank outside the proved determinant bound, overflow, a capped run presented as complete, or a genuine nonempty closed zero-polynomial subset. Preserve its complete120-permutation membership and all11 polynomial coefficients. A nonclosed zero-polynomial subset alone is not a complete real-cost counterexample.
