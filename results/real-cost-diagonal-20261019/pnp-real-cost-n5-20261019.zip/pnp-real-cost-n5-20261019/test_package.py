#!/usr/bin/env python3
"""Test payload integrity and rejection guards, including under Python -O.

Corrupted-output tests inject fixtures at the subprocess boundary to exercise
validation branches. They are not additional mathematical traversals.
"""
import argparse
from contextlib import redirect_stdout
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
from unittest.mock import patch

sys.dont_write_bytecode = True
from reproduce import ROOT, require, verify_tree


def load_primary():
    path = ROOT / 'real-cost-fiber-next-20261019' / 'verify_complete.py'
    spec = importlib.util.spec_from_file_location('primary_package_test', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def mutate_json(directory, filename, field, value):
    path = directory / filename
    item = json.loads(path.read_text())
    item[field] = value
    path.write_text(json.dumps(item))


def mutate_line(directory, filename, index):
    path = directory / filename
    lines = path.read_text().splitlines()
    row = list(map(int, lines[0].split()))
    row[index] += 1
    lines[0] = ' '.join(map(str, row))
    path.write_text('\n'.join(lines) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    require(not output.is_relative_to(ROOT), 'Test report must be outside the frozen payload')
    require(not output.exists(), 'Refusing to overwrite an existing test report')
    report = {'integrity': verify_tree(), 'optimized_python': bool(sys.flags.optimize), 'checks': {}}
    module = load_primary()
    fixture = ROOT / 'real-cost-fiber-next-20261019' / 'FINAL_REPLAY'
    cases = [
        ('capped_search', lambda d: mutate_json(d, 'TRAVERSAL_stats.json', 'capped', True), 'Traversal incomplete'),
        ('missing_root', lambda d: mutate_json(d, 'ROOT_COUNTS.json', 'closed_total', 570), 'Root count discrepancy'),
        ('missing_pair', lambda d: mutate_json(d, 'TRAVERSAL_stats.json', 'pairs', 326040), 'Missing root pairs'),
        ('missing_node', lambda d: mutate_json(d, 'TRAVERSAL_stats.json', 'nodes', 177378), 'Traversal count discrepancy'),
        ('claimed_zero_candidate', lambda d: mutate_json(d, 'TRAVERSAL_stats.json', 'candidates', 1), 'Cancelling candidate found'),
        ('nonempty_witness', lambda d: (d / 'TRAVERSAL_candidates.txt').write_text('injected witness\n'), 'Cancelling candidate found'),
        ('unaccounted_node', lambda d: mutate_json(d, 'TRAVERSAL_stats.json', 'expanded', 4570), 'Unaccounted nodes'),
        ('missing_survivor', lambda d: (d / 'TRAVERSAL_eval_zero.txt').write_text(''), 'Missing evaluation-zero records'),
        ('corrupt_survivor', lambda d: mutate_line(d, 'TRAVERSAL_eval_zero.txt', -1), 'Evaluation-zero survivor check failed'),
        ('corrupt_per_core_total', lambda d: mutate_line(d, 'TRAVERSAL_core_stats.txt', 2), 'Per-core counter mismatch'),
    ]
    with tempfile.TemporaryDirectory(prefix='pnp-negative-') as tmp:
        tmp = Path(tmp)
        for name, mutation, expected in cases:
            directory = tmp / name
            shutil.copytree(fixture, directory)
            mutation(directory)
            try:
                with patch.object(module.subprocess, 'run', return_value=None), patch.object(sys, 'argv', ['verify_complete.py', '--output', str(directory)]), redirect_stdout(io.StringIO()):
                    module.main()
            except RuntimeError as exc:
                require(expected in str(exc), 'Wrong failure for ' + name + ': ' + str(exc))
                report['checks'][name] = {'rejected': True, 'reason': str(exc)}
            else:
                raise RuntimeError('Mutation was accepted: ' + name)
        for name, mutation in [('mutated_source', lambda d: (d / 'source.py').write_text('tampered\n')), ('unexpected_file', lambda d: (d / 'extra.txt').write_text('unexpected\n')), ('missing_source', lambda d: (d / 'source.py').unlink())]:
            directory = tmp / name
            directory.mkdir()
            original = b'print("frozen")\n'
            (directory / 'source.py').write_bytes(original)
            (directory / 'SHA256SUMS').write_text(hashlib.sha256(original).hexdigest() + '  source.py\n')
            verify_tree(directory)
            mutation(directory)
            try:
                verify_tree(directory)
            except RuntimeError as exc:
                report['checks'][name] = {'rejected': True, 'reason': str(exc)}
            else:
                raise RuntimeError('Integrity mutation was accepted: ' + name)
    report['status'] = 'passed'
    report['guards_tested'] = len(report['checks'])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
