"""Regenerate every affine-closed balanced endpoint slice from definitions."""
from collections import defaultdict, Counter
from itertools import permutations
from math import prod, isqrt
from pathlib import Path
import argparse,json,hashlib,time
P=1000000007
PS=list(permutations(range(5)))
SIGN=[(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5)) for p in PS]
V=[[1]+[int(p[i]==j) for i in range(4) for j in range(4)] for p in PS]
def basis(rows):
 b={}
 for row in rows:
  v=row[:]
  for i in range(17):
   if not v[i]:continue
   if i in b:
    z=v[i];v=[(x-z*y)%P for x,y in zip(v,b[i])]
   else:
    z=pow(v[i],P-2,P);b[i]=[x*z%P for x in v];break
 return b
def belongs(row,b):
 v=row[:]
 for i in range(17):
  if not v[i]:continue
  if i not in b:return False
  z=v[i];v=[(x-z*y)%P for x,y in zip(v,b[i])]
 return True
def sums(weights):
 out=defaultdict(list);out[0].append(0);ss=[0]
 for k,w in enumerate(weights):
  old=len(ss)
  for mask in range(old):
   val=ss[mask]+w;ss.append(val);out[val].append(mask|old)
 return out

def generate():
 slices=[];stats=[]
 for r in range(5):
  ids=[i for i,p in enumerate(PS) if p[0]==r]
  pos=[i for i in ids if SIGN[i]>0];neg=[i for i in ids if SIGN[i]<0]
  scalar=lambda i:prod(row**PS[i][row] for row in range(1,5))
  left=sums([scalar(i) for i in pos]);right=sums([scalar(i) for i in neg]);balanced=0;found=[]
  for value,lmasks in left.items():
   for lm in lmasks:
    for rm in right.get(value,[]):
     members=[i for k,i in enumerate(pos) if lm>>k&1]+[i for k,i in enumerate(neg) if rm>>k&1]
     if not members:continue
     balanced+=1;members.sort();b=basis([V[i] for i in members]);closure=[i for i in ids if belongs(V[i],b)]
     if closure==members:found.append({'r':r,'ids':members,'rank':len(b)})
  found.sort(key=lambda s:sum(1<<ids.index(i) for i in s['ids']))
  if len({tuple(s['ids']) for s in found})!=len(found):raise RuntimeError('Duplicate slices')
  stats.append({'r':r,'balanced':balanced,'closed':len(found),'ranks':dict(sorted(Counter(s['rank'] for s in found).items()))})
  slices.extend(found);print(f'r={r} balanced={balanced} closed={len(found)}',flush=True)
 return slices,stats

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--directory',default=str(Path(__file__).resolve().parent/'REGENERATED'));args=ap.parse_args();out=Path(args.directory);out.mkdir(parents=True,exist_ok=True)
 if not all(P%d for d in range(2,isqrt(P)+1)):raise RuntimeError('Nonprime incidence modulus')
 if not 5**17<P**2:raise RuntimeError('Hadamard incidence bound failed')
 start=time.time();slices,stats=generate()
 (out/'slices.json').write_text(json.dumps(slices,indent=2)+'\n')
 with (out/'slices.txt').open('w') as f:
  f.write(str(len(slices))+'\n')
  for s in slices:f.write(' '.join(map(str,[s['r'],len(s['ids'])]+s['ids']))+'\n')
 (out/'ROOT_COUNTS.json').write_text(json.dumps({'balanced_total':sum(s['balanced'] for s in stats),'closed_total':len(slices),'groups':stats,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'elapsed_seconds':time.time()-start},indent=2)+'\n')
if __name__=='__main__':main()
