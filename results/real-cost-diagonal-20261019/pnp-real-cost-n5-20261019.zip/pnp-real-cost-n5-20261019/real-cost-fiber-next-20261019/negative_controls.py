"""Adversarial arithmetic and completeness checks; never modifies final evidence."""
import argparse,json,itertools,tempfile
from pathlib import Path
import verify_complete as verify
import regenerate_slices as roots

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--replay',default=str(Path(__file__).resolve().parent/'FINAL_REPLAY'));ap.add_argument('--output',default=str(Path(__file__).resolve().parent/'NEGATIVE_CONTROLS.json'));args=ap.parse_args();source=Path(args.replay)/'TRAVERSAL_terms.txt';original=source.read_text();report={}
 with tempfile.TemporaryDirectory() as d:
  f=Path(d)/'terms.txt'
  for name,index in [('corrupt_centered_coefficient',1),('corrupt_taylor_projection',12),('corrupt_direct_evaluation',71)]:
   rows=original.splitlines();v=rows[0].split();v[index]=str(int(v[index])+1);rows[0]=' '.join(v);f.write_text('\n'.join(rows)+'\n')
   try:verify.arithmetic_check(f)
   except RuntimeError as e:report[name]={'rejected':True,'reason':str(e)}
   else:raise RuntimeError('Mutation was not rejected: '+name)
  f.write_text(original)
  for name,modulus in [('composite_modulus',1000000005),('insufficient_hadamard_modulus',3)]:
   old=verify.PRIMES;verify.PRIMES=[modulus]
   try:
    try:verify.arithmetic_check(f)
    except RuntimeError as e:report[name]={'rejected':True,'reason':str(e)}
    else:raise RuntimeError('Invalid modulus was not rejected')
   finally:verify.PRIMES=old
 ps=list(itertools.permutations(range(5)));index={''.join(map(str,p)):i for i,p in enumerate(ps)}
 zero8=['03241','04123','04231','04321','12340','13240','14230','32140'];ids=[index[p] for p in zero8]
 coefficients=[sum(verify.polynomial(ps[i],0)[k] for i in ids) for k in range(11)]
 verify.need(not any(coefficients),'Known arbitrary subset should cancel')
 outsider=index['02143'];right=[('03241',1),('04123',1),('04321',-1),('12340',1),('13240',-1)]
 for r in range(5):
  for c in range(5):verify.need(int(ps[outsider][r]==c)==sum(a*int(ps[index[p]][r]==c) for p,a in right),'Explicit affine identity failed')
 verify.need(sum(a for _,a in right)==1 and outsider not in ids,'Invalid affine outsider witness')
 cl=[i for i in range(120) if roots.belongs(roots.V[i],roots.basis([roots.V[j] for j in ids]))]
 verify.need(outsider in cl and set(cl)!=set(ids),'Known zero subset incorrectly treated as closed')
 union={(r,ps[i][r]) for i in ids for r in range(5)}
 complete=[i for i,p in enumerate(ps) if all((r,p[r]) in union for r in range(5))]
 actual=[sum(verify.polynomial(ps[i],0)[k] for i in complete) for k in range(11)]
 verify.need(len(complete)==12 and any(actual),'Known complete-fiber negative control failed')
 report['zero_subset_is_not_complete_fiber']={'zero_subset':zero8,'all_eleven_coefficients_zero':True,'forced_outsider':'02143','claimed_membership_rejected':True,'actual_row0_red_cost1_fiber':[''.join(map(str,ps[i])) for i in complete],'actual_fiber_original_L_coefficients':actual,'affine_closure_members':[''.join(map(str,ps[i])) for i in cl]}
 full=[sum(verify.polynomial(p,0)[k] for p in ps) for k in range(11)];verify.need(full==[288]+[0]*10,'Full determinant control failed')
 report['full_constant_cost_fiber']={'members':120,'original_L_coefficients':full,'nonzero':True}
 report['status']='All adversarial controls passed; no retained evidence was modified.'
 Path(args.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
