# Canonical n=5 real-cost fibers

Exact local exclusion of polynomial cancellation in every nonempty complete real additive-edge-cost fiber, on any supported graph. Read PROOF.md for the mathematical scope and verification boundary.

Final entry points:

- regenerate_slices.py: regenerate all 571 endpoint slices directly.
- enumerate_flats.cpp: exact affine-flat traversal with scalar interval/gcd pruning.
- verify_complete.py: standalone regeneration, compilation, exhaustion, independent coefficient/projection checks, and result manifest.
- negative_controls.py: adversarial arithmetic mutations and incomplete-fiber controls.

Run:

    python verify_complete.py --output NEW_DIRECTORY

The final verifier does not read earlier artifacts. Files beginning `explore_`, capped EXPLORE/FAST/PRUNED/SPAN runs, the earlier primary_exact.cpp, and prepare*.py are retained exploratory history, not final entry points. In particular, capped runs are not evidence of complete exclusion and the redundant polynomial-span code is not part of the final method.

No remote repository changes were made. Independent full traversal passed; see ../affine-fiber-next-20261019/INDEPENDENT_RESULT.json. The allowlist in ACCEPTED_MANIFEST.json identifies the final sources and evidence.
