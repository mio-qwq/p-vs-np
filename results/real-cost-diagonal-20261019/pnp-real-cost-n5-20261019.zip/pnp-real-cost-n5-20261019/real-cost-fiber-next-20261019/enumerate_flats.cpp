#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <stdexcept>
#include <vector>
#include <chrono>
using namespace std;
const int P=1000000007;
using V=array<int,17>;
int powmod(int a,int e){long long z=1;for(;e;e>>=1,a=(long long)a*a%P)if(e&1)z=z*a%P;return z;}
struct Basis {array<V,17>b{};int rank=0;bool add(V v){for(int i=0;i<17;++i){if(!v[i])continue;if(b[i][i]){int a=v[i];for(int j=i;j<17;++j)v[j]=(v[j]-(long long)a*b[i][j]%P+P)%P;}else{int z=powmod(v[i],P-2);for(int j=i;j<17;++j)b[i][j]=(long long)v[j]*z%P;++rank;return true;}}return false;}
 V residue(V v)const{for(int i=0;i<17;++i){if(!v[i]||!b[i][i])continue;int a=v[i];for(int j=i;j<17;++j)v[j]=(v[j]-(long long)a*b[i][j]%P+P)%P;}return v;}
 bool contains(V v)const{for(int i=0;i<17;++i){if(!v[i])continue;if(!b[i][i])return false;int a=v[i];for(int j=i;j<17;++j)v[j]=(v[j]-(long long)a*b[i][j]%P+P)%P;}return true;}
};
using Mask=__uint128_t;
Mask bit(int i){return (Mask)1<<i;}
struct Slice{int r;Mask mask=0;};
array<array<int,5>,120>ps;
array<V,120>vec;
array<array<long long,11>,120>poly;
array<long long,120>eval;
const int NC=59;
array<array<long long,NC>,120>checks;
array<int,120>rv;
vector<Slice>ss;
long long pairs=0,compatible=0,cores=0,nodes=0,terminal=0,extensions=0,forbidden_reject=0,canonical_reject=0,candidates=0;
map<int,long long>core_ranks,node_ranks;
ofstream candidateout,nodeout,evalout;
long long interval_reject=0,gcd_reject=0,eval_zero=0,expanded=0;
Mask close(const Basis&b,Mask forbidden,bool &bad){Mask m=0;bad=false;for(int i=0;i<120;++i)if(b.contains(vec[i])){m|=bit(i);if(forbidden&bit(i)){bad=true;return m;}}return m;}
void dfs(const Basis&bs,Mask m,Mask forbidden,int last,int a,int b){
 ++nodes;++node_ranks[bs.rank];if(nodes%100000==0)cerr<<"nodes="<<nodes<<" a="<<a<<" b="<<b<<" rank="<<bs.rank<<"\n";
 int sz=0,c0=0,c4=0;long long ev=0;for(int i=0;i<120;++i)if(m&bit(i)){++sz;c0|=1<<ps[i][0];c4|=1<<ps[i][4];ev+=eval[i];}
 if(ev==0){++eval_zero;array<long long,11>sum{};for(int i=0;i<120;++i)if(m&bit(i))for(int j=0;j<11;++j)sum[j]+=poly[i][j];evalout<<a<<' '<<b<<' '<<last<<' '<<bs.rank<<' '<<sz;for(int i=0;i<120;++i)if(m&bit(i))evalout<<' '<<i;for(auto x:sum)evalout<<' '<<x;evalout<<'\n';bool zero=true;for(auto z:sum)if(z)zero=false;if(zero){++candidates;candidateout<<a<<' '<<b<<' '<<bs.rank<<' '<<sz;for(int i=0;i<120;++i)if(m&bit(i))candidateout<<' '<<i;candidateout<<'\n';candidateout.flush();cerr<<"CANDIDATE "<<a<<' '<<b<<' '<<sz<<'\n';}}
 map<V,Mask> groups;
 for(int i=0;i<120;++i){if(m&bit(i))continue;V r=bs.residue(vec[i]);int j=0;while(j<17&&!r[j])++j;if(j==17)throw runtime_error("closure mismatch");int z=powmod(r[j],P-2);for(int k=j;k<17;++k)r[k]=(long long)r[k]*z%P;groups[r]|=bit(i);}
 vector<pair<int,Mask>> valid;
 array<long long,NC> total{},pos{},neg{},div{};
 for(int i=0;i<120;++i)if(m&bit(i))for(int j=0;j<NC;++j)total[j]+=checks[i][j];
 for(auto &item:groups){Mask g=item.second;++extensions;if(g&forbidden){++forbidden_reject;continue;}int i=0;while(!(g&bit(i)))++i;if(i<=last){++canonical_reject;continue;}valid.push_back({i,g});array<long long,NC>w{};for(int k=0;k<120;++k)if(g&bit(k))for(int j=0;j<NC;++j)w[j]+=checks[k][j];for(int j=0;j<NC;++j){if(w[j]>0)pos[j]+=w[j];else neg[j]+=w[j];div[j]=gcd(div[j],w[j]);}}
 for(int j=0;j<NC;++j){if(-total[j]<neg[j]||-total[j]>pos[j]){++interval_reject;return;}if(div[j]&&total[j]%div[j]){++gcd_reject;return;}}
 ++expanded;
 bool child=false;
 for(auto [i,g]:valid){Basis nb=bs;if(!nb.add(vec[i]))throw runtime_error("closure mismatch");child=true;dfs(nb,m|g,forbidden,i,a,b);}

 if(!child)++terminal;
}
int main(int argc,char**argv){if(argc<3)return 1;bool only=argc>3&&string(argv[3])=="cores";if(argc>3&&!only)throw runtime_error("Only optional argument is cores; no budget cutoff is supported");array<int,5>p{0,1,2,3,4};int z=0;do{ps[z++]=p;}while(next_permutation(p.begin(),p.end()));for(int i=0;i<120;++i){vec[i][0]=1;for(int r=0;r<4;++r)for(int c=0;c<4;++c)vec[i][1+4*r+c]=ps[i][r]==c;p=ps[i];reverse(p.begin(),p.end());rv[i]=find(ps.begin(),ps.end(),p)-ps.begin();int inv=0;for(int r=0;r<5;++r)for(int s=r+1;s<5;++s)inv+=ps[i][r]>ps[i][s];poly[i][0]=inv%2?-1:1;int deg=0;for(int r=0;r<5;++r)for(int e=0;e<ps[i][r];++e){for(int j=++deg;j>=1;--j)poly[i][j]=poly[i][j-1]+(r-2)*poly[i][j];poly[i][0]*=(r-2);}long long power=1;for(auto c:poly[i]){eval[i]+=c*power;power*=3;}}
 for(int i=0;i<120;++i){int q=0;for(int a=-2;a<=2;++a)for(int k=0;k<=10;++k){long long val=0;for(int j=k;j<=10;++j){long long bin=1,pow=1;for(int h=1;h<=k;++h)bin=bin*(j-h+1)/h;for(int h=0;h<j-k;++h)pow*=a;val+=poly[i][j]*bin*pow;}checks[i][q++]=val;}for(int a:{-4,-3,3,4}){long long val=0,pow=1;for(int k=0;k<=10;++k){val+=poly[i][k]*pow;pow*=a;}checks[i][q++]=val;}if(q!=NC)throw runtime_error("projection count");}
 ifstream in(argv[1]);int n;in>>n;ss.resize(n);for(auto&s:ss){int k;in>>s.r>>k;while(k--){in>>z;s.mask|=bit(z);}}string prefix=argv[2];candidateout.open(prefix+"_candidates.txt");nodeout.open(prefix+"_cores.txt");evalout.open(prefix+"_eval_zero.txt");ofstream corestats(prefix+"_core_stats.txt");ofstream terms(prefix+"_terms.txt");for(int i=0;i<120;++i){terms<<i;for(auto x:poly[i])terms<<' '<<x;for(auto x:checks[i])terms<<' '<<x;terms<<' '<<eval[i]<<'\n';}auto start=chrono::steady_clock::now();
 for(int a=0;a<n;++a){for(int b=0;b<n;++b){++pairs;Mask m=ss[a].mask,other=0;for(int i=0;i<120;++i)if(ss[b].mask&bit(i))other|=bit(rv[i]);m|=other;Mask forbidden=0;for(int i=0;i<120;++i)if(ps[i][0]<ss[a].r||ps[i][4]<ss[b].r||(ps[i][0]==ss[a].r&&!(ss[a].mask&bit(i)))||(ps[i][4]==ss[b].r&&!(other&bit(i))))forbidden|=bit(i);if(m&forbidden)continue;++compatible;Basis bs;for(int i=0;i<120;++i)if(m&bit(i))bs.add(vec[i]);bool bad;m=close(bs,forbidden,bad);if(bad)continue;++cores;++core_ranks[bs.rank];nodeout<<a<<' '<<b<<' '<<bs.rank;for(int i=0;i<120;++i)if(m&bit(i))nodeout<<' '<<i;nodeout<<'\n';long long before=nodes,bi=interval_reject,bg=gcd_reject,be=expanded,bz=eval_zero;if(!only)dfs(bs,m,forbidden,-1,a,b);corestats<<a<<' '<<b<<' '<<nodes-before<<' '<<interval_reject-bi<<' '<<gcd_reject-bg<<' '<<expanded-be<<' '<<eval_zero-bz<<'\n';}
 if(a%1==0)cerr<<"a="<<a<<" cores="<<cores<<" nodes="<<nodes<<" ext="<<extensions<<" sec="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';}
 ofstream out(prefix+"_stats.json");out<<"{\"pairs\":"<<pairs<<",\"compatible\":"<<compatible<<",\"cores\":"<<cores<<",\"nodes\":"<<nodes<<",\"extensions\":"<<extensions<<",\"forbidden_reject\":"<<forbidden_reject<<",\"canonical_reject\":"<<canonical_reject<<",\"terminal\":"<<terminal<<",\"candidates\":"<<candidates<<",\"capped\":false,\"interval_reject\":"<<interval_reject<<",\"gcd_reject\":"<<gcd_reject<<",\"eval_zero\":"<<eval_zero<<",\"expanded\":"<<expanded<<",\"core_ranks\":{";bool first=true;for(auto[r,c]:core_ranks){if(!first)out<<',';first=false;out<<'"'<<r<<"\":"<<c;}out<<"},\"node_ranks\":{";first=true;for(auto[r,c]:node_ranks){if(!first)out<<',';first=false;out<<'"'<<r<<"\":"<<c;}out<<"}}\n";
}
