"""Standalone exact regeneration, traversal, and independent arithmetic checks."""
import argparse,hashlib,itertools,json,math,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PRIMES=[1000000007]
def need(condition,message):
 if not condition:raise RuntimeError(message)
def convolve(a,b):
 out=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return out
def polynomial(p,shift):
 sign=(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5));out=[sign]
 for i,e in enumerate(p):out=convolve(out,[math.comb(e,k)*(shift+i)**(e-k) for k in range(e+1)])
 return out
def term(p,L):
 return (-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))*math.prod((L+i)**e for i,e in enumerate(p))
def arithmetic_check(path):
 for p in PRIMES:need(p>=2 and all(p%d for d in range(2,math.isqrt(p)+1)),f'Nonprime modulus: {p}')
 need(5**17<PRIMES[0]**2,'Incidence Hadamard bound failed')
 all_ps=list(itertools.permutations(range(5)));coeffs=[polynomial(p,-2) for p in all_ps]
 norm=max(sum(c*c for c in row) for row in coeffs);need(norm==258620,'Unexpected centered norm')
 rows=[list(map(int,l.split())) for l in path.read_text().splitlines()];need(len(rows)==120,'Wrong term count')
 max_projection_sum=0;projection_rows=[]
 for i,p in enumerate(all_ps):
  checks=[]
  for shift in range(-4,1):checks.extend(polynomial(p,shift))
  checks.extend(term(p,L) for L in [-6,-5,1,2]);projection_rows.append(checks)
  expected=[i]+coeffs[i]+checks+[term(p,1)]
  need(rows[i]==expected,f'Coefficient or projection disagreement at permutation {p}')
  for t in range(-5,6):need(sum(c*t**k for k,c in enumerate(coeffs[i]))==term(p,t-2),'Direct product disagreement')
 max_projection_sum=max(sum(abs(row[j]) for row in projection_rows) for j in range(59))
 need(max_projection_sum<2**63,'Projection arithmetic overflow bound')
 need(max(PRIMES)**2+max(PRIMES)<2**63,'Modular arithmetic overflow bound')
 return {'all_120_term_vectors_verified':True,'all_59_projections_verified':True,'centered_coefficient_max_abs':max(abs(c) for row in coeffs for c in row),'centered_squared_norm_max':norm,'max_projection_absolute_sum':max_projection_sum,'moduli':PRIMES,'moduli_verified_prime':True,'incidence_rank_exact_by_hadamard':True}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--sanitize',action='store_true');args=ap.parse_args();out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True);start=time.time()
 subprocess.run([sys.executable,str(HERE/'regenerate_slices.py'),'--directory',str(out)],check=True)
 roots=json.loads((out/'ROOT_COUNTS.json').read_text());need(roots['balanced_total']==33126 and roots['closed_total']==571,'Root count discrepancy')
 exe=out/'verify_flats';flags=['-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=undefined'] if args.sanitize else ['-O3']
 subprocess.run(['g++','-std=c++17','-Wall','-Wextra']+flags+[str(HERE/'enumerate_flats.cpp'),'-o',str(exe)],check=True)
 prefix=out/'TRAVERSAL'
 with (out/'traversal.log').open('w') as log:subprocess.run([str(exe),str(out/'slices.txt'),str(prefix)],stdout=log,stderr=subprocess.STDOUT,check=True)
 arithmetic=arithmetic_check(out/'TRAVERSAL_terms.txt');(out/'ARITHMETIC_CHECK.json').write_text(json.dumps(arithmetic,indent=2)+'\n')
 result=json.loads((out/'TRAVERSAL_stats.json').read_text());need(not result['capped'],'Traversal incomplete');need(result['pairs']==571**2,'Missing root pairs');need(result['compatible']==49274 and result['cores']==1949,'Core count discrepancy');need(result['nodes']==177379,'Traversal count discrepancy');need(result['candidates']==0 and not (out/'TRAVERSAL_candidates.txt').read_text(),'Cancelling candidate found')
 need(result['nodes']==result['interval_reject']+result['gcd_reject']+result['expanded'],'Unaccounted nodes')
 survivors=(out/'TRAVERSAL_eval_zero.txt').read_text().splitlines();need(len(survivors)==result['eval_zero'],'Missing evaluation-zero records')
 ps=list(itertools.permutations(range(5)))
 for line in survivors:
  values=list(map(int,line.split()));a,b,last,rank,size=values[:5];ids=values[5:5+size];coeff=values[5+size:]
  need(len(coeff)==11 and len(set(ids))==size,'Bad survivor record')
  expected=[sum(polynomial(ps[i],-2)[k] for i in ids) for k in range(11)]
  need(coeff==expected and any(coeff) and sum(term(ps[i],1) for i in ids)==0,'Evaluation-zero survivor check failed')
 core_records=[list(map(int,l.split())) for l in (out/'TRAVERSAL_core_stats.txt').read_text().splitlines()]
 need(len(core_records)==1949,'Missing per-core records')
 for col,name in [(2,'nodes'),(3,'interval_reject'),(4,'gcd_reject'),(5,'expanded'),(6,'eval_zero')]:need(sum(r[col] for r in core_records)==result[name],'Per-core counter mismatch')
 report={'claim':'Every nonempty canonical n=5 complete real additive-edge-cost fiber has nonzero polynomial.','status':'Exact standalone verification passed; independent audit is a separate requirement.','sanitize':args.sanitize,'root_counts':roots['groups'],'traversal':result,'arithmetic_check':'ARITHMETIC_CHECK.json','elapsed_seconds':time.time()-start,'source_sha256':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in ['regenerate_slices.py','enumerate_flats.cpp','verify_complete.py']}}
 (out/'COMPLETE_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
