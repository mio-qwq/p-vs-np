# Canonical five-row noncancellation for arbitrary real additive edge costs

19 October 2026. New exact finite-model result. This proof and verifier do not assume the earlier binary-cost theorem, any cardinality lower bound, or the earlier endpoint-degree exclusion. Standalone verification and a separately implemented full traversal audit have passed. The independent audit regenerates every endpoint slice by Gray-code enumeration, uses lower-right incidence coordinates and a different certified prime, and directly constructs all polynomial projections. See `../affine-fiber-next-20261019/INDEPENDENT_RESULT.json`. This is AI-assisted finite mathematics, not external peer review, proof-assistant formalization, or a complexity-theoretic separation. No repository, merge, or release was changed.

## 1. Statement

For a permutation p of {0,1,2,3,4}, define

    f_p(L) = sgn(p) product_(i=0)^4 (L+i)^(p(i)).

Let G be any bipartite graph on these labelled rows and columns, let w assign arbitrary real costs to its supported edges, and let t be real. Define the **entire** cost fiber

    F = {p in PM(G): sum_i w(i,p(i)) = t}.

**Finite exact theorem.** If F is nonempty, then sum_(p in F) f_p(L) is not the zero polynomial.

Thus the noncancellation statement holds for every sparse supported complete fiber in canonical dimension five, with no restriction to binary, integer, or rational edge costs. This theorem does not concern arbitrary polynomial-zero subsets, arbitrary dimension, changed row offsets, or arbitrary coefficient weights on the matching terms.

The proof eliminates edge-cost variables entirely. It classifies possible endpoint slices, joins their affine hulls, and traverses the compatible affine-closed matching families. Sound exact scalar constraints eliminate every possible polynomial-zero completion.

## 2. Complete real fibers are precisely affine-closed subsets

Let v_p be the 25-coordinate incidence vector of p. For a nonempty subset S of the 120 permutations, write

    cl(S) = {q: v_q belongs to aff{v_p: p in S}}.

Every complete real-cost fiber F satisfies cl(F)=F. Indeed, a q in cl(F) uses only edges in union(F): each edge absent from that union has coordinate zero in every affine combination. It is therefore supported in G. Every affine combination of the v_p, p in F, has cost t. Completeness then includes q in F.

Conversely, any nonempty affine-closed S can be realized as a complete real-cost fiber even on K5,5. Fix p0 in S and let W be the span of v_p−v_p0 for p in S. For every q outside S, the functional on W-perpendicular given by w -> w·(v_q−v_p0) is nonzero. Choose w outside this finite union of proper hyperplanes in W-perpendicular. Exactly the members of S have cost w·v_p0. Rational w can be chosen because all defining vectors are rational; scaling gives integer costs if desired. The all-120 set is realized by zero costs.

Only the necessary direction is needed for exclusion. The converse identifies the exact remaining model: there is no hidden loss from dropping support and cost variables.

## 3. Exact incidence-rank arithmetic

Use the augmented vector

    h_p = (1, (v_p(i,j))_(0<=i,j<4)) in Z^17.

Row and column sums equal one, so these coordinates recover every entry of v_p. Affine closure of the incidence vectors is exactly linear span membership of the h_p.

Each h_p has at most five entries equal to one and all other entries zero. Every square m-by-m minor, m<=17, of any matrix of such rows has absolute determinant at most 5^(m/2) by Hadamard's inequality. The verifier checks

    5^17 < 1000000007^2

and independently checks that 1000000007 is prime. Thus a nonzero integer minor cannot vanish modulo this prime. Every rank and span-membership test in the verifier is exactly the corresponding rational, hence real, test.

This also validates comparisons of quotient projective directions: equality of two nonzero quotient directions is equivalent to a rank statement about a matrix of original incidence rows. No numerical tolerance or probabilistic modular assumption is used. Intermediate modular products are below 1000000007^2+1000000007, hence below signed 64-bit range.

## 4. All possible least-root slices

Suppose an affine-closed nonempty F has zero polynomial. Let

    r = min{p(0): p in F},
    S = {p in F: p(0)=r}.

The coefficient of L^r gives the necessary scalar identity

    sum_(p in S) sgn(p) product_(i=1)^4 i^(p(i)) = 0.

The slice S is affine-closed among the 24 permutations with p(0)=r. Any affine-forced matching in that 24-element set also lies in cl(F), so completeness includes it.

For each r=0,...,4, there are 12 positive and 12 negative scalar terms. `regenerate_slices.py` enumerates all 4096 subsets on each sign side, joins every pair with equal unsigned scalar sum, excludes the empty pair, and checks affine closure. Duplicate scalar sums retain all their masks. All catalogues are regenerated directly from the definitions, without reading a prior membership list.

| r | Nonempty scalar-balanced subsets | Affine-closed subsets |
|---|---:|---:|
| 0 | 13,419 | 216 |
| 1 | 1,437 | 23 |
| 2 | 1,242 | 24 |
| 3 | 3,609 | 92 |
| 4 | 13,419 | 216 |
| Total | 33,126 | 571 |

For row reversal rho(i)=4−i, sign(rho)=+1 and every term has total degree ten. Hence

    f_p(−4−L) = f_(p composed with rho)(L).

The least-column slice at row 4 therefore has the reversed membership of one of the same 571 slices. This uses only the proved reversal symmetry; no arbitrary row or column relabelling is assumed.

## 5. Pairing endpoint slices

For every ordered pair (S,T) of catalogued slices, reverse T to row 4 and form their union U. Let D contain every permutation that is forbidden by the prescribed slices: one whose row-0 or row-4 column is below its specified minimum, or one lying at either minimum but absent from that endpoint's chosen slice.

Reject if U meets D. Otherwise compute C=cl(U), and reject if C meets D. Every hypothetical zero complete fiber contains the C from its own two least-root slices and avoids its D.

Exact pair counts:

- 326,041 ordered pairs, equal to 571 squared
- 49,274 pairs with compatible memberships
- 47,325 further pairs rejected by affine closure
- 1,949 consistent closed cores

The augmented-rank distribution of the cores is:

    5:10, 6:112, 7:268, 8:408, 9:540,
    10:382, 11:178, 12:47, 13:4.

Each valid fiber has a unique pair of endpoint slices. No lower bound on its size or on endpoint support is used.

## 6. Exhaustive canonical traversal of the compatible flats

At a current closed set C, reduce every h_q modulo the span of {h_p:p in C}. Points already in C have zero residue. Partition all other points into blocks whose nonzero residues are proportional. For each block B,

    cl(C union {q}) = C union B for every q in B.

Consequently any closed extension of C either contains all of B or none of B. Discard blocks meeting D.

Permutations are ordered lexicographically, with indices 0,...,119. A traversal state also records `last`, initially −1. For each remaining block B, let i be its least index. Recurse to C union B only if i>last, then replace last by i. The next state is already closed.

This is complete: for any target closed extension F of a core, repeatedly take the least member of F minus the current C. The corresponding entire block is contained in F and has that least index. These least indices strictly increase. Thus this canonical path is present unless soundly pruned. It is unique because choosing a larger missing index first would eventually require adding a previously skipped smaller one, which is prohibited. Blocks with least index at most last cannot occur in a descendant of the current canonical branch and may be omitted from its completion constraints.

## 7. Exact scalar completion constraints

Set T=L+2 and write each polynomial in T. The verifier uses these 59 integer linear functionals on polynomials:

1. All eleven Taylor coefficients at each of T=−2,−1,0,1,2 (55 functionals). These are Taylor coefficients at original L=−4,−3,−2,−1,0.
2. Evaluation at T=−4,−3,3,4, equivalent to L=−6,−5,1,2.

For a current C and its allowed blocks B, let a be a chosen functional applied to sum_(p in C) f_p, and let b_B be the functional applied to sum_(p in B) f_p. A polynomial-zero descendant would require

    −a = sum_(B selected) b_B.

Necessary conditions are therefore

    sum_(b_B<0) b_B <= −a <= sum_(b_B>0) b_B,
    gcd{b_B} divides a whenever this gcd is nonzero.

The interval condition also handles the case where every b_B is zero. If any functional fails either condition, the entire canonical branch is rejected. These are exact integer necessary conditions, not claims that passing them suffices.

The final algorithm does not use polynomial-span relaxation, multi-prime rank tests on polynomial coefficients, numerical optimization, or a search budget. An exploratory polynomial-span check proved redundant and was removed from the final verifier.

Every visited C is itself checked for polynomial cancellation: a nonzero Q_C(1) rejects it immediately; when Q_C(1)=0, all eleven centered coefficients are computed. This never infers polynomial identity from finitely many unexplained zero evaluations.

## 8. Complete result and arithmetic checks

The complete traversal gives:

| Quantity | Count |
|---|---:|
| Consistent cores | 1,949 |
| Visited closed-set states | 177,379 |
| Quotient blocks inspected | 11,340,790 |
| Blocks excluded by forbidden endpoints | 4,690,101 |
| Blocks excluded by canonical index | 3,525,766 |
| States rejected by scalar interval | 68,234 |
| States rejected by scalar gcd | 104,574 |
| States expanded | 4,571 |
| States with Q_C(1)=0 | 48 |
| States with all eleven coefficients zero | 0 |

The state accounting is exact: 68,234+104,574+4,571=177,379. Expanded states generate 175,430 child states; adding the 1,949 roots gives 177,379. Per-core counts and all 48 first-evaluation survivors are retained.

`verify_complete.py` reconstructs all 120 centered coefficient vectors by binomial convolution, independently of the C++ repeated-factor expansion. It also constructs the 55 Taylor-coefficient vectors directly as products in the corresponding translated variable and checks the four evaluations by direct integer products. It checks every term at eleven more integer arguments and independently reconstructs all 48 Q_C(1)=0 survivor polynomials.

The individual centered coefficients have absolute value at most 368. The largest sum of absolute values across all 120 terms for any of the 59 scalar coordinates is 142,672,320. Thus all polynomial sums, subset bounds, and gcd inputs are far below signed 64-bit limits. The modular and mask arithmetic is separately bounded. The traversal uses 128-bit masks only to store 120 Boolean memberships.

The first catalogue-reuse run, fresh standalone catalogue replay, and undefined-behavior-sanitized replay agree on the exhaustive aggregate counts. Fresh final normal, optimized-Python, and sanitized runs are recorded separately. Independent review should be consulted for its distinct enumeration and traversal choices.

### Adversarial controls

`negative_controls.py` separately verifies that corrupted centered coefficients, corrupted Taylor projections, corrupted direct evaluations, a composite modulus, and a prime too small for the Hadamard bound are rejected. It also reconstructs the known eight-term polynomial-zero subset and its explicit forced affine outsider 02143. The claimed eight-member fiber is rejected: its union-support constant-cost fiber contains twelve matchings and has a nonzero polynomial. The full 120-member constant-cost fiber independently gives the constant 288. Normal and optimized-Python control receipts are byte-identical.

The final primary, fully optimized-Python, and sanitized replay evidence is byte-identical for all deterministic catalogue, traversal, polynomial, projection, and survivor files. Root review separately read the proof and final source and regenerated the full result successfully. `ACCEPTED_MANIFEST.json` records the final allowlist and independent audit receipts; obsolete exploratory sources and binaries are expressly excluded.

## 9. Reproduction and recovery

From this directory:

    python verify_complete.py --output NEW_REPLAY_DIRECTORY
    PYTHONOPTIMIZE=1 python -O verify_complete.py --output NEW_OPTIMIZED_DIRECTORY
    python verify_complete.py --sanitize --output NEW_SANITIZED_DIRECTORY
    python negative_controls.py --replay NEW_REPLAY_DIRECTORY --output NEW_CONTROLS.json

The verifier uses standard-library Python and a C++17 compiler with its 128-bit integer extension. It regenerates all slices, compiles the traversal, exhausts all endpoint pairs and every unpruned canonical branch, verifies arithmetic independently, and writes COMPLETE_RESULT.json. Validation uses explicit exceptions, not removable Python assertions. No prior research file, saved slice list, remote repository, or external solver is needed.

Suspend the full exclusion claim if an independent implementation finds a missing balanced affine-closed slice, a mismatched core closure, an omitted canonical extension, an invalid quotient class, a false scalar interval/gcd rejection, an arithmetic mismatch, or a polynomial-zero visited state. Preserve both endpoint memberships, the current full 120-point membership mask, `last`, the exact allowed quotient blocks, the disputed scalar coordinate and its values, all eleven polynomial coefficients, and the relevant branch path. A zero subset without affine closure is not a complete real fiber; a zero at Q(1) alone is not polynomial cancellation.

This closes the canonical sparse n=5 real-cost boundary only. It supplies no unrestricted P-versus-NP result, no arbitrary-dimension isolation theorem, and no authorization to merge or publish research.
