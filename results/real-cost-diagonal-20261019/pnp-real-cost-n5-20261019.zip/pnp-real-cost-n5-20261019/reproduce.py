#!/usr/bin/env python3
"""Verify the frozen payload and replay both complete independent implementations."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def verify_tree(root=ROOT):
    expected = {}
    for line in (root / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        require(len(digest) == 64 and all(c in '0123456789abcdef' for c in digest), 'Malformed digest')
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts, 'Unsafe manifest path')
        require(name not in expected, 'Duplicate manifest path')
        expected[name] = digest
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p != root / 'SHA256SUMS'}
    require(actual == set(expected), 'Payload file list differs from SHA256SUMS')
    for name, digest in expected.items():
        path = root / name
        require(not path.is_symlink(), 'Payload symlink is not allowed')
        require(hashlib.sha256(path.read_bytes()).hexdigest() == digest, 'Payload hash mismatch: ' + name)
    return {'files_verified': len(expected), 'payload_sha256sums': hashlib.sha256((root / 'SHA256SUMS').read_bytes()).hexdigest()}


def catalogue(path, independent):
    rows = path.read_text().splitlines()
    require(rows[0] == '571' and len(rows) == 572, 'Wrong catalogue size')
    result = []
    for row in rows[1:]:
        v = list(map(int, row.split()))
        minimum, size, ids = (v[0], v[2], v[3:]) if independent else (v[0], v[1], v[2:])
        require(size == len(ids) == len(set(ids)), 'Malformed root membership')
        result.append((minimum, tuple(sorted(ids))))
    require(len(set(result)) == 571, 'Duplicate roots')
    return result


def cores(path, roots):
    result = {}
    for line in path.read_text().splitlines():
        a, b, rank, *ids = map(int, line.split())
        key = (roots[a], roots[b])
        require(key not in result, 'Duplicate core pair')
        result[key] = (rank, tuple(sorted(ids)))
    require(len(result) == 1949, 'Wrong complete core count')
    return result


def crosscheck(primary, independent):
    p = json.loads((primary / 'COMPLETE_RESULT.json').read_text())['traversal']
    i = json.loads((independent / 'INDEPENDENT_RESULT.json').read_text())
    comparisons = [
        ('pairs', 'all_pairs', 326041),
        ('compatible', 'membership_compatible', 49274),
        ('cores', 'cores', 1949),
        ('nodes', 'nodes', 177379),
        ('extensions', 'quotient_blocks', 11340790),
        ('forbidden_reject', 'forbidden_blocks', 4690101),
        ('canonical_reject', 'canonical_blocks', 3525766),
        ('candidates', 'zero_candidates', 0),
    ]
    for left, right, value in comparisons:
        require(p[left] == i[right] == value, 'Traversal mismatch: ' + left)
    require(p['capped'] is False and i['search_cap'] is None, 'Incomplete traversal')
    require(p['node_ranks'] == i['node_ranks'], 'Visited rank distribution mismatch')
    require(p['interval_reject'] + p['gcd_reject'] == i['interval_pruned'] + i['gcd_pruned'] == 172808, 'Pruned node count mismatch')
    pr = catalogue(primary / 'slices.txt', False)
    ir = catalogue(independent / 'ALL_GRAY_SLICES.txt', True)
    require(set(pr) == set(ir), 'Root membership mismatch')
    require(cores(primary / 'TRAVERSAL_cores.txt', pr) == cores(independent / 'AUDIT_cores.txt', ir), 'Core membership mismatch')
    return {'status': 'passed', 'root_memberships_equal': 571, 'core_memberships_and_ranks_equal': 1949, 'visited_states_each': 177379, 'zero_candidates_each': 0, 'rank_distributions_equal': True, 'no_search_cap': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--sanitize', action='store_true')
    parser.add_argument('--optimized', action='store_true')
    args = parser.parse_args()
    integrity = verify_tree()
    output = args.output.resolve()
    require(not output.is_relative_to(ROOT), 'Output must be outside the frozen payload')
    require(not output.exists(), 'Refusing to reuse existing output directory')
    output.mkdir(parents=True)
    python = [sys.executable] + (['-O'] if args.optimized else [])
    for dirname, script, subdir in [('real-cost-fiber-next-20261019', 'verify_complete.py', 'primary'), ('affine-fiber-next-20261019', 'verify_independent.py', 'independent')]:
        command = python + [str(ROOT / dirname / script), '--output', str(output / subdir)]
        if args.sanitize:
            command += ['--sanitize']
        with (output / (subdir + '.log')).open('w') as log:
            subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
    report = crosscheck(output / 'primary', output / 'independent')
    report['integrity'] = integrity
    report['sanitize'] = args.sanitize
    report['optimized_python'] = args.optimized
    (output / 'PACKAGE_REPLAY.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
